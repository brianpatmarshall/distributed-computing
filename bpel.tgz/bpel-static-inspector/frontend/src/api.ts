import type {
  BrowseResponse,
  Neo4jConfig,
  Neo4jConnectionStatus,
  Neo4jQueryResult,
  Neo4jSyncSummary,
  ProjectAnalysisResult,
} from './types';

async function jsonRequest<T>(url: string, options?: RequestInit): Promise<T> {
  const resp = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const text = await resp.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(`Invalid JSON from ${url}: ${text.slice(0, 200)}`);
  }
  if (!resp.ok) {
    const errMsg =
      data && typeof data === 'object' && 'error' in data
        ? String((data as { error: unknown }).error)
        : `HTTP ${resp.status}`;
    throw new Error(errMsg);
  }
  return data as T;
}

export function fetchHealth(): Promise<{ status: string; neo4jBrowserUpstream: string; cwd: string }> {
  return jsonRequest('/api/health');
}

export function analyzeProject(projectPath: string): Promise<ProjectAnalysisResult> {
  return jsonRequest('/api/analyze', {
    method: 'POST',
    body: JSON.stringify({ projectPath }),
  });
}

export function browseDirectory(path?: string): Promise<BrowseResponse> {
  const qs = path ? `?path=${encodeURIComponent(path)}` : '';
  return jsonRequest(`/api/fs/browse${qs}`);
}

export function testNeo4jConnection(neo4j: Neo4jConfig): Promise<Neo4jConnectionStatus> {
  return jsonRequest('/api/neo4j/test', {
    method: 'POST',
    body: JSON.stringify({
      uri: neo4j.uri,
      username: neo4j.username,
      password: neo4j.password,
      database: neo4j.database,
    }),
  });
}

export function syncToNeo4j(
  projectPath: string,
  neo4j: Neo4jConfig
): Promise<Neo4jSyncSummary> {
  return jsonRequest('/api/neo4j/sync', {
    method: 'POST',
    body: JSON.stringify({
      projectPath,
      clearExisting: neo4j.clearOnSync,
      includeComponents: neo4j.includeComponents,
      neo4j: {
        uri: neo4j.uri,
        username: neo4j.username,
        password: neo4j.password,
        database: neo4j.database,
      },
    }),
  });
}

export function expandBpelInNeo4j(
  bpelPath: string,
  neo4j: Neo4jConfig
): Promise<Neo4jQueryResult> {
  return jsonRequest('/api/neo4j/expand-bpel', {
    method: 'POST',
    body: JSON.stringify({
      bpelPath,
      neo4j: {
        uri: neo4j.uri,
        username: neo4j.username,
        password: neo4j.password,
        database: neo4j.database,
      },
    }),
  });
}

export function runNeo4jQuery(
  cypher: string,
  neo4j: Neo4jConfig
): Promise<Neo4jQueryResult> {
  return jsonRequest('/api/neo4j/query', {
    method: 'POST',
    body: JSON.stringify({
      cypher,
      neo4j: {
        uri: neo4j.uri,
        username: neo4j.username,
        password: neo4j.password,
        database: neo4j.database,
      },
    }),
  });
}
