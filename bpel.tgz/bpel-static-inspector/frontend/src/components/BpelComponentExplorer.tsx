import { useEffect, useMemo, useRef, useState } from 'react';
import {
  BookOpen,
  ChevronDown,
  ChevronRight,
  Database,
  Maximize2,
  Minimize2,
  RotateCcw,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { expandBpelInNeo4j } from '../api';
import type {
  ComponentNode,
  GraphData,
  GraphEdge,
  GraphNode,
  Neo4jConfig,
  ProcessAuditReport,
} from '../types';
import { CategoryBadge } from './SubProjectExplorer';

interface BpelComponentExplorerProps {
  reports: ProcessAuditReport[];
  projectGraph: GraphData;
  selectedBpelPath: string | null;
  selectedNodeId: string | null;
  neo4jConfig: Neo4jConfig;
  neo4jConnected: boolean;
  onSelectNode: (node: GraphNode, contextGraph: GraphData) => void;
  onSelectBpelPath: (bpelPath: string) => void;
}

const CONTAINER_KINDS = new Set(['SCOPE', 'FLOW', 'IF', 'PICK', 'LOOP']);

interface NodeStyle {
  fill: string;
  stroke: string;
  text: string;
  short: string;
  r: number;
}

function getComponentStyle(label: string, kind: string): NodeStyle {
  if (label === 'BpelFile') {
    return { fill: '#facc15', stroke: '#fef08a', text: '#052e16', short: 'BPEL', r: 26 };
  }
  if (label === 'BpelPartnerLink') {
    return { fill: '#d97706', stroke: '#fde047', text: '#ffffff', short: 'PL', r: 17 };
  }
  if (label === 'BpelVariable') {
    return { fill: '#0f766e', stroke: '#99f6e4', text: '#ffffff', short: 'VAR', r: 16 };
  }
  if (label === 'BpelCorrelationSet') {
    return { fill: '#65a30d', stroke: '#d9f99d', text: '#ffffff', short: 'CORR', r: 16 };
  }
  switch (kind) {
    case 'RECEIVE':
      return { fill: '#009A49', stroke: '#facc15', text: '#ffffff', short: 'RECV', r: 20 };
    case 'REPLY':
      return { fill: '#16a34a', stroke: '#fde047', text: '#ffffff', short: 'RPLY', r: 20 };
    case 'INVOKE':
      return { fill: '#15803d', stroke: '#facc15', text: '#fef9c3', short: 'INV', r: 20 };
    case 'ASSIGN':
      return { fill: '#0d9488', stroke: '#5eead4', text: '#ffffff', short: 'ASGN', r: 17 };
    case 'IF':
      return { fill: '#ca8a04', stroke: '#fef08a', text: '#052e16', short: 'IF', r: 19 };
    case 'FLOW':
      return { fill: '#eab308', stroke: '#fef9c3', text: '#052e16', short: 'FLOW', r: 20 };
    case 'LOOP':
      return { fill: '#a16207', stroke: '#fde047', text: '#ffffff', short: 'LOOP', r: 19 };
    case 'SCOPE':
      return { fill: '#047857', stroke: '#facc15', text: '#fef08a', short: 'SCPE', r: 21 };
    case 'PICK':
      return { fill: '#b45309', stroke: '#fde047', text: '#ffffff', short: 'PICK', r: 19 };
    case 'WAIT':
    case 'THROW':
    case 'COMPENSATE':
      return { fill: '#e11d48', stroke: '#fda4af', text: '#ffffff', short: kind.slice(0, 4), r: 19 };
    case 'SEQUENCE':
      return { fill: '#166534', stroke: '#86efac', text: '#ecfdf5', short: 'SEQ', r: 17 };
    default:
      return { fill: '#166534', stroke: '#86efac', text: '#ffffff', short: 'ACT', r: 17 };
  }
}

export function BpelComponentExplorer({
  reports,
  projectGraph,
  selectedBpelPath,
  selectedNodeId,
  neo4jConfig,
  neo4jConnected,
  onSelectNode,
  onSelectBpelPath,
}: BpelComponentExplorerProps) {
  const [expandedBpels, setExpandedBpels] = useState<Set<string>>(() =>
    selectedBpelPath ? new Set([selectedBpelPath]) : new Set()
  );
  const [collapsedContainers, setCollapsedContainers] = useState<Set<string>>(new Set());
  const [focusedBpelPath, setFocusedBpelPath] = useState<string | null>(selectedBpelPath);

  // Filter toggles (Option 1 defaults: hide <assign> and <sequence> wrappers for clean view)
  const [showAssign, setShowAssign] = useState(false);
  const [showSequence, setShowSequence] = useState(false);
  const [showPartnerLinks, setShowPartnerLinks] = useState(true);
  const [showVariables, setShowVariables] = useState(true);

  // Optional live Neo4j expansion cache per bpelPath
  const [neo4jExpandedInfo, setNeo4jExpandedInfo] = useState<Record<string, { nodes: number; ms: number }>>({});
  const [expandingPath, setExpandingPath] = useState<string | null>(null);

  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragOverrides, setDragOverrides] = useState<Record<string, { x: number; y: number }>>({});

  const draggingNodeRef = useRef<{ id: string; startX: number; startY: number; origX: number; origY: number } | null>(null);
  const panningRef = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(null);

  // Sync focused BPEL when user clicks one in the left sidebar
  useEffect(() => {
    if (selectedBpelPath) {
      setFocusedBpelPath(selectedBpelPath);
    }
  }, [selectedBpelPath]);

  const toggleBpelExpand = async (bpelPath: string) => {
    setFocusedBpelPath(bpelPath);
    onSelectBpelPath(bpelPath);

    const willExpand = !expandedBpels.has(bpelPath);
    setExpandedBpels((prev) => {
      const next = new Set(prev);
      if (willExpand) next.add(bpelPath);
      else next.delete(bpelPath);
      return next;
    });

    if (willExpand && neo4jConnected && !neo4jExpandedInfo[bpelPath]) {
      setExpandingPath(bpelPath);
      try {
        const res = await expandBpelInNeo4j(bpelPath, neo4jConfig);
        if (res.nodes.length > 0) {
          setNeo4jExpandedInfo((prev) => ({
            ...prev,
            [bpelPath]: { nodes: res.nodes.length, ms: res.executionMs },
          }));
        }
      } catch {
        // Gracefully fall back to local AST components
      } finally {
        setExpandingPath(null);
      }
    }
  };

  const toggleContainer = (activityId: string) => {
    setCollapsedContainers((prev) => {
      const next = new Set(prev);
      if (next.has(activityId)) next.delete(activityId);
      else next.add(activityId);
      return next;
    });
  };

  // Build visible GraphData + deterministic cluster layout
  const { visibleGraph, basePositions, containerHasChildren } = useMemo(() => {
    const nodes: GraphNode[] = [];
    const edges: GraphEdge[] = [];
    const positions: Record<string, { x: number; y: number }> = {};
    const hasChildrenMap: Record<string, boolean> = {};

    let currentClusterTop = 55;

    for (const report of reports) {
      const bpelPath = report.relativeSourcePath;
      const bpelNodeId = `bpel:${bpelPath}`;
      const isExpanded = expandedBpels.has(bpelPath);
      const fileName = bpelPath.split('/').pop() ?? bpelPath;

      nodes.push({
        id: bpelNodeId,
        label: 'BpelFile',
        name: fileName,
        subProject: bpelPath.includes('/') ? bpelPath.slice(0, bpelPath.lastIndexOf('/')) : '.',
        properties: {
          path: bpelPath,
          processName: report.processName,
          category: report.category,
          deployedInMemory: report.deployedInMemory,
          expanded: isExpanded,
        },
      });

      if (!isExpanded || !report.components) {
        positions[bpelNodeId] = { x: 110, y: currentClusterTop + 20 };
        currentClusterTop += 96;
        continue;
      }

      const comp = report.components;
      const compNodeById = new Map<string, ComponentNode>(comp.nodes.map((n) => [n.id, n]));

      // Track children per activity for container collapse and sequence unwrapping
      const childrenByParent = new Map<string, ComponentNode[]>();
      for (const cn of comp.nodes) {
        if (cn.label === 'BpelActivity' && cn.parentActivityId) {
          const list = childrenByParent.get(cn.parentActivityId) ?? [];
          list.push(cn);
          childrenByParent.set(cn.parentActivityId, list);
          hasChildrenMap[cn.parentActivityId] = true;
        }
      }

      // Determine hidden activities due to collapsed containers or filter toggles
      const hiddenDueToCollapse = new Set<string>();
      const markSubtreeHidden = (actId: string) => {
        for (const child of childrenByParent.get(actId) ?? []) {
          hiddenDueToCollapse.add(child.id);
          markSubtreeHidden(child.id);
        }
      };
      for (const actId of collapsedContainers) {
        markSubtreeHidden(actId);
      }

      const isVisibleComponent = (cn: ComponentNode): boolean => {
        if (cn.label === 'BpelPartnerLink') return showPartnerLinks;
        if (cn.label === 'BpelVariable') return showVariables;
        if (cn.label === 'BpelCorrelationSet') return true;
        if (hiddenDueToCollapse.has(cn.id)) return false;
        if (cn.kind === 'ASSIGN' && !showAssign) return false;
        if (cn.kind === 'SEQUENCE' && !showSequence) return false;
        if (cn.kind === 'EMPTY') return false;
        return true;
      };

      const visibleCompNodes = comp.nodes.filter(isVisibleComponent);
      const visibleIds = new Set<string>([bpelNodeId, ...visibleCompNodes.map((n) => n.id)]);

      // Compute effective parent for visible activities when <sequence> wrappers are hidden
      const resolveEffectiveParent = (cn: ComponentNode): string => {
        let cur = cn.parentActivityId;
        while (cur) {
          if (visibleIds.has(cur)) return cur;
          cur = compNodeById.get(cur)?.parentActivityId ?? null;
        }
        return bpelNodeId;
      };

      // Organize columns within this BPEL cluster:
      // Col 0: BpelFile
      // Col 1: Activities (depth-indented horizontally)
      // Col right: PartnerLinks & Variables
      const activities = visibleCompNodes.filter((n) => n.label === 'BpelActivity');
      const partnerLinks = visibleCompNodes.filter((n) => n.label === 'BpelPartnerLink');
      const variables = visibleCompNodes.filter(
        (n) => n.label === 'BpelVariable' || n.label === 'BpelCorrelationSet'
      );

      // Compute depth of each visible activity for clean tree layout
      const depthMap = new Map<string, number>();
      const getDepth = (cn: ComponentNode): number => {
        if (depthMap.has(cn.id)) return depthMap.get(cn.id)!;
        const p = resolveEffectiveParent(cn);
        const d = p === bpelNodeId ? 1 : getDepth(compNodeById.get(p)!) + 1;
        depthMap.set(cn.id, d);
        return d;
      };
      activities.forEach(getDepth);
      const maxDepth = Math.max(1, ...Array.from(depthMap.values()));

      const rowCount = Math.max(activities.length, partnerLinks.length + variables.length, 2);
      const rowStep = 76;
      const clusterHeight = Math.max(170, rowCount * rowStep);

      positions[bpelNodeId] = { x: 105, y: currentClusterTop + clusterHeight / 2 };

      activities.forEach((act, idx) => {
        const d = depthMap.get(act.id) ?? 1;
        positions[act.id] = {
          x: 115 + d * 170,
          y: currentClusterTop + 34 + idx * rowStep,
        };
      });

      const sideX = 115 + (maxDepth + 1) * 185;
      const sideNodes = [...partnerLinks, ...variables];
      sideNodes.forEach((sn, idx) => {
        positions[sn.id] = {
          x: sideX,
          y: currentClusterTop + 34 + idx * 72,
        };
      });

      // Add component nodes
      for (const cn of visibleCompNodes) {
        nodes.push({
          id: cn.id,
          label: cn.label,
          name: cn.name,
          subProject: report.processName,
          properties: {
            ...cn.properties,
            kind: cn.kind,
          },
        });
      }

      // Add edges (bridging across hidden SEQUENCE / ASSIGN nodes cleanly)
      const edgeIds = new Set<string>();
      const pushEdge = (source: string, target: string, type: string, properties: Record<string, unknown> = {}) => {
        if (source === target || !visibleIds.has(source) || !visibleIds.has(target)) return;
        const id = `${source}->${type}->${target}`;
        if (edgeIds.has(id)) return;
        edgeIds.add(id);
        edges.push({ id, source, target, type, properties });
      };

      // Direct declaration edges
      for (const cn of sideNodes) {
        const relType =
          cn.label === 'BpelPartnerLink'
            ? 'HAS_PARTNER_LINK'
            : cn.label === 'BpelVariable'
            ? 'HAS_VARIABLE'
            : 'HAS_CORRELATION_SET';
        pushEdge(bpelNodeId, cn.id, relType);
      }

      // Structural containment edges for visible activities
      for (const act of activities) {
        const parent = resolveEffectiveParent(act);
        pushEdge(parent, act.id, parent === bpelNodeId ? 'HAS_ACTIVITY' : 'CONTAINS');
      }

      // Bridge NEXT edges across hidden ASSIGN nodes
      const nextMap = new Map<string, string>();
      for (const ce of comp.edges) {
        if (ce.type === 'NEXT') {
          nextMap.set(ce.source, ce.target);
        }
      }
      for (const ce of comp.edges) {
        if (ce.type === 'NEXT' && visibleIds.has(ce.source)) {
          let target: string | undefined = ce.target;
          let guard = 0;
          while (target && !visibleIds.has(target) && guard < 20) {
            target = nextMap.get(target);
            guard++;
          }
          if (target && visibleIds.has(target)) {
            pushEdge(ce.source, target, 'NEXT');
          }
        } else if (
          ce.type === 'USES_PARTNER_LINK' ||
          ce.type === 'READS_VARIABLE' ||
          ce.type === 'WRITES_VARIABLE'
        ) {
          pushEdge(ce.source, ce.target, ce.type, ce.properties);
        }
      }

      currentClusterTop += clusterHeight + 65;
    }

    // Add cross-process INVOKES_PROCESS edges between BPEL file nodes
    const visibleNodeIds = new Set(nodes.map((n) => n.id));
    for (const e of projectGraph.edges) {
      if (e.type === 'INVOKES_PROCESS' && visibleNodeIds.has(e.source) && visibleNodeIds.has(e.target)) {
        edges.push(e);
      }
    }

    return {
      visibleGraph: { nodes, edges },
      basePositions: positions,
      containerHasChildren: hasChildrenMap,
    };
  }, [
    reports,
    projectGraph.edges,
    expandedBpels,
    collapsedContainers,
    showAssign,
    showSequence,
    showPartnerLinks,
    showVariables,
  ]);

  const getPos = (id: string) => dragOverrides[id] ?? basePositions[id] ?? { x: 100, y: 100 };

  const focusedReport = useMemo(() => {
    if (focusedBpelPath) {
      const found = reports.find((r) => r.relativeSourcePath === focusedBpelPath);
      if (found) return found;
    }
    const firstExpanded = Array.from(expandedBpels)[0];
    if (firstExpanded) {
      return reports.find((r) => r.relativeSourcePath === firstExpanded) ?? reports[0] ?? null;
    }
    return reports[0] ?? null;
  }, [reports, focusedBpelPath, expandedBpels]);

  const handleSvgMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (draggingNodeRef.current) {
      const { id, startX, startY, origX, origY } = draggingNodeRef.current;
      const dx = (e.clientX - startX) / zoom;
      const dy = (e.clientY - startY) / zoom;
      setDragOverrides((prev) => ({
        ...prev,
        [id]: { x: origX + dx, y: origY + dy },
      }));
    } else if (panningRef.current) {
      const { startX, startY, origX, origY } = panningRef.current;
      setPan({ x: origX + (e.clientX - startX), y: origY + (e.clientY - startY) });
    }
  };

  const handleSvgMouseUp = () => {
    draggingNodeRef.current = null;
    panningRef.current = null;
  };

  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.1 : 0.9;
    setZoom((z) => Math.max(0.35, Math.min(2.5, Number((z * factor).toFixed(2)))));
  };

  return (
    <div className="flex-1 flex flex-col p-4 gap-3 min-h-0 overflow-hidden">
      {/* Top Toolbar */}
      <div className="bg-[#083c26] border border-[#166544] rounded-xl px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-semibold text-[#fde047]">Click any BPEL node to expand:</span>
          <label className="inline-flex items-center gap-1 cursor-pointer">
            <input
              type="checkbox"
              checked={showAssign}
              onChange={(e) => setShowAssign(e.target.checked)}
              className="accent-[#facc15]"
            />
            <span>&lt;assign&gt;</span>
          </label>
          <label className="inline-flex items-center gap-1 cursor-pointer">
            <input
              type="checkbox"
              checked={showSequence}
              onChange={(e) => setShowSequence(e.target.checked)}
              className="accent-[#facc15]"
            />
            <span>&lt;sequence&gt;</span>
          </label>
          <label className="inline-flex items-center gap-1 cursor-pointer">
            <input
              type="checkbox"
              checked={showPartnerLinks}
              onChange={(e) => setShowPartnerLinks(e.target.checked)}
              className="accent-[#facc15]"
            />
            <span>PartnerLinks</span>
          </label>
          <label className="inline-flex items-center gap-1 cursor-pointer">
            <input
              type="checkbox"
              checked={showVariables}
              onChange={(e) => setShowVariables(e.target.checked)}
              className="accent-[#facc15]"
            />
            <span>Variables</span>
          </label>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setExpandedBpels(new Set(reports.map((r) => r.relativeSourcePath)))}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0c4d31] hover:bg-[#11613f] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
          >
            <Maximize2 className="w-3 h-3" /> Expand All
          </button>
          <button
            type="button"
            onClick={() => {
              setExpandedBpels(new Set());
              setCollapsedContainers(new Set());
            }}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0c4d31] hover:bg-[#11613f] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
          >
            <Minimize2 className="w-3 h-3" /> Collapse All
          </button>
        </div>
      </div>

      {/* Top Split: Expandable BPEL Component Graph */}
      <div className="flex-[1.2] bg-[#031d12] border border-[#166544] rounded-xl relative overflow-hidden min-h-[260px] shadow-inner">
        {reports.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-xs text-[#a7f3d0]/80 gap-1.5">
            <div className="text-sm font-semibold text-[#fde047]">No BPEL files loaded</div>
            <p>Analyze a Java BPEL project above to inspect and expand BPEL components here.</p>
          </div>
        ) : (
          <svg
            className="w-full h-full block select-none cursor-grab active:cursor-grabbing"
            onMouseDown={(e) => {
              if ((e.target as Element).closest('[data-comp-node]')) return;
              panningRef.current = {
                startX: e.clientX,
                startY: e.clientY,
                origX: pan.x,
                origY: pan.y,
              };
            }}
            onMouseMove={handleSvgMouseMove}
            onMouseUp={handleSvgMouseUp}
            onMouseLeave={handleSvgMouseUp}
            onWheel={handleWheel}
          >
            <defs>
              <pattern id="compGrid" width="28" height="28" patternUnits="userSpaceOnUse">
                <circle cx="1" cy="1" r="1" fill="#145338" opacity="0.6" />
              </pattern>
              <marker id="comp-arrow-green" viewBox="0 0 10 10" refX="24" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#4ade80" />
              </marker>
              <marker id="comp-arrow-yellow" viewBox="0 0 10 10" refX="26" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#facc15" />
              </marker>
            </defs>

            <rect width="100%" height="100%" fill="url(#compGrid)" />

            <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
              {/* Edges */}
              {visibleGraph.edges.map((edge) => {
                const a = getPos(edge.source);
                const b = getPos(edge.target);
                const isNext = edge.type === 'NEXT';
                const isCross = edge.type === 'INVOKES_PROCESS';
                const isHighlighted = edge.source === selectedNodeId || edge.target === selectedNodeId;
                const stroke = isNext || isCross || isHighlighted ? '#facc15' : '#4ade80';
                const opacity = isNext || isCross || isHighlighted ? 0.92 : 0.35;
                const width = isNext || isCross ? 2.4 : isHighlighted ? 2.2 : 1.25;
                const mx = (a.x + b.x) / 2;
                const my = (a.y + b.y) / 2 - 5;

                return (
                  <g key={edge.id}>
                    <line
                      x1={a.x}
                      y1={a.y}
                      x2={b.x}
                      y2={b.y}
                      stroke={stroke}
                      strokeWidth={width}
                      strokeOpacity={opacity}
                      strokeDasharray={isCross ? '6,3' : edge.type === 'READS_VARIABLE' || edge.type === 'WRITES_VARIABLE' ? '3,3' : undefined}
                      markerEnd={isNext || isCross || isHighlighted ? 'url(#comp-arrow-yellow)' : 'url(#comp-arrow-green)'}
                    />
                    {(isHighlighted || isNext || isCross) && (
                      <text x={mx} y={my} textAnchor="middle" fill="#fef08a" fontSize="12" fontWeight="500">
                        {edge.type}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Nodes */}
              {visibleGraph.nodes.map((node) => {
                const pos = getPos(node.id);
                const kind = typeof node.properties.kind === 'string' ? node.properties.kind : '';
                const style = getComponentStyle(node.label, kind);
                const selected = node.id === selectedNodeId;
                const isBpel = node.label === 'BpelFile';
                const bpelPath = isBpel && typeof node.properties.path === 'string' ? node.properties.path : '';
                const isExpanded = isBpel && expandedBpels.has(bpelPath);
                const isCollapsibleContainer =
                  node.label === 'BpelActivity' && CONTAINER_KINDS.has(kind) && containerHasChildren[node.id];
                const isContainerCollapsed = isCollapsibleContainer && collapsedContainers.has(node.id);

                return (
                  <g
                    key={node.id}
                    data-comp-node={node.id}
                    transform={`translate(${pos.x}, ${pos.y})`}
                    className="cursor-pointer"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      draggingNodeRef.current = {
                        id: node.id,
                        startX: e.clientX,
                        startY: e.clientY,
                        origX: pos.x,
                        origY: pos.y,
                      };
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      if (isBpel && bpelPath) {
                        void toggleBpelExpand(bpelPath);
                      }
                      onSelectNode(node, visibleGraph);
                    }}
                    onDoubleClick={(e) => {
                      e.stopPropagation();
                      if (isCollapsibleContainer) {
                        toggleContainer(node.id);
                      }
                    }}
                  >
                    {selected && (
                      <circle r={style.r + 7} fill="none" stroke="#facc15" strokeWidth="2.5" strokeOpacity="0.9" />
                    )}
                    <circle
                      r={style.r}
                      fill={style.fill}
                      stroke={selected ? '#fef9c3' : style.stroke}
                      strokeWidth={selected ? 3 : 2}
                    />
                    <text y="4" textAnchor="middle" fill={style.text} fontSize="12" fontWeight="700">
                      {style.short}
                    </text>

                    {/* Expand / Collapse Badge on BPEL or Composite Containers */}
                    {(isBpel || isCollapsibleContainer) && (
                      <g
                        transform={`translate(${style.r - 4}, ${-style.r + 4})`}
                        onClick={(e) => {
                          if (isCollapsibleContainer) {
                            e.stopPropagation();
                            toggleContainer(node.id);
                          }
                        }}
                      >
                        <circle r="9" fill="#042416" stroke="#facc15" strokeWidth="1.5" />
                        <text y="4" textAnchor="middle" fill="#fde047" fontSize="12" fontWeight="700">
                          {isBpel ? (isExpanded ? '−' : '+') : isContainerCollapsed ? '+' : '−'}
                        </text>
                      </g>
                    )}

                    <text
                      y={style.r + 16}
                      textAnchor="middle"
                      fill={selected || isExpanded ? '#fde047' : '#ecfdf5'}
                      fontSize="12"
                      fontWeight={selected || isBpel ? '700' : '500'}
                    >
                      {node.name}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>
        )}

        {/* Top-Right Zoom Controls */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          {expandingPath && (
            <span className="px-2 py-1 rounded-lg bg-[#facc15] text-[#052e16] text-xs font-semibold">
              Querying Neo4j...
            </span>
          )}
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2.5, Number((z * 1.15).toFixed(2))))}
            className="p-1.5 rounded-lg bg-[#063320]/95 border border-[#1b6e4a] text-[#fde047] hover:border-[#facc15] cursor-pointer"
            title="Zoom in"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.35, Number((z / 1.15).toFixed(2))))}
            className="p-1.5 rounded-lg bg-[#063320]/95 border border-[#1b6e4a] text-[#fde047] hover:border-[#facc15] cursor-pointer"
            title="Zoom out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              setZoom(1);
              setPan({ x: 0, y: 0 });
              setDragOverrides({});
            }}
            className="p-1.5 rounded-lg bg-[#063320]/95 border border-[#1b6e4a] text-[#fde047] hover:border-[#facc15] cursor-pointer"
            title="Reset layout & zoom"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom-Left Legend */}
        <div className="absolute bottom-2.5 left-3 bg-[#063320]/95 border border-[#1b6e4a] rounded-lg px-2.5 py-1 flex flex-wrap items-center gap-3 text-xs text-[#ecfdf5]">
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#facc15]" /> BPEL</span>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#009A49]" /> Messaging</span>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#ca8a04]" /> Control</span>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#d97706]" /> PartnerLink</span>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#0f766e]" /> Variable</span>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-rose-600" /> Wait/Fault</span>
        </div>
      </div>

      {/* Bottom Split Panel: Plain-English BPEL Explanation */}
      <div className="flex-1 bg-[#083c26] border border-[#166544] rounded-xl flex flex-col min-h-[210px] overflow-hidden">
        <div className="px-4 py-2.5 bg-[#063320] border-b border-[#145338] flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#facc15]" />
            <span className="font-semibold text-xs text-[#fde047]">
              BPEL Explanation{focusedReport ? ` — ${focusedReport.processName}` : ''}
            </span>
            {focusedReport && <CategoryBadge category={focusedReport.category} />}
            {focusedReport && neo4jExpandedInfo[focusedReport.relativeSourcePath] && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#0c4d31] border border-[#facc15]/40 text-xs text-[#fef08a]">
                <Database className="w-3 h-3 text-[#facc15]" />
                Neo4j Verified ({neo4jExpandedInfo[focusedReport.relativeSourcePath].ms}ms)
              </span>
            )}
          </div>

          {/* Quick switcher pills when multiple BPELs are expanded */}
          {expandedBpels.size > 1 && (
            <div className="flex flex-wrap items-center gap-1 text-xs">
              {Array.from(expandedBpels).map((path) => {
                const r = reports.find((x) => x.relativeSourcePath === path);
                if (!r) return null;
                const active = focusedReport?.relativeSourcePath === path;
                return (
                  <button
                    key={path}
                    type="button"
                    onClick={() => setFocusedBpelPath(path)}
                    className={
                      active
                        ? 'px-2 py-0.5 rounded bg-[#facc15] text-[#052e16] font-semibold cursor-pointer'
                        : 'px-2 py-0.5 rounded bg-[#0c4d31] text-[#fef08a] border border-[#1e7a52] cursor-pointer'
                    }
                  >
                    {r.processName}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {!focusedReport || !focusedReport.components ? (
          <div className="p-4 text-xs text-[#a7f3d0]/75">
            Click any yellow <strong className="text-[#fde047]">BPEL</strong> node above to expand its components and read a step-by-step explanation.
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
            {/* Overview */}
            <div className="bg-[#042014] border border-[#166544] rounded-lg p-3 space-y-1.5">
              <p className="text-[#ecfdf5] leading-relaxed">{focusedReport.components.explanation.summary}</p>
              <div className="text-[#a7f3d0]/85">
                <strong className="text-[#fde047]">Trigger:</strong> {focusedReport.components.explanation.triggerDescription}
              </div>
              <div className="text-[#a7f3d0]/85">
                <strong className="text-[#4ade80]">Deployment:</strong> {focusedReport.components.explanation.deploymentSummary}
              </div>
            </div>

            {/* Interactive Step-by-Step Walkthrough */}
            <div className="space-y-1.5">
              <div className="font-semibold text-white">
                Step-by-Step Walkthrough ({focusedReport.components.explanation.steps.length} steps — click a step to highlight its node)
              </div>
              <div className="space-y-1">
                {focusedReport.components.explanation.steps.map((step) => {
                  const isActiveStep = selectedNodeId === step.activityId;
                  return (
                    <button
                      key={step.activityId + '-' + step.stepNumber}
                      type="button"
                      onClick={() => {
                        if (!expandedBpels.has(focusedReport.relativeSourcePath)) {
                          setExpandedBpels((prev) => new Set(prev).add(focusedReport.relativeSourcePath));
                        }
                        if (step.kind === 'ASSIGN' && !showAssign) {
                          setShowAssign(true);
                        }
                        const matchNode = visibleGraph.nodes.find((n) => n.id === step.activityId);
                        if (matchNode) {
                          onSelectNode(matchNode, visibleGraph);
                        } else {
                          const rawComp = focusedReport.components?.nodes.find((n) => n.id === step.activityId);
                          if (rawComp) {
                            onSelectNode(
                              {
                                id: rawComp.id,
                                label: rawComp.label,
                                name: rawComp.name,
                                subProject: focusedReport.processName,
                                properties: rawComp.properties,
                              },
                              visibleGraph
                            );
                          }
                        }
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg border transition cursor-pointer flex items-start gap-2.5 ${
                        isActiveStep
                          ? 'bg-[#facc15]/15 border-[#facc15] text-[#fef9c3]'
                          : 'bg-[#042014] border-[#166544] hover:border-[#facc15]/60 text-[#ecfdf5]'
                      }`}
                    >
                      <span className="w-5 h-5 rounded-full bg-[#009A49] text-[#fef08a] font-bold flex items-center justify-center shrink-0 mt-0.5">
                        {step.stepNumber}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="font-semibold text-[#fde047] flex items-center gap-1.5">
                          {isActiveStep ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5 opacity-60" />}
                          <span>{step.title}</span>
                          <span className="font-mono text-[#a7f3d0]/70 font-normal">[{step.kind}]</span>
                        </div>
                        <div className="text-[#ecfdf5]/90 mt-0.5">{step.detail}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Handlers & Observations */}
            {(focusedReport.components.explanation.handlerSummaries.length > 0 ||
              focusedReport.components.explanation.keyObservations.length > 0) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {focusedReport.components.explanation.handlerSummaries.length > 0 && (
                  <div className="bg-[#042014] border border-rose-500/35 rounded-lg p-3 space-y-1">
                    <div className="font-semibold text-rose-300">Fault, Event &amp; Compensation Handlers</div>
                    {focusedReport.components.explanation.handlerSummaries.map((h) => (
                      <div key={h} className="text-[#ecfdf5]/90">• {h}</div>
                    ))}
                  </div>
                )}
                {focusedReport.components.explanation.keyObservations.length > 0 && (
                  <div className="bg-[#042014] border border-[#facc15]/35 rounded-lg p-3 space-y-1">
                    <div className="font-semibold text-[#fde047]">Key Observations</div>
                    {focusedReport.components.explanation.keyObservations.map((obs) => (
                      <div key={obs} className="text-[#ecfdf5]/90">• {obs}</div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
