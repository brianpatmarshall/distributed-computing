import type { PayloadFieldSpec, ProcessAuditReport } from '../types';
import { CategoryBadge } from './SubProjectExplorer';

interface BlueprintViewProps {
  report: ProcessAuditReport | null;
}

function PayloadTree({ fields, depth = 0 }: { fields: PayloadFieldSpec[]; depth?: number }) {
  return (
    <ul className={depth > 0 ? 'ml-4 pl-3 border-l border-[#166544] space-y-1 mt-1' : 'space-y-1'}>
      {fields.map((f) => (
        <li key={`${f.xpathPath}-${f.fieldName}`} className="text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-mono text-[#ecfdf5] font-medium">{f.fieldName}</span>
            <span className="font-mono text-[#a7f3d0]/75">{f.javaType}</span>
            {f.usedByBpel ? (
              <span className="px-1.5 py-0.5 rounded bg-[#facc15]/20 text-[#fde047] border border-[#facc15]/50 font-medium">
                usedByBpel
              </span>
            ) : (
              <span className="px-1.5 py-0.5 rounded bg-[#042014] text-[#a7f3d0]/60 border border-[#166544]">
                unused
              </span>
            )}
          </div>
          {f.children.length > 0 && <PayloadTree fields={f.children} depth={depth + 1} />}
        </li>
      ))}
    </ul>
  );
}

export function BlueprintView({ report }: BlueprintViewProps) {
  if (!report) {
    return (
      <div className="p-6 text-xs text-[#a7f3d0]/75">
        Select a BPEL process to view its Spring WebFlux / Reactor 3 migration blueprint and payload DTO trees.
      </div>
    );
  }

  const bp = report.reactorBlueprint;

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h3 className="font-semibold text-sm text-[#fde047]">
              {report.processName} — Spring WebFlux / Reactor 3 Blueprint
            </h3>
            <div className="text-xs font-mono text-[#a7f3d0]/75">{report.relativeSourcePath}</div>
          </div>
          <CategoryBadge category={report.category} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="bg-[#042014] border border-[#166544] rounded-lg p-3">
            <div className="text-[#a7f3d0]/75">Suggested REST Controller Path</div>
            <div className="font-mono font-semibold text-[#fef08a] mt-1">
              {bp.suggestedRestControllerPath}
            </div>
          </div>
          <div className="bg-[#042014] border border-[#166544] rounded-lg p-3">
            <div className="text-[#a7f3d0]/75">Reactive Return Signature</div>
            <div className="font-mono font-semibold text-[#4ade80] mt-1">
              {bp.reactiveReturnSignature}
            </div>
          </div>
        </div>

        <div className="space-y-1.5 text-xs">
          <div className="font-semibold text-white">Required Reactor Operators</div>
          {bp.requiredReactorOperators.map((op) => (
            <div
              key={op}
              className="px-3 py-1.5 rounded-lg bg-[#042014] border border-[#166544] font-mono text-[#ecfdf5]"
            >
              {op}
            </div>
          ))}
        </div>

        <div className="space-y-1.5 text-xs">
          <div className="font-semibold text-white">Architectural Notes</div>
          {bp.architecturalNotes.map((note) => (
            <div
              key={note}
              className="px-3 py-2 rounded-lg bg-[#0c4d31] border border-[#facc15]/40 text-[#fef9c3]"
            >
              {note}
            </div>
          ))}
        </div>
      </div>

      {/* Touchpoints & XSD DTO Trees */}
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-4 space-y-3">
        <h3 className="font-semibold text-sm text-white">
          Touchpoints &amp; Payload DTO Trees ({report.touchpoints.length})
        </h3>
        <div className="space-y-3">
          {report.touchpoints.map((tp, idx) => (
            <div
              key={`${tp.partnerLink}-${tp.operation}-${idx}`}
              className="bg-[#042014] border border-[#166544] rounded-lg p-3 space-y-2"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div>
                  <span className="font-semibold text-[#fde047]">{tp.partnerLink}</span>
                  <span className="text-[#a7f3d0]/75">.{tp.operation}</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-[#0c4d31] text-[#4ade80] font-mono">
                  {tp.style}
                </span>
              </div>
              {tp.inputDtoTree.length > 0 && (
                <div>
                  <div className="text-xs text-[#a7f3d0]/75 mb-1">Input DTO Tree:</div>
                  <PayloadTree fields={tp.inputDtoTree} />
                </div>
              )}
              {tp.outputDtoTree.length > 0 && (
                <div>
                  <div className="text-xs text-[#a7f3d0]/75 mb-1">Output DTO Tree:</div>
                  <PayloadTree fields={tp.outputDtoTree} />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Mermaid Sequence Diagram Source */}
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-4 space-y-2">
        <h3 className="font-semibold text-sm text-white">Mermaid Sequence Diagram</h3>
        <pre className="bg-[#042014] border border-[#166544] rounded-lg p-3 text-xs font-mono text-[#fef08a] overflow-x-auto">
          {report.mermaidSequenceDiagram}
        </pre>
      </div>
    </div>
  );
}
