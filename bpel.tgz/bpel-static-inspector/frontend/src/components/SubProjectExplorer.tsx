import { Search, Layers } from 'lucide-react';
import type { MigrationCategory, ProcessAuditReport, SubProjectSummary } from '../types';

interface SubProjectExplorerProps {
  subProjects: SubProjectSummary[];
  reports: ProcessAuditReport[];
  selectedSubProject: string | null;
  selectedBpelPath: string | null;
  categoryFilter: 'ALL' | MigrationCategory;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onCategoryFilterChange: (cat: 'ALL' | MigrationCategory) => void;
  onSelectSubProject: (spId: string) => void;
  onSelectBpel: (subProjectId: string, bpelRelativePath: string) => void;
}

export function CategoryBadge({ category }: { category: MigrationCategory }) {
  if (category === 'STATELESS_PIPELINE') {
    return (
      <span className="px-1.5 py-0.5 rounded text-xs bg-[#009A49]/25 text-[#4ade80] border border-[#009A49]/50 font-medium shrink-0">
        Stateless
      </span>
    );
  }
  if (category === 'STATEFUL_ASYNC') {
    return (
      <span className="px-1.5 py-0.5 rounded text-xs bg-[#facc15]/20 text-[#fde047] border border-[#facc15]/50 font-medium shrink-0">
        Async
      </span>
    );
  }
  return (
    <span className="px-1.5 py-0.5 rounded text-xs bg-rose-500/20 text-rose-300 border border-rose-400/40 font-medium shrink-0">
      Saga
    </span>
  );
}

const FILTER_OPTIONS: { id: 'ALL' | MigrationCategory; label: string }[] = [
  { id: 'ALL', label: 'All' },
  { id: 'STATELESS_PIPELINE', label: 'Stateless' },
  { id: 'STATEFUL_ASYNC', label: 'Async' },
  { id: 'SAGA_COMPENSATING', label: 'Saga' },
];

export function SubProjectExplorer({
  subProjects,
  reports,
  selectedSubProject,
  selectedBpelPath,
  categoryFilter,
  searchQuery,
  onSearchChange,
  onCategoryFilterChange,
  onSelectSubProject,
  onSelectBpel,
}: SubProjectExplorerProps) {
  const reportByRelPath = new Map(reports.map((r) => [r.relativeSourcePath, r]));
  const q = searchQuery.trim().toLowerCase();

  return (
    <aside className="bg-[#05291a] border-r border-[#145338] flex flex-col min-h-0 h-full">
      <div className="p-3 border-b border-[#145338] space-y-2.5">
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-[#86efac]/60 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Filter sub-projects or BPELs..."
            className="w-full bg-[#042014] border border-[#1b6e4a] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#ecfdf5] placeholder-[#86efac]/55 focus:outline-none focus:border-[#facc15]"
          />
        </div>

        <div className="flex flex-wrap gap-1.5">
          {FILTER_OPTIONS.map((opt) => {
            const active = categoryFilter === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => onCategoryFilterChange(opt.id)}
                className={
                  active
                    ? 'px-2.5 py-1 rounded text-xs font-semibold bg-[#facc15] text-[#052e16] cursor-pointer'
                    : 'px-2.5 py-1 rounded text-xs font-medium bg-[#083c26] border border-[#166544] text-[#ecfdf5] hover:border-[#facc15] cursor-pointer'
                }
              >
                {opt.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {subProjects.length === 0 ? (
          <div className="text-xs text-[#a7f3d0]/75 p-3 bg-[#083c26] border border-[#166544] rounded-lg space-y-1">
            <div className="font-semibold text-[#fde047] flex items-center gap-1.5">
              <Layers className="w-4 h-4" />
              No project analyzed yet
            </div>
            <p>
              Enter a Java multi-module project path above and click{' '}
              <strong className="text-[#fde047]">Analyze Project</strong> to discover BPEL sub-projects.
            </p>
          </div>
        ) : (
          subProjects.map((sp) => {
            const matchingBpels = sp.bpelRelativePaths
              .map((p) => reportByRelPath.get(p))
              .filter((r): r is ProcessAuditReport => {
                if (!r) return false;
                if (categoryFilter !== 'ALL' && r.category !== categoryFilter) return false;
                if (!q) return true;
                return (
                  sp.name.toLowerCase().includes(q) ||
                  sp.relativePath.toLowerCase().includes(q) ||
                  r.processName.toLowerCase().includes(q) ||
                  r.relativeSourcePath.toLowerCase().includes(q)
                );
              });

            if (matchingBpels.length === 0) return null;
            const isSpActive = selectedSubProject === sp.id;

            return (
              <div
                key={sp.id}
                className={`rounded-lg border ${
                  isSpActive ? 'border-[#facc15]/75' : 'border-[#166544]'
                } bg-[#083c26] overflow-hidden`}
              >
                <button
                  type="button"
                  onClick={() => onSelectSubProject(sp.id)}
                  className="w-full px-3 py-2 flex items-center justify-between text-left hover:bg-[#0c4d31] cursor-pointer"
                >
                  <div className="min-w-0">
                    <div
                      className={`font-semibold text-xs truncate ${
                        isSpActive ? 'text-[#fde047]' : 'text-white'
                      }`}
                    >
                      {sp.name}
                    </div>
                    <div className="text-xs text-[#a7f3d0]/75 truncate">
                      {matchingBpels.length} BPEL · {sp.wsdlCount} WSDL · {sp.deployXmlCount} deploy
                    </div>
                  </div>
                  {isSpActive && (
                    <span className="text-xs text-[#facc15] font-semibold shrink-0 ml-2">
                      Active
                    </span>
                  )}
                </button>

                <div className="divide-y divide-[#145338] border-t border-[#145338]">
                  {matchingBpels.map((b) => {
                    const active = selectedBpelPath === b.relativeSourcePath;
                    const wsdlCount = b.dependencies?.wsdlFiles.length ?? 0;
                    const xsdCount = b.dependencies?.xsdFiles.length ?? 0;
                    const fileName = b.relativeSourcePath.split('/').pop() ?? b.relativeSourcePath;

                    return (
                      <button
                        key={b.relativeSourcePath}
                        type="button"
                        onClick={() => onSelectBpel(sp.id, b.relativeSourcePath)}
                        className={`w-full px-3 py-2 text-left flex items-center justify-between gap-2 cursor-pointer ${
                          active
                            ? 'bg-[#facc15]/15 border-l-2 border-[#facc15]'
                            : 'hover:bg-[#0c4d31]/60'
                        }`}
                      >
                        <div className="min-w-0">
                          <div
                            className={`text-xs font-medium truncate ${
                              active ? 'text-[#fef08a]' : 'text-[#ecfdf5]'
                            }`}
                            title={b.relativeSourcePath}
                          >
                            {fileName}
                          </div>
                          <div className="text-xs text-[#a7f3d0]/70 truncate">
                            {b.processName} · {wsdlCount} WSDL · {xsdCount} XSD
                          </div>
                        </div>
                        <CategoryBadge category={b.category} />
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
}
