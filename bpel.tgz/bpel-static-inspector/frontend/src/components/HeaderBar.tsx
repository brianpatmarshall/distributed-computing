import { FolderOpen, Play, RefreshCw, Settings } from 'lucide-react';
import type { Neo4jConfig, Neo4jConnectionStatus } from '../types';

interface HeaderBarProps {
  projectPath: string;
  onProjectPathChange: (val: string) => void;
  onAnalyze: () => void;
  onSyncNeo4j: () => void;
  onOpenFolderPicker: () => void;
  onOpenNeo4jSettings: () => void;
  analyzing: boolean;
  syncing: boolean;
  neo4jConfig: Neo4jConfig;
  neo4jStatus: Neo4jConnectionStatus | null;
}

export function HeaderBar({
  projectPath,
  onProjectPathChange,
  onAnalyze,
  onSyncNeo4j,
  onOpenFolderPicker,
  onOpenNeo4jSettings,
  analyzing,
  syncing,
  neo4jConfig,
  neo4jStatus,
}: HeaderBarProps) {
  const isConnected = neo4jStatus?.connected ?? false;

  return (
    <header className="bg-[#063320] border-b border-[#145338] px-5 py-3 flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-[#009A49] border-2 border-[#facc15] text-[#fef08a] font-bold flex items-center justify-center text-sm shadow-sm">
          BI
        </div>
        <div>
          <div className="font-semibold text-sm leading-tight text-white flex items-center gap-2">
            <span>BPEL Static Inspector</span>
            <span className="px-1.5 py-0.5 rounded bg-[#facc15]/20 text-[#fde047] border border-[#facc15]/40 text-xs font-medium">
              Neo4j Studio
            </span>
          </div>
          <div className="text-xs text-[#a7f3d0]/80">
            Multi-Module Java / Apache ODE Analyzer &amp; Dependency Visualizer
          </div>
        </div>
      </div>

      <form
        className="flex-1 max-w-2xl flex items-center gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          onAnalyze();
        }}
      >
        <div className="flex-1 flex items-center bg-[#042014] border border-[#1b6e4a] rounded-lg focus-within:border-[#facc15] focus-within:ring-2 focus-within:ring-[#facc15]/30">
          <input
            type="text"
            value={projectPath}
            onChange={(e) => onProjectPathChange(e.target.value)}
            placeholder="/path/to/java-bpel-project"
            className="flex-1 bg-transparent px-3 py-1.5 text-sm text-[#ecfdf5] placeholder-[#86efac]/50 focus:outline-none"
            aria-label="Java Project Root Directory"
          />
          <button
            type="button"
            onClick={onOpenFolderPicker}
            title="Browse folders"
            className="px-2.5 py-1.5 text-[#fde047] hover:bg-[#0c4d31] rounded-r-lg transition cursor-pointer"
          >
            <FolderOpen className="w-4 h-4" />
          </button>
        </div>

        <button
          type="submit"
          disabled={analyzing || !projectPath.trim()}
          className="inline-flex items-center gap-1.5 bg-[#facc15] hover:bg-[#fde047] disabled:opacity-50 text-[#052e16] font-semibold px-3.5 py-1.5 rounded-lg text-sm transition cursor-pointer shadow-sm"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          {analyzing ? 'Analyzing...' : 'Analyze Project'}
        </button>

        <button
          type="button"
          onClick={onSyncNeo4j}
          disabled={syncing || !projectPath.trim()}
          className="inline-flex items-center gap-1.5 bg-[#0c4d31] hover:bg-[#11613f] disabled:opacity-50 text-[#fef08a] border border-[#1e7a52] hover:border-[#facc15] px-3 py-1.5 rounded-lg text-sm font-medium transition cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
          {syncing ? 'Syncing...' : 'Sync to Neo4j'}
        </button>
      </form>

      <div className="flex items-center gap-2 text-xs">
        <button
          type="button"
          onClick={onOpenNeo4jSettings}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#0a452b] hover:bg-[#0f5838] border border-[#facc15]/50 text-[#fef9c3] transition cursor-pointer"
          title="Configure Neo4j Bolt & Browser settings"
        >
          <span
            className={`w-2 h-2 rounded-full ${
              isConnected
                ? 'bg-[#facc15] shadow-[0_0_6px_#facc15]'
                : 'bg-emerald-300/40'
            }`}
          />
          <span className="font-mono">{neo4jConfig.uri}</span>
          <Settings className="w-3.5 h-3.5 text-[#fde047]" />
        </button>
      </div>
    </header>
  );
}
