import { useState } from 'react';
import { Check, Copy, Download, ExternalLink, RefreshCw } from 'lucide-react';

interface EmbeddedNeo4jBrowserProps {
  browserUrl: string;
  selectedProcessName: string | null;
  cypherScript: string;
  grassStyle: string;
}

export function EmbeddedNeo4jBrowser({
  browserUrl,
  selectedProcessName,
  cypherScript,
  grassStyle,
}: EmbeddedNeo4jBrowserProps) {
  const [useProxy, setUseProxy] = useState(true);
  const [customUrl, setCustomUrl] = useState(browserUrl);
  const [reloadNonce, setReloadNonce] = useState(0);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const iframeSrc = useProxy ? `/neo4j-browser/browser/?r=${reloadNonce}` : customUrl;

  const quickQuery = selectedProcessName
    ? `MATCH p = (b:BpelFile {processName: '${selectedProcessName.replace(/'/g, "\\'")}'})-[*1..3]->(dep) RETURN p;`
    : 'MATCH (n) WHERE n:BpelFile OR n:DeployXml OR n:WsdlFile OR n:XsdFile OR n:ExternalService OPTIONAL MATCH (n)-[r]->(m) RETURN n, r, m;';

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 1800);
    } catch {
      // Clipboard API may be unavailable in restricted contexts
    }
  };

  const downloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col p-4 gap-3 min-h-0">
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-3 space-y-2.5 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-[240px]">
            <label className="inline-flex items-center gap-1.5 text-[#fde047] font-medium cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={useProxy}
                onChange={(e) => setUseProxy(e.target.checked)}
                className="accent-[#facc15]"
              />
              Use Built-in Iframe Proxy
            </label>
            <input
              type="text"
              value={useProxy ? '/neo4j-browser/browser/ (proxied to Neo4j HTTP)' : customUrl}
              disabled={useProxy}
              onChange={(e) => setCustomUrl(e.target.value)}
              className="flex-1 bg-[#042014] border border-[#1b6e4a] disabled:opacity-75 rounded-lg px-2.5 py-1 font-mono text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setReloadNonce((n) => n + 1)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0c4d31] hover:bg-[#11613f] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reload
            </button>
            <button
              type="button"
              onClick={() => void copyText('query', quickQuery)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0c4d31] hover:bg-[#11613f] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
            >
              {copiedKey === 'query' ? <Check className="w-3.5 h-3.5 text-[#4ade80]" /> : <Copy className="w-3.5 h-3.5" />}
              Copy Match Query
            </button>
            {cypherScript && (
              <button
                type="button"
                onClick={() => downloadFile('neo4j-dependencies.cypher', cypherScript)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0c4d31] hover:bg-[#11613f] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> .cypher
              </button>
            )}
            {grassStyle && (
              <button
                type="button"
                onClick={() => downloadFile('neo4j-style.grass', grassStyle)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#0c4d31] hover:bg-[#11613f] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> .grass Theme
              </button>
            )}
            <a
              href={browserUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#facc15] hover:bg-[#fde047] text-[#052e16] font-semibold"
            >
              <ExternalLink className="w-3.5 h-3.5" /> New Tab
            </a>
          </div>
        </div>

        <div className="bg-[#042014] border border-[#166544] rounded-lg px-2.5 py-1.5 font-mono text-[#fde047] overflow-x-auto whitespace-nowrap">
          {quickQuery}
        </div>
      </div>

      <div className="flex-1 bg-[#031d12] border border-[#166544] rounded-xl overflow-hidden min-h-[420px]">
        <iframe
          key={`${useProxy}-${reloadNonce}`}
          src={iframeSrc}
          title="Embedded Neo4j Browser"
          className="w-full h-full min-h-[420px] border-0 bg-[#042416]"
        />
      </div>
    </div>
  );
}
