import { useEffect, useState } from 'react';
import { ArrowUp, Folder, X } from 'lucide-react';
import { browseDirectory } from '../api';
import type { BrowseResponse } from '../types';

interface FolderPickerModalProps {
  open: boolean;
  initialPath: string;
  onClose: () => void;
  onSelect: (path: string) => void;
}

export function FolderPickerModal({
  open,
  initialPath,
  onClose,
  onSelect,
}: FolderPickerModalProps) {
  const [data, setData] = useState<BrowseResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadPath = async (target?: string) => {
    setLoading(true);
    setError(null);
    try {
      const resp = await browseDirectory(target);
      setData(resp);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      loadPath(initialPath || undefined);
    }
  }, [open, initialPath]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="bg-[#063320] border border-[#1b6e4a] rounded-xl max-w-2xl w-full max-h-[80vh] flex flex-col shadow-2xl">
        <div className="px-4 py-3 border-b border-[#145338] flex items-center justify-between">
          <h2 className="font-semibold text-sm text-[#fde047]">Select Java / BPEL Project Directory</h2>
          <button
            type="button"
            onClick={onClose}
            className="text-[#a7f3d0] hover:text-white cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 py-2.5 bg-[#042014] border-b border-[#145338] flex items-center gap-2 text-xs">
          <button
            type="button"
            disabled={!data?.parentPath || loading}
            onClick={() => data?.parentPath && loadPath(data.parentPath)}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#0c4d31] hover:bg-[#11613f] disabled:opacity-40 text-[#fef08a] border border-[#1e7a52] cursor-pointer"
          >
            <ArrowUp className="w-3.5 h-3.5" /> Up
          </button>
          <span className="font-mono text-[#ecfdf5] truncate flex-1">
            {data?.currentPath ?? initialPath}
          </span>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-1.5 min-h-[280px]">
          {error && (
            <div className="text-xs text-rose-300 bg-rose-950/60 border border-rose-500/40 rounded-lg p-2.5">
              {error}
            </div>
          )}
          {loading ? (
            <div className="text-xs text-[#a7f3d0]/75 p-4 text-center">Loading directories...</div>
          ) : (
            data?.directories.map((dir) => (
              <div
                key={dir.path}
                className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-[#083c26] hover:bg-[#0c4d31] border border-[#166544] hover:border-[#facc15]/60 text-xs"
              >
                <button
                  type="button"
                  onClick={() => loadPath(dir.path)}
                  className="flex items-center gap-2 flex-1 text-left min-w-0 cursor-pointer"
                >
                  <Folder className="w-4 h-4 text-[#facc15] shrink-0" />
                  <span className="truncate text-[#ecfdf5] font-medium">{dir.name}</span>
                  {dir.hasBpel && (
                    <span className="px-1.5 py-0.5 rounded bg-[#facc15]/20 text-[#fde047] border border-[#facc15]/40">
                      BPEL
                    </span>
                  )}
                  {dir.hasPom && (
                    <span className="px-1.5 py-0.5 rounded bg-[#009A49]/25 text-[#4ade80] border border-[#009A49]/50">
                      Java
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onSelect(dir.path);
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded bg-[#facc15] text-[#052e16] font-semibold hover:bg-[#fde047] cursor-pointer shrink-0"
                >
                  Select
                </button>
              </div>
            ))
          )}
        </div>

        <div className="px-4 py-3 border-t border-[#145338] flex items-center justify-between gap-2 text-xs">
          <span className="text-[#a7f3d0]/75">Tip: Folders containing `.bpel` files are tagged.</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-[#0c4d31] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={!data?.currentPath}
              onClick={() => {
                if (data?.currentPath) {
                  onSelect(data.currentPath);
                  onClose();
                }
              }}
              className="px-3.5 py-1.5 rounded-lg bg-[#facc15] hover:bg-[#fde047] text-[#052e16] font-semibold cursor-pointer"
            >
              Use Current Folder
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
