import { useEffect, useMemo, useRef, useState } from 'react';
import { Maximize2, Play, RotateCcw, ZoomIn, ZoomOut } from 'lucide-react';
import type { GraphData, GraphEdge, GraphNode } from '../types';

export type GraphScope = 'ALL' | 'SUBPROJECT' | 'BPEL';
export type GraphPreset = 'full' | 'shared' | 'cross' | 'external' | 'live';

interface InteractiveGraphProps {
  graph: GraphData;
  liveGraph: GraphData | null;
  scope: GraphScope;
  selectedSubProject: string | null;
  selectedBpelPath: string | null;
  selectedNodeId: string | null;
  selectedProcessName: string | null;
  onSelectNode: (nodeId: string) => void;
  onExecuteLiveCypher: (cypher: string) => Promise<void>;
  onClearLiveGraph: () => void;
  runningCypher: boolean;
  neo4jConnected: boolean;
}

const NODE_STYLES: Record<
  string,
  { fill: string; stroke: string; text: string; short: string; r: number; col: number }
> = {
  BpelFile: { fill: '#facc15', stroke: '#fef08a', text: '#052e16', short: 'BPEL', r: 24, col: 0 },
  DeployXml: { fill: '#ea580c', stroke: '#fdba74', text: '#ffffff', short: 'DD', r: 19, col: 1 },
  WsdlFile: { fill: '#009A49', stroke: '#86efac', text: '#ffffff', short: 'WSDL', r: 21, col: 2 },
  XsdFile: { fill: '#0d9488', stroke: '#5eead4', text: '#ffffff', short: 'XSD', r: 17, col: 3 },
  ExternalService: { fill: '#e11d48', stroke: '#fda4af', text: '#ffffff', short: 'EXT', r: 19, col: 3 },
};

const ALL_LABELS = ['BpelFile', 'DeployXml', 'WsdlFile', 'XsdFile', 'ExternalService'] as const;

function computeLayeredPositions(nodes: GraphNode[]): Record<string, { x: number; y: number }> {
  const columns = new Map<number, GraphNode[]>();
  for (const n of nodes) {
    const col = NODE_STYLES[n.label]?.col ?? 2;
    const list = columns.get(col) ?? [];
    list.push(n);
    columns.set(col, list);
  }

  const colSpacing = 220;
  const rowSpacing = 96;
  const positions: Record<string, { x: number; y: number }> = {};

  const sortedCols = Array.from(columns.keys()).sort((a, b) => a - b);
  const maxRows = Math.max(1, ...sortedCols.map((c) => columns.get(c)!.length));
  const totalHeight = Math.max(420, maxRows * rowSpacing);

  sortedCols.forEach((col, colIdx) => {
    const list = columns.get(col)!;
    const x = 110 + colIdx * colSpacing;
    const step = totalHeight / (list.length + 1);
    list.forEach((n, idx) => {
      positions[n.id] = { x, y: Math.round(step * (idx + 1)) };
    });
  });

  return positions;
}

export function InteractiveGraph({
  graph,
  liveGraph,
  scope,
  selectedSubProject,
  selectedBpelPath,
  selectedNodeId,
  selectedProcessName,
  onSelectNode,
  onExecuteLiveCypher,
  onClearLiveGraph,
  runningCypher,
  neo4jConnected,
}: InteractiveGraphProps) {
  const [preset, setPreset] = useState<GraphPreset>('full');
  const [cypher, setCypher] = useState(
    'MATCH (n) WHERE n:BpelFile OR n:DeployXml OR n:WsdlFile OR n:XsdFile OR n:ExternalService OPTIONAL MATCH (n)-[r]->(m) RETURN n, r, m'
  );
  const [visibleLabels, setVisibleLabels] = useState<Set<string>>(new Set(ALL_LABELS));
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragOverrides, setDragOverrides] = useState<Record<string, { x: number; y: number }>>({});

  const draggingNodeRef = useRef<{ id: string; startX: number; startY: number; origX: number; origY: number } | null>(null);
  const panningRef = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(null);

  const activeSource = liveGraph && preset === 'live' ? liveGraph : graph;

  const filteredGraph = useMemo(() => {
    let nodes = activeSource.nodes;
    let edges = activeSource.edges;

    if (preset !== 'live') {
      if (preset === 'shared') {
        const wsdlUseCount = new Map<string, number>();
        edges
          .filter((e) => e.type === 'DEPENDS_ON_WSDL')
          .forEach((e) => wsdlUseCount.set(e.target, (wsdlUseCount.get(e.target) ?? 0) + 1));
        const shared = new Set(
          Array.from(wsdlUseCount.entries())
            .filter(([, count]) => count > 1)
            .map(([id]) => id)
        );
        edges = edges.filter((e) => e.type === 'DEPENDS_ON_WSDL' && shared.has(e.target));
        const ids = new Set<string>();
        edges.forEach((e) => {
          ids.add(e.source);
          ids.add(e.target);
        });
        nodes = nodes.filter((n) => ids.has(n.id));
      } else if (preset === 'cross') {
        edges = edges.filter((e) => e.type === 'INVOKES_PROCESS');
        const ids = new Set<string>();
        edges.forEach((e) => {
          ids.add(e.source);
          ids.add(e.target);
        });
        nodes = nodes.filter((n) => ids.has(n.id));
      } else if (preset === 'external') {
        const extIds = new Set(nodes.filter((n) => n.label === 'ExternalService').map((n) => n.id));
        const deployIds = new Set(
          edges.filter((e) => extIds.has(e.target)).map((e) => e.source)
        );
        const bpelIds = new Set(
          edges.filter((e) => deployIds.has(e.target)).map((e) => e.source)
        );
        const keep = new Set([...extIds, ...deployIds, ...bpelIds]);
        nodes = nodes.filter((n) => keep.has(n.id));
        edges = edges.filter((e) => keep.has(e.source) && keep.has(e.target));
      } else if (scope === 'BPEL' && selectedBpelPath) {
        const startId = `bpel:${selectedBpelPath}`;
        const visited = new Set([startId]);
        let frontier = [startId];
        for (let hop = 0; hop < 3; hop++) {
          const next: string[] = [];
          for (const e of edges) {
            if (frontier.includes(e.source) && !visited.has(e.target)) {
              visited.add(e.target);
              next.push(e.target);
            }
          }
          frontier = next;
        }
        nodes = nodes.filter((n) => visited.has(n.id));
        edges = edges.filter((e) => visited.has(e.source) && visited.has(e.target));
      } else if (scope === 'SUBPROJECT' && selectedSubProject) {
        const seedIds = nodes
          .filter((n) => n.label === 'BpelFile' && n.subProject === selectedSubProject)
          .map((n) => n.id);
        const visited = new Set(seedIds);
        let frontier = [...seedIds];
        for (let hop = 0; hop < 3; hop++) {
          const next: string[] = [];
          for (const e of edges) {
            if (frontier.includes(e.source) && !visited.has(e.target)) {
              visited.add(e.target);
              next.push(e.target);
            }
          }
          frontier = next;
        }
        nodes = nodes.filter((n) => visited.has(n.id));
        edges = edges.filter((e) => visited.has(e.source) && visited.has(e.target));
      }
    }

    const visibleNodes = nodes.filter((n) => visibleLabels.has(n.label) || !(ALL_LABELS as readonly string[]).includes(n.label));
    const finalNodeIds = new Set(visibleNodes.map((n) => n.id));
    const visibleEdges = edges.filter((e) => finalNodeIds.has(e.source) && finalNodeIds.has(e.target));
    return { nodes: visibleNodes, edges: visibleEdges };
  }, [activeSource, preset, scope, selectedBpelPath, selectedSubProject, visibleLabels]);

  const basePositions = useMemo(() => computeLayeredPositions(filteredGraph.nodes), [filteredGraph.nodes]);

  useEffect(() => {
    setDragOverrides({});
  }, [activeSource, preset, scope, selectedBpelPath, selectedSubProject]);

  const getPos = (id: string) => dragOverrides[id] ?? basePositions[id] ?? { x: 120, y: 120 };

  const applyPreset = (p: Exclude<GraphPreset, 'live'>) => {
    setPreset(p);
    onClearLiveGraph();
    if (p === 'full') {
      setCypher(
        'MATCH (n) WHERE n:BpelFile OR n:DeployXml OR n:WsdlFile OR n:XsdFile OR n:ExternalService OPTIONAL MATCH (n)-[r]->(m) RETURN n, r, m'
      );
    } else if (p === 'shared') {
      setCypher(
        'MATCH (b:BpelFile)-[r:DEPENDS_ON_WSDL]->(w:WsdlFile) WITH w, collect(b) AS procs, collect(r) AS rels WHERE size(procs) > 1 RETURN w, procs, rels'
      );
    } else if (p === 'cross') {
      setCypher('MATCH p = (a:BpelFile)-[:INVOKES_PROCESS*1..5]->(b:BpelFile) RETURN p');
    } else if (p === 'external') {
      setCypher('MATCH p = (b:BpelFile)-[:DEPLOYED_BY]->(d:DeployXml)-[:BINDS_SERVICE]->(s:ExternalService) RETURN p');
    }
  };

  const handleRunCypher = async () => {
    setPreset('live');
    await onExecuteLiveCypher(cypher);
  };

  const toggleLabel = (label: string) => {
    setVisibleLabels((prev) => {
      const next = new Set(prev);
      if (next.has(label)) next.delete(label);
      else next.add(label);
      return next;
    });
  };

  const handleSvgMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (draggingNodeRef.current) {
      const { id, startX, startY, origX, origY } = draggingNodeRef.current;
      const dx = (e.clientX - startX) / zoom;
      const dy = (e.clientY - startY) / zoom;
      setDragOverrides((prev) => ({
        ...prev,
        [id]: { x: origX + dx, y: origY + dy },
      }));
    } else if (panningRef.current) {
      const { startX, startY, origX, origY } = panningRef.current;
      setPan({ x: origX + (e.clientX - startX), y: origY + (e.clientY - startY) });
    }
  };

  const handleSvgMouseUp = () => {
    draggingNodeRef.current = null;
    panningRef.current = null;
  };

  const handleWheel = (e: React.WheelEvent<SVGSVGElement>) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.1 : 0.9;
    setZoom((z) => Math.max(0.35, Math.min(2.6, Number((z * factor).toFixed(2)))));
  };

  return (
    <div className="flex-1 flex flex-col p-4 gap-3 min-h-0">
      {/* Cypher Query Bar */}
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-2.5 space-y-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold text-[#facc15] px-1">cypher&gt;</span>
          <input
            type="text"
            value={cypher}
            onChange={(e) => setCypher(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && neo4jConnected) {
                void handleRunCypher();
              }
            }}
            className="flex-1 bg-[#042014] border border-[#1b6e4a] rounded-lg px-2.5 py-1 text-xs font-mono text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
          />
          <button
            type="button"
            disabled={runningCypher}
            onClick={() => void handleRunCypher()}
            title="Run Cypher query directly against Neo4j Bolt"
            className="inline-flex items-center gap-1 bg-[#facc15] hover:bg-[#fde047] disabled:opacity-50 text-[#052e16] font-semibold px-3 py-1 rounded-lg text-xs cursor-pointer shrink-0"
          >
            <Play className="w-3 h-3 fill-current" />
            {runningCypher ? 'Running...' : 'Run in Neo4j'}
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[#a7f3d0]/75">Presets:</span>
            {(
              [
                ['full', 'Full Graph'],
                ['shared', 'Shared WSDLs'],
                ['cross', 'Cross-BPEL Calls'],
                ['external', 'External Services'],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => applyPreset(key)}
                className={
                  preset === key
                    ? 'px-2 py-0.5 rounded bg-[#facc15] text-[#052e16] font-semibold cursor-pointer'
                    : 'px-2 py-0.5 rounded bg-[#0c4d31] text-[#fef08a] border border-[#1e7a52] hover:border-[#facc15] cursor-pointer'
                }
              >
                {label}
              </button>
            ))}
            {selectedProcessName && (
              <button
                type="button"
                onClick={() =>
                  setCypher(
                    `MATCH p = (b:BpelFile {processName: '${selectedProcessName.replace(/'/g, "\\'")}'})-[*1..3]->(dep) RETURN p`
                  )
                }
                className="px-2 py-0.5 rounded bg-[#042014] text-[#4ade80] border border-[#166544] hover:border-[#facc15] cursor-pointer"
              >
                Load {selectedProcessName} Query
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {ALL_LABELS.map((lbl) => (
              <label key={lbl} className="inline-flex items-center gap-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={visibleLabels.has(lbl)}
                  onChange={() => toggleLabel(lbl)}
                  className="accent-[#facc15]"
                />
                <span className="text-[#ecfdf5]">
                  {lbl === 'BpelFile'
                    ? 'BPEL'
                    : lbl === 'DeployXml'
                    ? 'deploy.xml'
                    : lbl === 'WsdlFile'
                    ? 'WSDL'
                    : lbl === 'XsdFile'
                    ? 'XSD'
                    : 'External'}
                </span>
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Interactive SVG Graph Canvas */}
      <div className="flex-1 bg-[#031d12] border border-[#166544] rounded-xl relative overflow-hidden min-h-[420px] shadow-inner">
        {filteredGraph.nodes.length === 0 ? (
          <div className="h-full min-h-[420px] flex flex-col items-center justify-center text-center p-6 text-xs text-[#a7f3d0]/80 gap-2">
            <div className="text-sm font-semibold text-[#fde047]">No graph nodes match the current view</div>
            <p className="max-w-md">
              Analyze a Java BPEL project above, switch presets to <strong className="text-white">Full Graph</strong>, or run a Cypher query against your Neo4j instance.
            </p>
          </div>
        ) : (
          <svg
            className="w-full h-full min-h-[420px] block select-none cursor-grab active:cursor-grabbing"
            onMouseDown={(e) => {
              if ((e.target as Element).closest('[data-node-id]')) return;
              panningRef.current = {
                startX: e.clientX,
                startY: e.clientY,
                origX: pan.x,
                origY: pan.y,
              };
            }}
            onMouseMove={handleSvgMouseMove}
            onMouseUp={handleSvgMouseUp}
            onMouseLeave={handleSvgMouseUp}
            onWheel={handleWheel}
          >
            <defs>
              <pattern id="irishDotGrid" width="28" height="28" patternUnits="userSpaceOnUse">
                <circle cx="1" cy="1" r="1" fill="#145338" opacity="0.6" />
              </pattern>
              <marker id="edge-arrow-green" viewBox="0 0 10 10" refX="26" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#4ade80" />
              </marker>
              <marker id="edge-arrow-yellow" viewBox="0 0 10 10" refX="28" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 1 L 10 5 L 0 9 z" fill="#facc15" />
              </marker>
            </defs>

            <rect width="100%" height="100%" fill="url(#irishDotGrid)" />

            <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
              {/* Edges */}
              {filteredGraph.edges.map((edge: GraphEdge) => {
                const a = getPos(edge.source);
                const b = getPos(edge.target);
                const isHighlight = edge.source === selectedNodeId || edge.target === selectedNodeId;
                const isCross = edge.type === 'INVOKES_PROCESS';
                const stroke = isCross || isHighlight ? '#facc15' : '#4ade80';
                const width = isCross ? 2.8 : isHighlight ? 2.3 : 1.3;
                const opacity = isHighlight || isCross ? 0.95 : 0.38;
                const mx = (a.x + b.x) / 2;
                const my = (a.y + b.y) / 2 - 6;

                return (
                  <g key={edge.id}>
                    <line
                      x1={a.x}
                      y1={a.y}
                      x2={b.x}
                      y2={b.y}
                      stroke={stroke}
                      strokeWidth={width}
                      strokeOpacity={opacity}
                      strokeDasharray={isCross ? '6,3' : undefined}
                      markerEnd={isCross || isHighlight ? 'url(#edge-arrow-yellow)' : 'url(#edge-arrow-green)'}
                    />
                    {(isHighlight || isCross) && (
                      <text
                        x={mx}
                        y={my}
                        textAnchor="middle"
                        fill="#fef08a"
                        fontSize="12"
                        fontWeight="500"
                      >
                        {edge.type}
                      </text>
                    )}
                  </g>
                );
              })}

              {/* Nodes */}
              {filteredGraph.nodes.map((node) => {
                const pos = getPos(node.id);
                const style = NODE_STYLES[node.label] ?? {
                  fill: '#16a34a',
                  stroke: '#bbf7d0',
                  text: '#ffffff',
                  short: 'NODE',
                  r: 18,
                  col: 2,
                };
                const selected = node.id === selectedNodeId;

                return (
                  <g
                    key={node.id}
                    data-node-id={node.id}
                    transform={`translate(${pos.x}, ${pos.y})`}
                    className="cursor-pointer"
                    onMouseDown={(e) => {
                      e.stopPropagation();
                      draggingNodeRef.current = {
                        id: node.id,
                        startX: e.clientX,
                        startY: e.clientY,
                        origX: pos.x,
                        origY: pos.y,
                      };
                    }}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectNode(node.id);
                    }}
                  >
                    {selected && (
                      <circle
                        r={style.r + 7}
                        fill="none"
                        stroke="#facc15"
                        strokeWidth="2.5"
                        strokeOpacity="0.9"
                      />
                    )}
                    <circle
                      r={style.r}
                      fill={style.fill}
                      stroke={selected ? '#fef9c3' : style.stroke}
                      strokeWidth={selected ? 3 : 2}
                    />
                    <text
                      y="4"
                      textAnchor="middle"
                      fill={style.text}
                      fontSize="12"
                      fontWeight="700"
                    >
                      {style.short}
                    </text>
                    <text
                      y={style.r + 16}
                      textAnchor="middle"
                      fill={selected ? '#fde047' : '#ecfdf5'}
                      fontSize="12"
                      fontWeight={selected ? '700' : '500'}
                    >
                      {node.name}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>
        )}

        {/* Top-Right Controls */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5">
          {preset === 'live' && (
            <span className="px-2 py-1 rounded-lg bg-[#facc15] text-[#052e16] text-xs font-semibold">
              Live Neo4j Result
            </span>
          )}
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(2.6, Number((z * 1.15).toFixed(2))))}
            title="Zoom in"
            className="p-1.5 rounded-lg bg-[#063320]/95 border border-[#1b6e4a] text-[#fde047] hover:border-[#facc15] cursor-pointer"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.35, Number((z / 1.15).toFixed(2))))}
            title="Zoom out"
            className="p-1.5 rounded-lg bg-[#063320]/95 border border-[#1b6e4a] text-[#fde047] hover:border-[#facc15] cursor-pointer"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              setZoom(1);
              setPan({ x: 0, y: 0 });
            }}
            title="Reset pan & zoom"
            className="p-1.5 rounded-lg bg-[#063320]/95 border border-[#1b6e4a] text-[#fde047] hover:border-[#facc15] cursor-pointer"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setDragOverrides({})}
            title="Reset node positions"
            className="p-1.5 rounded-lg bg-[#063320]/95 border border-[#1b6e4a] text-[#fde047] hover:border-[#facc15] cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom-Left Legend */}
        <div className="absolute bottom-3 left-3 bg-[#063320]/95 border border-[#1b6e4a] rounded-lg px-3 py-1.5 flex flex-wrap items-center gap-3 text-xs text-[#ecfdf5]">
          <span className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#facc15]" /> BpelFile</span>
          <span className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-orange-500" /> DeployXml</span>
          <span className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-[#009A49]" /> WsdlFile</span>
          <span className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-teal-500" /> XsdFile</span>
          <span className="inline-flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> ExternalService</span>
          <span className="text-[#a7f3d0]/70">· {filteredGraph.nodes.length} nodes, {filteredGraph.edges.length} edges</span>
        </div>
      </div>
    </div>
  );
}
