import { useState } from 'react';
import { CheckCircle2, PlugZap, X, XCircle } from 'lucide-react';
import { testNeo4jConnection } from '../api';
import type { Neo4jConfig, Neo4jConnectionStatus } from '../types';

interface Neo4jSettingsModalProps {
  open: boolean;
  config: Neo4jConfig;
  onChange: (cfg: Neo4jConfig) => void;
  onStatusUpdate: (status: Neo4jConnectionStatus) => void;
  onClose: () => void;
}

export function Neo4jSettingsModal({
  open,
  config,
  onChange,
  onStatusUpdate,
  onClose,
}: Neo4jSettingsModalProps) {
  const [draft, setDraft] = useState<Neo4jConfig>(config);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<Neo4jConnectionStatus | null>(null);

  if (!open) return null;

  const handleTest = async () => {
    setTesting(true);
    try {
      const res = await testNeo4jConnection(draft);
      setTestResult(res);
      onStatusUpdate(res);
    } catch (e) {
      const failed: Neo4jConnectionStatus = {
        connected: false,
        uri: draft.uri,
        database: draft.database,
        serverAgent: '',
        message: e instanceof Error ? e.message : String(e),
      };
      setTestResult(failed);
      onStatusUpdate(failed);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="bg-[#063320] border border-[#1b6e4a] rounded-xl max-w-lg w-full shadow-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-[#145338] flex items-center justify-between">
          <h2 className="font-semibold text-sm text-[#fde047]">Neo4j Connection &amp; Browser Settings</h2>
          <button type="button" onClick={onClose} className="text-[#a7f3d0] hover:text-white cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3 text-xs">
          <div>
            <label className="block text-[#a7f3d0] mb-1">Bolt URI</label>
            <input
              type="text"
              value={draft.uri}
              onChange={(e) => setDraft({ ...draft, uri: e.target.value })}
              className="w-full bg-[#042014] border border-[#1b6e4a] rounded-lg px-3 py-1.5 font-mono text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[#a7f3d0] mb-1">Username</label>
              <input
                type="text"
                value={draft.username}
                onChange={(e) => setDraft({ ...draft, username: e.target.value })}
                className="w-full bg-[#042014] border border-[#1b6e4a] rounded-lg px-3 py-1.5 text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
              />
            </div>
            <div>
              <label className="block text-[#a7f3d0] mb-1">Password (or env NEO4J_PASSWORD)</label>
              <input
                type="password"
                value={draft.password}
                onChange={(e) => setDraft({ ...draft, password: e.target.value })}
                placeholder="••••••••"
                className="w-full bg-[#042014] border border-[#1b6e4a] rounded-lg px-3 py-1.5 text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[#a7f3d0] mb-1">Database</label>
              <input
                type="text"
                value={draft.database}
                onChange={(e) => setDraft({ ...draft, database: e.target.value })}
                className="w-full bg-[#042014] border border-[#1b6e4a] rounded-lg px-3 py-1.5 font-mono text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
              />
            </div>
            <div>
              <label className="block text-[#a7f3d0] mb-1">Embedded Neo4j Browser URL</label>
              <input
                type="text"
                value={draft.browserUrl}
                onChange={(e) => setDraft({ ...draft, browserUrl: e.target.value })}
                className="w-full bg-[#042014] border border-[#1b6e4a] rounded-lg px-3 py-1.5 font-mono text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
              />
            </div>
          </div>

          <label className="flex items-center gap-2 pt-1 cursor-pointer">
            <input
              type="checkbox"
              checked={draft.clearOnSync}
              onChange={(e) => setDraft({ ...draft, clearOnSync: e.target.checked })}
              className="accent-[#facc15]"
            />
            <span className="text-[#ecfdf5]">
              Clear existing BPEL nodes in Neo4j before syncing
            </span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={draft.includeComponents}
              onChange={(e) => setDraft({ ...draft, includeComponents: e.target.checked })}
              className="accent-[#facc15]"
            />
            <span className="text-[#ecfdf5]">
              Include internal BPEL components (:BpelActivity, :BpelPartnerLink, :BpelVariable)
            </span>
          </label>

          {testResult && (
            <div
              className={`rounded-lg p-2.5 border flex items-start gap-2 ${
                testResult.connected
                  ? 'bg-[#009A49]/20 border-[#4ade80]/50 text-[#ecfdf5]'
                  : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
              }`}
            >
              {testResult.connected ? (
                <CheckCircle2 className="w-4 h-4 text-[#4ade80] shrink-0 mt-0.5" />
              ) : (
                <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )}
              <div>
                <div className="font-semibold">
                  {testResult.connected ? `Connected (${testResult.serverAgent})` : 'Connection Failed'}
                </div>
                <div className="opacity-85 break-all">{testResult.message}</div>
              </div>
            </div>
          )}
        </div>

        <div className="px-4 py-3 border-t border-[#145338] flex items-center justify-between text-xs">
          <button
            type="button"
            disabled={testing}
            onClick={handleTest}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0c4d31] hover:bg-[#11613f] text-[#fef08a] border border-[#1e7a52] cursor-pointer"
          >
            <PlugZap className="w-3.5 h-3.5" />
            {testing ? 'Testing...' : 'Test Connection'}
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-[#083c26] text-[#a7f3d0] border border-[#166544] cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                onChange(draft);
                onClose();
              }}
              className="px-3.5 py-1.5 rounded-lg bg-[#facc15] hover:bg-[#fde047] text-[#052e16] font-semibold cursor-pointer"
            >
              Save Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
