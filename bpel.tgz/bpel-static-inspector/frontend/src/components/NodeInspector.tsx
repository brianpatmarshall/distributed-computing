import type { GraphEdge, GraphNode } from '../types';

interface NodeInspectorProps {
  selectedNode: GraphNode | null;
  allNodes: GraphNode[];
  allEdges: GraphEdge[];
  onJumpToNode: (nodeId: string) => void;
}

export function NodeInspector({
  selectedNode,
  allNodes,
  allEdges,
  onJumpToNode,
}: NodeInspectorProps) {
  const nodeById = new Map(allNodes.map((n) => [n.id, n]));

  if (!selectedNode) {
    return (
      <aside className="bg-[#05291a] border-l border-[#145338] flex flex-col h-full">
        <div className="px-4 py-3 border-b border-[#145338] flex items-center justify-between">
          <span className="font-semibold text-sm text-white">Node &amp; Dependency Inspector</span>
        </div>
        <div className="p-4 text-xs text-[#a7f3d0]/75">
          Click any BPEL file, <code className="text-[#fde047]">deploy.xml</code>, WSDL, XSD, or
          External Service node to inspect its properties and impact graph.
        </div>
      </aside>
    );
  }

  const outgoing = allEdges
    .filter((e) => e.source === selectedNode.id)
    .map((e) => ({ edge: e, node: nodeById.get(e.target) }))
    .filter((item): item is { edge: GraphEdge; node: GraphNode } => Boolean(item.node));

  const incoming = allEdges
    .filter((e) => e.target === selectedNode.id)
    .map((e) => ({ edge: e, node: nodeById.get(e.source) }))
    .filter((item): item is { edge: GraphEdge; node: GraphNode } => Boolean(item.node));

  return (
    <aside className="bg-[#05291a] border-l border-[#145338] flex flex-col min-h-0 h-full">
      <div className="px-4 py-3 border-b border-[#145338] flex items-center justify-between gap-2">
        <span className="font-semibold text-sm text-white">Node Inspector</span>
        <span className="text-xs px-2 py-0.5 rounded-full bg-[#facc15]/20 text-[#fde047] border border-[#facc15]/40 font-semibold">
          {selectedNode.label}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        <div className="space-y-1">
          <div className="text-sm font-semibold text-[#fde047] break-words">
            {selectedNode.name}
          </div>
          <div className="text-[#a7f3d0]/75">
            Sub-project:{' '}
            <span className="text-white font-medium">{selectedNode.subProject || '.'}</span>
          </div>
        </div>

        <div className="bg-[#042014] border border-[#166544] rounded-lg p-3 space-y-2">
          <div className="font-semibold text-[#fef08a]">Properties</div>
          {Object.entries(selectedNode.properties).length === 0 ? (
            <div className="text-[#a7f3d0]/70">No properties</div>
          ) : (
            Object.entries(selectedNode.properties).map(([k, v]) => (
              <div key={k} className="flex flex-col">
                <span className="text-[#a7f3d0]/75">{k}</span>
                <span className="font-mono text-[#ecfdf5] break-all">
                  {Array.isArray(v) ? v.join(', ') : String(v)}
                </span>
              </div>
            ))
          )}
        </div>

        <div className="space-y-1.5">
          <div className="font-semibold text-white">
            Outgoing Dependencies ({outgoing.length})
          </div>
          {outgoing.length === 0 ? (
            <div className="text-[#a7f3d0]/70">None</div>
          ) : (
            outgoing.map(({ edge, node }) => (
              <button
                key={edge.id}
                type="button"
                onClick={() => onJumpToNode(node.id)}
                className="w-full text-left px-2.5 py-1.5 rounded-lg bg-[#083c26] border border-[#166544] hover:border-[#facc15] flex items-center justify-between gap-2 cursor-pointer"
              >
                <span className="truncate text-[#ecfdf5]">{node.name}</span>
                <span className="text-[#fde047] font-mono shrink-0">{edge.type}</span>
              </button>
            ))
          )}
        </div>

        <div className="space-y-1.5">
          <div className="font-semibold text-white">
            Referenced By ({incoming.length})
          </div>
          {incoming.length === 0 ? (
            <div className="text-[#a7f3d0]/70">None</div>
          ) : (
            incoming.map(({ edge, node }) => (
              <button
                key={edge.id}
                type="button"
                onClick={() => onJumpToNode(node.id)}
                className="w-full text-left px-2.5 py-1.5 rounded-lg bg-[#083c26] border border-[#166544] hover:border-[#facc15] flex items-center justify-between gap-2 cursor-pointer"
              >
                <span className="truncate text-[#ecfdf5]">{node.name}</span>
                <span className="text-[#4ade80] font-mono shrink-0">{edge.type}</span>
              </button>
            ))
          )}
        </div>
      </div>
    </aside>
  );
}
