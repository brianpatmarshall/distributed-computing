import type { ProcessAuditReport, QNameLike } from '../types';

interface DependenciesViewProps {
  report: ProcessAuditReport | null;
}

function formatQName(q: QNameLike | string | null | undefined): string {
  if (!q) return '';
  if (typeof q === 'string') return q;
  return q.localPart ? (q.namespaceURI ? `{${q.namespaceURI}}${q.localPart}` : q.localPart) : '';
}

export function DependenciesView({ report }: DependenciesViewProps) {
  if (!report) {
    return (
      <div className="p-6 text-xs text-[#a7f3d0]/75">
        Select a BPEL process from the left explorer to inspect its <code className="text-[#fde047]">deploy.xml</code>, WSDL, and XSD dependencies.
      </div>
    );
  }

  const deps = report.dependencies;

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {/* deploy.xml */}
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h3 className="font-semibold text-sm text-[#fde047]">
              {report.processName} — ODE Deployment Descriptor
            </h3>
            <div className="text-xs font-mono text-[#a7f3d0]/75">{report.relativeSourcePath}</div>
          </div>
          <span className="text-xs px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 border border-orange-400/40 font-medium">
            deploy.xml
          </span>
        </div>

        {!deps?.deployXml ? (
          <div className="text-xs text-[#a7f3d0]/70">No matching deploy.xml found for this process.</div>
        ) : (
          <div className="space-y-3 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              <span className="font-mono text-[#ecfdf5] bg-[#042014] px-2.5 py-1 rounded border border-[#166544]">
                {deps.deployXml.relativePath}
              </span>
              <span className="px-2 py-0.5 rounded bg-[#0c4d31] text-[#fef08a] border border-[#facc15]/40">
                inMemory={String(deps.deployXml.inMemory)}
              </span>
            </div>

            {deps.deployXml.providedServices.length > 0 && (
              <div className="space-y-1.5">
                <div className="font-semibold text-[#4ade80]">Provided Services</div>
                {deps.deployXml.providedServices.map((ref, idx) => (
                  <div
                    key={`${ref.partnerLink}-${idx}`}
                    className="bg-[#042014] border border-[#166544] rounded-lg px-3 py-2 flex flex-wrap items-center justify-between gap-2"
                  >
                    <div>
                      <span className="text-[#fde047] font-semibold">{ref.partnerLink}</span>
                      <span className="text-[#a7f3d0]/75 mx-1.5">→</span>
                      <span className="font-mono text-[#ecfdf5]">{formatQName(ref.serviceName)}</span>
                      <span className="text-[#a7f3d0]/75 ml-1.5">(port: {ref.portName})</span>
                    </div>
                    <span className="font-mono text-[#4ade80]">
                      {ref.wsdlRelativePath ?? 'External / WSDL not in repo'}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {deps.deployXml.invokedServices.length > 0 && (
              <div className="space-y-1.5">
                <div className="font-semibold text-[#fde047]">Invoked Services</div>
                {deps.deployXml.invokedServices.map((ref, idx) => (
                  <div
                    key={`${ref.partnerLink}-${idx}`}
                    className="bg-[#042014] border border-[#166544] rounded-lg px-3 py-2 flex flex-wrap items-center justify-between gap-2"
                  >
                    <div>
                      <span className="text-[#fde047] font-semibold">{ref.partnerLink}</span>
                      <span className="text-[#a7f3d0]/75 mx-1.5">→</span>
                      <span className="font-mono text-[#ecfdf5]">{formatQName(ref.serviceName)}</span>
                      <span className="text-[#a7f3d0]/75 ml-1.5">(port: {ref.portName})</span>
                    </div>
                    <span className={`font-mono ${ref.wsdlRelativePath ? 'text-[#4ade80]' : 'text-rose-300'}`}>
                      {ref.wsdlRelativePath ?? 'ExternalService (no local WSDL)'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* WSDLs */}
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-4 space-y-2.5">
        <h3 className="font-semibold text-sm text-white">
          WSDL Dependencies ({deps?.wsdlFiles.length ?? 0})
        </h3>
        {!deps || deps.wsdlFiles.length === 0 ? (
          <div className="text-xs text-[#a7f3d0]/70">No WSDL dependencies discovered.</div>
        ) : (
          <div className="divide-y divide-[#145338]">
            {deps.wsdlFiles.map((w) => (
              <div key={w.relativePath} className="py-2.5 space-y-1.5">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-semibold text-[#4ade80] font-mono">{w.relativePath}</span>
                  <span className="font-mono text-[#a7f3d0]/75">{w.targetNamespace}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {w.reasons.map((r) => (
                    <span
                      key={r}
                      className="px-2 py-0.5 rounded bg-[#042014] border border-[#facc15]/35 text-xs font-mono text-[#fef08a]"
                    >
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* XSDs */}
      <div className="bg-[#083c26] border border-[#166544] rounded-xl p-4 space-y-2.5">
        <h3 className="font-semibold text-sm text-white">
          XSD Schema Dependencies ({deps?.xsdFiles.length ?? 0})
        </h3>
        {!deps || deps.xsdFiles.length === 0 ? (
          <div className="text-xs text-[#a7f3d0]/70">No XSD dependencies discovered.</div>
        ) : (
          <div className="divide-y divide-[#145338]">
            {deps.xsdFiles.map((x) => (
              <div key={x.relativePath} className="py-2 space-y-1">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-semibold text-teal-300 font-mono">{x.relativePath}</span>
                  <span className="font-mono text-[#a7f3d0]/75">{x.targetNamespace}</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {x.reasons.map((r) => (
                    <span
                      key={r}
                      className="px-2 py-0.5 rounded bg-[#042014] border border-teal-400/35 text-xs font-mono text-teal-200"
                    >
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
