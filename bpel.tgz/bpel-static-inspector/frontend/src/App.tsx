import { useEffect, useMemo, useState } from 'react';
import {
  analyzeProject,
  fetchHealth,
  runNeo4jQuery,
  syncToNeo4j,
} from './api';
import { BlueprintView } from './components/BlueprintView';
import { BpelComponentExplorer } from './components/BpelComponentExplorer';
import { DependenciesView } from './components/DependenciesView';
import { EmbeddedNeo4jBrowser } from './components/EmbeddedNeo4jBrowser';
import { FolderPickerModal } from './components/FolderPickerModal';
import { HeaderBar } from './components/HeaderBar';
import { InteractiveGraph, type GraphScope } from './components/InteractiveGraph';
import { Neo4jSettingsModal } from './components/Neo4jSettingsModal';
import { NodeInspector } from './components/NodeInspector';
import { SubProjectExplorer } from './components/SubProjectExplorer';
import type {
  GraphData,
  GraphNode,
  MigrationCategory,
  Neo4jConfig,
  Neo4jConnectionStatus,
  ProjectAnalysisResult,
} from './types';

type ActiveTab = 'graph' | 'components' | 'browser' | 'deps' | 'blueprint';

const DEFAULT_NEO4J: Neo4jConfig = {
  uri: 'bolt://localhost:7687',
  username: 'neo4j',
  password: '',
  database: 'neo4j',
  browserUrl: 'http://localhost:7474/browser/',
  clearOnSync: true,
  includeComponents: true,
};

const EMPTY_GRAPH: GraphData = { nodes: [], edges: [] };

export default function App() {
  const [projectPath, setProjectPath] = useState('');
  const [analysis, setAnalysis] = useState<ProjectAnalysisResult | null>(null);
  const [liveGraph, setLiveGraph] = useState<GraphData | null>(null);

  const [selectedSubProject, setSelectedSubProject] = useState<string | null>(null);
  const [selectedBpelPath, setSelectedBpelPath] = useState<string | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [componentInspectorGraph, setComponentInspectorGraph] = useState<GraphData | null>(null);
  const [componentSelectedNode, setComponentSelectedNode] = useState<GraphNode | null>(null);

  const [categoryFilter, setCategoryFilter] = useState<'ALL' | MigrationCategory>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<ActiveTab>('graph');
  const [graphScope, setGraphScope] = useState<GraphScope>('ALL');

  const [analyzing, setAnalyzing] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [runningCypher, setRunningCypher] = useState(false);

  const [neo4jConfig, setNeo4jConfig] = useState<Neo4jConfig>(DEFAULT_NEO4J);
  const [neo4jStatus, setNeo4jStatus] = useState<Neo4jConnectionStatus | null>(null);

  const [folderPickerOpen, setFolderPickerOpen] = useState(false);
  const [neo4jModalOpen, setNeo4jModalOpen] = useState(false);
  const [statusMessage, setStatusMessage] = useState(
    'Enter a Java multi-module BPEL project directory and click Analyze Project'
  );
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    fetchHealth()
      .then((h) => {
        if (h.cwd && !projectPath) {
          setProjectPath(h.cwd);
        }
        if (h.neo4jBrowserUpstream) {
          setNeo4jConfig((prev) => ({
            ...prev,
            browserUrl: `${h.neo4jBrowserUpstream.replace(/\/+$/, '')}/browser/`,
          }));
        }
      })
      .catch(() => {
        // Backend may not be running yet
      });
  }, []);

  const handleAnalyze = async (pathOverride?: string) => {
    const target = (pathOverride ?? projectPath).trim();
    if (!target) return;
    setAnalyzing(true);
    setErrorMessage(null);
    try {
      const res = await analyzeProject(target);
      setAnalysis(res);
      setLiveGraph(null);
      if (res.subProjects.length > 0) {
        setSelectedSubProject(res.subProjects[0].id);
      }
      if (res.reports.length > 0) {
        const firstPath = res.reports[0].relativeSourcePath;
        setSelectedBpelPath(firstPath);
        setSelectedNodeId(`bpel:${firstPath}`);
      } else {
        setSelectedBpelPath(null);
        setSelectedNodeId(null);
      }
      setStatusMessage(
        `Analyzed ${res.projectName}: ${res.counts.subProjects} sub-project(s), ${res.counts.bpelFiles} BPEL file(s), ${res.counts.wsdlFiles} WSDL(s), ${res.counts.deployXmls} deploy.xml`
      );
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : String(e));
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSyncNeo4j = async () => {
    if (!projectPath.trim()) return;
    setSyncing(true);
    setErrorMessage(null);
    try {
      const summary = await syncToNeo4j(projectPath.trim(), neo4jConfig);
      setNeo4jStatus({
        connected: true,
        uri: neo4jConfig.uri,
        database: neo4jConfig.database,
        serverAgent: 'Neo4j',
        message: 'Synced successfully',
      });
      setStatusMessage(
        `Synced to Neo4j (${neo4jConfig.uri}): ${summary.bpelCount} BPELs, ${summary.deployEdges} deploy links, ${summary.wsdlEdges} WSDL links, ${summary.componentNodes} component nodes`
      );
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : String(e));
    } finally {
      setSyncing(false);
    }
  };

  const handleRunLiveCypher = async (cypher: string) => {
    setRunningCypher(true);
    setErrorMessage(null);
    try {
      const res = await runNeo4jQuery(cypher, neo4jConfig);
      setLiveGraph({ nodes: res.nodes, edges: res.edges });
      setNeo4jStatus({
        connected: true,
        uri: neo4jConfig.uri,
        database: neo4jConfig.database,
        serverAgent: 'Neo4j',
        message: 'Query succeeded',
      });
      setStatusMessage(
        `Neo4j Cypher returned ${res.nodes.length} node(s), ${res.edges.length} edge(s) in ${res.executionMs}ms`
      );
    } catch (e) {
      setErrorMessage(e instanceof Error ? e.message : String(e));
    } finally {
      setRunningCypher(false);
    }
  };

  const activeGraph = liveGraph ?? analysis?.graph ?? EMPTY_GRAPH;

  const selectedReport = useMemo(() => {
    if (!analysis || !selectedBpelPath) return null;
    return analysis.reports.find((r) => r.relativeSourcePath === selectedBpelPath) ?? null;
  }, [analysis, selectedBpelPath]);

  const inspectorGraph =
    activeTab === 'components' && componentInspectorGraph ? componentInspectorGraph : activeGraph;

  const selectedNode = useMemo(() => {
    if (activeTab === 'components' && componentSelectedNode) {
      return inspectorGraph.nodes.find((n) => n.id === componentSelectedNode.id) ?? componentSelectedNode;
    }
    if (!selectedNodeId) return null;
    return inspectorGraph.nodes.find((n) => n.id === selectedNodeId) ?? null;
  }, [activeTab, componentSelectedNode, inspectorGraph, selectedNodeId]);

  const handleSelectNode = (nodeId: string) => {
    setSelectedNodeId(nodeId);
    const node = inspectorGraph.nodes.find((n) => n.id === nodeId);
    if (activeTab === 'components' && node) {
      setComponentSelectedNode(node);
    } else {
      setComponentSelectedNode(null);
    }
    if (node && node.label === 'BpelFile' && typeof node.properties.path === 'string') {
      const bpelPath = node.properties.path;
      setSelectedBpelPath(bpelPath);
      if (node.subProject) {
        setSelectedSubProject(node.subProject);
      }
    }
  };

  const counts = analysis?.counts ?? {
    subProjects: 0,
    bpelFiles: 0,
    deployXmls: 0,
    wsdlFiles: 0,
    xsdFiles: 0,
    externalServices: 0,
  };

  return (
    <div className="min-h-screen h-screen flex flex-col bg-[#042416] text-[#ecfdf5] overflow-hidden">
      <HeaderBar
        projectPath={projectPath}
        onProjectPathChange={setProjectPath}
        onAnalyze={() => void handleAnalyze()}
        onSyncNeo4j={() => void handleSyncNeo4j()}
        onOpenFolderPicker={() => setFolderPickerOpen(true)}
        onOpenNeo4jSettings={() => setNeo4jModalOpen(true)}
        analyzing={analyzing}
        syncing={syncing}
        neo4jConfig={neo4jConfig}
        neo4jStatus={neo4jStatus}
      />

      {/* Summary KPI & Status Strip */}
      <section className="bg-[#052b1b] border-b border-[#145338] px-5 py-2 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex flex-wrap items-center gap-4">
          <span>
            <strong className="text-sm text-[#fde047]">{counts.subProjects}</strong>{' '}
            <span className="text-[#a7f3d0]/80">Sub-Projects</span>
          </span>
          <span className="text-[#166544]">|</span>
          <span>
            <strong className="text-sm text-[#facc15]">{counts.bpelFiles}</strong>{' '}
            <span className="text-[#a7f3d0]/80">BPEL Files</span>
          </span>
          <span>
            <strong className="text-sm text-orange-400">{counts.deployXmls}</strong>{' '}
            <span className="text-[#a7f3d0]/80">deploy.xml</span>
          </span>
          <span>
            <strong className="text-sm text-[#4ade80]">{counts.wsdlFiles}</strong>{' '}
            <span className="text-[#a7f3d0]/80">WSDL Files</span>
          </span>
          <span>
            <strong className="text-sm text-teal-300">{counts.xsdFiles}</strong>{' '}
            <span className="text-[#a7f3d0]/80">XSD Schemas</span>
          </span>
          <span>
            <strong className="text-sm text-rose-400">{counts.externalServices}</strong>{' '}
            <span className="text-[#a7f3d0]/80">External Services</span>
          </span>
        </div>

        <div className={`text-xs truncate max-w-xl ${errorMessage ? 'text-rose-300 font-medium' : 'text-[#fde047]'}`}>
          {errorMessage ?? statusMessage}
        </div>
      </section>

      {/* Main 3-Pane Workspace */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 min-h-0 overflow-hidden">
        <div className="lg:col-span-3 min-h-0 overflow-hidden">
          <SubProjectExplorer
            subProjects={analysis?.subProjects ?? []}
            reports={analysis?.reports ?? []}
            selectedSubProject={selectedSubProject}
            selectedBpelPath={selectedBpelPath}
            categoryFilter={categoryFilter}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onCategoryFilterChange={setCategoryFilter}
            onSelectSubProject={setSelectedSubProject}
            onSelectBpel={(spId, bpelRel) => {
              setSelectedSubProject(spId);
              setSelectedBpelPath(bpelRel);
              setSelectedNodeId(`bpel:${bpelRel}`);
            }}
          />
        </div>

        <main className="lg:col-span-6 bg-[#042416] flex flex-col min-w-0 min-h-0 overflow-hidden">
          {/* Tabs Header */}
          <div className="bg-[#063320] border-b border-[#145338] px-4 pt-2 flex items-center justify-between gap-2 flex-wrap shrink-0">
            <div className="flex items-center gap-1">
              {(
                [
                  ['graph', 'Neo4j Graph (Interactive)'],
                  ['components', 'BPEL Component View'],
                  ['browser', 'Embedded Neo4j Browser'],
                  ['deps', 'Dependencies Table'],
                  ['blueprint', 'Reactor Blueprint'],
                ] as const
              ).map(([tabId, label]) => {
                const active = activeTab === tabId;
                return (
                  <button
                    key={tabId}
                    type="button"
                    onClick={() => setActiveTab(tabId)}
                    className={
                      active
                        ? 'px-3 py-2 text-xs font-semibold border-b-2 border-[#facc15] text-[#fde047] cursor-pointer'
                        : 'px-3 py-2 text-xs font-medium border-b-2 border-transparent text-[#a7f3d0]/80 hover:text-[#fef08a] cursor-pointer'
                    }
                  >
                    {label}
                  </button>
                );
              })}
            </div>

            {activeTab === 'graph' && (
              <div className="pb-1.5 flex items-center gap-1.5 text-xs">
                <span className="text-[#a7f3d0]/75">Scope:</span>
                <select
                  value={graphScope}
                  onChange={(e) => setGraphScope(e.target.value as GraphScope)}
                  className="bg-[#042014] border border-[#1b6e4a] rounded px-2 py-1 text-xs text-[#ecfdf5] focus:outline-none focus:border-[#facc15]"
                >
                  <option value="ALL">Entire Java Project</option>
                  <option value="SUBPROJECT">Selected Sub-Project</option>
                  <option value="BPEL">Selected BPEL Only</option>
                </select>
              </div>
            )}
          </div>

          {activeTab === 'graph' && (
            <InteractiveGraph
              graph={analysis?.graph ?? EMPTY_GRAPH}
              liveGraph={liveGraph}
              scope={graphScope}
              selectedSubProject={selectedSubProject}
              selectedBpelPath={selectedBpelPath}
              selectedNodeId={selectedNodeId}
              selectedProcessName={selectedReport?.processName ?? null}
              onSelectNode={handleSelectNode}
              onExecuteLiveCypher={handleRunLiveCypher}
              onClearLiveGraph={() => setLiveGraph(null)}
              runningCypher={runningCypher}
              neo4jConnected={neo4jStatus?.connected ?? false}
            />
          )}

          {activeTab === 'components' && (
            <BpelComponentExplorer
              reports={analysis?.reports ?? []}
              projectGraph={analysis?.graph ?? EMPTY_GRAPH}
              selectedBpelPath={selectedBpelPath}
              selectedNodeId={selectedNodeId}
              neo4jConfig={neo4jConfig}
              neo4jConnected={neo4jStatus?.connected ?? false}
              onSelectNode={(node, ctxGraph) => {
                setSelectedNodeId(node.id);
                setComponentSelectedNode(node);
                setComponentInspectorGraph(ctxGraph);
              }}
              onSelectBpelPath={(bpelPath) => {
                setSelectedBpelPath(bpelPath);
              }}
            />
          )}

          {activeTab === 'browser' && (
            <EmbeddedNeo4jBrowser
              browserUrl={neo4jConfig.browserUrl}
              selectedProcessName={selectedReport?.processName ?? null}
              cypherScript={analysis?.cypherScript ?? ''}
              grassStyle={analysis?.grassStyle ?? ''}
            />
          )}

          {activeTab === 'deps' && <DependenciesView report={selectedReport} />}

          {activeTab === 'blueprint' && <BlueprintView report={selectedReport} />}
        </main>

        <div className="lg:col-span-3 min-h-0 overflow-hidden">
          <NodeInspector
            selectedNode={selectedNode}
            allNodes={inspectorGraph.nodes}
            allEdges={inspectorGraph.edges}
            onJumpToNode={handleSelectNode}
          />
        </div>
      </div>

      <FolderPickerModal
        open={folderPickerOpen}
        initialPath={projectPath}
        onClose={() => setFolderPickerOpen(false)}
        onSelect={(selectedPath) => {
          setProjectPath(selectedPath);
          void handleAnalyze(selectedPath);
        }}
      />

      <Neo4jSettingsModal
        open={neo4jModalOpen}
        config={neo4jConfig}
        onChange={setNeo4jConfig}
        onStatusUpdate={setNeo4jStatus}
        onClose={() => setNeo4jModalOpen(false)}
      />
    </div>
  );
}
