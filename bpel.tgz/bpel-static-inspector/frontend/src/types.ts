export type MigrationCategory =
  | 'STATELESS_PIPELINE'
  | 'STATEFUL_ASYNC'
  | 'SAGA_COMPENSATING';

export type NodeLabel =
  | 'BpelFile'
  | 'DeployXml'
  | 'WsdlFile'
  | 'XsdFile'
  | 'ExternalService'
  | 'BpelActivity'
  | 'BpelPartnerLink'
  | 'BpelVariable'
  | 'BpelCorrelationSet'
  | string;

export interface QNameLike {
  namespaceURI?: string;
  localPart?: string;
  prefix?: string;
}

export interface ServiceBindingRef {
  partnerLink: string;
  serviceName: QNameLike | string;
  portName: string;
  wsdlFile: string | null;
  wsdlRelativePath: string | null;
}

export interface DeployDependency {
  file: string;
  relativePath: string;
  inMemory: boolean;
  providedServices: ServiceBindingRef[];
  invokedServices: ServiceBindingRef[];
}

export interface WsdlDependency {
  file: string;
  relativePath: string;
  targetNamespace: string;
  reasons: string[];
  importedWsdlRelativePaths: string[];
  referencedXsdRelativePaths: string[];
}

export interface XsdDependency {
  file: string;
  relativePath: string;
  targetNamespace: string;
  reasons: string[];
  importedXsdRelativePaths: string[];
}

export interface ProcessDependencies {
  deployXml: DeployDependency | null;
  wsdlFiles: WsdlDependency[];
  xsdFiles: XsdDependency[];
}

export interface PayloadFieldSpec {
  fieldName: string;
  xpathPath: string;
  javaType: string;
  required: boolean;
  isCollection: boolean;
  usedByBpel: boolean;
  children: PayloadFieldSpec[];
}

export interface Touchpoint {
  direction: 'EXTERNAL_TO_ODE' | 'ODE_TO_EXTERNAL';
  style:
    | 'INBOUND_TRIGGER'
    | 'INBOUND_CALLBACK'
    | 'OUTBOUND_SYNC'
    | 'OUTBOUND_ONEWAY'
    | 'OUTBOUND_REPLY';
  partnerLink: string;
  portType: QNameLike | string;
  operation: string;
  inputPayloadSchema: QNameLike | string | null;
  outputPayloadSchema: QNameLike | string | null;
  activeInputXPaths: string[];
  activeOutputXPaths: string[];
  inputDtoTree: PayloadFieldSpec[];
  outputDtoTree: PayloadFieldSpec[];
}

export interface ReactorBlueprint {
  suggestedRestControllerPath: string;
  reactiveReturnSignature: string;
  requiredReactorOperators: string[];
  architecturalNotes: string[];
}

export interface ExplanationStep {
  stepNumber: number;
  activityId: string;
  kind: string;
  title: string;
  detail: string;
}

export interface BpelExplanation {
  summary: string;
  triggerDescription: string;
  deploymentSummary: string;
  steps: ExplanationStep[];
  handlerSummaries: string[];
  keyObservations: string[];
}

export interface ComponentNode {
  id: string;
  label: NodeLabel;
  kind: string;
  name: string;
  parentActivityId: string | null;
  properties: Record<string, unknown>;
}

export interface ComponentEdge {
  id: string;
  source: string;
  target: string;
  type: string;
  properties: Record<string, unknown>;
}

export interface BpelComponentGraph {
  explanation: BpelExplanation;
  nodes: ComponentNode[];
  edges: ComponentEdge[];
}

export interface ProcessAuditReport {
  processName: string;
  targetNamespace: string;
  sourceFile: string;
  relativeSourcePath: string;
  category: MigrationCategory;
  deployedInMemory: boolean;
  dependencies: ProcessDependencies | null;
  components: BpelComponentGraph | null;
  reactorBlueprint: ReactorBlueprint;
  touchpoints: Touchpoint[];
  mermaidSequenceDiagram: string;
}

export interface GraphNode {
  id: string;
  label: NodeLabel;
  name: string;
  subProject: string;
  properties: Record<string, unknown>;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  type: string;
  properties: Record<string, unknown>;
}

export interface GraphData {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface SubProjectSummary {
  id: string;
  name: string;
  relativePath: string;
  bpelRelativePaths: string[];
  bpelCount: number;
  wsdlCount: number;
  deployXmlCount: number;
}

export interface SummaryCounts {
  subProjects: number;
  bpelFiles: number;
  deployXmls: number;
  wsdlFiles: number;
  xsdFiles: number;
  externalServices: number;
}

export interface ProjectAnalysisResult {
  rootDir: string;
  projectName: string;
  counts: SummaryCounts;
  subProjects: SubProjectSummary[];
  reports: ProcessAuditReport[];
  graph: GraphData;
  cypherScript: string;
  grassStyle: string;
}

export interface Neo4jConfig {
  uri: string;
  username: string;
  password: string;
  database: string;
  browserUrl: string;
  clearOnSync: boolean;
  includeComponents: boolean;
}

export interface Neo4jConnectionStatus {
  connected: boolean;
  uri: string;
  database: string;
  serverAgent: string;
  message: string;
}

export interface Neo4jSyncSummary {
  bpelCount: number;
  deployEdges: number;
  wsdlEdges: number;
  xsdEdges: number;
  crossProcessEdges: number;
  componentNodes: number;
  componentEdges: number;
}

export interface Neo4jQueryResult {
  nodes: GraphNode[];
  edges: GraphEdge[];
  rowCount: number;
  executionMs: number;
}

export interface DirectoryEntry {
  name: string;
  path: string;
  hasPom: boolean;
  hasBpel: boolean;
}

export interface BrowseResponse {
  currentPath: string;
  parentPath: string | null;
  directories: DirectoryEntry[];
}
