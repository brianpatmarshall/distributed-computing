package com.corev5.bpel.inspector.model.ast;

import java.util.Optional;

public record DataEndpoint(
        EndpointKind kind,
        Optional<String> variableName,
        Optional<String> partName,
        Optional<String> xpathQuery,
        boolean isSkeletonLiteral
) {
    public enum EndpointKind {
        VARIABLE_PART,
        EXPRESSION,
        LITERAL,
        PARTNER_LINK,
        UNKNOWN
    }
}
