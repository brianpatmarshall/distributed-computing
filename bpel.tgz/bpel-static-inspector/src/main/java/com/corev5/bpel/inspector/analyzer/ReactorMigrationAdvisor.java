package com.corev5.bpel.inspector.analyzer;

import com.corev5.bpel.inspector.model.ast.BpelActivity;
import com.corev5.bpel.inspector.model.ast.BpelActivity.*;
import com.corev5.bpel.inspector.model.ast.BpelProcess;
import com.corev5.bpel.inspector.model.report.ReactorBlueprint;

import java.util.*;

public final class ReactorMigrationAdvisor {

    public ReactorBlueprint advise(BpelProcess process) {
        Set<String> operators = new LinkedHashSet<>();
        List<String> notes = new ArrayList<>();

        if (process.hasProcessFaultHandlers()) {
            operators.add(".onErrorResume(...) replacing BPEL <faultHandlers>");
        }
        if (process.hasProcessEventHandlers()) {
            operators.add("External Callback Endpoint + Correlation Store");
        }

        boolean hasReply = inspectNode(process.rootActivity(), operators, notes);
        for (BpelActivity handler : process.processHandlerActivities()) {
            hasReply |= inspectNode(handler, operators, notes);
        }
        boolean hasAsyncWaitOrCallback = operators.contains("External Callback Endpoint + Correlation Store")
                || operators.contains("Mono.delay(Duration) or persisted timer")
                || operators.contains("Mono.timeout(Duration) / scheduled deadline handler");

        String kebabName = process.processName()
                .replaceAll("([a-z])([A-Z])", "$1-$2")
                .toLowerCase();

        String restPath = "/api/v1/" + kebabName;
        String returnSig = hasReply && !hasAsyncWaitOrCallback
                ? "Mono<ResponseEntity<" + process.processName() + "Response>>"
                : "Mono<ResponseEntity<Void>> (202 Accepted)";

        if (!hasAsyncWaitOrCallback) {
            notes.add("100% non-blocking Reactor pipeline: replace JBoss/ODE deployment with a stateless Spring WebFlux @RestController + WebClient.");
        } else {
            notes.add("Contains mid-flight <receive>/<pick>/<wait>: return 202 Accepted on entry, persist state by correlation key, and expose a REST webhook/callback endpoint to resume.");
        }

        return new ReactorBlueprint(
                restPath,
                returnSig,
                List.copyOf(operators),
                List.copyOf(notes)
        );
    }

    private boolean inspectNode(BpelActivity node, Set<String> operators, List<String> notes) {
        return switch (node) {
            case ReceiveNode rec -> {
                if (rec.createInstance()) {
                    operators.add("WebFlux @PostMapping entry point (" + rec.operation() + ")");
                } else {
                    operators.add("External Callback Endpoint + Correlation Store");
                }
                yield false;
            }
            case ReplyNode _ -> {
                operators.add("Mono<ResponseEntity<T>> synchronous HTTP reply");
                yield true;
            }
            case InvokeNode inv -> {
                if (inv.isSynchronous()) {
                    operators.add("WebClient REST call -> .flatMap() (" + inv.partnerLink() + "." + inv.operation() + ")");
                } else {
                    operators.add("Fire-and-forget WebClient call -> .then() (" + inv.partnerLink() + "." + inv.operation() + ")");
                }
                yield false;
            }
            case FlowNode flow -> {
                operators.add("Mono.zip(...) for parallel <flow> fan-out/join");
                if (flow.hasLinks()) {
                    notes.add("<flow> uses <links> transitionConditions: model DAG dependencies using dependent Mono chains before Mono.zip.");
                }
                boolean replied = false;
                for (BpelActivity branch : flow.branches()) {
                    replied |= inspectNode(branch, operators, notes);
                }
                yield replied;
            }
            case LoopNode loop -> {
                if (loop.parallel()) {
                    operators.add("Flux.fromIterable(...).flatMap(...) (parallel scatter-gather)");
                } else {
                    operators.add("Flux.fromIterable(...).concatMap(...) (sequential iteration)");
                }
                yield inspectNode(loop.body(), operators, notes);
            }
            case IfNode ifNode -> {
                operators.add("Mono.defer / conditional branching");
                boolean replied = false;
                for (ConditionalBranch b : ifNode.branches()) {
                    replied |= inspectNode(b.activity(), operators, notes);
                }
                yield replied;
            }
            case PickNode pick -> {
                if (!pick.createInstance()) {
                    operators.add("External Callback Endpoint + Correlation Store");
                }
                if (!pick.onAlarms().isEmpty()) {
                    operators.add("Mono.timeout(Duration) / scheduled deadline handler");
                }
                boolean replied = false;
                for (OnMessageBranch m : pick.onMessages()) {
                    replied |= inspectNode(m.activity(), operators, notes);
                }
                for (OnAlarmBranch a : pick.onAlarms()) {
                    replied |= inspectNode(a.activity(), operators, notes);
                }
                yield replied;
            }
            case WaitNode _ -> {
                operators.add("Mono.delay(Duration) or persisted timer");
                yield false;
            }
            case ScopeNode scope -> {
                if (scope.hasFaultHandlers()) {
                    operators.add(".onErrorResume(...) replacing BPEL <faultHandlers>");
                }
                if (scope.hasCompensationHandler()) {
                    operators.add("Explicit Saga compensation rollback chain");
                }
                boolean replied = inspectNode(scope.primaryActivity(), operators, notes);
                for (BpelActivity h : scope.handlerActivities()) {
                    replied |= inspectNode(h, operators, notes);
                }
                yield replied;
            }
            case SequenceNode seq -> {
                boolean replied = false;
                for (BpelActivity step : seq.steps()) {
                    replied |= inspectNode(step, operators, notes);
                }
                yield replied;
            }
            default -> false;
        };
    }
}
