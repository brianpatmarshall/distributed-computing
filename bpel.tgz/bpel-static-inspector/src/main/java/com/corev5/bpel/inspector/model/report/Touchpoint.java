package com.corev5.bpel.inspector.model.report;

import javax.xml.namespace.QName;
import java.util.List;
import java.util.Optional;

public record Touchpoint(
        Direction direction,
        InteractionStyle style,
        String partnerLink,
        QName portType,
        String operation,
        Optional<QName> inputPayloadSchema,
        Optional<QName> outputPayloadSchema,
        List<String> activeInputXPaths,
        List<String> activeOutputXPaths,
        List<PayloadFieldSpec> inputDtoTree,
        List<PayloadFieldSpec> outputDtoTree
) {
    public enum Direction { EXTERNAL_TO_ODE, ODE_TO_EXTERNAL }
    public enum InteractionStyle {
        INBOUND_TRIGGER,
        INBOUND_CALLBACK,
        OUTBOUND_SYNC,
        OUTBOUND_ONEWAY,
        OUTBOUND_REPLY
    }
}
