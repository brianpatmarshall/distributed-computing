package com.corev5.bpel.inspector.parser;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class XmlDomUtils {

    private XmlDomUtils() {}

    public static Document parseDocument(Path path) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            return factory.newDocumentBuilder().parse(path.toFile());
        } catch (Exception e) {
            throw new IllegalStateException("Failed to parse XML file: " + path, e);
        }
    }

    public static QName resolveQName(Element contextElement, String rawQName) {
        if (rawQName == null || rawQName.isBlank()) {
            return new QName("");
        }
        int colonIdx = rawQName.indexOf(':');
        if (colonIdx < 0) {
            String defaultNs = contextElement.lookupNamespaceURI(null);
            return new QName(defaultNs != null ? defaultNs : "", rawQName);
        }
        String prefix = rawQName.substring(0, colonIdx);
        String localPart = rawQName.substring(colonIdx + 1);
        String namespaceUri = contextElement.lookupNamespaceURI(prefix);
        return new QName(namespaceUri != null ? namespaceUri : "", localPart, prefix);
    }

    public static List<Element> childElements(Element parent) {
        List<Element> children = new ArrayList<>();
        NodeList nodes = parent.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i) instanceof Element el) {
                children.add(el);
            }
        }
        return children;
    }

    public static Optional<Element> firstChildElement(Element parent, String namespaceUri, String localName) {
        NodeList nodes = parent.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            if (nodes.item(i) instanceof Element el
                    && namespaceUri.equals(el.getNamespaceURI())
                    && localName.equals(el.getLocalName())) {
                return Optional.of(el);
            }
        }
        return Optional.empty();
    }

    public static Optional<String> childText(Element parent, String namespaceUri, String localName) {
        return firstChildElement(parent, namespaceUri, localName)
                .map(Node::getTextContent)
                .map(String::trim)
                .filter(s -> !s.isEmpty());
    }
}
