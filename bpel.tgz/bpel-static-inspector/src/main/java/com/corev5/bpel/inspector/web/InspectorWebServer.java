package com.corev5.bpel.inspector.web;

import com.corev5.bpel.inspector.renderer.Neo4jGraphPublisher;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.stream.Stream;

/**
 * Lightweight embedded HTTP server exposing the BPEL Static Inspector REST API,
 * live Neo4j Bolt bridge, Neo4j Browser iframe reverse proxy (stripping X-Frame-Options),
 * and optional static hosting of the built React frontend (frontend/dist).
 */
public final class InspectorWebServer {

    private final int port;
    private final Path staticDir;
    private final String neo4jBrowserUpstream;
    private final ProjectInspectionService inspectionService = new ProjectInspectionService();
    private final Neo4jQueryService neo4jQueryService = new Neo4jQueryService();
    private final Map<String, ProjectAnalysisResult> analysisCache = new ConcurrentHashMap<>();
    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new Jdk8Module())
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .enable(SerializationFeature.INDENT_OUTPUT);
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    private HttpServer server;

    public InspectorWebServer(int port, Path staticDir, String neo4jBrowserUpstream) {
        this.port = port;
        this.staticDir = staticDir;
        this.neo4jBrowserUpstream = (neo4jBrowserUpstream == null || neo4jBrowserUpstream.isBlank())
                ? "http://localhost:7474"
                : neo4jBrowserUpstream.replaceAll("/+$", "");
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        server.setExecutor(Executors.newVirtualThreadPerTaskExecutor());

        server.createContext("/api/health", this::handleHealth);
        server.createContext("/api/analyze", this::handleAnalyze);
        server.createContext("/api/fs/browse", this::handleBrowse);
        server.createContext("/api/neo4j/test", this::handleNeo4jTest);
        server.createContext("/api/neo4j/sync", this::handleNeo4jSync);
        server.createContext("/api/neo4j/query", this::handleNeo4jQuery);
        server.createContext("/api/neo4j/expand-bpel", this::handleNeo4jExpandBpel);
        server.createContext("/neo4j-browser", this::handleNeo4jBrowserProxy);
        server.createContext("/", this::handleStaticFrontend);

        server.start();
    }

    public int getPort() {
        return server != null ? server.getAddress().getPort() : port;
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
    }

    private void handleHealth(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        sendJson(ex, 200, Map.of(
                "status", "ok",
                "neo4jBrowserUpstream", neo4jBrowserUpstream,
                "cwd", Path.of("").toAbsolutePath().normalize().toString()
        ));
    }

    private void handleAnalyze(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            sendJson(ex, 405, Map.of("error", "Method not allowed"));
            return;
        }
        try {
            record AnalyzeReq(String projectPath) {}
            AnalyzeReq req = readJson(ex, AnalyzeReq.class);
            if (req == null || req.projectPath() == null || req.projectPath().isBlank()) {
                sendJson(ex, 400, Map.of("error", "projectPath is required"));
                return;
            }
            Path path = Path.of(req.projectPath()).toAbsolutePath().normalize();
            ProjectAnalysisResult result = inspectionService.inspectProject(path);
            analysisCache.put(path.toString(), result);
            sendJson(ex, 200, result);
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, Map.of("error", e.getMessage()));
        } catch (Exception e) {
            sendJson(ex, 500, Map.of("error", "Analysis failed: " + e.getMessage()));
        }
    }

    private void handleBrowse(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        try {
            Map<String, String> query = parseQuery(ex.getRequestURI().getRawQuery());
            String rawPath = query.getOrDefault("path", System.getProperty("user.home", "."));
            Path dir = Path.of(rawPath).toAbsolutePath().normalize();
            if (!Files.isDirectory(dir)) {
                sendJson(ex, 400, Map.of("error", "Not a directory: " + dir));
                return;
            }

            record DirEntry(String name, String path, boolean hasPom, boolean hasBpel) {}
            List<DirEntry> entries = new ArrayList<>();
            try (Stream<Path> list = Files.list(dir)) {
                list.filter(Files::isDirectory)
                        .filter(p -> !p.getFileName().toString().startsWith("."))
                        .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                        .limit(200)
                        .forEach(sub -> {
                            boolean hasPom = Files.isRegularFile(sub.resolve("pom.xml"))
                                    || Files.isRegularFile(sub.resolve("build.gradle"));
                            boolean hasBpel = hasBpelShallow(sub);
                            entries.add(new DirEntry(sub.getFileName().toString(), sub.toString(), hasPom, hasBpel));
                        });
            }

            Map<String, Object> resp = new LinkedHashMap<>();
            resp.put("currentPath", dir.toString());
            resp.put("parentPath", dir.getParent() != null ? dir.getParent().toString() : null);
            resp.put("directories", entries);
            sendJson(ex, 200, resp);
        } catch (Exception e) {
            sendJson(ex, 500, Map.of("error", "Browse failed: " + e.getMessage()));
        }
    }

    private boolean hasBpelShallow(Path dir) {
        try (Stream<Path> walk = Files.walk(dir, 3)) {
            return walk.filter(Files::isRegularFile).anyMatch(p -> p.toString().endsWith(".bpel"));
        } catch (Exception e) {
            return false;
        }
    }

    private void handleNeo4jTest(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            sendJson(ex, 405, Map.of("error", "Method not allowed"));
            return;
        }
        try {
            Neo4jQueryService.Neo4jConfig config = readJson(ex, Neo4jQueryService.Neo4jConfig.class);
            if (config == null || config.uri() == null || config.uri().isBlank()) {
                sendJson(ex, 400, Map.of("error", "Neo4j uri is required"));
                return;
            }
            sendJson(ex, 200, neo4jQueryService.testConnection(config));
        } catch (Exception e) {
            sendJson(ex, 500, Map.of("error", e.getMessage()));
        }
    }

    private void handleNeo4jSync(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            sendJson(ex, 405, Map.of("error", "Method not allowed"));
            return;
        }
        try {
            record SyncReq(String projectPath, boolean clearExisting, Boolean includeComponents, Neo4jQueryService.Neo4jConfig neo4j) {}
            SyncReq req = readJson(ex, SyncReq.class);
            if (req == null || req.projectPath() == null || req.neo4j() == null) {
                sendJson(ex, 400, Map.of("error", "projectPath and neo4j config are required"));
                return;
            }
            Path norm = Path.of(req.projectPath()).toAbsolutePath().normalize();
            ProjectAnalysisResult result = analysisCache.get(norm.toString());
            if (result == null) {
                result = inspectionService.inspectProject(norm);
                analysisCache.put(norm.toString(), result);
            }
            boolean includeComponents = req.includeComponents() == null || req.includeComponents();
            Neo4jGraphPublisher.PublishSummary summary = neo4jQueryService.publish(
                    req.neo4j(), result.reports(), req.clearExisting(), includeComponents
            );
            sendJson(ex, 200, summary);
        } catch (Exception e) {
            sendJson(ex, 500, Map.of("error", "Neo4j sync failed: " + e.getMessage()));
        }
    }

    private void handleNeo4jExpandBpel(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            sendJson(ex, 405, Map.of("error", "Method not allowed"));
            return;
        }
        try {
            record ExpandReq(String bpelPath, Neo4jQueryService.Neo4jConfig neo4j) {}
            ExpandReq req = readJson(ex, ExpandReq.class);
            if (req == null || req.bpelPath() == null || req.bpelPath().isBlank() || req.neo4j() == null) {
                sendJson(ex, 400, Map.of("error", "bpelPath and neo4j config are required"));
                return;
            }
            Neo4jQueryService.QueryResult result = neo4jQueryService.expandBpelComponents(req.neo4j(), req.bpelPath());
            sendJson(ex, 200, result);
        } catch (Exception e) {
            sendJson(ex, 500, Map.of("error", "Neo4j expand failed: " + e.getMessage()));
        }
    }

    private void handleNeo4jQuery(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            sendJson(ex, 405, Map.of("error", "Method not allowed"));
            return;
        }
        try {
            record QueryReq(String cypher, Neo4jQueryService.Neo4jConfig neo4j) {}
            QueryReq req = readJson(ex, QueryReq.class);
            if (req == null || req.cypher() == null || req.cypher().isBlank() || req.neo4j() == null) {
                sendJson(ex, 400, Map.of("error", "cypher and neo4j config are required"));
                return;
            }
            Neo4jQueryService.QueryResult result = neo4jQueryService.executeReadQuery(req.neo4j(), req.cypher());
            sendJson(ex, 200, result);
        } catch (Exception e) {
            sendJson(ex, 500, Map.of("error", "Cypher query failed: " + e.getMessage()));
        }
    }

    private void handleNeo4jBrowserProxy(HttpExchange ex) throws IOException {
        if (handleCorsPreflight(ex)) return;
        String rawPath = ex.getRequestURI().getRawPath();
        String suffix = rawPath.substring("/neo4j-browser".length());
        if (suffix.isEmpty() || "/".equals(suffix)) {
            suffix = "/browser/";
        }
        String query = ex.getRequestURI().getRawQuery();
        String targetUrl = neo4jBrowserUpstream + suffix + (query != null ? "?" + query : "");

        try {
            HttpRequest.Builder reqBuilder = HttpRequest.newBuilder()
                    .uri(URI.create(targetUrl))
                    .timeout(Duration.ofSeconds(10));
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                byte[] body = ex.getRequestBody().readAllBytes();
                reqBuilder.POST(HttpRequest.BodyPublishers.ofByteArray(body));
            } else {
                reqBuilder.GET();
            }
            HttpResponse<byte[]> upstreamResp = httpClient.send(reqBuilder.build(), HttpResponse.BodyHandlers.ofByteArray());

            Headers outHeaders = ex.getResponseHeaders();
            upstreamResp.headers().map().forEach((k, values) -> {
                String lower = k.toLowerCase();
                // Strip framing restrictions so Neo4j Browser renders smoothly in an embedded <iframe>
                if (lower.equals("x-frame-options")
                        || lower.equals("content-security-policy")
                        || lower.equals("transfer-encoding")
                        || lower.equals("content-length")
                        || lower.equals("connection")) {
                    return;
                }
                for (String v : values) {
                    outHeaders.add(k, v);
                }
            });
            byte[] bytes = upstreamResp.body();
            ex.sendResponseHeaders(upstreamResp.statusCode(), bytes.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(bytes);
            }
        } catch (Exception e) {
            String html = """
                    <!DOCTYPE html>
                    <html><body style="background:#042416;color:#ecfdf5;font-family:sans-serif;padding:24px;">
                      <h3 style="color:#fde047;margin-top:0;">Neo4j Browser not reachable at %s</h3>
                      <p>Start Neo4j locally (default HTTP port 7474) or update the Neo4j Browser URL above.</p>
                      <pre style="background:#083c26;padding:12px;border-radius:8px;color:#fef08a;">%s</pre>
                    </body></html>
                    """.formatted(neo4jBrowserUpstream, e.getMessage());
            byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(502, bytes.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(bytes);
            }
        }
    }

    private void handleStaticFrontend(HttpExchange ex) throws IOException {
        if (staticDir == null || !Files.isDirectory(staticDir)) {
            sendJson(ex, 200, Map.of(
                    "service", "bpel-static-inspector-api",
                    "hint", "Start React frontend with `cd frontend && npm run dev`, or build it with `npm run build` to serve from here."
            ));
            return;
        }
        String reqPath = ex.getRequestURI().getPath();
        if (reqPath == null || reqPath.equals("/")) {
            reqPath = "/index.html";
        }
        Path candidate = staticDir.resolve(reqPath.substring(1)).toAbsolutePath().normalize();
        if (!candidate.startsWith(staticDir.toAbsolutePath().normalize()) || !Files.isRegularFile(candidate)) {
            candidate = staticDir.resolve("index.html");
        }
        if (!Files.isRegularFile(candidate)) {
            sendJson(ex, 404, Map.of("error", "Not found"));
            return;
        }
        byte[] bytes = Files.readAllBytes(candidate);
        ex.getResponseHeaders().set("Content-Type", guessContentType(candidate.toString()));
        ex.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private boolean handleCorsPreflight(HttpExchange ex) throws IOException {
        Headers h = ex.getResponseHeaders();
        h.set("Access-Control-Allow-Origin", "*");
        h.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        h.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
        if ("OPTIONS".equalsIgnoreCase(ex.getRequestMethod())) {
            ex.sendResponseHeaders(204, -1);
            return true;
        }
        return false;
    }

    private <T> T readJson(HttpExchange ex, Class<T> type) throws IOException {
        try (InputStream is = ex.getRequestBody()) {
            return mapper.readValue(is, type);
        }
    }

    private void sendJson(HttpExchange ex, int status, Object body) throws IOException {
        byte[] bytes = mapper.writeValueAsBytes(body);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private Map<String, String> parseQuery(String rawQuery) {
        Map<String, String> map = new HashMap<>();
        if (rawQuery == null || rawQuery.isBlank()) {
            return map;
        }
        for (String pair : rawQuery.split("&")) {
            int idx = pair.indexOf('=');
            if (idx > 0) {
                String key = URLDecoder.decode(pair.substring(0, idx), StandardCharsets.UTF_8);
                String val = URLDecoder.decode(pair.substring(idx + 1), StandardCharsets.UTF_8);
                map.put(key, val);
            }
        }
        return map;
    }

    private String guessContentType(String file) {
        if (file.endsWith(".html")) return "text/html; charset=utf-8";
        if (file.endsWith(".js")) return "application/javascript; charset=utf-8";
        if (file.endsWith(".css")) return "text/css; charset=utf-8";
        if (file.endsWith(".svg")) return "image/svg+xml";
        if (file.endsWith(".json")) return "application/json; charset=utf-8";
        if (file.endsWith(".png")) return "image/png";
        return "application/octet-stream";
    }

    public static void main(String[] args) throws Exception {
        int port = 8080;
        String neo4jHttp = "http://localhost:7474";
        for (int i = 0; i < args.length; i++) {
            if ("--port".equals(args[i]) && i + 1 < args.length) {
                port = Integer.parseInt(args[++i]);
            } else if ("--neo4j-http".equals(args[i]) && i + 1 < args.length) {
                neo4jHttp = args[++i];
            }
        }
        Path dist = Path.of("frontend/dist").toAbsolutePath().normalize();
        InspectorWebServer webServer = new InspectorWebServer(port, dist, neo4jHttp);
        webServer.start();
        System.out.printf("BPEL Static Inspector API running at http://localhost:%d (Neo4j Browser proxy -> %s)%n",
                webServer.getPort(), neo4jHttp);
        Thread.currentThread().join();
    }
}
