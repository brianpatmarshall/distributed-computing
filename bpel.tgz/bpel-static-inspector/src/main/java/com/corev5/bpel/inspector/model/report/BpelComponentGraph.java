package com.corev5.bpel.inspector.model.report;

import java.util.List;
import java.util.Map;

public record BpelComponentGraph(
        BpelExplanation explanation,
        List<ComponentNode> nodes,
        List<ComponentEdge> edges
) {
    public record BpelExplanation(
            String summary,
            String triggerDescription,
            String deploymentSummary,
            List<ExplanationStep> steps,
            List<String> handlerSummaries,
            List<String> keyObservations
    ) {}

    public record ExplanationStep(
            int stepNumber,
            String activityId,
            String kind,
            String title,
            String detail
    ) {}

    public record ComponentNode(
            String id,
            String label,
            String kind,
            String name,
            String parentActivityId,
            Map<String, Object> properties
    ) {}

    public record ComponentEdge(
            String id,
            String source,
            String target,
            String type,
            Map<String, Object> properties
    ) {}
}
