package com.corev5.bpel.inspector.model.report;

import java.util.List;

public record ReactorBlueprint(
        String suggestedRestControllerPath,
        String reactiveReturnSignature,
        List<String> requiredReactorOperators,
        List<String> architecturalNotes
) {}
