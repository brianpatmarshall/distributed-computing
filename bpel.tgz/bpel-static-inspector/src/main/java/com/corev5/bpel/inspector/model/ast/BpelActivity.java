package com.corev5.bpel.inspector.model.ast;

import javax.xml.namespace.QName;
import java.util.List;
import java.util.Optional;

public sealed interface BpelActivity permits
        BpelActivity.ReceiveNode,
        BpelActivity.ReplyNode,
        BpelActivity.InvokeNode,
        BpelActivity.PickNode,
        BpelActivity.AssignNode,
        BpelActivity.SequenceNode,
        BpelActivity.FlowNode,
        BpelActivity.IfNode,
        BpelActivity.LoopNode,
        BpelActivity.ScopeNode,
        BpelActivity.WaitNode,
        BpelActivity.ThrowNode,
        BpelActivity.CompensateNode,
        BpelActivity.EmptyNode {

    String name();

    record CorrelationRef(String setName, String initiate) {}

    record ReceiveNode(
            String name,
            String partnerLink,
            QName portType,
            String operation,
            String variable,
            boolean createInstance,
            List<CorrelationRef> correlations
    ) implements BpelActivity {}

    record ReplyNode(
            String name,
            String partnerLink,
            QName portType,
            String operation,
            String variable,
            Optional<QName> faultName
    ) implements BpelActivity {}

    record InvokeNode(
            String name,
            String partnerLink,
            QName portType,
            String operation,
            Optional<String> inputVariable,
            Optional<String> outputVariable,
            List<CorrelationRef> correlations
    ) implements BpelActivity {
        public boolean isSynchronous() {
            return outputVariable.isPresent();
        }
    }

    record OnMessageBranch(
            String partnerLink,
            QName portType,
            String operation,
            String variable,
            List<CorrelationRef> correlations,
            BpelActivity activity
    ) {}

    record OnAlarmBranch(String durationOrDeadlineExpr, BpelActivity activity) {}

    record PickNode(
            String name,
            boolean createInstance,
            List<OnMessageBranch> onMessages,
            List<OnAlarmBranch> onAlarms
    ) implements BpelActivity {}

    record AssignNode(String name, List<CopyOperation> copies) implements BpelActivity {}

    record SequenceNode(String name, List<BpelActivity> steps) implements BpelActivity {}

    record FlowNode(String name, List<BpelActivity> branches, boolean hasLinks) implements BpelActivity {}

    record ConditionalBranch(Optional<String> conditionExpr, BpelActivity activity) {}

    record IfNode(String name, List<ConditionalBranch> branches) implements BpelActivity {}

    record LoopNode(String name, String loopType, boolean parallel, BpelActivity body) implements BpelActivity {}

    record ScopeNode(
            String name,
            boolean hasFaultHandlers,
            boolean hasCompensationHandler,
            boolean hasEventHandlers,
            BpelActivity primaryActivity,
            List<BpelActivity> handlerActivities
    ) implements BpelActivity {}

    record WaitNode(String name, String durationOrDeadlineExpr) implements BpelActivity {}

    record ThrowNode(String name, Optional<QName> faultName) implements BpelActivity {}

    record CompensateNode(String name, Optional<String> targetScope) implements BpelActivity {}

    record EmptyNode(String name, String rawTag) implements BpelActivity {}
}
