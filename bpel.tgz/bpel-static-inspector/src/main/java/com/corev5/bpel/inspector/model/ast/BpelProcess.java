package com.corev5.bpel.inspector.model.ast;

import javax.xml.namespace.QName;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public record BpelProcess(
        Path sourceFile,
        String processName,
        String targetNamespace,
        List<ImportDecl> imports,
        Map<String, PartnerLinkDecl> partnerLinks,
        Map<String, VariableDecl> variables,
        List<String> correlationSets,
        boolean hasProcessFaultHandlers,
        boolean hasProcessEventHandlers,
        BpelActivity rootActivity,
        List<BpelActivity> processHandlerActivities
) {
    public record ImportDecl(
            String namespace,
            Optional<String> location,
            Optional<String> importType
    ) {}

    public record PartnerLinkDecl(
            String name,
            QName partnerLinkType,
            Optional<String> myRole,
            Optional<String> partnerRole
    ) {}

    public record VariableDecl(
            String name,
            Optional<QName> messageType,
            Optional<QName> elementType,
            Optional<QName> xmlType
    ) {}
}
