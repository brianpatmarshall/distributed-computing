package com.corev5.bpel.inspector.model.ast;

public record CopyOperation(
        DataEndpoint from,
        DataEndpoint to,
        boolean ignoreMissingFromData
) {}
