package com.corev5.bpel.inspector.renderer;

import com.corev5.bpel.inspector.model.report.ProcessAuditReport;
import com.corev5.bpel.inspector.model.report.Touchpoint;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class MermaidDiagramRenderer {

    public String renderSequence(String processName, List<Touchpoint> touchpoints) {
        var sb = new StringBuilder();
        sb.append("sequenceDiagram\n");
        sb.append("    participant ODE as ").append(sanitize(processName)).append("\n");

        Set<String> partners = new LinkedHashSet<>();
        for (Touchpoint tp : touchpoints) {
            partners.add(tp.partnerLink());
        }
        for (String partner : partners) {
            sb.append("    participant ").append(sanitize(partner)).append("\n");
        }

        for (Touchpoint tp : touchpoints) {
            String partner = sanitize(tp.partnerLink());
            String label = tp.operation() + " [" + tp.style().name() + "]";
            if (tp.direction() == Touchpoint.Direction.EXTERNAL_TO_ODE) {
                sb.append("    ").append(partner).append("->>ODE: ").append(label).append("\n");
            } else {
                String arrow = tp.style() == Touchpoint.InteractionStyle.OUTBOUND_ONEWAY ? "-->>" : "->>";
                sb.append("    ODE").append(arrow).append(partner).append(": ").append(label).append("\n");
                if (tp.style() == Touchpoint.InteractionStyle.OUTBOUND_SYNC) {
                    sb.append("    ").append(partner).append("-->>ODE: response\n");
                }
            }
        }
        return sb.toString();
    }

    public String renderGlobalContextGraph(List<ProcessAuditReport> reports) {
        var sb = new StringBuilder("flowchart LR\n");
        Set<String> edges = new LinkedHashSet<>();

        for (ProcessAuditReport report : reports) {
            String procId = "PROC_" + sanitize(report.processName());
            sb.append("    ").append(procId).append("[\"").append(report.processName())
              .append("\\n(").append(report.category()).append(")\"]\n");

            for (Touchpoint tp : report.touchpoints()) {
                String extId = "EXT_" + sanitize(tp.partnerLink());
                if (tp.direction() == Touchpoint.Direction.EXTERNAL_TO_ODE) {
                    edges.add("    " + extId + "([" + tp.partnerLink() + "]) -->|" + tp.operation() + "| " + procId);
                } else {
                    edges.add("    " + procId + " -->|" + tp.operation() + "| " + extId + "([" + tp.partnerLink() + "])");
                }
            }
        }
        edges.forEach(e -> sb.append(e).append("\n"));
        return sb.toString();
    }

    private String sanitize(String raw) {
        return raw.replaceAll("[^a-zA-Z0-9_]", "_");
    }
}
