package com.corev5.bpel.inspector.model.report;

public enum MigrationCategory {
    STATELESS_PIPELINE,
    STATEFUL_ASYNC,
    SAGA_COMPENSATING
}
