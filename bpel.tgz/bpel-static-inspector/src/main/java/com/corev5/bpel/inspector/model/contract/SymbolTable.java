package com.corev5.bpel.inspector.model.contract;

import org.apache.ws.commons.schema.XmlSchemaCollection;

import javax.xml.namespace.QName;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

public record SymbolTable(
        Path rootDir,
        Map<QName, PartnerLinkTypeDef> partnerLinkTypes,
        Map<QName, WsdlMessageDef> messages,
        Map<QName, WsdlPortTypeDef> portTypes,
        Map<QName, OdeDeploymentBinding> odeDeployments,
        Map<Path, WsdlFileDef> wsdlFiles,
        Map<QName, Path> serviceToWsdl,
        Map<Path, XsdFileDef> xsdFiles,
        Map<QName, Path> schemaElementToXsd,
        Map<QName, Path> schemaTypeToXsd,
        XmlSchemaCollection schemaCollection
) {
    public record PartnerLinkTypeDef(QName qName, Map<String, QName> roleToPortType, Path sourceFile) {}
    public record WsdlMessageDef(QName qName, Map<String, QName> partToElementOrType, Path sourceFile) {}
    public record WsdlPortTypeDef(QName qName, Map<String, OperationDef> operations, Path sourceFile) {}
    public record OperationDef(String name, QName inputMessage, QName outputMessage) {}

    public record WsdlFileDef(
            Path sourceFile,
            String targetNamespace,
            List<Path> importedWsdlFiles,
            List<Path> referencedXsdFiles,
            Map<QName, List<String>> services
    ) {}

    public record XsdFileDef(
            Path sourceFile,
            String targetNamespace,
            List<Path> importedXsdFiles
    ) {}

    public String toRelativePath(Path path) {
        Path normalized = path.toAbsolutePath().normalize();
        if (rootDir != null) {
            Path normalizedRoot = rootDir.toAbsolutePath().normalize();
            if (normalized.startsWith(normalizedRoot)) {
                return normalizedRoot.relativize(normalized).toString().replace('\\', '/');
            }
        }
        return normalized.toString().replace('\\', '/');
    }
}
