package com.corev5.bpel.inspector.model.report;

import java.util.List;

public record PayloadFieldSpec(
        String fieldName,
        String xpathPath,
        String javaType,
        boolean required,
        boolean isCollection,
        boolean usedByBpel,
        List<PayloadFieldSpec> children
) {}
