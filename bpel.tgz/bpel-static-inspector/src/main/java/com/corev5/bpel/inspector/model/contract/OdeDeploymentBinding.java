package com.corev5.bpel.inspector.model.contract;

import javax.xml.namespace.QName;
import java.nio.file.Path;
import java.util.Map;

public record OdeDeploymentBinding(
        QName processName,
        Path sourceFile,
        boolean inMemory,
        Map<String, EndpointRef> providedEndpoints,
        Map<String, EndpointRef> invokedEndpoints
) {
    public record EndpointRef(QName serviceName, String portName) {}
}
