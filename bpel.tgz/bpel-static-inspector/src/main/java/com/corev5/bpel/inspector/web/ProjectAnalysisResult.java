package com.corev5.bpel.inspector.web;

import com.corev5.bpel.inspector.model.report.ProcessAuditReport;

import java.util.List;
import java.util.Map;

public record ProjectAnalysisResult(
        String rootDir,
        String projectName,
        SummaryCounts counts,
        List<SubProjectSummary> subProjects,
        List<ProcessAuditReport> reports,
        GraphData graph,
        String cypherScript,
        String grassStyle
) {
    public record SummaryCounts(
            int subProjects,
            int bpelFiles,
            int deployXmls,
            int wsdlFiles,
            int xsdFiles,
            int externalServices
    ) {}

    public record SubProjectSummary(
            String id,
            String name,
            String relativePath,
            List<String> bpelRelativePaths,
            int bpelCount,
            int wsdlCount,
            int deployXmlCount
    ) {}

    public record GraphData(
            List<GraphNode> nodes,
            List<GraphEdge> edges
    ) {}

    public record GraphNode(
            String id,
            String label,
            String name,
            String subProject,
            Map<String, Object> properties
    ) {}

    public record GraphEdge(
            String id,
            String source,
            String target,
            String type,
            Map<String, Object> properties
    ) {}
}
