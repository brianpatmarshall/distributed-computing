package com.corev5.bpel.inspector.analyzer;

import com.corev5.bpel.inspector.model.ast.*;
import com.corev5.bpel.inspector.model.ast.BpelActivity.*;
import com.corev5.bpel.inspector.model.contract.OdeDeploymentBinding;
import com.corev5.bpel.inspector.model.contract.SymbolTable;
import com.corev5.bpel.inspector.model.report.*;
import com.corev5.bpel.inspector.renderer.MermaidDiagramRenderer;

import javax.xml.namespace.QName;
import java.util.*;

public final class ProcessAnalyzer {

    private final SymbolTable symbols;
    private final XsdPayloadResolver payloadResolver;
    private final DependencyResolver dependencyResolver;
    private final BpelComponentAnalyzer componentAnalyzer;
    private final ReactorMigrationAdvisor reactorAdvisor;
    private final MermaidDiagramRenderer mermaidRenderer;

    public ProcessAnalyzer(SymbolTable symbols) {
        this.symbols = symbols;
        this.payloadResolver = new XsdPayloadResolver(symbols);
        this.dependencyResolver = new DependencyResolver(symbols);
        this.componentAnalyzer = new BpelComponentAnalyzer();
        this.reactorAdvisor = new ReactorMigrationAdvisor();
        this.mermaidRenderer = new MermaidDiagramRenderer();
    }

    public ProcessAuditReport analyze(BpelProcess process) {
        boolean inMemory = dependencyResolver.findDeploymentBinding(process)
                .map(OdeDeploymentBinding::inMemory)
                .orElse(false);

        String relPath = symbols.toRelativePath(process.sourceFile());
        ProcessDependencies dependencies = dependencyResolver.resolve(process);

        Map<String, Set<String>> readXPathsByVar = new HashMap<>();
        Map<String, Set<String>> writtenXPathsByVar = new HashMap<>();
        collectDataLineage(process.rootActivity(), readXPathsByVar, writtenXPathsByVar);
        process.processHandlerActivities().forEach(h -> collectDataLineage(h, readXPathsByVar, writtenXPathsByVar));

        List<Touchpoint> touchpoints = new ArrayList<>();
        StateFlags flags = new StateFlags();
        if (process.hasProcessEventHandlers()) {
            flags.hasMidFlightWaitOrReceive = true;
        }
        walkActivities(process, process.rootActivity(), touchpoints, flags, readXPathsByVar, writtenXPathsByVar);
        process.processHandlerActivities().forEach(h ->
                walkActivities(process, h, touchpoints, flags, readXPathsByVar, writtenXPathsByVar));

        MigrationCategory category = classify(flags, inMemory);
        BpelComponentGraph components = componentAnalyzer.analyze(process, relPath, category, inMemory, dependencies);
        ReactorBlueprint blueprint = reactorAdvisor.advise(process);
        String sequenceDiagram = mermaidRenderer.renderSequence(process.processName(), touchpoints);

        return new ProcessAuditReport(
                process.processName(),
                process.targetNamespace(),
                process.sourceFile(),
                relPath,
                category,
                inMemory,
                dependencies,
                components,
                blueprint,
                List.copyOf(touchpoints),
                sequenceDiagram
        );
    }

    private void collectDataLineage(
            BpelActivity activity,
            Map<String, Set<String>> reads,
            Map<String, Set<String>> writes
    ) {
        switch (activity) {
            case AssignNode assign -> {
                for (CopyOperation copy : assign.copies()) {
                    if (!copy.from().isSkeletonLiteral() && copy.from().variableName().isPresent()) {
                        String var = copy.from().variableName().get();
                        String path = formatPartAndPath(copy.from());
                        reads.computeIfAbsent(var, _ -> new LinkedHashSet<>()).add(path);
                    }
                    if (copy.to().variableName().isPresent()) {
                        String var = copy.to().variableName().get();
                        String path = formatPartAndPath(copy.to());
                        writes.computeIfAbsent(var, _ -> new LinkedHashSet<>()).add(path);
                    }
                }
            }
            case SequenceNode seq -> seq.steps().forEach(s -> collectDataLineage(s, reads, writes));
            case FlowNode flow -> flow.branches().forEach(b -> collectDataLineage(b, reads, writes));
            case IfNode ifNode -> ifNode.branches().forEach(b -> collectDataLineage(b.activity(), reads, writes));
            case LoopNode loop -> collectDataLineage(loop.body(), reads, writes);
            case PickNode pick -> {
                pick.onMessages().forEach(m -> collectDataLineage(m.activity(), reads, writes));
                pick.onAlarms().forEach(a -> collectDataLineage(a.activity(), reads, writes));
            }
            case ScopeNode scope -> {
                collectDataLineage(scope.primaryActivity(), reads, writes);
                scope.handlerActivities().forEach(h -> collectDataLineage(h, reads, writes));
            }
            default -> {}
        }
    }

    private void walkActivities(
            BpelProcess process,
            BpelActivity activity,
            List<Touchpoint> touchpoints,
            StateFlags flags,
            Map<String, Set<String>> reads,
            Map<String, Set<String>> writes
    ) {
        switch (activity) {
            case ReceiveNode rec -> {
                if (!rec.createInstance()) {
                    flags.hasMidFlightWaitOrReceive = true;
                }
                Optional<QName> inSchema = resolveVarSchema(process, rec.variable());
                Set<String> activeIn = reads.getOrDefault(rec.variable(), Set.of());
                touchpoints.add(new Touchpoint(
                        Touchpoint.Direction.EXTERNAL_TO_ODE,
                        rec.createInstance()
                                ? Touchpoint.InteractionStyle.INBOUND_TRIGGER
                                : Touchpoint.InteractionStyle.INBOUND_CALLBACK,
                        rec.partnerLink(),
                        rec.portType(),
                        rec.operation(),
                        inSchema,
                        Optional.empty(),
                        List.copyOf(activeIn),
                        List.of(),
                        inSchema.map(q -> payloadResolver.resolvePayloadTree(q, activeIn)).orElse(List.of()),
                        List.of()
                ));
            }
            case ReplyNode rep -> {
                Optional<QName> outSchema = resolveVarSchema(process, rep.variable());
                Set<String> activeOut = writes.getOrDefault(rep.variable(), Set.of());
                touchpoints.add(new Touchpoint(
                        Touchpoint.Direction.ODE_TO_EXTERNAL,
                        Touchpoint.InteractionStyle.OUTBOUND_REPLY,
                        rep.partnerLink(),
                        rep.portType(),
                        rep.operation(),
                        Optional.empty(),
                        outSchema,
                        List.of(),
                        List.copyOf(activeOut),
                        List.of(),
                        outSchema.map(q -> payloadResolver.resolvePayloadTree(q, activeOut)).orElse(List.of())
                ));
            }
            case InvokeNode inv -> {
                String inVar = inv.inputVariable().orElse("");
                String outVar = inv.outputVariable().orElse("");
                Optional<QName> inSchema = resolveVarSchema(process, inVar);
                Optional<QName> outSchema = resolveVarSchema(process, outVar);
                Set<String> activeIn = writes.getOrDefault(inVar, Set.of());
                Set<String> activeOut = reads.getOrDefault(outVar, Set.of());

                touchpoints.add(new Touchpoint(
                        Touchpoint.Direction.ODE_TO_EXTERNAL,
                        inv.isSynchronous()
                                ? Touchpoint.InteractionStyle.OUTBOUND_SYNC
                                : Touchpoint.InteractionStyle.OUTBOUND_ONEWAY,
                        inv.partnerLink(),
                        inv.portType(),
                        inv.operation(),
                        inSchema,
                        outSchema,
                        List.copyOf(activeIn),
                        List.copyOf(activeOut),
                        inSchema.map(q -> payloadResolver.resolvePayloadTree(q, activeIn)).orElse(List.of()),
                        outSchema.map(q -> payloadResolver.resolvePayloadTree(q, activeOut)).orElse(List.of())
                ));
            }
            case PickNode pick -> {
                if (!pick.createInstance()) {
                    flags.hasMidFlightWaitOrReceive = true;
                }
                for (OnMessageBranch msg : pick.onMessages()) {
                    Optional<QName> inSchema = resolveVarSchema(process, msg.variable());
                    Set<String> activeIn = reads.getOrDefault(msg.variable(), Set.of());
                    touchpoints.add(new Touchpoint(
                            Touchpoint.Direction.EXTERNAL_TO_ODE,
                            pick.createInstance()
                                    ? Touchpoint.InteractionStyle.INBOUND_TRIGGER
                                    : Touchpoint.InteractionStyle.INBOUND_CALLBACK,
                            msg.partnerLink(),
                            msg.portType(),
                            msg.operation(),
                            inSchema,
                            Optional.empty(),
                            List.copyOf(activeIn),
                            List.of(),
                            inSchema.map(q -> payloadResolver.resolvePayloadTree(q, activeIn)).orElse(List.of()),
                            List.of()
                    ));
                    walkActivities(process, msg.activity(), touchpoints, flags, reads, writes);
                }
                for (OnAlarmBranch alarm : pick.onAlarms()) {
                    flags.hasMidFlightWaitOrReceive = true;
                    walkActivities(process, alarm.activity(), touchpoints, flags, reads, writes);
                }
            }
            case WaitNode _ -> flags.hasMidFlightWaitOrReceive = true;
            case CompensateNode _ -> flags.hasCompensation = true;
            case ScopeNode scope -> {
                if (scope.hasCompensationHandler()) flags.hasCompensation = true;
                if (scope.hasEventHandlers()) flags.hasMidFlightWaitOrReceive = true;
                walkActivities(process, scope.primaryActivity(), touchpoints, flags, reads, writes);
                scope.handlerActivities().forEach(h -> walkActivities(process, h, touchpoints, flags, reads, writes));
            }
            case SequenceNode seq -> seq.steps().forEach(s -> walkActivities(process, s, touchpoints, flags, reads, writes));
            case FlowNode flow -> flow.branches().forEach(b -> walkActivities(process, b, touchpoints, flags, reads, writes));
            case IfNode ifNode -> ifNode.branches().forEach(b -> walkActivities(process, b.activity(), touchpoints, flags, reads, writes));
            case LoopNode loop -> walkActivities(process, loop.body(), touchpoints, flags, reads, writes);
            default -> {}
        }
    }

    private Optional<QName> resolveVarSchema(BpelProcess process, String varName) {
        if (varName == null || varName.isBlank()) return Optional.empty();
        BpelProcess.VariableDecl decl = process.variables().get(varName);
        if (decl == null) return Optional.empty();
        return decl.messageType().or(decl::elementType).or(decl::xmlType);
    }

    private String formatPartAndPath(DataEndpoint ep) {
        String part = ep.partName().map(p -> "$" + p).orElse("");
        String xpath = ep.xpathQuery().orElse("");
        return (part + xpath).isBlank() ? "<whole-variable>" : part + xpath;
    }

    private MigrationCategory classify(StateFlags flags, boolean inMemory) {
        if (flags.hasCompensation) {
            return MigrationCategory.SAGA_COMPENSATING;
        }
        if (!inMemory && flags.hasMidFlightWaitOrReceive) {
            return MigrationCategory.STATEFUL_ASYNC;
        }
        return MigrationCategory.STATELESS_PIPELINE;
    }

    private static final class StateFlags {
        boolean hasMidFlightWaitOrReceive = false;
        boolean hasCompensation = false;
    }
}
