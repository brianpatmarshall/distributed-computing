package com.corev5.bpel.inspector.parser;

import com.corev5.bpel.inspector.model.contract.OdeDeploymentBinding;
import com.corev5.bpel.inspector.model.contract.SymbolTable;
import org.apache.ws.commons.schema.XmlSchemaCollection;
import org.apache.ws.commons.schema.XmlSchemaException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

public final class ContractIndexer {

    private static final String WSDL_NS = "http://schemas.xmlsoap.org/wsdl/";
    private static final String XSD_NS = "http://www.w3.org/2001/XMLSchema";
    private static final String PLNK_2_0_NS = "http://docs.oasis-open.org/wsbpel/2.0/plnktype";
    private static final String PLNK_1_1_NS = "http://schemas.xmlsoap.org/ws/2003/05/partner-link/";
    private static final String ODE_DEPLOY_NS = "http://www.apache.org/ode/schemas/dd/2007/03";

    public SymbolTable indexDirectory(Path rootDir) throws IOException {
        Path normalizedRoot = rootDir.toAbsolutePath().normalize();
        var partnerLinkTypes = new HashMap<QName, SymbolTable.PartnerLinkTypeDef>();
        var messages = new HashMap<QName, SymbolTable.WsdlMessageDef>();
        var portTypes = new HashMap<QName, SymbolTable.WsdlPortTypeDef>();
        var odeDeployments = new HashMap<QName, OdeDeploymentBinding>();
        var wsdlFiles = new LinkedHashMap<Path, SymbolTable.WsdlFileDef>();
        var serviceToWsdl = new HashMap<QName, Path>();
        var xsdFiles = new LinkedHashMap<Path, SymbolTable.XsdFileDef>();
        var schemaElementToXsd = new HashMap<QName, Path>();
        var schemaTypeToXsd = new HashMap<QName, Path>();
        var schemaCollection = new XmlSchemaCollection();

        List<Path> allFiles;
        try (Stream<Path> walk = Files.walk(normalizedRoot)) {
            allFiles = walk.filter(Files::isRegularFile)
                    .map(p -> p.toAbsolutePath().normalize())
                    .sorted()
                    .toList();
        }

        for (Path file : allFiles) {
            if (file.toString().endsWith(".xsd")) {
                parseXsd(file, xsdFiles, schemaElementToXsd, schemaTypeToXsd, schemaCollection);
            }
        }

        // First collect WSDL namespaces so namespace-only <wsdl:import> can resolve too
        Map<String, List<Path>> wsdlsByNamespace = new HashMap<>();
        List<Path> wsdlPaths = allFiles.stream().filter(p -> p.toString().endsWith(".wsdl")).toList();
        Map<Path, Document> wsdlDocs = new LinkedHashMap<>();
        for (Path wsdlPath : wsdlPaths) {
            Document doc = XmlDomUtils.parseDocument(wsdlPath);
            wsdlDocs.put(wsdlPath, doc);
            String tns = doc.getDocumentElement().getAttribute("targetNamespace");
            if (tns != null && !tns.isBlank()) {
                wsdlsByNamespace.computeIfAbsent(tns, _ -> new ArrayList<>()).add(wsdlPath);
            }
        }

        for (var entry : wsdlDocs.entrySet()) {
            parseWsdl(
                    entry.getKey(),
                    entry.getValue(),
                    wsdlsByNamespace,
                    xsdFiles,
                    schemaElementToXsd,
                    schemaTypeToXsd,
                    partnerLinkTypes,
                    messages,
                    portTypes,
                    wsdlFiles,
                    serviceToWsdl,
                    schemaCollection
            );
        }

        for (Path file : allFiles) {
            if (file.getFileName().toString().equals("deploy.xml")) {
                parseDeployXml(file, odeDeployments);
            }
        }

        return new SymbolTable(
                normalizedRoot,
                Map.copyOf(partnerLinkTypes),
                Map.copyOf(messages),
                Map.copyOf(portTypes),
                Map.copyOf(odeDeployments),
                Map.copyOf(wsdlFiles),
                Map.copyOf(serviceToWsdl),
                Map.copyOf(xsdFiles),
                Map.copyOf(schemaElementToXsd),
                Map.copyOf(schemaTypeToXsd),
                schemaCollection
        );
    }

    private void parseXsd(
            Path xsdPath,
            Map<Path, SymbolTable.XsdFileDef> xsdFiles,
            Map<QName, Path> schemaElementToXsd,
            Map<QName, Path> schemaTypeToXsd,
            XmlSchemaCollection schemaCollection
    ) {
        Document doc = XmlDomUtils.parseDocument(xsdPath);
        Element root = doc.getDocumentElement();
        String targetNs = root.getAttribute("targetNamespace");

        Set<Path> importedXsds = new LinkedHashSet<>();
        collectSchemaReferences(root, xsdPath.getParent(), importedXsds);

        for (Element child : XmlDomUtils.childElements(root)) {
            if (!XSD_NS.equals(child.getNamespaceURI())) {
                continue;
            }
            String localName = child.getLocalName();
            String name = child.getAttribute("name");
            if (name == null || name.isBlank()) {
                continue;
            }
            QName qName = new QName(targetNs, name);
            if ("element".equals(localName)) {
                schemaElementToXsd.putIfAbsent(qName, xsdPath);
            } else if ("complexType".equals(localName) || "simpleType".equals(localName)) {
                schemaTypeToXsd.putIfAbsent(qName, xsdPath);
            }
        }

        xsdFiles.put(xsdPath, new SymbolTable.XsdFileDef(xsdPath, targetNs, List.copyOf(importedXsds)));

        try {
            schemaCollection.setBaseUri(xsdPath.getParent().toUri().toString());
            schemaCollection.read(new StreamSource(xsdPath.toFile()));
        } catch (XmlSchemaException ignored) {
            // Schema may already have been loaded transitively via another XSD's import/include
        }
    }

    private void parseWsdl(
            Path wsdlPath,
            Document doc,
            Map<String, List<Path>> wsdlsByNamespace,
            Map<Path, SymbolTable.XsdFileDef> xsdFiles,
            Map<QName, Path> schemaElementToXsd,
            Map<QName, Path> schemaTypeToXsd,
            Map<QName, SymbolTable.PartnerLinkTypeDef> plts,
            Map<QName, SymbolTable.WsdlMessageDef> messages,
            Map<QName, SymbolTable.WsdlPortTypeDef> portTypes,
            Map<Path, SymbolTable.WsdlFileDef> wsdlFiles,
            Map<QName, Path> serviceToWsdl,
            XmlSchemaCollection schemas
    ) {
        Element root = doc.getDocumentElement();
        String targetNs = root.getAttribute("targetNamespace");

        Set<Path> importedWsdls = new LinkedHashSet<>();
        Set<Path> referencedXsds = new LinkedHashSet<>();

        // <wsdl:import namespace="..." location="..."/>
        NodeList importNodes = root.getElementsByTagNameNS(WSDL_NS, "import");
        for (int i = 0; i < importNodes.getLength(); i++) {
            Element impEl = (Element) importNodes.item(i);
            String location = impEl.getAttribute("location");
            String ns = impEl.getAttribute("namespace");
            Optional<Path> resolved = resolveRelativePath(wsdlPath.getParent(), location);
            if (resolved.isPresent()) {
                Path p = resolved.get();
                if (!p.equals(wsdlPath)) {
                    if (p.toString().endsWith(".xsd")) {
                        referencedXsds.add(p);
                    } else {
                        importedWsdls.add(p);
                    }
                }
            } else if (ns != null && !ns.isBlank()) {
                for (Path candidate : wsdlsByNamespace.getOrDefault(ns, List.of())) {
                    if (!candidate.equals(wsdlPath)) {
                        importedWsdls.add(candidate);
                    }
                }
            }
        }

        // Inline <xs:schema> inside <wsdl:types>
        NodeList schemaNodes = root.getElementsByTagNameNS(XSD_NS, "schema");
        for (int i = 0; i < schemaNodes.getLength(); i++) {
            Element schemaEl = (Element) schemaNodes.item(i);
            collectSchemaReferences(schemaEl, wsdlPath.getParent(), xsdFiles, referencedXsds);
            try {
                schemas.setBaseUri(wsdlPath.getParent().toUri().toString());
                schemas.read(schemaEl, wsdlPath.toUri().toString());
            } catch (XmlSchemaException ignored) {
                // Inline schema targetNamespace may already exist in schemaCollection
            }
        }

        // <plnk:partnerLinkType> (supports both WS-BPEL 2.0 and BPEL 1.1 namespaces)
        for (String plnkNs : List.of(PLNK_2_0_NS, PLNK_1_1_NS)) {
            NodeList pltNodes = root.getElementsByTagNameNS(plnkNs, "partnerLinkType");
            for (int i = 0; i < pltNodes.getLength(); i++) {
                Element pltEl = (Element) pltNodes.item(i);
                QName pltQName = new QName(targetNs, pltEl.getAttribute("name"));
                Map<String, QName> roleMap = new HashMap<>();
                NodeList roles = pltEl.getElementsByTagNameNS(plnkNs, "role");
                for (int r = 0; r < roles.getLength(); r++) {
                    Element roleEl = (Element) roles.item(r);
                    String rawPt = roleEl.getAttribute("portType");
                    if ((rawPt == null || rawPt.isBlank())) {
                        rawPt = XmlDomUtils.firstChildElement(roleEl, plnkNs, "portType")
                                .map(pt -> pt.getAttribute("name"))
                                .orElse("");
                    }
                    QName portTypeQName = XmlDomUtils.resolveQName(roleEl, rawPt);
                    roleMap.put(roleEl.getAttribute("name"), portTypeQName);
                }
                plts.put(pltQName, new SymbolTable.PartnerLinkTypeDef(pltQName, Map.copyOf(roleMap), wsdlPath));
            }
        }

        // <wsdl:message>
        NodeList msgNodes = root.getElementsByTagNameNS(WSDL_NS, "message");
        for (int i = 0; i < msgNodes.getLength(); i++) {
            Element msgEl = (Element) msgNodes.item(i);
            QName msgQName = new QName(targetNs, msgEl.getAttribute("name"));
            Map<String, QName> parts = new HashMap<>();
            NodeList partNodes = msgEl.getElementsByTagNameNS(WSDL_NS, "part");
            for (int p = 0; p < partNodes.getLength(); p++) {
                Element partEl = (Element) partNodes.item(p);
                boolean isElement = partEl.hasAttribute("element");
                String ref = isElement ? partEl.getAttribute("element") : partEl.getAttribute("type");
                if (!ref.isEmpty()) {
                    QName refQName = XmlDomUtils.resolveQName(partEl, ref);
                    parts.put(partEl.getAttribute("name"), refQName);
                    Path xsdPath = isElement
                            ? schemaElementToXsd.get(refQName)
                            : schemaTypeToXsd.get(refQName);
                    if (xsdPath != null && xsdFiles.containsKey(xsdPath)) {
                        referencedXsds.add(xsdPath);
                    }
                }
            }
            messages.put(msgQName, new SymbolTable.WsdlMessageDef(msgQName, Map.copyOf(parts), wsdlPath));
        }

        // <wsdl:portType>
        NodeList ptNodes = root.getElementsByTagNameNS(WSDL_NS, "portType");
        for (int i = 0; i < ptNodes.getLength(); i++) {
            Element ptEl = (Element) ptNodes.item(i);
            QName ptQName = new QName(targetNs, ptEl.getAttribute("name"));
            Map<String, SymbolTable.OperationDef> ops = new LinkedHashMap<>();
            for (Element opEl : XmlDomUtils.childElements(ptEl)) {
                if (WSDL_NS.equals(opEl.getNamespaceURI()) && "operation".equals(opEl.getLocalName())) {
                    String opName = opEl.getAttribute("name");
                    QName inMsg = XmlDomUtils.firstChildElement(opEl, WSDL_NS, "input")
                            .map(inEl -> XmlDomUtils.resolveQName(inEl, inEl.getAttribute("message")))
                            .orElse(null);
                    QName outMsg = XmlDomUtils.firstChildElement(opEl, WSDL_NS, "output")
                            .map(outEl -> XmlDomUtils.resolveQName(outEl, outEl.getAttribute("message")))
                            .orElse(null);
                    ops.put(opName, new SymbolTable.OperationDef(opName, inMsg, outMsg));
                }
            }
            portTypes.put(ptQName, new SymbolTable.WsdlPortTypeDef(ptQName, Map.copyOf(ops), wsdlPath));
        }

        // <wsdl:service>
        Map<QName, List<String>> services = new LinkedHashMap<>();
        NodeList svcNodes = root.getElementsByTagNameNS(WSDL_NS, "service");
        for (int i = 0; i < svcNodes.getLength(); i++) {
            Element svcEl = (Element) svcNodes.item(i);
            String svcName = svcEl.getAttribute("name");
            if (svcName == null || svcName.isBlank()) {
                continue;
            }
            QName svcQName = new QName(targetNs, svcName);
            List<String> ports = new ArrayList<>();
            for (Element portEl : XmlDomUtils.childElements(svcEl)) {
                if (WSDL_NS.equals(portEl.getNamespaceURI()) && "port".equals(portEl.getLocalName())) {
                    String portName = portEl.getAttribute("name");
                    if (portName != null && !portName.isBlank()) {
                        ports.add(portName);
                    }
                }
            }
            services.put(svcQName, List.copyOf(ports));
            serviceToWsdl.put(svcQName, wsdlPath);
        }

        wsdlFiles.put(wsdlPath, new SymbolTable.WsdlFileDef(
                wsdlPath,
                targetNs,
                List.copyOf(importedWsdls),
                List.copyOf(referencedXsds),
                Map.copyOf(services)
        ));
    }

    private void collectSchemaReferences(Element schemaEl, Path baseDir, Set<Path> targetSet) {
        collectSchemaReferences(schemaEl, baseDir, Map.of(), targetSet);
    }

    private void collectSchemaReferences(
            Element schemaEl,
            Path baseDir,
            Map<Path, SymbolTable.XsdFileDef> indexedXsds,
            Set<Path> targetSet
    ) {
        for (String tag : List.of("import", "include")) {
            NodeList nodes = schemaEl.getElementsByTagNameNS(XSD_NS, tag);
            for (int i = 0; i < nodes.getLength(); i++) {
                Element el = (Element) nodes.item(i);
                String loc = el.getAttribute("schemaLocation");
                Optional<Path> resolved = resolveRelativePath(baseDir, loc);
                if (resolved.isPresent()) {
                    targetSet.add(resolved.get());
                } else if ("import".equals(tag)) {
                    String ns = el.getAttribute("namespace");
                    if (ns != null && !ns.isBlank()) {
                        indexedXsds.values().stream()
                                .filter(x -> ns.equals(x.targetNamespace()))
                                .map(SymbolTable.XsdFileDef::sourceFile)
                                .forEach(targetSet::add);
                    }
                }
            }
        }
    }

    private Optional<Path> resolveRelativePath(Path baseDir, String location) {
        if (location == null || location.isBlank() || location.contains("://")) {
            return Optional.empty();
        }
        try {
            Path resolved = baseDir.resolve(location).toAbsolutePath().normalize();
            if (Files.isRegularFile(resolved)) {
                return Optional.of(resolved);
            }
        } catch (Exception ignored) {
            // Ignore malformed URI/path strings
        }
        return Optional.empty();
    }

    private void parseDeployXml(Path deployPath, Map<QName, OdeDeploymentBinding> deployments) {
        Document doc = XmlDomUtils.parseDocument(deployPath);
        NodeList processes = doc.getElementsByTagNameNS(ODE_DEPLOY_NS, "process");
        for (int i = 0; i < processes.getLength(); i++) {
            Element procEl = (Element) processes.item(i);
            QName procName = XmlDomUtils.resolveQName(procEl, procEl.getAttribute("name"));
            boolean inMemory = "true".equalsIgnoreCase(XmlDomUtils.childText(procEl, ODE_DEPLOY_NS, "in-memory").orElse("false"));

            Map<String, OdeDeploymentBinding.EndpointRef> provided = extractBindings(procEl, "provide");
            Map<String, OdeDeploymentBinding.EndpointRef> invoked = extractBindings(procEl, "invoke");

            deployments.put(procName, new OdeDeploymentBinding(procName, deployPath, inMemory, provided, invoked));
        }
    }

    private Map<String, OdeDeploymentBinding.EndpointRef> extractBindings(Element procEl, String tagName) {
        Map<String, OdeDeploymentBinding.EndpointRef> map = new LinkedHashMap<>();
        NodeList nodes = procEl.getElementsByTagNameNS(ODE_DEPLOY_NS, tagName);
        for (int i = 0; i < nodes.getLength(); i++) {
            Element el = (Element) nodes.item(i);
            String partnerLink = el.getAttribute("partnerLink");
            NodeList services = el.getElementsByTagNameNS(ODE_DEPLOY_NS, "service");
            if (services.getLength() > 0) {
                Element svcEl = (Element) services.item(0);
                QName svcQName = XmlDomUtils.resolveQName(svcEl, svcEl.getAttribute("name"));
                map.put(partnerLink, new OdeDeploymentBinding.EndpointRef(svcQName, svcEl.getAttribute("port")));
            }
        }
        return Map.copyOf(map);
    }
}
