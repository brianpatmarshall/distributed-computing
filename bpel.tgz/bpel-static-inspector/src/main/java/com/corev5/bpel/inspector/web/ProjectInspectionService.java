package com.corev5.bpel.inspector.web;

import com.corev5.bpel.inspector.analyzer.ProcessAnalyzer;
import com.corev5.bpel.inspector.model.ast.BpelProcess;
import com.corev5.bpel.inspector.model.contract.SymbolTable;
import com.corev5.bpel.inspector.model.report.ProcessAuditReport;
import com.corev5.bpel.inspector.model.report.ProcessDependencies;
import com.corev5.bpel.inspector.parser.BpelAstParser;
import com.corev5.bpel.inspector.parser.ContractIndexer;
import com.corev5.bpel.inspector.renderer.Neo4jCypherRenderer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

/**
 * Analyzes a root Java multi-module directory containing multiple BPEL sub-projects,
 * groups processes by sub-project, and constructs the unified dependency graph.
 */
public final class ProjectInspectionService {

    public ProjectAnalysisResult inspectProject(Path rootDir) throws IOException {
        Path normalizedRoot = rootDir.toAbsolutePath().normalize();
        if (!Files.isDirectory(normalizedRoot)) {
            throw new IllegalArgumentException("Directory does not exist: " + normalizedRoot);
        }

        SymbolTable symbolTable = new ContractIndexer().indexDirectory(normalizedRoot);
        BpelAstParser parser = new BpelAstParser();
        ProcessAnalyzer analyzer = new ProcessAnalyzer(symbolTable);

        List<ProcessAuditReport> reports = new ArrayList<>();
        try (Stream<Path> walk = Files.walk(normalizedRoot)) {
            List<Path> bpelFiles = walk
                    .filter(Files::isRegularFile)
                    .filter(p -> p.toString().endsWith(".bpel"))
                    .filter(p -> !isIgnoredBuildPath(normalizedRoot, p))
                    .sorted()
                    .toList();

            for (Path bpelFile : bpelFiles) {
                BpelProcess process = parser.parse(bpelFile);
                reports.add(analyzer.analyze(process));
            }
        }

        Map<String, List<ProcessAuditReport>> bySubProject = new LinkedHashMap<>();
        Map<String, String> bpelToSubProject = new HashMap<>();
        for (ProcessAuditReport report : reports) {
            String subProjectRel = detectSubProject(normalizedRoot, report.sourceFile());
            bySubProject.computeIfAbsent(subProjectRel, _ -> new ArrayList<>()).add(report);
            bpelToSubProject.put(report.relativeSourcePath(), subProjectRel);
        }

        List<ProjectAnalysisResult.SubProjectSummary> subProjects = bySubProject.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(entry -> {
                    String spRel = entry.getKey();
                    List<ProcessAuditReport> spReports = entry.getValue();
                    Set<String> spWsdls = new LinkedHashSet<>();
                    Set<String> spDeploys = new LinkedHashSet<>();
                    for (ProcessAuditReport r : spReports) {
                        if (r.dependencies() != null) {
                            r.dependencies().deployXml().ifPresent(d -> spDeploys.add(d.relativePath()));
                            r.dependencies().wsdlFiles().forEach(w -> spWsdls.add(w.relativePath()));
                        }
                    }
                    String spName = spRel.equals(".")
                            ? normalizedRoot.getFileName().toString()
                            : spRel.substring(spRel.lastIndexOf('/') + 1);
                    return new ProjectAnalysisResult.SubProjectSummary(
                            spRel,
                            spName,
                            spRel,
                            spReports.stream().map(ProcessAuditReport::relativeSourcePath).toList(),
                            spReports.size(),
                            spWsdls.size(),
                            spDeploys.size()
                    );
                })
                .toList();

        ProjectAnalysisResult.GraphData graph = buildGraph(normalizedRoot, reports, bpelToSubProject);

        Neo4jCypherRenderer neo4jRenderer = new Neo4jCypherRenderer();
        String cypherScript = neo4jRenderer.renderCypher(reports);
        String grassStyle = neo4jRenderer.renderBrowserGrassStyle();

        int deployCount = (int) graph.nodes().stream().filter(n -> "DeployXml".equals(n.label())).count();
        int wsdlCount = (int) graph.nodes().stream().filter(n -> "WsdlFile".equals(n.label())).count();
        int xsdCount = (int) graph.nodes().stream().filter(n -> "XsdFile".equals(n.label())).count();
        int extCount = (int) graph.nodes().stream().filter(n -> "ExternalService".equals(n.label())).count();

        String projectName = normalizedRoot.getFileName() != null
                ? normalizedRoot.getFileName().toString()
                : normalizedRoot.toString();

        return new ProjectAnalysisResult(
                normalizedRoot.toString(),
                projectName,
                new ProjectAnalysisResult.SummaryCounts(
                        subProjects.size(),
                        reports.size(),
                        deployCount,
                        wsdlCount,
                        xsdCount,
                        extCount
                ),
                subProjects,
                List.copyOf(reports),
                graph,
                cypherScript,
                grassStyle
        );
    }

    private ProjectAnalysisResult.GraphData buildGraph(
            Path rootDir,
            List<ProcessAuditReport> reports,
            Map<String, String> bpelToSubProject
    ) {
        Map<String, ProjectAnalysisResult.GraphNode> nodes = new LinkedHashMap<>();
        Map<String, ProjectAnalysisResult.GraphEdge> edges = new LinkedHashMap<>();

        // Index provided (serviceName#portName) -> caller/callee matching
        Map<String, List<String>> providedServiceToBpels = new LinkedHashMap<>();
        for (ProcessAuditReport report : reports) {
            if (report.dependencies() != null && report.dependencies().deployXml().isPresent()) {
                for (ProcessDependencies.ServiceBindingRef ref : report.dependencies().deployXml().get().providedServices()) {
                    String key = ref.serviceName().toString() + "#" + ref.portName();
                    providedServiceToBpels.computeIfAbsent(key, _ -> new ArrayList<>())
                            .add(report.relativeSourcePath());
                }
            }
        }

        for (ProcessAuditReport report : reports) {
            String bpelPath = report.relativeSourcePath();
            String bpelId = "bpel:" + bpelPath;
            String sp = bpelToSubProject.getOrDefault(bpelPath, ".");

            Map<String, Object> bpelProps = new LinkedHashMap<>();
            bpelProps.put("path", bpelPath);
            bpelProps.put("processName", report.processName());
            bpelProps.put("targetNamespace", report.targetNamespace());
            bpelProps.put("category", report.category().name());
            bpelProps.put("deployedInMemory", report.deployedInMemory());
            nodes.put(bpelId, new ProjectAnalysisResult.GraphNode(
                    bpelId, "BpelFile", fileName(bpelPath), sp, bpelProps
            ));

            ProcessDependencies deps = report.dependencies();
            if (deps == null) {
                continue;
            }

            deps.deployXml().ifPresent(deploy -> {
                String deployPath = deploy.relativePath();
                String deployId = "deploy:" + deployPath;
                String deploySp = detectSubProject(rootDir, deploy.file());
                nodes.computeIfAbsent(deployId, _ -> {
                    Map<String, Object> props = new LinkedHashMap<>();
                    props.put("path", deployPath);
                    props.put("inMemory", deploy.inMemory());
                    props.put("providedCount", deploy.providedServices().size());
                    props.put("invokedCount", deploy.invokedServices().size());
                    return new ProjectAnalysisResult.GraphNode(deployId, "DeployXml", fileName(deployPath), deploySp, props);
                });

                Map<String, Object> depEdgeProps = new LinkedHashMap<>();
                depEdgeProps.put("inMemory", deploy.inMemory());
                depEdgeProps.put("providedCount", deploy.providedServices().size());
                depEdgeProps.put("invokedCount", deploy.invokedServices().size());
                String edgeId = bpelId + "->DEPLOYED_BY->" + deployId;
                edges.put(edgeId, new ProjectAnalysisResult.GraphEdge(edgeId, bpelId, deployId, "DEPLOYED_BY", depEdgeProps));

                for (ProcessDependencies.ServiceBindingRef ref : deploy.providedServices()) {
                    addServiceBindingEdge(rootDir, nodes, edges, deployId, report.processName(), "PROVIDE", ref);
                }
                for (ProcessDependencies.ServiceBindingRef ref : deploy.invokedServices()) {
                    addServiceBindingEdge(rootDir, nodes, edges, deployId, report.processName(), "INVOKE", ref);
                }
            });

            for (ProcessDependencies.WsdlDependency wsdl : deps.wsdlFiles()) {
                String wsdlPath = wsdl.relativePath();
                String wsdlId = "wsdl:" + wsdlPath;
                String wsdlSp = detectSubProject(rootDir, wsdl.file());
                Map<String, Object> wsdlProps = new LinkedHashMap<>();
                wsdlProps.put("path", wsdlPath);
                wsdlProps.put("targetNamespace", wsdl.targetNamespace());
                nodes.put(wsdlId, new ProjectAnalysisResult.GraphNode(
                        wsdlId, "WsdlFile", fileName(wsdlPath), wsdlSp, wsdlProps
                ));

                String edgeId = bpelId + "->DEPENDS_ON_WSDL->" + wsdlId;
                edges.put(edgeId, new ProjectAnalysisResult.GraphEdge(
                        edgeId, bpelId, wsdlId, "DEPENDS_ON_WSDL", Map.of("reasons", wsdl.reasons())
                ));

                for (String impWsdl : wsdl.importedWsdlRelativePaths()) {
                    String impId = "wsdl:" + impWsdl;
                    nodes.computeIfAbsent(impId, _ -> new ProjectAnalysisResult.GraphNode(
                            impId, "WsdlFile", fileName(impWsdl), wsdlSp, Map.of("path", impWsdl)
                    ));
                    String impEdgeId = wsdlId + "->IMPORTS_WSDL->" + impId;
                    edges.putIfAbsent(impEdgeId, new ProjectAnalysisResult.GraphEdge(
                            impEdgeId, wsdlId, impId, "IMPORTS_WSDL", Map.of()
                    ));
                }

                for (String refXsd : wsdl.referencedXsdRelativePaths()) {
                    String xsdId = "xsd:" + refXsd;
                    nodes.computeIfAbsent(xsdId, _ -> new ProjectAnalysisResult.GraphNode(
                            xsdId, "XsdFile", fileName(refXsd), wsdlSp, Map.of("path", refXsd)
                    ));
                    String xsdEdgeId = wsdlId + "->USES_XSD->" + xsdId;
                    edges.putIfAbsent(xsdEdgeId, new ProjectAnalysisResult.GraphEdge(
                            xsdEdgeId, wsdlId, xsdId, "USES_XSD", Map.of()
                    ));
                }
            }

            for (ProcessDependencies.XsdDependency xsd : deps.xsdFiles()) {
                String xsdPath = xsd.relativePath();
                String xsdId = "xsd:" + xsdPath;
                String xsdSp = detectSubProject(rootDir, xsd.file());
                Map<String, Object> xsdProps = new LinkedHashMap<>();
                xsdProps.put("path", xsdPath);
                xsdProps.put("targetNamespace", xsd.targetNamespace());
                nodes.put(xsdId, new ProjectAnalysisResult.GraphNode(
                        xsdId, "XsdFile", fileName(xsdPath), xsdSp, xsdProps
                ));

                String edgeId = bpelId + "->DEPENDS_ON_XSD->" + xsdId;
                edges.put(edgeId, new ProjectAnalysisResult.GraphEdge(
                        edgeId, bpelId, xsdId, "DEPENDS_ON_XSD", Map.of("reasons", xsd.reasons())
                ));

                for (String impXsd : xsd.importedXsdRelativePaths()) {
                    String impId = "xsd:" + impXsd;
                    nodes.computeIfAbsent(impId, _ -> new ProjectAnalysisResult.GraphNode(
                            impId, "XsdFile", fileName(impXsd), xsdSp, Map.of("path", impXsd)
                    ));
                    String impEdgeId = xsdId + "->IMPORTS_XSD->" + impId;
                    edges.putIfAbsent(impEdgeId, new ProjectAnalysisResult.GraphEdge(
                            impEdgeId, xsdId, impId, "IMPORTS_XSD", Map.of()
                    ));
                }
            }
        }

        // Cross-process BPEL -> BPEL invocations
        for (ProcessAuditReport report : reports) {
            if (report.dependencies() == null || report.dependencies().deployXml().isEmpty()) {
                continue;
            }
            String callerPath = report.relativeSourcePath();
            String callerId = "bpel:" + callerPath;
            for (ProcessDependencies.ServiceBindingRef ref : report.dependencies().deployXml().get().invokedServices()) {
                String svcKey = ref.serviceName().toString() + "#" + ref.portName();
                for (String calleePath : providedServiceToBpels.getOrDefault(svcKey, List.of())) {
                    if (callerPath.equals(calleePath)) {
                        continue;
                    }
                    String calleeId = "bpel:" + calleePath;
                    String edgeId = callerId + "->INVOKES_PROCESS(" + ref.partnerLink() + ")->" + calleeId;
                    edges.putIfAbsent(edgeId, new ProjectAnalysisResult.GraphEdge(
                            edgeId, callerId, calleeId, "INVOKES_PROCESS",
                            Map.of(
                                    "partnerLink", ref.partnerLink(),
                                    "serviceName", ref.serviceName().toString(),
                                    "portName", ref.portName()
                            )
                    ));
                }
            }
        }

        return new ProjectAnalysisResult.GraphData(
                List.copyOf(nodes.values()),
                List.copyOf(edges.values())
        );
    }

    private void addServiceBindingEdge(
            Path rootDir,
            Map<String, ProjectAnalysisResult.GraphNode> nodes,
            Map<String, ProjectAnalysisResult.GraphEdge> edges,
            String deployId,
            String processName,
            String direction,
            ProcessDependencies.ServiceBindingRef ref
    ) {
        Map<String, Object> edgeProps = new LinkedHashMap<>();
        edgeProps.put("processName", processName);
        edgeProps.put("partnerLink", ref.partnerLink());
        edgeProps.put("direction", direction);
        edgeProps.put("serviceName", ref.serviceName().toString());
        edgeProps.put("portName", ref.portName());

        if (ref.wsdlRelativePath().isPresent()) {
            String wsdlPath = ref.wsdlRelativePath().get();
            String wsdlId = "wsdl:" + wsdlPath;
            String sp = ref.wsdlFile().map(p -> detectSubProject(rootDir, p)).orElse(".");
            nodes.computeIfAbsent(wsdlId, _ -> new ProjectAnalysisResult.GraphNode(
                    wsdlId, "WsdlFile", fileName(wsdlPath), sp, Map.of("path", wsdlPath)
            ));
            String edgeId = deployId + "->BINDS_SERVICE(" + processName + ":" + ref.partnerLink() + ":" + direction + ")->" + wsdlId;
            edges.putIfAbsent(edgeId, new ProjectAnalysisResult.GraphEdge(edgeId, deployId, wsdlId, "BINDS_SERVICE", edgeProps));
        } else {
            String svcKey = ref.serviceName().toString() + "#" + ref.portName();
            String extId = "ext:" + svcKey;
            nodes.computeIfAbsent(extId, _ -> {
                Map<String, Object> props = new LinkedHashMap<>();
                props.put("key", svcKey);
                props.put("serviceName", ref.serviceName().toString());
                props.put("portName", ref.portName());
                return new ProjectAnalysisResult.GraphNode(
                        extId, "ExternalService", ref.serviceName().getLocalPart(), "external", props
                );
            });
            String edgeId = deployId + "->BINDS_SERVICE(" + processName + ":" + ref.partnerLink() + ":" + direction + ")->" + extId;
            edges.putIfAbsent(edgeId, new ProjectAnalysisResult.GraphEdge(edgeId, deployId, extId, "BINDS_SERVICE", edgeProps));
        }
    }

    private String detectSubProject(Path rootDir, Path file) {
        if (file == null) {
            return ".";
        }
        Path normRoot = rootDir.toAbsolutePath().normalize();
        Path current = file.toAbsolutePath().normalize().getParent();
        Path fallbackDir = current;

        while (current != null && current.startsWith(normRoot) && !current.equals(normRoot)) {
            if (Files.isRegularFile(current.resolve("pom.xml"))
                    || Files.isRegularFile(current.resolve("build.gradle"))
                    || Files.isRegularFile(current.resolve("build.gradle.kts"))) {
                return normRoot.relativize(current).toString().replace('\\', '/');
            }
            if (Files.isRegularFile(current.resolve("deploy.xml"))) {
                fallbackDir = current;
            }
            current = current.getParent();
        }

        if (fallbackDir != null && fallbackDir.startsWith(normRoot) && !fallbackDir.equals(normRoot)) {
            Path rel = normRoot.relativize(fallbackDir);
            if (rel.getNameCount() >= 1) {
                return rel.toString().replace('\\', '/');
            }
        }
        return ".";
    }

    private boolean isIgnoredBuildPath(Path root, Path file) {
        Path rel = root.relativize(file);
        for (Path part : rel) {
            String name = part.toString();
            if (name.equals("target") || name.equals("build") || name.equals("node_modules") || name.equals(".git")) {
                return true;
            }
        }
        return false;
    }

    private String fileName(String relativePath) {
        int slash = relativePath.lastIndexOf('/');
        return slash >= 0 ? relativePath.substring(slash + 1) : relativePath;
    }
}
