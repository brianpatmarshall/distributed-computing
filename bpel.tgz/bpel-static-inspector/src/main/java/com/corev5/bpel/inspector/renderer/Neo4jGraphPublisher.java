package com.corev5.bpel.inspector.renderer;

import com.corev5.bpel.inspector.model.report.BpelComponentGraph;
import com.corev5.bpel.inspector.model.report.ProcessAuditReport;
import com.corev5.bpel.inspector.model.report.ProcessDependencies;
import org.neo4j.driver.*;

import java.nio.file.Path;
import java.util.*;

/**
 * Publishes per-BPEL dependency graphs and internal BPEL component graphs
 * directly to a live Neo4j instance via Bolt using parameterized Cypher statements.
 */
public final class Neo4jGraphPublisher implements AutoCloseable {

    public record PublishSummary(
            int bpelCount,
            int deployEdges,
            int wsdlEdges,
            int xsdEdges,
            int crossProcessEdges,
            int componentNodes,
            int componentEdges
    ) {}

    private static final Set<String> ALLOWED_COMPONENT_LABELS = Set.of(
            "BpelActivity", "BpelPartnerLink", "BpelVariable", "BpelCorrelationSet"
    );

    private static final Set<String> ALLOWED_COMPONENT_REL_TYPES = Set.of(
            "HAS_PARTNER_LINK", "HAS_VARIABLE", "HAS_CORRELATION_SET",
            "HAS_ROOT_ACTIVITY", "HAS_PROCESS_HANDLER",
            "CONTAINS", "NEXT", "USES_PARTNER_LINK", "READS_VARIABLE", "WRITES_VARIABLE"
    );

    private final Driver driver;
    private final String database;

    public Neo4jGraphPublisher(String uri, String username, String password, String database) {
        this(createDriver(uri, username, password), database);
    }

    Neo4jGraphPublisher(Driver driver, String database) {
        this.driver = driver;
        this.database = (database == null || database.isBlank()) ? "neo4j" : database;
    }

    private static Driver createDriver(String uri, String username, String password) {
        AuthToken auth = (username == null || username.isBlank())
                ? AuthTokens.none()
                : AuthTokens.basic(username, password == null ? "" : password);
        return GraphDatabase.driver(uri, auth);
    }

    public PublishSummary publish(List<ProcessAuditReport> reports, boolean clearExisting) {
        return publish(reports, clearExisting, true);
    }

    public PublishSummary publish(List<ProcessAuditReport> reports, boolean clearExisting, boolean includeComponents) {
        driver.verifyConnectivity();

        SessionConfig sessionConfig = SessionConfig.builder()
                .withDatabase(database)
                .build();

        Map<String, List<String>> providedServiceToBpels = Neo4jCypherRenderer.indexProvidedServices(reports);

        try (Session session = driver.session(sessionConfig)) {
            session.run("CREATE CONSTRAINT bpel_file_path IF NOT EXISTS FOR (b:BpelFile) REQUIRE b.path IS UNIQUE").consume();
            session.run("CREATE CONSTRAINT deploy_xml_path IF NOT EXISTS FOR (d:DeployXml) REQUIRE d.path IS UNIQUE").consume();
            session.run("CREATE CONSTRAINT wsdl_file_path IF NOT EXISTS FOR (w:WsdlFile) REQUIRE w.path IS UNIQUE").consume();
            session.run("CREATE CONSTRAINT xsd_file_path IF NOT EXISTS FOR (x:XsdFile) REQUIRE x.path IS UNIQUE").consume();
            session.run("CREATE CONSTRAINT external_service_key IF NOT EXISTS FOR (s:ExternalService) REQUIRE s.key IS UNIQUE").consume();
            if (includeComponents) {
                session.run("CREATE CONSTRAINT bpel_activity_id IF NOT EXISTS FOR (a:BpelActivity) REQUIRE a.id IS UNIQUE").consume();
                session.run("CREATE CONSTRAINT bpel_partner_link_id IF NOT EXISTS FOR (p:BpelPartnerLink) REQUIRE p.id IS UNIQUE").consume();
                session.run("CREATE CONSTRAINT bpel_variable_id IF NOT EXISTS FOR (v:BpelVariable) REQUIRE v.id IS UNIQUE").consume();
                session.run("CREATE CONSTRAINT bpel_correlation_id IF NOT EXISTS FOR (c:BpelCorrelationSet) REQUIRE c.id IS UNIQUE").consume();
            }

            int[] counts = session.executeWrite(tx -> {
                if (clearExisting) {
                    tx.run("""
                            MATCH (n)
                            WHERE n:BpelFile OR n:DeployXml OR n:WsdlFile OR n:XsdFile OR n:ExternalService
                               OR n:BpelActivity OR n:BpelPartnerLink OR n:BpelVariable OR n:BpelCorrelationSet
                            DETACH DELETE n
                            """).consume();
                }

                int dEdges = 0;
                int wEdges = 0;
                int xEdges = 0;
                int pEdges = 0;
                int cNodes = 0;
                int cEdges = 0;

                for (ProcessAuditReport report : reports) {
                    String bpelPath = report.relativeSourcePath();
                    tx.run("""
                            MERGE (b:BpelFile {path: $path})
                            SET b.name = $name,
                                b.processName = $processName,
                                b.targetNamespace = $targetNamespace,
                                b.category = $category,
                                b.deployedInMemory = $inMemory
                            """,
                            Map.of(
                                    "path", bpelPath,
                                    "name", fileName(report.sourceFile(), bpelPath),
                                    "processName", report.processName(),
                                    "targetNamespace", report.targetNamespace(),
                                    "category", report.category().name(),
                                    "inMemory", report.deployedInMemory()
                            )
                    ).consume();

                    ProcessDependencies deps = report.dependencies();
                    if (deps != null) {
                        if (deps.deployXml().isPresent()) {
                            ProcessDependencies.DeployDependency deploy = deps.deployXml().get();
                            tx.run("""
                                    MERGE (d:DeployXml {path: $deployPath})
                                    SET d.name = $deployName
                                    WITH d
                                    MATCH (b:BpelFile {path: $bpelPath})
                                    MERGE (b)-[r:DEPLOYED_BY]->(d)
                                    SET r.inMemory = $inMemory,
                                        r.providedCount = $providedCount,
                                        r.invokedCount = $invokedCount
                                    """,
                                    Map.of(
                                            "deployPath", deploy.relativePath(),
                                            "deployName", fileName(deploy.file(), deploy.relativePath()),
                                            "bpelPath", bpelPath,
                                            "inMemory", deploy.inMemory(),
                                            "providedCount", deploy.providedServices().size(),
                                            "invokedCount", deploy.invokedServices().size()
                                    )
                            ).consume();
                            dEdges++;

                            for (ProcessDependencies.ServiceBindingRef ref : deploy.providedServices()) {
                                mergeDeployBinding(tx, report.processName(), deploy.relativePath(), ref, "PROVIDE");
                            }
                            for (ProcessDependencies.ServiceBindingRef ref : deploy.invokedServices()) {
                                mergeDeployBinding(tx, report.processName(), deploy.relativePath(), ref, "INVOKE");
                            }
                        }

                        for (ProcessDependencies.WsdlDependency wsdl : deps.wsdlFiles()) {
                            tx.run("""
                                    MERGE (w:WsdlFile {path: $wsdlPath})
                                    SET w.name = $wsdlName,
                                        w.targetNamespace = $targetNamespace
                                    WITH w
                                    MATCH (b:BpelFile {path: $bpelPath})
                                    MERGE (b)-[r:DEPENDS_ON_WSDL]->(w)
                                    SET r.reasons = $reasons
                                    """,
                                    Map.of(
                                            "wsdlPath", wsdl.relativePath(),
                                            "wsdlName", fileName(wsdl.file(), wsdl.relativePath()),
                                            "targetNamespace", wsdl.targetNamespace(),
                                            "bpelPath", bpelPath,
                                            "reasons", wsdl.reasons()
                                    )
                            ).consume();
                            wEdges++;

                            for (String importedWsdl : wsdl.importedWsdlRelativePaths()) {
                                tx.run("""
                                        MERGE (w2:WsdlFile {path: $importedPath})
                                        ON CREATE SET w2.name = $importedName
                                        WITH w2
                                        MATCH (w1:WsdlFile {path: $wsdlPath})
                                        MERGE (w1)-[:IMPORTS_WSDL]->(w2)
                                        """,
                                        Map.of(
                                                "wsdlPath", wsdl.relativePath(),
                                                "importedPath", importedWsdl,
                                                "importedName", fileName(null, importedWsdl)
                                        )
                                ).consume();
                            }

                            for (String refXsd : wsdl.referencedXsdRelativePaths()) {
                                tx.run("""
                                        MERGE (x:XsdFile {path: $xsdPath})
                                        ON CREATE SET x.name = $xsdName
                                        WITH x
                                        MATCH (w:WsdlFile {path: $wsdlPath})
                                        MERGE (w)-[:USES_XSD]->(x)
                                        """,
                                        Map.of(
                                                "wsdlPath", wsdl.relativePath(),
                                                "xsdPath", refXsd,
                                                "xsdName", fileName(null, refXsd)
                                        )
                                ).consume();
                            }
                        }

                        for (ProcessDependencies.XsdDependency xsd : deps.xsdFiles()) {
                            tx.run("""
                                    MERGE (x:XsdFile {path: $xsdPath})
                                    SET x.name = $xsdName,
                                        x.targetNamespace = $targetNamespace
                                    WITH x
                                    MATCH (b:BpelFile {path: $bpelPath})
                                    MERGE (b)-[r:DEPENDS_ON_XSD]->(x)
                                    SET r.reasons = $reasons
                                    """,
                                    Map.of(
                                            "xsdPath", xsd.relativePath(),
                                            "xsdName", fileName(xsd.file(), xsd.relativePath()),
                                            "targetNamespace", xsd.targetNamespace(),
                                            "bpelPath", bpelPath,
                                            "reasons", xsd.reasons()
                                    )
                            ).consume();
                            xEdges++;

                            for (String importedXsd : xsd.importedXsdRelativePaths()) {
                                tx.run("""
                                        MERGE (x2:XsdFile {path: $importedPath})
                                        ON CREATE SET x2.name = $importedName
                                        WITH x2
                                        MATCH (x1:XsdFile {path: $xsdPath})
                                        MERGE (x1)-[:IMPORTS_XSD]->(x2)
                                        """,
                                        Map.of(
                                                "xsdPath", xsd.relativePath(),
                                                "importedPath", importedXsd,
                                                "importedName", fileName(null, importedXsd)
                                        )
                                ).consume();
                            }
                        }
                    }

                    if (includeComponents && report.components() != null) {
                        int[] compCounts = publishComponents(tx, bpelPath, report.components());
                        cNodes += compCounts[0];
                        cEdges += compCounts[1];
                    }
                }

                // Cross-process BPEL -> BPEL invocation edges
                for (ProcessAuditReport report : reports) {
                    if (report.dependencies() == null || report.dependencies().deployXml().isEmpty()) {
                        continue;
                    }
                    String callerPath = report.relativeSourcePath();
                    for (ProcessDependencies.ServiceBindingRef ref : report.dependencies().deployXml().get().invokedServices()) {
                        String svcKey = Neo4jCypherRenderer.servicePortKey(ref);
                        for (String targetPath : providedServiceToBpels.getOrDefault(svcKey, List.of())) {
                            if (callerPath.equals(targetPath)) {
                                continue;
                            }
                            tx.run("""
                                    MATCH (caller:BpelFile {path: $callerPath}), (callee:BpelFile {path: $calleePath})
                                    MERGE (caller)-[r:INVOKES_PROCESS {partnerLink: $partnerLink}]->(callee)
                                    SET r.serviceName = $serviceName,
                                        r.portName = $portName
                                    """,
                                    Map.of(
                                            "callerPath", callerPath,
                                            "calleePath", targetPath,
                                            "partnerLink", ref.partnerLink(),
                                            "serviceName", ref.serviceName().toString(),
                                            "portName", ref.portName()
                                    )
                            ).consume();
                            pEdges++;
                        }
                    }
                }

                return new int[]{dEdges, wEdges, xEdges, pEdges, cNodes, cEdges};
            });

            return new PublishSummary(reports.size(), counts[0], counts[1], counts[2], counts[3], counts[4], counts[5]);
        }
    }

    private int[] publishComponents(TransactionContext tx, String bpelPath, BpelComponentGraph comp) {
        String bpelNodeId = "bpel:" + bpelPath;
        Map<String, String> idToLabel = new HashMap<>();
        int nodeCount = 0;
        int edgeCount = 0;

        for (BpelComponentGraph.ComponentNode node : comp.nodes()) {
            String label = ALLOWED_COMPONENT_LABELS.contains(node.label()) ? node.label() : "BpelActivity";
            idToLabel.put(node.id(), label);

            Map<String, Object> props = new LinkedHashMap<>(node.properties());
            props.put("id", node.id());
            props.put("name", node.name());
            props.put("kind", node.kind());
            props.put("bpelPath", bpelPath);
            if (node.parentActivityId() != null) {
                props.put("parentActivityId", node.parentActivityId());
            }

            tx.run("MERGE (c:" + label + " {id: $id}) SET c += $props",
                    Map.of("id", node.id(), "props", props)
            ).consume();
            nodeCount++;
        }

        for (BpelComponentGraph.ComponentEdge edge : comp.edges()) {
            String relType = ALLOWED_COMPONENT_REL_TYPES.contains(edge.type()) ? edge.type() : "CONTAINS";
            boolean srcIsBpel = edge.source().equals(bpelNodeId);
            boolean tgtIsBpel = edge.target().equals(bpelNodeId);

            String srcClause = srcIsBpel
                    ? "(src:BpelFile {path: $bpelPath})"
                    : "(src:" + idToLabel.getOrDefault(edge.source(), "BpelActivity") + " {id: $srcId})";
            String tgtClause = tgtIsBpel
                    ? "(tgt:BpelFile {path: $bpelPath})"
                    : "(tgt:" + idToLabel.getOrDefault(edge.target(), "BpelActivity") + " {id: $tgtId})";

            Map<String, Object> params = new LinkedHashMap<>();
            params.put("bpelPath", bpelPath);
            params.put("srcId", edge.source());
            params.put("tgtId", edge.target());
            params.put("props", edge.properties());

            tx.run("MATCH " + srcClause + ", " + tgtClause
                    + " MERGE (src)-[r:" + relType + "]->(tgt) SET r += $props",
                    params
            ).consume();
            edgeCount++;
        }
        return new int[]{nodeCount, edgeCount};
    }

    private void mergeDeployBinding(
            TransactionContext tx,
            String processName,
            String deployPath,
            ProcessDependencies.ServiceBindingRef ref,
            String direction
    ) {
        if (ref.wsdlRelativePath().isPresent()) {
            String wsdlPath = ref.wsdlRelativePath().get();
            tx.run("""
                    MERGE (w:WsdlFile {path: $wsdlPath})
                    ON CREATE SET w.name = $wsdlName
                    WITH w
                    MATCH (d:DeployXml {path: $deployPath})
                    MERGE (d)-[r:BINDS_SERVICE {processName: $processName, partnerLink: $partnerLink, direction: $direction}]->(w)
                    SET r.serviceName = $serviceName,
                        r.portName = $portName
                    """,
                    Map.of(
                            "processName", processName,
                            "deployPath", deployPath,
                            "wsdlPath", wsdlPath,
                            "wsdlName", fileName(ref.wsdlFile().orElse(null), wsdlPath),
                            "partnerLink", ref.partnerLink(),
                            "direction", direction,
                            "serviceName", ref.serviceName().toString(),
                            "portName", ref.portName()
                    )
            ).consume();
        } else {
            String svcKey = Neo4jCypherRenderer.servicePortKey(ref);
            tx.run("""
                    MERGE (s:ExternalService {key: $svcKey})
                    SET s.name = $svcLocalName,
                        s.serviceName = $serviceName,
                        s.portName = $portName
                    WITH s
                    MATCH (d:DeployXml {path: $deployPath})
                    MERGE (d)-[r:BINDS_SERVICE {processName: $processName, partnerLink: $partnerLink, direction: $direction}]->(s)
                    SET r.serviceName = $serviceName,
                        r.portName = $portName
                    """,
                    Map.of(
                            "processName", processName,
                            "deployPath", deployPath,
                            "svcKey", svcKey,
                            "svcLocalName", ref.serviceName().getLocalPart(),
                            "partnerLink", ref.partnerLink(),
                            "direction", direction,
                            "serviceName", ref.serviceName().toString(),
                            "portName", ref.portName()
                    )
            ).consume();
        }
    }

    private String fileName(Path path, String fallbackRelPath) {
        if (path != null && path.getFileName() != null) {
            return path.getFileName().toString();
        }
        int slash = fallbackRelPath.lastIndexOf('/');
        return slash >= 0 ? fallbackRelPath.substring(slash + 1) : fallbackRelPath;
    }

    @Override
    public void close() {
        driver.close();
    }
}
