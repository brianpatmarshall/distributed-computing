package com.corev5.bpel.inspector.analyzer;

import com.corev5.bpel.inspector.model.ast.*;
import com.corev5.bpel.inspector.model.ast.BpelActivity.*;
import com.corev5.bpel.inspector.model.report.BpelComponentGraph;
import com.corev5.bpel.inspector.model.report.BpelComponentGraph.*;
import com.corev5.bpel.inspector.model.report.MigrationCategory;
import com.corev5.bpel.inspector.model.report.ProcessDependencies;

import java.util.*;

/**
 * Extracts the internal component graph (partnerLinks, variables, correlationSets,
 * and nested BPEL activities with control/data-flow edges) and generates a
 * deterministic plain-English explanation of a BPEL process.
 */
public final class BpelComponentAnalyzer {

    public BpelComponentGraph analyze(
            BpelProcess process,
            String bpelRelativePath,
            MigrationCategory category,
            boolean inMemory,
            ProcessDependencies dependencies
    ) {
        String bpelNodeId = "bpel:" + bpelRelativePath;
        List<ComponentNode> nodes = new ArrayList<>();
        Map<String, ComponentEdge> edges = new LinkedHashMap<>();
        List<ExplanationStep> steps = new ArrayList<>();
        List<String> handlerSummaries = new ArrayList<>();
        Set<String> observations = new LinkedHashSet<>();

        Map<String, String> partnerLinkIds = new LinkedHashMap<>();
        for (BpelProcess.PartnerLinkDecl pl : process.partnerLinks().values()) {
            String plId = "pl:" + bpelRelativePath + ":" + pl.name();
            partnerLinkIds.put(pl.name(), plId);

            Map<String, Object> props = new LinkedHashMap<>();
            props.put("bpelPath", bpelRelativePath);
            props.put("name", pl.name());
            props.put("partnerLinkType", pl.partnerLinkType().toString());
            pl.myRole().ifPresent(r -> props.put("myRole", r));
            pl.partnerRole().ifPresent(r -> props.put("partnerRole", r));

            nodes.add(new ComponentNode(plId, "BpelPartnerLink", "PARTNER_LINK", pl.name(), null, props));
            addEdge(edges, bpelNodeId, plId, "HAS_PARTNER_LINK", Map.of());
        }

        Map<String, String> variableIds = new LinkedHashMap<>();
        for (BpelProcess.VariableDecl v : process.variables().values()) {
            String varId = "var:" + bpelRelativePath + ":" + v.name();
            variableIds.put(v.name(), varId);

            Map<String, Object> props = new LinkedHashMap<>();
            props.put("bpelPath", bpelRelativePath);
            props.put("name", v.name());
            v.messageType().ifPresent(m -> props.put("messageType", m.toString()));
            v.elementType().ifPresent(e -> props.put("elementType", e.toString()));
            v.xmlType().ifPresent(t -> props.put("xmlType", t.toString()));

            nodes.add(new ComponentNode(varId, "BpelVariable", "VARIABLE", v.name(), null, props));
            addEdge(edges, bpelNodeId, varId, "HAS_VARIABLE", Map.of());
        }

        for (String corr : process.correlationSets()) {
            String corrId = "corr:" + bpelRelativePath + ":" + corr;
            Map<String, Object> props = new LinkedHashMap<>();
            props.put("bpelPath", bpelRelativePath);
            props.put("name", corr);
            nodes.add(new ComponentNode(corrId, "BpelCorrelationSet", "CORRELATION_SET", corr, null, props));
            addEdge(edges, bpelNodeId, corrId, "HAS_CORRELATION_SET", Map.of());
        }

        WalkContext ctx = new WalkContext(
                bpelRelativePath,
                partnerLinkIds,
                variableIds,
                nodes,
                edges,
                steps,
                handlerSummaries,
                observations
        );

        String rootActId = walkActivity(process.rootActivity(), null, ctx);
        addEdge(edges, bpelNodeId, rootActId, "HAS_ROOT_ACTIVITY", Map.of());

        if (process.hasProcessFaultHandlers()) {
            handlerSummaries.add("Process-level <faultHandlers> are defined to catch unhandled faults across the workflow.");
        }
        if (process.hasProcessEventHandlers()) {
            handlerSummaries.add("Process-level <eventHandlers> listen for concurrent inbound events or alarms while the process is active.");
            observations.add("Process-level event handlers require persistent instance correlation in a reactive migration.");
        }

        for (int i = 0; i < process.processHandlerActivities().size(); i++) {
            BpelActivity handler = process.processHandlerActivities().get(i);
            String hId = walkActivity(handler, null, ctx);
            addEdge(edges, bpelNodeId, hId, "HAS_PROCESS_HANDLER", Map.of("order", i + 1));
        }

        BpelExplanation explanation = buildExplanation(process, category, inMemory, dependencies, ctx);
        return new BpelComponentGraph(explanation, List.copyOf(nodes), List.copyOf(edges.values()));
    }

    private String walkActivity(BpelActivity activity, String parentId, WalkContext ctx) {
        String id = "act:" + ctx.bpelPath + ":" + (++ctx.counter);
        String kind = activityKind(activity);
        String displayName = displayName(activity, kind);

        Map<String, Object> props = new LinkedHashMap<>();
        props.put("bpelPath", ctx.bpelPath);
        props.put("kind", kind);
        props.put("name", displayName);

        switch (activity) {
            case ReceiveNode rec -> {
                props.put("partnerLink", rec.partnerLink());
                props.put("operation", rec.operation());
                props.put("variable", rec.variable());
                props.put("createInstance", rec.createInstance());
                if (rec.createInstance() && ctx.triggerDescription == null) {
                    ctx.triggerDescription = String.format(
                            "Instantiated by inbound <%s> operation '%s' on partnerLink '%s' (stored in variable '%s').",
                            "receive", rec.operation(), rec.partnerLink(), rec.variable()
                    );
                }
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                linkPartner(ctx, id, rec.partnerLink(), rec.operation(), "inbound");
                linkVariable(ctx, id, rec.variable(), "WRITES_VARIABLE");

                ctx.addStep(id, kind,
                        (rec.createInstance() ? "Receive Entry: " : "Await Callback: ") + rec.partnerLink() + "." + rec.operation(),
                        rec.createInstance()
                                ? String.format("Starts a new workflow instance when '%s' calls '%s', saving the payload into '%s'.",
                                        rec.partnerLink(), rec.operation(), rec.variable())
                                : String.format("Pauses mid-flight waiting for correlated callback '%s' from '%s' into '%s'.",
                                        rec.operation(), rec.partnerLink(), rec.variable())
                );
            }
            case ReplyNode rep -> {
                props.put("partnerLink", rep.partnerLink());
                props.put("operation", rep.operation());
                props.put("variable", rep.variable());
                rep.faultName().ifPresent(f -> props.put("faultName", f.toString()));
                ctx.hasReply = true;
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                linkPartner(ctx, id, rep.partnerLink(), rep.operation(), "reply");
                linkVariable(ctx, id, rep.variable(), "READS_VARIABLE");

                ctx.addStep(id, kind,
                        "Reply: " + rep.partnerLink() + "." + rep.operation(),
                        rep.faultName().isPresent()
                                ? String.format("Returns fault '%s' to '%s' for operation '%s' using variable '%s'.",
                                        rep.faultName().get().getLocalPart(), rep.partnerLink(), rep.operation(), rep.variable())
                                : String.format("Sends synchronous response from variable '%s' back to '%s' for '%s'.",
                                        rep.variable(), rep.partnerLink(), rep.operation())
                );
            }
            case InvokeNode inv -> {
                props.put("partnerLink", inv.partnerLink());
                props.put("operation", inv.operation());
                props.put("synchronous", inv.isSynchronous());
                inv.inputVariable().ifPresent(v -> props.put("inputVariable", v));
                inv.outputVariable().ifPresent(v -> props.put("outputVariable", v));
                ctx.invokedOps.add(inv.partnerLink() + "." + inv.operation());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                linkPartner(ctx, id, inv.partnerLink(), inv.operation(), inv.isSynchronous() ? "sync-invoke" : "oneway-invoke");
                inv.inputVariable().ifPresent(v -> linkVariable(ctx, id, v, "READS_VARIABLE"));
                inv.outputVariable().ifPresent(v -> linkVariable(ctx, id, v, "WRITES_VARIABLE"));

                ctx.addStep(id, kind,
                        (inv.isSynchronous() ? "Invoke (Sync): " : "Invoke (One-Way): ") + inv.partnerLink() + "." + inv.operation(),
                        inv.isSynchronous()
                                ? String.format("Calls '%s.%s' synchronously (request: %s -> response: %s).",
                                        inv.partnerLink(), inv.operation(),
                                        inv.inputVariable().orElse("none"), inv.outputVariable().orElse("none"))
                                : String.format("Fires a one-way call to '%s.%s' (request: %s).",
                                        inv.partnerLink(), inv.operation(), inv.inputVariable().orElse("none"))
                );
            }
            case AssignNode assign -> {
                props.put("copyCount", assign.copies().size());
                List<String> mappings = new ArrayList<>();
                for (CopyOperation copy : assign.copies()) {
                    String fromDesc = describeEndpoint(copy.from());
                    String toDesc = describeEndpoint(copy.to());
                    mappings.add(fromDesc + " -> " + toDesc);
                    copy.from().variableName().ifPresent(v -> linkVariable(ctx, id, v, "READS_VARIABLE"));
                    copy.to().variableName().ifPresent(v -> linkVariable(ctx, id, v, "WRITES_VARIABLE"));
                }
                if (!mappings.isEmpty()) {
                    props.put("mappings", mappings);
                }
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));

                String preview = mappings.isEmpty()
                        ? "Performs variable initialization/transformation."
                        : "Copies " + String.join("; ", mappings.subList(0, Math.min(3, mappings.size())))
                                + (mappings.size() > 3 ? " (+" + (mappings.size() - 3) + " more)" : "") + ".";
                ctx.addStep(id, kind, "Transform Data (" + displayName + ")", preview);
            }
            case SequenceNode seq -> {
                props.put("stepCount", seq.steps().size());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                String prevChildId = null;
                for (int i = 0; i < seq.steps().size(); i++) {
                    String childId = walkActivity(seq.steps().get(i), id, ctx);
                    addEdge(ctx.edges, id, childId, "CONTAINS", Map.of("order", i + 1));
                    if (prevChildId != null) {
                        addEdge(ctx.edges, prevChildId, childId, "NEXT", Map.of());
                    }
                    prevChildId = childId;
                }
            }
            case FlowNode flow -> {
                props.put("branchCount", flow.branches().size());
                props.put("hasLinks", flow.hasLinks());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                ctx.observations.add(flow.hasLinks()
                        ? "Uses parallel <flow> with <links> transition dependencies (model as a Reactor DAG before Mono.zip)."
                        : "Executes " + flow.branches().size() + " branches in parallel via <flow> (maps cleanly to Mono.zip).");
                ctx.addStep(id, kind,
                        "Parallel Fan-Out (" + flow.branches().size() + " branches)",
                        String.format("Executes %d concurrent branch(es)%s and joins before continuing.",
                                flow.branches().size(), flow.hasLinks() ? " coordinated by BPEL <links>" : ""));
                for (int i = 0; i < flow.branches().size(); i++) {
                    String childId = walkActivity(flow.branches().get(i), id, ctx);
                    addEdge(ctx.edges, id, childId, "CONTAINS", Map.of("order", i + 1, "branch", "parallel-" + (i + 1)));
                }
            }
            case IfNode ifNode -> {
                props.put("branchCount", ifNode.branches().size());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                String firstCond = ifNode.branches().isEmpty()
                        ? ""
                        : ifNode.branches().getFirst().conditionExpr().orElse("");
                ctx.addStep(id, kind,
                        "Conditional Branch (" + ifNode.branches().size() + " paths)",
                        firstCond.isBlank()
                                ? "Branches workflow execution based on runtime conditions."
                                : "Evaluates condition `" + firstCond + "` across " + ifNode.branches().size() + " branch(es).");
                for (int i = 0; i < ifNode.branches().size(); i++) {
                    ConditionalBranch br = ifNode.branches().get(i);
                    String childId = walkActivity(br.activity(), id, ctx);
                    String label = br.conditionExpr().map(c -> "if: " + c).orElse("else");
                    addEdge(ctx.edges, id, childId, "CONTAINS", Map.of("order", i + 1, "branch", label));
                }
            }
            case LoopNode loop -> {
                props.put("loopType", loop.loopType());
                props.put("parallel", loop.parallel());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                ctx.addStep(id, kind,
                        "Loop (" + loop.loopType() + (loop.parallel() ? ", parallel" : "") + ")",
                        loop.parallel()
                                ? "Iterates in parallel (maps to Flux.flatMap scatter-gather)."
                                : "Iterates sequentially using <" + loop.loopType() + "> (maps to Flux.concatMap).");
                String bodyId = walkActivity(loop.body(), id, ctx);
                addEdge(ctx.edges, id, bodyId, "CONTAINS", Map.of("order", 1, "branch", loop.loopType()));
            }
            case PickNode pick -> {
                props.put("createInstance", pick.createInstance());
                props.put("onMessageCount", pick.onMessages().size());
                props.put("onAlarmCount", pick.onAlarms().size());
                if (pick.createInstance() && ctx.triggerDescription == null) {
                    ctx.triggerDescription = "Instantiated by <pick> listening across " + pick.onMessages().size() + " message operation(s).";
                }
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                ctx.addStep(id, kind,
                        "Pick (" + pick.onMessages().size() + " message / " + pick.onAlarms().size() + " alarm)",
                        "Waits for the first matching inbound message or timeout alarm to fire.");
                int ord = 0;
                for (OnMessageBranch m : pick.onMessages()) {
                    linkPartner(ctx, id, m.partnerLink(), m.operation(), "onMessage");
                    linkVariable(ctx, id, m.variable(), "WRITES_VARIABLE");
                    String childId = walkActivity(m.activity(), id, ctx);
                    addEdge(ctx.edges, id, childId, "CONTAINS", Map.of("order", ++ord, "branch", "onMessage:" + m.operation()));
                }
                for (OnAlarmBranch a : pick.onAlarms()) {
                    String childId = walkActivity(a.activity(), id, ctx);
                    addEdge(ctx.edges, id, childId, "CONTAINS", Map.of("order", ++ord, "branch", "onAlarm:" + a.durationOrDeadlineExpr()));
                }
            }
            case ScopeNode scope -> {
                props.put("hasFaultHandlers", scope.hasFaultHandlers());
                props.put("hasCompensationHandler", scope.hasCompensationHandler());
                props.put("hasEventHandlers", scope.hasEventHandlers());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));

                List<String> traits = new ArrayList<>();
                if (scope.hasFaultHandlers()) traits.add("fault handler");
                if (scope.hasCompensationHandler()) traits.add("compensation handler");
                if (scope.hasEventHandlers()) traits.add("event handler");
                if (!traits.isEmpty()) {
                    ctx.handlerSummaries.add("Scope '" + displayName + "' attaches: " + String.join(", ", traits) + ".");
                }
                ctx.addStep(id, kind,
                        "Scope: " + displayName,
                        traits.isEmpty()
                                ? "Groups nested activities in an isolated execution scope."
                                : "Executes an isolated scope protected by " + String.join(" & ", traits) + ".");

                String primaryId = walkActivity(scope.primaryActivity(), id, ctx);
                addEdge(ctx.edges, id, primaryId, "CONTAINS", Map.of("order", 1, "branch", "primary"));
                for (int i = 0; i < scope.handlerActivities().size(); i++) {
                    String hId = walkActivity(scope.handlerActivities().get(i), id, ctx);
                    addEdge(ctx.edges, id, hId, "CONTAINS", Map.of("order", i + 2, "branch", "handler"));
                }
            }
            case WaitNode wait -> {
                props.put("expression", wait.durationOrDeadlineExpr());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                ctx.addStep(id, kind,
                        "Wait (" + wait.durationOrDeadlineExpr() + ")",
                        "Suspends workflow execution until timer/deadline `" + wait.durationOrDeadlineExpr() + "` elapses.");
            }
            case ThrowNode throwNode -> {
                throwNode.faultName().ifPresent(f -> props.put("faultName", f.toString()));
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                ctx.addStep(id, kind,
                        "Throw Fault" + throwNode.faultName().map(f -> ": " + f.getLocalPart()).orElse(""),
                        "Signals a BPEL fault to trigger enclosing <faultHandlers>.");
            }
            case CompensateNode comp -> {
                comp.targetScope().ifPresent(t -> props.put("targetScope", t));
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
                ctx.addStep(id, kind,
                        "Compensate" + comp.targetScope().map(t -> " (" + t + ")").orElse(""),
                        "Triggers Saga rollback compensation handlers for previously completed scopes.");
            }
            case EmptyNode empty -> {
                props.put("rawTag", empty.rawTag());
                ctx.nodes.add(new ComponentNode(id, "BpelActivity", kind, displayName, parentId, props));
            }
        }
        return id;
    }

    private BpelExplanation buildExplanation(
            BpelProcess process,
            MigrationCategory category,
            boolean inMemory,
            ProcessDependencies deps,
            WalkContext ctx
    ) {
        String trigger = ctx.triggerDescription != null
                ? ctx.triggerDescription
                : "No createInstance <receive> or <pick> detected (may be invoked internally or incomplete).";

        String deploySummary;
        if (deps != null && deps.deployXml().isPresent()) {
            ProcessDependencies.DeployDependency dd = deps.deployXml().get();
            deploySummary = String.format(
                    "Deployed via %s (%s) — provides %d service endpoint(s) and invokes %d partner endpoint(s).",
                    dd.relativePath(),
                    dd.inMemory() ? "in-memory transient execution" : "persisted ODE runtime state",
                    dd.providedServices().size(),
                    dd.invokedServices().size()
            );
        } else {
            deploySummary = "No matching Apache ODE deploy.xml binding was found in the scanned directory.";
            ctx.observations.add("No deploy.xml found for this process; partner endpoints could not be mapped to concrete WSDL services.");
        }

        String categoryNote = switch (category) {
            case STATELESS_PIPELINE -> "a stateless synchronous/one-way pipeline suitable for a direct Spring WebFlux + WebClient migration";
            case STATEFUL_ASYNC -> "a stateful asynchronous workflow (uses mid-flight waits/callbacks) requiring persisted state and 202 Accepted + webhook resume";
            case SAGA_COMPENSATING -> "a Saga-compensating workflow (uses compensation handlers) requiring explicit rollback orchestration";
        };

        String invokeText = ctx.invokedOps.isEmpty()
                ? "does not invoke downstream partner services"
                : "orchestrates " + ctx.invokedOps.size() + " downstream call(s): " + String.join(", ", ctx.invokedOps);

        String summary = String.format(
                "%s is %s. It declares %d partner link(s), %d variable(s), and %s%s.",
                process.processName(),
                categoryNote,
                process.partnerLinks().size(),
                process.variables().size(),
                invokeText,
                ctx.hasReply ? ", returning a synchronous reply to the caller" : ""
        );

        if (inMemory) {
            ctx.observations.add("Configured with <in-memory>true</in-memory> in deploy.xml, confirming low-latency stateless intent.");
        }
        if (deps != null && !deps.wsdlFiles().isEmpty()) {
            ctx.observations.add("Depends on " + deps.wsdlFiles().size() + " WSDL file(s) and " + deps.xsdFiles().size() + " XSD schema(s).");
        }

        return new BpelExplanation(
                summary,
                trigger,
                deploySummary,
                List.copyOf(ctx.steps),
                List.copyOf(ctx.handlerSummaries),
                List.copyOf(ctx.observations)
        );
    }

    private void linkPartner(WalkContext ctx, String activityId, String partnerLink, String operation, String role) {
        if (partnerLink == null || partnerLink.isBlank()) return;
        String plId = ctx.partnerLinkIds.get(partnerLink);
        if (plId != null) {
            addEdge(ctx.edges, activityId, plId, "USES_PARTNER_LINK",
                    Map.of("operation", operation == null ? "" : operation, "role", role));
        }
    }

    private void linkVariable(WalkContext ctx, String activityId, String varName, String relType) {
        if (varName == null || varName.isBlank()) return;
        String varId = ctx.variableIds.get(varName);
        if (varId != null) {
            addEdge(ctx.edges, activityId, varId, relType, Map.of());
        }
    }

    private void addEdge(
            Map<String, ComponentEdge> edges,
            String source,
            String target,
            String type,
            Map<String, Object> props
    ) {
        String edgeId = source + "->" + type + "->" + target;
        edges.putIfAbsent(edgeId, new ComponentEdge(edgeId, source, target, type, props));
    }

    private String describeEndpoint(DataEndpoint ep) {
        return switch (ep.kind()) {
            case VARIABLE_PART -> ep.variableName().orElse("?")
                    + ep.partName().map(p -> "." + p).orElse("")
                    + ep.xpathQuery().orElse("");
            case LITERAL -> ep.isSkeletonLiteral() ? "<xml-skeleton>" : "<literal>";
            case PARTNER_LINK -> "partnerLink(" + ep.variableName().orElse("?") + ")";
            case EXPRESSION -> ep.xpathQuery().orElse("<expr>");
            case UNKNOWN -> "<unknown>";
        };
    }

    private String activityKind(BpelActivity activity) {
        return switch (activity) {
            case ReceiveNode _ -> "RECEIVE";
            case ReplyNode _ -> "REPLY";
            case InvokeNode _ -> "INVOKE";
            case AssignNode _ -> "ASSIGN";
            case SequenceNode _ -> "SEQUENCE";
            case FlowNode _ -> "FLOW";
            case IfNode _ -> "IF";
            case LoopNode _ -> "LOOP";
            case PickNode _ -> "PICK";
            case ScopeNode _ -> "SCOPE";
            case WaitNode _ -> "WAIT";
            case ThrowNode _ -> "THROW";
            case CompensateNode _ -> "COMPENSATE";
            case EmptyNode _ -> "EMPTY";
        };
    }

    private String displayName(BpelActivity activity, String kind) {
        if (activity.name() != null && !activity.name().isBlank()) {
            return activity.name();
        }
        return switch (activity) {
            case ReceiveNode r -> "receive:" + r.operation();
            case ReplyNode r -> "reply:" + r.operation();
            case InvokeNode i -> "invoke:" + i.partnerLink() + "." + i.operation();
            case LoopNode l -> l.loopType();
            default -> kind.toLowerCase();
        };
    }

    private static final class WalkContext {
        final String bpelPath;
        final Map<String, String> partnerLinkIds;
        final Map<String, String> variableIds;
        final List<ComponentNode> nodes;
        final Map<String, ComponentEdge> edges;
        final List<ExplanationStep> steps;
        final List<String> handlerSummaries;
        final Set<String> observations;
        final Set<String> invokedOps = new LinkedHashSet<>();
        String triggerDescription;
        boolean hasReply;
        int counter = 0;

        WalkContext(
                String bpelPath,
                Map<String, String> partnerLinkIds,
                Map<String, String> variableIds,
                List<ComponentNode> nodes,
                Map<String, ComponentEdge> edges,
                List<ExplanationStep> steps,
                List<String> handlerSummaries,
                Set<String> observations
        ) {
            this.bpelPath = bpelPath;
            this.partnerLinkIds = partnerLinkIds;
            this.variableIds = variableIds;
            this.nodes = nodes;
            this.edges = edges;
            this.steps = steps;
            this.handlerSummaries = handlerSummaries;
            this.observations = observations;
        }

        void addStep(String activityId, String kind, String title, String detail) {
            steps.add(new ExplanationStep(steps.size() + 1, activityId, kind, title, detail));
        }
    }
}
