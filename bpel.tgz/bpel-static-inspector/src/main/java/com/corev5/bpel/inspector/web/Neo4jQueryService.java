package com.corev5.bpel.inspector.web;

import com.corev5.bpel.inspector.model.report.ProcessAuditReport;
import com.corev5.bpel.inspector.renderer.Neo4jGraphPublisher;
import org.neo4j.driver.*;
import org.neo4j.driver.types.Node;
import org.neo4j.driver.types.Path;
import org.neo4j.driver.types.Relationship;

import java.util.*;

/**
 * Handles live Neo4j Bolt connectivity checks, graph publishing, and read-only Cypher
 * graph queries for the React interactive Neo4j visualizer.
 */
public final class Neo4jQueryService {

    public record Neo4jConfig(
            String uri,
            String username,
            String password,
            String database
    ) {
        public String resolvedDatabase() {
            return (database == null || database.isBlank()) ? "neo4j" : database;
        }

        public String resolvedPassword() {
            return (password != null && !password.isEmpty()) ? password : System.getenv("NEO4J_PASSWORD");
        }
    }

    public record ConnectionStatus(
            boolean connected,
            String uri,
            String database,
            String serverAgent,
            String message
    ) {}

    public record QueryResult(
            List<ProjectAnalysisResult.GraphNode> nodes,
            List<ProjectAnalysisResult.GraphEdge> edges,
            int rowCount,
            long executionMs
    ) {}

    public ConnectionStatus testConnection(Neo4jConfig config) {
        try (Driver driver = createDriver(config)) {
            driver.verifyConnectivity();
            String agent = "Neo4j";
            try (Session session = driver.session(SessionConfig.builder().withDatabase(config.resolvedDatabase()).build())) {
                var summary = session.run("RETURN 1").consume();
                if (summary.server() != null && summary.server().agent() != null) {
                    agent = summary.server().agent();
                }
            }
            return new ConnectionStatus(true, config.uri(), config.resolvedDatabase(), agent, "Connected to Neo4j");
        } catch (Exception e) {
            return new ConnectionStatus(false, config.uri(), config.resolvedDatabase(), "", e.getMessage());
        }
    }

    public Neo4jGraphPublisher.PublishSummary publish(
            Neo4jConfig config,
            List<ProcessAuditReport> reports,
            boolean clearExisting,
            boolean includeComponents
    ) {
        try (Neo4jGraphPublisher publisher = new Neo4jGraphPublisher(
                config.uri(), config.username(), config.resolvedPassword(), config.resolvedDatabase()
        )) {
            return publisher.publish(reports, clearExisting, includeComponents);
        }
    }

    public QueryResult expandBpelComponents(Neo4jConfig config, String bpelPath) {
        long start = System.currentTimeMillis();
        Map<String, ProjectAnalysisResult.GraphNode> nodes = new LinkedHashMap<>();
        Map<String, ProjectAnalysisResult.GraphEdge> edges = new LinkedHashMap<>();

        try (Driver driver = createDriver(config);
             Session session = driver.session(SessionConfig.builder().withDatabase(config.resolvedDatabase()).build())) {
            int rowCount = session.executeRead(tx -> {
                Result result = tx.run("""
                        MATCH p = (b:BpelFile {path: $path})-[*1..6]->(c)
                        WHERE c:BpelActivity OR c:BpelPartnerLink OR c:BpelVariable OR c:BpelCorrelationSet
                        RETURN p
                        """,
                        Map.of("path", bpelPath)
                );
                int rows = 0;
                while (result.hasNext()) {
                    org.neo4j.driver.Record rec = result.next();
                    rows++;
                    for (Value v : rec.values()) {
                        extractGraphValues(v, nodes, edges);
                    }
                }
                return rows;
            });

            long elapsed = System.currentTimeMillis() - start;
            return new QueryResult(List.copyOf(nodes.values()), List.copyOf(edges.values()), rowCount, elapsed);
        }
    }

    public QueryResult executeReadQuery(Neo4jConfig config, String cypher) {
        long start = System.currentTimeMillis();
        Map<String, ProjectAnalysisResult.GraphNode> nodes = new LinkedHashMap<>();
        Map<String, ProjectAnalysisResult.GraphEdge> edges = new LinkedHashMap<>();

        try (Driver driver = createDriver(config);
             Session session = driver.session(SessionConfig.builder().withDatabase(config.resolvedDatabase()).build())) {
            int rowCount = session.executeRead(tx -> {
                Result result = tx.run(cypher);
                int rows = 0;
                while (result.hasNext()) {
                    org.neo4j.driver.Record rec = result.next();
                    rows++;
                    for (Value v : rec.values()) {
                        extractGraphValues(v, nodes, edges);
                    }
                }
                return rows;
            });

            long elapsed = System.currentTimeMillis() - start;
            return new QueryResult(List.copyOf(nodes.values()), List.copyOf(edges.values()), rowCount, elapsed);
        }
    }

    private void extractGraphValues(
            Value value,
            Map<String, ProjectAnalysisResult.GraphNode> nodes,
            Map<String, ProjectAnalysisResult.GraphEdge> edges
    ) {
        if (value == null || value.isNull()) {
            return;
        }
        switch (value.type().name()) {
            case "NODE" -> addNode(value.asNode(), nodes);
            case "RELATIONSHIP" -> addRelationship(value.asRelationship(), edges);
            case "PATH" -> {
                Path path = value.asPath();
                path.nodes().forEach(n -> addNode(n, nodes));
                path.relationships().forEach(r -> addRelationship(r, edges));
            }
            case "LIST OF ANY?" -> {
                for (Value item : value.values()) {
                    extractGraphValues(item, nodes, edges);
                }
            }
            case "MAP" -> {
                for (String key : value.keys()) {
                    extractGraphValues(value.get(key), nodes, edges);
                }
            }
            default -> {}
        }
    }

    private void addNode(Node node, Map<String, ProjectAnalysisResult.GraphNode> nodes) {
        String id = node.elementId();
        if (nodes.containsKey(id)) {
            return;
        }
        String label = "Node";
        for (String l : node.labels()) {
            label = l;
            break;
        }
        Map<String, Object> props = new LinkedHashMap<>(node.asMap());
        String name = Objects.toString(
                props.getOrDefault("name", props.getOrDefault("processName", props.getOrDefault("path", id))),
                id
        );
        String pathStr = Objects.toString(props.getOrDefault("path", ""), "");
        String subProject = pathStr.contains("/") ? pathStr.substring(0, pathStr.lastIndexOf('/')) : ".";
        nodes.put(id, new ProjectAnalysisResult.GraphNode(id, label, name, subProject, props));
    }

    private void addRelationship(Relationship rel, Map<String, ProjectAnalysisResult.GraphEdge> edges) {
        String id = rel.elementId();
        if (edges.containsKey(id)) {
            return;
        }
        edges.put(id, new ProjectAnalysisResult.GraphEdge(
                id,
                rel.startNodeElementId(),
                rel.endNodeElementId(),
                rel.type(),
                new LinkedHashMap<>(rel.asMap())
        ));
    }

    private Driver createDriver(Neo4jConfig config) {
        AuthToken auth = (config.username() == null || config.username().isBlank())
                ? AuthTokens.none()
                : AuthTokens.basic(config.username(), config.resolvedPassword() == null ? "" : config.resolvedPassword());
        return GraphDatabase.driver(config.uri(), auth);
    }
}
