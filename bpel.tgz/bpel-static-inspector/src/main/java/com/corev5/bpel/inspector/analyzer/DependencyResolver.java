package com.corev5.bpel.inspector.analyzer;

import com.corev5.bpel.inspector.model.ast.BpelActivity;
import com.corev5.bpel.inspector.model.ast.BpelActivity.*;
import com.corev5.bpel.inspector.model.ast.BpelProcess;
import com.corev5.bpel.inspector.model.contract.OdeDeploymentBinding;
import com.corev5.bpel.inspector.model.contract.SymbolTable;
import com.corev5.bpel.inspector.model.report.ProcessDependencies;

import javax.xml.namespace.QName;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class DependencyResolver {

    private static final String WSDL_NS = "http://schemas.xmlsoap.org/wsdl/";
    private static final String XSD_NS = "http://www.w3.org/2001/XMLSchema";

    private final SymbolTable symbols;

    public DependencyResolver(SymbolTable symbols) {
        this.symbols = symbols;
    }

    public Optional<OdeDeploymentBinding> findDeploymentBinding(BpelProcess process) {
        QName procQName = new QName(process.targetNamespace(), process.processName());
        OdeDeploymentBinding exact = symbols.odeDeployments().get(procQName);
        if (exact != null) {
            return Optional.of(exact);
        }
        Path bpelDir = process.sourceFile().toAbsolutePath().normalize().getParent();
        for (OdeDeploymentBinding binding : symbols.odeDeployments().values()) {
            Path deployDir = binding.sourceFile().toAbsolutePath().normalize().getParent();
            if (Objects.equals(bpelDir, deployDir)
                    && process.processName().equals(binding.processName().getLocalPart())) {
                return Optional.of(binding);
            }
        }
        return Optional.empty();
    }

    public ProcessDependencies resolve(BpelProcess process) {
        Map<Path, Set<String>> wsdlReasons = new LinkedHashMap<>();
        Map<Path, Set<String>> xsdReasons = new LinkedHashMap<>();

        // 1. Direct BPEL <import> declarations
        Path bpelDir = process.sourceFile().toAbsolutePath().normalize().getParent();
        for (BpelProcess.ImportDecl imp : process.imports()) {
            boolean matchedByLocation = false;
            if (imp.location().isPresent() && bpelDir != null) {
                String loc = imp.location().get();
                if (!loc.contains("://")) {
                    try {
                        Path resolved = bpelDir.resolve(loc).toAbsolutePath().normalize();
                        if (Files.isRegularFile(resolved)) {
                            matchedByLocation = true;
                            if (resolved.toString().endsWith(".xsd")
                                    || XSD_NS.equals(imp.importType().orElse(""))) {
                                addReason(xsdReasons, resolved, "bpel:import(" + loc + ")");
                            } else {
                                addReason(wsdlReasons, resolved, "bpel:import(" + loc + ")");
                            }
                        }
                    } catch (Exception ignored) {
                        // Fall through to namespace matching
                    }
                }
            }
            if (!matchedByLocation && imp.namespace() != null && !imp.namespace().isBlank()) {
                String impType = imp.importType().orElse("");
                if (XSD_NS.equals(impType)) {
                    symbols.xsdFiles().values().stream()
                            .filter(x -> imp.namespace().equals(x.targetNamespace()))
                            .forEach(x -> addReason(xsdReasons, x.sourceFile(), "bpel:import(ns=" + imp.namespace() + ")"));
                } else {
                    symbols.wsdlFiles().values().stream()
                            .filter(w -> imp.namespace().equals(w.targetNamespace()))
                            .forEach(w -> addReason(wsdlReasons, w.sourceFile(), "bpel:import(ns=" + imp.namespace() + ")"));
                }
            }
        }

        // 2. PartnerLinkType and associated PortType references
        for (BpelProcess.PartnerLinkDecl pl : process.partnerLinks().values()) {
            SymbolTable.PartnerLinkTypeDef pltDef = symbols.partnerLinkTypes().get(pl.partnerLinkType());
            if (pltDef != null) {
                addReason(wsdlReasons, pltDef.sourceFile(), "partnerLinkType:" + pl.partnerLinkType().getLocalPart());
                for (QName rolePt : pltDef.roleToPortType().values()) {
                    SymbolTable.WsdlPortTypeDef ptDef = symbols.portTypes().get(rolePt);
                    if (ptDef != null) {
                        addReason(wsdlReasons, ptDef.sourceFile(), "portType:" + rolePt.getLocalPart());
                    }
                }
            }
        }

        // 3. Variable messageType / element / type references
        for (BpelProcess.VariableDecl varDecl : process.variables().values()) {
            varDecl.messageType().ifPresent(msgQName -> {
                SymbolTable.WsdlMessageDef msgDef = symbols.messages().get(msgQName);
                if (msgDef != null) {
                    addReason(wsdlReasons, msgDef.sourceFile(), "messageType:" + msgQName.getLocalPart());
                }
            });
            varDecl.elementType().ifPresent(elQName -> {
                Path xsdPath = symbols.schemaElementToXsd().get(elQName);
                if (xsdPath != null) {
                    addReason(xsdReasons, xsdPath, "variable:" + varDecl.name() + "(element:" + elQName.getLocalPart() + ")");
                }
            });
            varDecl.xmlType().ifPresent(typeQName -> {
                Path xsdPath = symbols.schemaTypeToXsd().get(typeQName);
                if (xsdPath != null) {
                    addReason(xsdReasons, xsdPath, "variable:" + varDecl.name() + "(type:" + typeQName.getLocalPart() + ")");
                }
            });
        }

        // 4. Activity portType references (main activity + process-level handlers)
        collectActivityPortTypes(process.rootActivity(), wsdlReasons);
        process.processHandlerActivities().forEach(h -> collectActivityPortTypes(h, wsdlReasons));

        // 5. ODE deploy.xml binding and its service -> WSDL mappings
        Optional<ProcessDependencies.DeployDependency> deployDep = findDeploymentBinding(process)
                .map(binding -> buildDeployDependency(binding, wsdlReasons));

        // 6. Transitive <wsdl:import> dependencies
        Deque<Path> wsdlQueue = new ArrayDeque<>(wsdlReasons.keySet());
        Set<Path> visitedWsdls = new HashSet<>(wsdlReasons.keySet());
        while (!wsdlQueue.isEmpty()) {
            Path current = wsdlQueue.poll();
            SymbolTable.WsdlFileDef def = symbols.wsdlFiles().get(current);
            if (def == null) {
                continue;
            }
            for (Path imported : def.importedWsdlFiles()) {
                addReason(wsdlReasons, imported, "wsdl:import(from " + symbols.toRelativePath(current) + ")");
                if (visitedWsdls.add(imported)) {
                    wsdlQueue.add(imported);
                }
            }
        }

        // 7. XSDs referenced by any dependent WSDL + transitive <xs:import>/<xs:include>
        for (Path wsdlPath : wsdlReasons.keySet()) {
            SymbolTable.WsdlFileDef def = symbols.wsdlFiles().get(wsdlPath);
            if (def != null) {
                for (Path xsdPath : def.referencedXsdFiles()) {
                    addReason(xsdReasons, xsdPath, "wsdl:schema(from " + symbols.toRelativePath(wsdlPath) + ")");
                }
            }
        }
        Deque<Path> xsdQueue = new ArrayDeque<>(xsdReasons.keySet());
        Set<Path> visitedXsds = new HashSet<>(xsdReasons.keySet());
        while (!xsdQueue.isEmpty()) {
            Path current = xsdQueue.poll();
            SymbolTable.XsdFileDef def = symbols.xsdFiles().get(current);
            if (def == null) {
                continue;
            }
            for (Path imported : def.importedXsdFiles()) {
                addReason(xsdReasons, imported, "xsd:import(from " + symbols.toRelativePath(current) + ")");
                if (visitedXsds.add(imported)) {
                    xsdQueue.add(imported);
                }
            }
        }

        // Build deterministic sorted output lists
        List<ProcessDependencies.WsdlDependency> wsdlDeps = wsdlReasons.entrySet().stream()
                .sorted(Comparator.comparing(e -> symbols.toRelativePath(e.getKey())))
                .map(entry -> {
                    Path path = entry.getKey();
                    SymbolTable.WsdlFileDef def = symbols.wsdlFiles().get(path);
                    String tns = def != null ? def.targetNamespace() : "";
                    List<String> importedWsdls = def != null
                            ? def.importedWsdlFiles().stream().map(symbols::toRelativePath).sorted().toList()
                            : List.of();
                    List<String> refXsds = def != null
                            ? def.referencedXsdFiles().stream().map(symbols::toRelativePath).sorted().toList()
                            : List.of();
                    return new ProcessDependencies.WsdlDependency(
                            path,
                            symbols.toRelativePath(path),
                            tns,
                            List.copyOf(entry.getValue()),
                            importedWsdls,
                            refXsds
                    );
                })
                .toList();

        List<ProcessDependencies.XsdDependency> xsdDeps = xsdReasons.entrySet().stream()
                .sorted(Comparator.comparing(e -> symbols.toRelativePath(e.getKey())))
                .map(entry -> {
                    Path path = entry.getKey();
                    SymbolTable.XsdFileDef def = symbols.xsdFiles().get(path);
                    String tns = def != null ? def.targetNamespace() : "";
                    List<String> importedXsds = def != null
                            ? def.importedXsdFiles().stream().map(symbols::toRelativePath).sorted().toList()
                            : List.of();
                    return new ProcessDependencies.XsdDependency(
                            path,
                            symbols.toRelativePath(path),
                            tns,
                            List.copyOf(entry.getValue()),
                            importedXsds
                    );
                })
                .toList();

        return new ProcessDependencies(deployDep, wsdlDeps, xsdDeps);
    }

    private ProcessDependencies.DeployDependency buildDeployDependency(
            OdeDeploymentBinding binding,
            Map<Path, Set<String>> wsdlReasons
    ) {
        List<ProcessDependencies.ServiceBindingRef> provided = binding.providedEndpoints().entrySet().stream()
                .map(e -> toServiceBindingRef(e.getKey(), e.getValue(), "provide", wsdlReasons))
                .toList();
        List<ProcessDependencies.ServiceBindingRef> invoked = binding.invokedEndpoints().entrySet().stream()
                .map(e -> toServiceBindingRef(e.getKey(), e.getValue(), "invoke", wsdlReasons))
                .toList();

        return new ProcessDependencies.DeployDependency(
                binding.sourceFile(),
                symbols.toRelativePath(binding.sourceFile()),
                binding.inMemory(),
                provided,
                invoked
        );
    }

    private ProcessDependencies.ServiceBindingRef toServiceBindingRef(
            String partnerLink,
            OdeDeploymentBinding.EndpointRef endpointRef,
            String direction,
            Map<Path, Set<String>> wsdlReasons
    ) {
        Optional<Path> wsdlPath = resolveServiceWsdl(endpointRef.serviceName());
        wsdlPath.ifPresent(p -> addReason(wsdlReasons, p, "deploy.xml:" + direction + "(" + partnerLink + ")"));
        return new ProcessDependencies.ServiceBindingRef(
                partnerLink,
                endpointRef.serviceName(),
                endpointRef.portName(),
                wsdlPath,
                wsdlPath.map(symbols::toRelativePath)
        );
    }

    private Optional<Path> resolveServiceWsdl(QName serviceName) {
        if (serviceName == null || serviceName.getLocalPart().isBlank()) {
            return Optional.empty();
        }
        Path direct = symbols.serviceToWsdl().get(serviceName);
        if (direct != null) {
            return Optional.of(direct);
        }
        String ns = serviceName.getNamespaceURI();
        if (ns != null && !ns.isBlank()) {
            List<Path> matches = symbols.wsdlFiles().values().stream()
                    .filter(w -> ns.equals(w.targetNamespace()))
                    .map(SymbolTable.WsdlFileDef::sourceFile)
                    .toList();
            if (matches.size() == 1) {
                return Optional.of(matches.getFirst());
            }
        }
        return Optional.empty();
    }

    private void collectActivityPortTypes(BpelActivity activity, Map<Path, Set<String>> wsdlReasons) {
        switch (activity) {
            case ReceiveNode rec -> recordPortType(rec.portType(), wsdlReasons);
            case ReplyNode rep -> recordPortType(rep.portType(), wsdlReasons);
            case InvokeNode inv -> recordPortType(inv.portType(), wsdlReasons);
            case PickNode pick -> {
                for (OnMessageBranch m : pick.onMessages()) {
                    recordPortType(m.portType(), wsdlReasons);
                    collectActivityPortTypes(m.activity(), wsdlReasons);
                }
                pick.onAlarms().forEach(a -> collectActivityPortTypes(a.activity(), wsdlReasons));
            }
            case SequenceNode seq -> seq.steps().forEach(s -> collectActivityPortTypes(s, wsdlReasons));
            case FlowNode flow -> flow.branches().forEach(b -> collectActivityPortTypes(b, wsdlReasons));
            case IfNode ifNode -> ifNode.branches().forEach(b -> collectActivityPortTypes(b.activity(), wsdlReasons));
            case LoopNode loop -> collectActivityPortTypes(loop.body(), wsdlReasons);
            case ScopeNode scope -> {
                collectActivityPortTypes(scope.primaryActivity(), wsdlReasons);
                scope.handlerActivities().forEach(h -> collectActivityPortTypes(h, wsdlReasons));
            }
            default -> {}
        }
    }

    private void recordPortType(QName portType, Map<Path, Set<String>> wsdlReasons) {
        if (portType == null || portType.getLocalPart().isBlank()) {
            return;
        }
        SymbolTable.WsdlPortTypeDef ptDef = symbols.portTypes().get(portType);
        if (ptDef != null) {
            addReason(wsdlReasons, ptDef.sourceFile(), "portType:" + portType.getLocalPart());
        }
    }

    private void addReason(Map<Path, Set<String>> map, Path file, String reason) {
        if (file != null) {
            map.computeIfAbsent(file.toAbsolutePath().normalize(), _ -> new LinkedHashSet<>()).add(reason);
        }
    }
}
