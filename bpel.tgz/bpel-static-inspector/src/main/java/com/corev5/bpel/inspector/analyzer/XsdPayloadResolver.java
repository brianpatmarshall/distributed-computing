package com.corev5.bpel.inspector.analyzer;

import com.corev5.bpel.inspector.model.contract.SymbolTable;
import com.corev5.bpel.inspector.model.report.PayloadFieldSpec;
import org.apache.ws.commons.schema.*;

import javax.xml.namespace.QName;
import java.util.*;

public final class XsdPayloadResolver {

    private static final String XSD_NS = "http://www.w3.org/2001/XMLSchema";
    private final SymbolTable symbols;

    public XsdPayloadResolver(SymbolTable symbols) {
        this.symbols = symbols;
    }

    public List<PayloadFieldSpec> resolvePayloadTree(QName messageOrElementQName, Set<String> activeXPaths) {
        if (messageOrElementQName == null) {
            return List.of();
        }
        Set<String> normalizedActivePaths = normalizeXPaths(activeXPaths);

        SymbolTable.WsdlMessageDef msgDef = symbols.messages().get(messageOrElementQName);
        if (msgDef != null) {
            List<PayloadFieldSpec> parts = new ArrayList<>();
            for (var entry : msgDef.partToElementOrType().entrySet()) {
                String partName = entry.getKey();
                QName partTarget = entry.getValue();
                XmlSchemaElement rootEl = symbols.schemaCollection().getElementByQName(partTarget);
                if (rootEl != null) {
                    parts.add(walkElement(rootEl, "/" + rootEl.getName(), normalizedActivePaths, new HashSet<>()));
                } else {
                    XmlSchemaType schemaType = symbols.schemaCollection().getTypeByQName(partTarget);
                    parts.add(walkType(partName, "/" + partName, schemaType, true, false, normalizedActivePaths, new HashSet<>()));
                }
            }
            return List.copyOf(parts);
        }

        XmlSchemaElement rootEl = symbols.schemaCollection().getElementByQName(messageOrElementQName);
        if (rootEl != null) {
            return List.of(walkElement(rootEl, "/" + rootEl.getName(), normalizedActivePaths, new HashSet<>()));
        }
        XmlSchemaType schemaType = symbols.schemaCollection().getTypeByQName(messageOrElementQName);
        if (schemaType != null) {
            String name = messageOrElementQName.getLocalPart();
            return List.of(walkType(name, "/" + name, schemaType, true, false, normalizedActivePaths, new HashSet<>()));
        }
        return List.of();
    }

    private PayloadFieldSpec walkElement(
            XmlSchemaElement element,
            String currentPath,
            Set<String> activePaths,
            Set<QName> visitedTypes
    ) {
        XmlSchemaElement target = element.isRef() && element.getRef().getTarget() != null
                ? element.getRef().getTarget()
                : element;

        String name = target.getName();
        boolean required = element.getMinOccurs() >= 1;
        boolean isCollection = element.getMaxOccurs() > 1 || element.getMaxOccurs() == Long.MAX_VALUE;
        XmlSchemaType schemaType = target.getSchemaType();

        if (schemaType == null && target.getSchemaTypeName() != null) {
            schemaType = symbols.schemaCollection().getTypeByQName(target.getSchemaTypeName());
        }

        return walkType(name, currentPath, schemaType, required, isCollection, activePaths, visitedTypes);
    }

    private PayloadFieldSpec walkType(
            String fieldName,
            String currentPath,
            XmlSchemaType schemaType,
            boolean required,
            boolean isCollection,
            Set<String> activePaths,
            Set<QName> visitedTypes
    ) {
        if (schemaType instanceof XmlSchemaComplexType complexType) {
            QName typeQName = complexType.getQName();
            if (typeQName != null && !visitedTypes.add(typeQName)) {
                return new PayloadFieldSpec(fieldName, currentPath, mapTypeName(typeQName), required, isCollection, isPathUsed(currentPath, activePaths), List.of());
            }

            List<PayloadFieldSpec> children = new ArrayList<>();
            extractParticleChildren(complexType.getParticle(), currentPath, activePaths, visitedTypes, children);

            if (complexType.getContentModel() instanceof XmlSchemaComplexContent cc
                    && cc.getContent() instanceof XmlSchemaComplexContentExtension ext) {
                if (ext.getBaseTypeName() != null) {
                    XmlSchemaType baseType = symbols.schemaCollection().getTypeByQName(ext.getBaseTypeName());
                    PayloadFieldSpec baseSpec = walkType(fieldName, currentPath, baseType, required, isCollection, activePaths, new HashSet<>(visitedTypes));
                    children.addAll(baseSpec.children());
                }
                extractParticleChildren(ext.getParticle(), currentPath, activePaths, visitedTypes, children);
            }

            if (typeQName != null) {
                visitedTypes.remove(typeQName);
            }
            boolean used = isPathUsed(currentPath, activePaths) || children.stream().anyMatch(PayloadFieldSpec::usedByBpel);
            String javaType = toPascalCase(fieldName) + (isCollection ? " (List)" : "");
            return new PayloadFieldSpec(fieldName, currentPath, javaType, required, isCollection, used, List.copyOf(children));
        }

        QName scalarQName = schemaType != null ? schemaType.getQName() : new QName(XSD_NS, "string");
        return new PayloadFieldSpec(
                fieldName,
                currentPath,
                mapXsdScalarToJava(scalarQName),
                required,
                isCollection,
                isPathUsed(currentPath, activePaths),
                List.of()
        );
    }

    private void extractParticleChildren(
            XmlSchemaParticle particle,
            String parentPath,
            Set<String> activePaths,
            Set<QName> visitedTypes,
            List<PayloadFieldSpec> out
    ) {
        if (particle instanceof XmlSchemaSequence seq) {
            for (XmlSchemaSequenceMember member : seq.getItems()) {
                if (member instanceof XmlSchemaElement childEl) {
                    String name = childEl.isRef() && childEl.getRef().getTarget() != null
                            ? childEl.getRef().getTarget().getName()
                            : childEl.getName();
                    out.add(walkElement(childEl, parentPath + "/" + name, activePaths, visitedTypes));
                } else if (member instanceof XmlSchemaParticle nested) {
                    extractParticleChildren(nested, parentPath, activePaths, visitedTypes, out);
                }
            }
        } else if (particle instanceof XmlSchemaChoice choice) {
            for (XmlSchemaChoiceMember member : choice.getItems()) {
                if (member instanceof XmlSchemaElement childEl) {
                    String name = childEl.isRef() && childEl.getRef().getTarget() != null
                            ? childEl.getRef().getTarget().getName()
                            : childEl.getName();
                    out.add(walkElement(childEl, parentPath + "/" + name, activePaths, visitedTypes));
                } else if (member instanceof XmlSchemaParticle nested) {
                    extractParticleChildren(nested, parentPath, activePaths, visitedTypes, out);
                }
            }
        } else if (particle instanceof XmlSchemaAll all) {
            for (XmlSchemaAllMember member : all.getItems()) {
                if (member instanceof XmlSchemaElement childEl) {
                    String name = childEl.isRef() && childEl.getRef().getTarget() != null
                            ? childEl.getRef().getTarget().getName()
                            : childEl.getName();
                    out.add(walkElement(childEl, parentPath + "/" + name, activePaths, visitedTypes));
                }
            }
        }
    }

    private Set<String> normalizeXPaths(Set<String> rawXPaths) {
        Set<String> cleaned = new HashSet<>();
        for (String raw : rawXPaths) {
            String noPart = raw.replaceFirst("^\\$[a-zA-Z0-9_.-]+", "");
            String noPredicates = noPart.replaceAll("\\[[^\\]]*]", "");
            String noPrefixes = noPredicates.replaceAll("/[a-zA-Z0-9_.-]+:", "/");
            if (!noPrefixes.isBlank()) {
                cleaned.add(noPrefixes);
            }
        }
        return cleaned;
    }

    private boolean isPathUsed(String schemaPath, Set<String> normalizedActivePaths) {
        return normalizedActivePaths.stream()
                .anyMatch(active -> active.equals(schemaPath) || active.startsWith(schemaPath + "/"));
    }

    private String mapXsdScalarToJava(QName xsdType) {
        if (xsdType == null) return "String";
        return switch (xsdType.getLocalPart()) {
            case "int", "integer", "short", "byte" -> "Integer";
            case "long" -> "Long";
            case "decimal", "float", "double" -> "BigDecimal";
            case "boolean" -> "Boolean";
            case "date" -> "LocalDate";
            case "dateTime" -> "Instant";
            default -> "String";
        };
    }

    private String mapTypeName(QName qName) {
        return toPascalCase(qName.getLocalPart());
    }

    private String toPascalCase(String s) {
        if (s == null || s.isEmpty()) return "Object";
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
