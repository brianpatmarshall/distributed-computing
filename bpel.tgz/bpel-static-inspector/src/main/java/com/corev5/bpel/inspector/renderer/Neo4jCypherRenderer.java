package com.corev5.bpel.inspector.renderer;

import com.corev5.bpel.inspector.model.report.BpelComponentGraph;
import com.corev5.bpel.inspector.model.report.ProcessAuditReport;
import com.corev5.bpel.inspector.model.report.ProcessDependencies;

import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Generates an idempotent Neo4j Cypher script and Neo4j Browser GRASS stylesheet
 * to visualize per-BPEL file dependencies (deploy.xml, WSDL files, XSD schemas,
 * external services, cross-process invocations) and internal BPEL components.
 */
public final class Neo4jCypherRenderer {

    public String renderCypher(List<ProcessAuditReport> reports) {
        return renderCypher(reports, true);
    }

    public String renderCypher(List<ProcessAuditReport> reports, boolean includeComponents) {
        var sb = new StringBuilder();
        sb.append("// =========================================================================\n");
        sb.append("// BPEL Static Inspector - Neo4j Dependency & Component Graph Export\n");
        sb.append("// Import via cypher-shell:\n");
        sb.append("//   cypher-shell -u neo4j -p <password> < neo4j-dependencies.cypher\n");
        sb.append("// Or run directly in Neo4j Browser (enable multi-statement query editor).\n");
        sb.append("// =========================================================================\n\n");

        sb.append("// Schema constraints (idempotent)\n");
        sb.append("CREATE CONSTRAINT bpel_file_path IF NOT EXISTS FOR (b:BpelFile) REQUIRE b.path IS UNIQUE;\n");
        sb.append("CREATE CONSTRAINT deploy_xml_path IF NOT EXISTS FOR (d:DeployXml) REQUIRE d.path IS UNIQUE;\n");
        sb.append("CREATE CONSTRAINT wsdl_file_path IF NOT EXISTS FOR (w:WsdlFile) REQUIRE w.path IS UNIQUE;\n");
        sb.append("CREATE CONSTRAINT xsd_file_path IF NOT EXISTS FOR (x:XsdFile) REQUIRE x.path IS UNIQUE;\n");
        sb.append("CREATE CONSTRAINT external_service_key IF NOT EXISTS FOR (s:ExternalService) REQUIRE s.key IS UNIQUE;\n");
        if (includeComponents) {
            sb.append("CREATE CONSTRAINT bpel_activity_id IF NOT EXISTS FOR (a:BpelActivity) REQUIRE a.id IS UNIQUE;\n");
            sb.append("CREATE CONSTRAINT bpel_partner_link_id IF NOT EXISTS FOR (p:BpelPartnerLink) REQUIRE p.id IS UNIQUE;\n");
            sb.append("CREATE CONSTRAINT bpel_variable_id IF NOT EXISTS FOR (v:BpelVariable) REQUIRE v.id IS UNIQUE;\n");
            sb.append("CREATE CONSTRAINT bpel_correlation_id IF NOT EXISTS FOR (c:BpelCorrelationSet) REQUIRE c.id IS UNIQUE;\n");
        }
        sb.append("\n");

        Set<String> emittedDeployNodes = new LinkedHashSet<>();
        Set<String> emittedWsdlNodes = new LinkedHashSet<>();
        Set<String> emittedXsdNodes = new LinkedHashSet<>();
        Set<String> emittedExternalServices = new LinkedHashSet<>();
        Set<String> emittedWsdlImports = new LinkedHashSet<>();
        Set<String> emittedWsdlXsds = new LinkedHashSet<>();
        Set<String> emittedXsdImports = new LinkedHashSet<>();

        // Index provided (serviceName, portName) -> BpelFile relative path for cross-process invocation edges
        Map<String, List<String>> providedServiceToBpels = indexProvidedServices(reports);

        for (ProcessAuditReport report : reports) {
            String bpelPath = report.relativeSourcePath();
            String bpelName = fileName(report.sourceFile(), bpelPath);
            ProcessDependencies deps = report.dependencies();

            sb.append("// --- BPEL Process: ").append(report.processName())
              .append(" (").append(bpelPath).append(") ---\n");
            sb.append("MERGE (b:BpelFile {path: ").append(quote(bpelPath)).append("})\n");
            sb.append("SET b.name = ").append(quote(bpelName))
              .append(", b.processName = ").append(quote(report.processName()))
              .append(", b.targetNamespace = ").append(quote(report.targetNamespace()))
              .append(", b.category = ").append(quote(report.category().name()))
              .append(", b.deployedInMemory = ").append(report.deployedInMemory())
              .append(";\n");

            if (deps != null) {
                // deploy.xml dependency
                deps.deployXml().ifPresent(deploy -> {
                    String deployPath = deploy.relativePath();
                    if (emittedDeployNodes.add(deployPath)) {
                        sb.append("MERGE (d:DeployXml {path: ").append(quote(deployPath)).append("})\n");
                        sb.append("SET d.name = ").append(quote(fileName(deploy.file(), deployPath))).append(";\n");
                    }
                    sb.append("MATCH (b:BpelFile {path: ").append(quote(bpelPath))
                      .append("}), (d:DeployXml {path: ").append(quote(deployPath)).append("})\n");
                    sb.append("MERGE (b)-[r:DEPLOYED_BY]->(d)\n");
                    sb.append("SET r.inMemory = ").append(deploy.inMemory())
                      .append(", r.providedCount = ").append(deploy.providedServices().size())
                      .append(", r.invokedCount = ").append(deploy.invokedServices().size())
                      .append(";\n");

                    for (ProcessDependencies.ServiceBindingRef ref : deploy.providedServices()) {
                        appendDeployServiceBinding(sb, report.processName(), deployPath, ref, "PROVIDE",
                                emittedWsdlNodes, emittedExternalServices);
                    }
                    for (ProcessDependencies.ServiceBindingRef ref : deploy.invokedServices()) {
                        appendDeployServiceBinding(sb, report.processName(), deployPath, ref, "INVOKE",
                                emittedWsdlNodes, emittedExternalServices);
                    }
                });

                // WSDL dependencies
                for (ProcessDependencies.WsdlDependency wsdl : deps.wsdlFiles()) {
                    String wsdlPath = wsdl.relativePath();
                    if (emittedWsdlNodes.add(wsdlPath)) {
                        sb.append("MERGE (w:WsdlFile {path: ").append(quote(wsdlPath)).append("})\n");
                        sb.append("SET w.name = ").append(quote(fileName(wsdl.file(), wsdlPath)))
                          .append(", w.targetNamespace = ").append(quote(wsdl.targetNamespace()))
                          .append(";\n");
                    } else if (!wsdl.targetNamespace().isBlank()) {
                        sb.append("MATCH (w:WsdlFile {path: ").append(quote(wsdlPath)).append("})\n");
                        sb.append("SET w.targetNamespace = ").append(quote(wsdl.targetNamespace())).append(";\n");
                    }

                    sb.append("MATCH (b:BpelFile {path: ").append(quote(bpelPath))
                      .append("}), (w:WsdlFile {path: ").append(quote(wsdlPath)).append("})\n");
                    sb.append("MERGE (b)-[r:DEPENDS_ON_WSDL]->(w)\n");
                    sb.append("SET r.reasons = ").append(quoteList(wsdl.reasons())).append(";\n");

                    for (String importedWsdl : wsdl.importedWsdlRelativePaths()) {
                        if (emittedWsdlNodes.add(importedWsdl)) {
                            sb.append("MERGE (w:WsdlFile {path: ").append(quote(importedWsdl)).append("})\n");
                            sb.append("SET w.name = ").append(quote(fileName(null, importedWsdl))).append(";\n");
                        }
                        String edgeKey = wsdlPath + "->" + importedWsdl;
                        if (emittedWsdlImports.add(edgeKey)) {
                            sb.append("MATCH (w1:WsdlFile {path: ").append(quote(wsdlPath))
                              .append("}), (w2:WsdlFile {path: ").append(quote(importedWsdl)).append("})\n");
                            sb.append("MERGE (w1)-[:IMPORTS_WSDL]->(w2);\n");
                        }
                    }

                    for (String refXsd : wsdl.referencedXsdRelativePaths()) {
                        if (emittedXsdNodes.add(refXsd)) {
                            sb.append("MERGE (x:XsdFile {path: ").append(quote(refXsd)).append("})\n");
                            sb.append("SET x.name = ").append(quote(fileName(null, refXsd))).append(";\n");
                        }
                        String edgeKey = wsdlPath + "->" + refXsd;
                        if (emittedWsdlXsds.add(edgeKey)) {
                            sb.append("MATCH (w:WsdlFile {path: ").append(quote(wsdlPath))
                              .append("}), (x:XsdFile {path: ").append(quote(refXsd)).append("})\n");
                            sb.append("MERGE (w)-[:USES_XSD]->(x);\n");
                        }
                    }
                }

                // XSD dependencies
                for (ProcessDependencies.XsdDependency xsd : deps.xsdFiles()) {
                    String xsdPath = xsd.relativePath();
                    if (emittedXsdNodes.add(xsdPath)) {
                        sb.append("MERGE (x:XsdFile {path: ").append(quote(xsdPath)).append("})\n");
                        sb.append("SET x.name = ").append(quote(fileName(xsd.file(), xsdPath)))
                          .append(", x.targetNamespace = ").append(quote(xsd.targetNamespace()))
                          .append(";\n");
                    } else if (!xsd.targetNamespace().isBlank()) {
                        sb.append("MATCH (x:XsdFile {path: ").append(quote(xsdPath)).append("})\n");
                        sb.append("SET x.targetNamespace = ").append(quote(xsd.targetNamespace())).append(";\n");
                    }

                    sb.append("MATCH (b:BpelFile {path: ").append(quote(bpelPath))
                      .append("}), (x:XsdFile {path: ").append(quote(xsdPath)).append("})\n");
                    sb.append("MERGE (b)-[r:DEPENDS_ON_XSD]->(x)\n");
                    sb.append("SET r.reasons = ").append(quoteList(xsd.reasons())).append(";\n");

                    for (String importedXsd : xsd.importedXsdRelativePaths()) {
                        if (emittedXsdNodes.add(importedXsd)) {
                            sb.append("MERGE (x:XsdFile {path: ").append(quote(importedXsd)).append("})\n");
                            sb.append("SET x.name = ").append(quote(fileName(null, importedXsd))).append(";\n");
                        }
                        String edgeKey = xsdPath + "->" + importedXsd;
                        if (emittedXsdImports.add(edgeKey)) {
                            sb.append("MATCH (x1:XsdFile {path: ").append(quote(xsdPath))
                              .append("}), (x2:XsdFile {path: ").append(quote(importedXsd)).append("})\n");
                            sb.append("MERGE (x1)-[:IMPORTS_XSD]->(x2);\n");
                        }
                    }
                }
            }
            if (includeComponents && report.components() != null) {
                appendBpelComponents(sb, bpelPath, report.components());
            }
            sb.append("\n");
        }

        // Cross-process BPEL -> BPEL invocations (resolved via deploy.xml service/port bindings)
        boolean headerWritten = false;
        for (ProcessAuditReport report : reports) {
            if (report.dependencies() == null || report.dependencies().deployXml().isEmpty()) {
                continue;
            }
            String callerPath = report.relativeSourcePath();
            for (ProcessDependencies.ServiceBindingRef ref : report.dependencies().deployXml().get().invokedServices()) {
                String svcKey = servicePortKey(ref);
                for (String targetPath : providedServiceToBpels.getOrDefault(svcKey, List.of())) {
                    if (callerPath.equals(targetPath)) {
                        continue;
                    }
                    if (!headerWritten) {
                        sb.append("// --- Cross-Process BPEL Invocations ---\n");
                        headerWritten = true;
                    }
                    sb.append("MATCH (caller:BpelFile {path: ").append(quote(callerPath))
                      .append("}), (callee:BpelFile {path: ").append(quote(targetPath)).append("})\n");
                    sb.append("MERGE (caller)-[r:INVOKES_PROCESS {partnerLink: ").append(quote(ref.partnerLink())).append("}]->(callee)\n");
                    sb.append("SET r.serviceName = ").append(quote(ref.serviceName().toString()))
                      .append(", r.portName = ").append(quote(ref.portName()))
                      .append(";\n");
                }
            }
        }
        if (headerWritten) {
            sb.append("\n");
        }

        sb.append("// =========================================================================\n");
        sb.append("// Useful Neo4j Browser Visualization Queries:\n");
        sb.append("//\n");
        sb.append("// 1) View entire BPEL -> deploy.xml / WSDL / XSD dependency graph:\n");
        sb.append("//    MATCH (n) WHERE n:BpelFile OR n:DeployXml OR n:WsdlFile OR n:XsdFile OR n:ExternalService\n");
        sb.append("//    OPTIONAL MATCH (n)-[r]->(m)\n");
        sb.append("//    RETURN n, r, m;\n");
        sb.append("//\n");
        sb.append("// 2) View dependencies for a specific BPEL file (up to 3 hops):\n");
        sb.append("//    MATCH p = (b:BpelFile {processName: '<ProcessName>'})-[*1..3]->(dep)\n");
        sb.append("//    RETURN p;\n");
        sb.append("//\n");
        sb.append("// 3) Find shared WSDL files referenced by multiple BPEL files:\n");
        sb.append("//    MATCH (b:BpelFile)-[r:DEPENDS_ON_WSDL]->(w:WsdlFile)\n");
        sb.append("//    WITH w, collect(b) AS procs, collect(r) AS rels\n");
        sb.append("//    WHERE size(procs) > 1\n");
        sb.append("//    RETURN w, procs, rels;\n");
        sb.append("//\n");
        sb.append("// 4) View BPEL-to-BPEL orchestration chains:\n");
        sb.append("//    MATCH p = (a:BpelFile)-[:INVOKES_PROCESS*1..5]->(b:BpelFile)\n");
        sb.append("//    RETURN p;\n");
        sb.append("//\n");
        sb.append("// 5) Expand a single BPEL file into its internal activities, partnerLinks, and variables:\n");
        sb.append("//    MATCH p = (b:BpelFile {processName: '<ProcessName>'})-[*1..6]->(c)\n");
        sb.append("//    WHERE c:BpelActivity OR c:BpelPartnerLink OR c:BpelVariable OR c:BpelCorrelationSet\n");
        sb.append("//    RETURN p;\n");
        sb.append("// =========================================================================\n");
        return sb.toString();
    }

    private void appendBpelComponents(StringBuilder sb, String bpelPath, BpelComponentGraph comp) {
        String bpelNodeId = "bpel:" + bpelPath;
        Map<String, String> idToLabel = new HashMap<>();
        for (BpelComponentGraph.ComponentNode node : comp.nodes()) {
            idToLabel.put(node.id(), node.label());
            sb.append("MERGE (c:").append(node.label()).append(" {id: ").append(quote(node.id())).append("})\n");
            sb.append("SET c.name = ").append(quote(node.name()))
              .append(", c.kind = ").append(quote(node.kind()))
              .append(", c.bpelPath = ").append(quote(bpelPath));
            if (node.parentActivityId() != null) {
                sb.append(", c.parentActivityId = ").append(quote(node.parentActivityId()));
            }
            for (var prop : node.properties().entrySet()) {
                String k = prop.getKey();
                if (k.equals("name") || k.equals("kind") || k.equals("bpelPath") || k.equals("id")) {
                    continue;
                }
                sb.append(", c.").append(sanitizePropKey(k)).append(" = ").append(formatCypherValue(prop.getValue()));
            }
            sb.append(";\n");
        }

        for (BpelComponentGraph.ComponentEdge edge : comp.edges()) {
            String srcMatch = edge.source().equals(bpelNodeId)
                    ? "(src:BpelFile {path: " + quote(bpelPath) + "})"
                    : "(src:" + idToLabel.getOrDefault(edge.source(), "BpelActivity") + " {id: " + quote(edge.source()) + "})";
            String tgtMatch = edge.target().equals(bpelNodeId)
                    ? "(tgt:BpelFile {path: " + quote(bpelPath) + "})"
                    : "(tgt:" + idToLabel.getOrDefault(edge.target(), "BpelActivity") + " {id: " + quote(edge.target()) + "})";

            sb.append("MATCH ").append(srcMatch).append(", ").append(tgtMatch).append("\n");
            sb.append("MERGE (src)-[r:").append(edge.type()).append("]->(tgt)");
            if (!edge.properties().isEmpty()) {
                sb.append("\nSET ");
                String sets = edge.properties().entrySet().stream()
                        .map(e -> "r." + sanitizePropKey(e.getKey()) + " = " + formatCypherValue(e.getValue()))
                        .collect(Collectors.joining(", "));
                sb.append(sets);
            }
            sb.append(";\n");
        }
    }

    private String sanitizePropKey(String key) {
        return key.replaceAll("[^a-zA-Z0-9_]", "_");
    }

    private String formatCypherValue(Object value) {
        if (value == null) return "''";
        if (value instanceof Boolean || value instanceof Number) {
            return value.toString();
        }
        if (value instanceof List<?> list) {
            return "[" + list.stream().map(v -> quote(String.valueOf(v))).collect(Collectors.joining(", ")) + "]";
        }
        return quote(String.valueOf(value));
    }

    public String renderBrowserGrassStyle() {
        return """
                node {
                  diameter: 56px;
                  color: #A5ABB6;
                  border-color: #9AA1AC;
                  border-width: 2px;
                  text-color-internal: #FFFFFF;
                  font-size: 11px;
                }
                node.BpelFile {
                  color: #FACC15;
                  border-color: #FEF08A;
                  text-color-internal: #052E16;
                  diameter: 68px;
                  caption: "{name}";
                }
                node.DeployXml {
                  color: #EA580C;
                  border-color: #FDBA74;
                  text-color-internal: #FFFFFF;
                  diameter: 56px;
                  caption: "{name}";
                }
                node.WsdlFile {
                  color: #009A49;
                  border-color: #86EFAC;
                  text-color-internal: #FFFFFF;
                  diameter: 60px;
                  caption: "{name}";
                }
                node.XsdFile {
                  color: #0D9488;
                  border-color: #5EEAD4;
                  text-color-internal: #FFFFFF;
                  diameter: 52px;
                  caption: "{name}";
                }
                node.ExternalService {
                  color: #E11D48;
                  border-color: #FDA4AF;
                  text-color-internal: #FFFFFF;
                  diameter: 54px;
                  caption: "{name}";
                }
                node.BpelActivity {
                  color: #15803D;
                  border-color: #FACC15;
                  text-color-internal: #FEF9C3;
                  diameter: 52px;
                  caption: "{name}";
                }
                node.BpelPartnerLink {
                  color: #D97706;
                  border-color: #FDE047;
                  text-color-internal: #FFFFFF;
                  diameter: 48px;
                  caption: "{name}";
                }
                node.BpelVariable {
                  color: #0F766E;
                  border-color: #99F6E4;
                  text-color-internal: #FFFFFF;
                  diameter: 44px;
                  caption: "{name}";
                }
                node.BpelCorrelationSet {
                  color: #65A30D;
                  border-color: #D9F99D;
                  text-color-internal: #FFFFFF;
                  diameter: 44px;
                  caption: "{name}";
                }
                relationship {
                  color: #64748B;
                  shaft-width: 2px;
                  font-size: 9px;
                  padding: 3px;
                  text-color-external: #334155;
                  text-color-internal: #FFFFFF;
                  caption: "<type>";
                }
                relationship.DEPLOYED_BY {
                  color: #EA580C;
                  shaft-width: 3px;
                }
                relationship.DEPENDS_ON_WSDL {
                  color: #059669;
                  shaft-width: 2px;
                }
                relationship.BINDS_SERVICE {
                  color: #D97706;
                  shaft-width: 2px;
                  caption: "{direction}: {partnerLink}";
                }
                relationship.IMPORTS_WSDL {
                  color: #10B981;
                }
                relationship.USES_XSD {
                  color: #8B5CF6;
                }
                relationship.DEPENDS_ON_XSD {
                  color: #7C3AED;
                }
                relationship.IMPORTS_XSD {
                  color: #A78BFA;
                }
                relationship.INVOKES_PROCESS {
                  color: #2563EB;
                  shaft-width: 3px;
                  caption: "INVOKES: {partnerLink}";
                }
                """;
    }

    static Map<String, List<String>> indexProvidedServices(List<ProcessAuditReport> reports) {
        Map<String, List<String>> map = new LinkedHashMap<>();
        for (ProcessAuditReport report : reports) {
            if (report.dependencies() == null || report.dependencies().deployXml().isEmpty()) {
                continue;
            }
            for (ProcessDependencies.ServiceBindingRef ref : report.dependencies().deployXml().get().providedServices()) {
                map.computeIfAbsent(servicePortKey(ref), _ -> new ArrayList<>())
                        .add(report.relativeSourcePath());
            }
        }
        return map;
    }

    static String servicePortKey(ProcessDependencies.ServiceBindingRef ref) {
        return ref.serviceName().toString() + "#" + ref.portName();
    }

    private void appendDeployServiceBinding(
            StringBuilder sb,
            String processName,
            String deployPath,
            ProcessDependencies.ServiceBindingRef ref,
            String direction,
            Set<String> emittedWsdlNodes,
            Set<String> emittedExternalServices
    ) {
        if (ref.wsdlRelativePath().isPresent()) {
            String wsdlPath = ref.wsdlRelativePath().get();
            if (emittedWsdlNodes.add(wsdlPath)) {
                sb.append("MERGE (w:WsdlFile {path: ").append(quote(wsdlPath)).append("})\n");
                sb.append("SET w.name = ").append(quote(fileName(ref.wsdlFile().orElse(null), wsdlPath))).append(";\n");
            }
            sb.append("MATCH (d:DeployXml {path: ").append(quote(deployPath))
              .append("}), (w:WsdlFile {path: ").append(quote(wsdlPath)).append("})\n");
            sb.append("MERGE (d)-[r:BINDS_SERVICE {processName: ").append(quote(processName))
              .append(", partnerLink: ").append(quote(ref.partnerLink()))
              .append(", direction: ").append(quote(direction)).append("}]->(w)\n");
            sb.append("SET r.serviceName = ").append(quote(ref.serviceName().toString()))
              .append(", r.portName = ").append(quote(ref.portName()))
              .append(";\n");
        } else {
            String svcKey = servicePortKey(ref);
            if (emittedExternalServices.add(svcKey)) {
                sb.append("MERGE (s:ExternalService {key: ").append(quote(svcKey)).append("})\n");
                sb.append("SET s.name = ").append(quote(ref.serviceName().getLocalPart()))
                  .append(", s.serviceName = ").append(quote(ref.serviceName().toString()))
                  .append(", s.portName = ").append(quote(ref.portName()))
                  .append(";\n");
            }
            sb.append("MATCH (d:DeployXml {path: ").append(quote(deployPath))
              .append("}), (s:ExternalService {key: ").append(quote(svcKey)).append("})\n");
            sb.append("MERGE (d)-[r:BINDS_SERVICE {processName: ").append(quote(processName))
              .append(", partnerLink: ").append(quote(ref.partnerLink()))
              .append(", direction: ").append(quote(direction)).append("}]->(s)\n");
            sb.append("SET r.serviceName = ").append(quote(ref.serviceName().toString()))
              .append(", r.portName = ").append(quote(ref.portName()))
              .append(";\n");
        }
    }

    private String fileName(Path path, String fallbackRelPath) {
        if (path != null && path.getFileName() != null) {
            return path.getFileName().toString();
        }
        int slash = fallbackRelPath.lastIndexOf('/');
        return slash >= 0 ? fallbackRelPath.substring(slash + 1) : fallbackRelPath;
    }

    private String quote(String value) {
        String safe = value == null ? "" : value;
        return "'" + safe.replace("\\", "\\\\").replace("'", "\\'") + "'";
    }

    private String quoteList(List<String> values) {
        return "[" + values.stream().map(this::quote).collect(Collectors.joining(", ")) + "]";
    }
}
