package com.corev5.bpel.inspector;

import com.corev5.bpel.inspector.analyzer.ProcessAnalyzer;
import com.corev5.bpel.inspector.model.ast.BpelProcess;
import com.corev5.bpel.inspector.model.contract.SymbolTable;
import com.corev5.bpel.inspector.model.report.ProcessAuditReport;
import com.corev5.bpel.inspector.model.report.ProcessDependencies;
import com.corev5.bpel.inspector.parser.BpelAstParser;
import com.corev5.bpel.inspector.parser.ContractIndexer;
import com.corev5.bpel.inspector.renderer.MermaidDiagramRenderer;
import com.corev5.bpel.inspector.renderer.Neo4jCypherRenderer;
import com.corev5.bpel.inspector.renderer.Neo4jGraphPublisher;
import com.corev5.bpel.inspector.web.InspectorWebServer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.stream.Stream;

@Command(
        name = "bpel-inspector",
        mixinStandardHelpOptions = true,
        description = "Static analyzer for Apache ODE BPEL 2.0 workflows."
)
public final class InspectorCli implements Callable<Integer> {

    @Option(names = {"-i", "--input"}, description = "Root directory containing .bpel, .wsdl, .xsd, and deploy.xml files")
    private Path inputDir;

    @Option(names = {"-o", "--output"}, defaultValue = "./bpel-audit-output", description = "Output directory for JSON audit, Mermaid diagrams, and Neo4j exports")
    private Path outputDir;

    @Option(names = {"--serve"}, description = "Start the HTTP API server for the React web frontend")
    private boolean serve;

    @Option(names = {"--port"}, defaultValue = "8080", description = "HTTP port when running with --serve (default: ${DEFAULT-VALUE})")
    private int port;

    @Option(names = {"--neo4j-http"}, defaultValue = "http://localhost:7474", description = "Upstream Neo4j Browser HTTP URL to proxy when running with --serve")
    private String neo4jHttp;

    @Option(names = {"--neo4j-uri"}, description = "Optional Neo4j Bolt URI (e.g. bolt://localhost:7687) to push the dependency graph directly")
    private String neo4jUri;

    @Option(names = {"--neo4j-user"}, defaultValue = "neo4j", description = "Neo4j username (default: ${DEFAULT-VALUE})")
    private String neo4jUser;

    @Option(names = {"--neo4j-password"}, description = "Neo4j password (falls back to NEO4J_PASSWORD env var)")
    private String neo4jPassword;

    @Option(names = {"--neo4j-database"}, defaultValue = "neo4j", description = "Target Neo4j database name (default: ${DEFAULT-VALUE})")
    private String neo4jDatabase;

    @Option(names = {"--neo4j-clear"}, description = "Clear existing BpelFile/DeployXml/WsdlFile/XsdFile nodes in Neo4j before importing")
    private boolean neo4jClear;

    @Override
    public Integer call() throws Exception {
        if (serve) {
            Path dist = Path.of("frontend/dist").toAbsolutePath().normalize();
            InspectorWebServer webServer = new InspectorWebServer(port, dist, neo4jHttp);
            webServer.start();
            System.out.printf("BPEL Static Inspector Web API running at http://localhost:%d (Neo4j Browser proxy -> %s)%n",
                    webServer.getPort(), neo4jHttp);
            Thread.currentThread().join();
            return 0;
        }
        if (inputDir == null) {
            System.err.println("Error: Missing required option '--input=<inputDir>' (or pass '--serve' to run the web API).");
            return 2;
        }
        Files.createDirectories(outputDir);
        Path diagramsDir = Files.createDirectories(outputDir.resolve("diagrams"));

        SymbolTable symbolTable = new ContractIndexer().indexDirectory(inputDir);

        BpelAstParser parser = new BpelAstParser();
        ProcessAnalyzer analyzer = new ProcessAnalyzer(symbolTable);
        List<ProcessAuditReport> reports = new ArrayList<>();

        try (Stream<Path> walk = Files.walk(inputDir)) {
            List<Path> bpelFiles = walk.filter(p -> p.toString().endsWith(".bpel")).sorted().toList();
            java.util.Set<String> usedDiagramNames = new java.util.HashSet<>();
            for (Path bpelFile : bpelFiles) {
                BpelProcess process = parser.parse(bpelFile);
                ProcessAuditReport report = analyzer.analyze(process);
                reports.add(report);

                String diagramBase = uniqueDiagramBaseName(report.processName(), usedDiagramNames);
                Files.writeString(
                        diagramsDir.resolve(diagramBase + ".mmd"),
                        report.mermaidSequenceDiagram()
                );
            }
        }

        String globalGraph = new MermaidDiagramRenderer().renderGlobalContextGraph(reports);
        Files.writeString(outputDir.resolve("global-topology.mmd"), globalGraph);

        Neo4jCypherRenderer neo4jRenderer = new Neo4jCypherRenderer();
        Path cypherFile = outputDir.resolve("neo4j-dependencies.cypher");
        Files.writeString(cypherFile, neo4jRenderer.renderCypher(reports));
        Files.writeString(outputDir.resolve("neo4j-style.grass"), neo4jRenderer.renderBrowserGrassStyle());

        String dependencySummary = formatDependencySummary(reports);
        Files.writeString(outputDir.resolve("bpel-dependencies.txt"), dependencySummary);

        ObjectMapper mapper = new ObjectMapper()
                .registerModule(new Jdk8Module())
                .enable(SerializationFeature.INDENT_OUTPUT);
        mapper.writeValue(outputDir.resolve("migration-audit.json").toFile(), reports);

        System.out.println(dependencySummary);
        System.out.printf("Inspected %d BPEL processes. Reports & Neo4j Cypher script written to %s%n",
                reports.size(), outputDir.toAbsolutePath());

        if (neo4jUri != null && !neo4jUri.isBlank()) {
            String password = (neo4jPassword != null) ? neo4jPassword : System.getenv("NEO4J_PASSWORD");
            try (Neo4jGraphPublisher publisher = new Neo4jGraphPublisher(neo4jUri, neo4jUser, password, neo4jDatabase)) {
                Neo4jGraphPublisher.PublishSummary summary = publisher.publish(reports, neo4jClear);
                System.out.printf(
                        "Published dependency graph to Neo4j (%s, db=%s): %d BPEL files, %d deploy.xml links, %d WSDL links, %d XSD links, %d cross-process links.%n",
                        neo4jUri, neo4jDatabase,
                        summary.bpelCount(), summary.deployEdges(), summary.wsdlEdges(),
                        summary.xsdEdges(), summary.crossProcessEdges()
                );
            }
        }

        return 0;
    }

    private static String uniqueDiagramBaseName(String rawName, java.util.Set<String> usedNames) {
        String sanitized = (rawName == null || rawName.isBlank())
                ? "unnamed_process"
                : rawName.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (usedNames.add(sanitized)) {
            return sanitized;
        }
        int suffix = 2;
        while (!usedNames.add(sanitized + "_" + suffix)) {
            suffix++;
        }
        return sanitized + "_" + suffix;
    }

    public static String formatDependencySummary(List<ProcessAuditReport> reports) {
        var sb = new StringBuilder();
        sb.append("=== BPEL File Dependencies ===\n");
        for (ProcessAuditReport report : reports) {
            sb.append("\nBPEL: ").append(report.relativeSourcePath())
              .append(" [").append(report.processName()).append(" | ").append(report.category()).append("]\n");
            ProcessDependencies deps = report.dependencies();
            if (deps == null) {
                continue;
            }
            if (deps.deployXml().isPresent()) {
                ProcessDependencies.DeployDependency deploy = deps.deployXml().get();
                sb.append("  deploy.xml : ").append(deploy.relativePath())
                  .append(" (inMemory=").append(deploy.inMemory()).append(")\n");
                for (ProcessDependencies.ServiceBindingRef ref : deploy.providedServices()) {
                    sb.append("    provide  : partnerLink=").append(ref.partnerLink())
                      .append(", service=").append(ref.serviceName().getLocalPart())
                      .append(", port=").append(ref.portName())
                      .append(ref.wsdlRelativePath().map(w -> " -> " + w).orElse(""))
                      .append("\n");
                }
                for (ProcessDependencies.ServiceBindingRef ref : deploy.invokedServices()) {
                    sb.append("    invoke   : partnerLink=").append(ref.partnerLink())
                      .append(", service=").append(ref.serviceName().getLocalPart())
                      .append(", port=").append(ref.portName())
                      .append(ref.wsdlRelativePath().map(w -> " -> " + w).orElse(""))
                      .append("\n");
                }
            } else {
                sb.append("  deploy.xml : (none found)\n");
            }

            if (deps.wsdlFiles().isEmpty()) {
                sb.append("  WSDLs      : (none)\n");
            } else {
                sb.append("  WSDLs (").append(deps.wsdlFiles().size()).append("):\n");
                for (ProcessDependencies.WsdlDependency wsdl : deps.wsdlFiles()) {
                    sb.append("    - ").append(wsdl.relativePath())
                      .append("  [").append(String.join(", ", wsdl.reasons())).append("]\n");
                }
            }

            if (!deps.xsdFiles().isEmpty()) {
                sb.append("  XSDs (").append(deps.xsdFiles().size()).append("):\n");
                for (ProcessDependencies.XsdDependency xsd : deps.xsdFiles()) {
                    sb.append("    - ").append(xsd.relativePath())
                      .append("  [").append(String.join(", ", xsd.reasons())).append("]\n");
                }
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        System.exit(new CommandLine(new InspectorCli()).execute(args));
    }
}
