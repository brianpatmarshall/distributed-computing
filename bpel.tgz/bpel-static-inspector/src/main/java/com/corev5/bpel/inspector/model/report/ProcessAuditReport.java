package com.corev5.bpel.inspector.model.report;

import java.nio.file.Path;
import java.util.List;

public record ProcessAuditReport(
        String processName,
        String targetNamespace,
        Path sourceFile,
        String relativeSourcePath,
        MigrationCategory category,
        boolean deployedInMemory,
        ProcessDependencies dependencies,
        BpelComponentGraph components,
        ReactorBlueprint reactorBlueprint,
        List<Touchpoint> touchpoints,
        String mermaidSequenceDiagram
) {}
