package com.corev5.bpel.inspector.model.report;

import javax.xml.namespace.QName;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

public record ProcessDependencies(
        Optional<DeployDependency> deployXml,
        List<WsdlDependency> wsdlFiles,
        List<XsdDependency> xsdFiles
) {
    public record DeployDependency(
            Path file,
            String relativePath,
            boolean inMemory,
            List<ServiceBindingRef> providedServices,
            List<ServiceBindingRef> invokedServices
    ) {}

    public record ServiceBindingRef(
            String partnerLink,
            QName serviceName,
            String portName,
            Optional<Path> wsdlFile,
            Optional<String> wsdlRelativePath
    ) {}

    public record WsdlDependency(
            Path file,
            String relativePath,
            String targetNamespace,
            List<String> reasons,
            List<String> importedWsdlRelativePaths,
            List<String> referencedXsdRelativePaths
    ) {}

    public record XsdDependency(
            Path file,
            String relativePath,
            String targetNamespace,
            List<String> reasons,
            List<String> importedXsdRelativePaths
    ) {}
}
