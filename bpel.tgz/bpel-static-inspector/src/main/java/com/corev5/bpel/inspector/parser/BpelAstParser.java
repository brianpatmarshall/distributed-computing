package com.corev5.bpel.inspector.parser;

import com.corev5.bpel.inspector.model.ast.*;
import com.corev5.bpel.inspector.model.ast.BpelActivity.*;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.namespace.QName;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class BpelAstParser {

    public static final String BPEL_2_0_NS = "http://docs.oasis-open.org/wsbpel/2.0/process/executable";
    private static final Pattern VAR_PART_XPATH_PATTERN =
            Pattern.compile("^\\$([a-zA-Z0-9_.-]+?)(?:\\.([a-zA-Z0-9_.-]+))?(/.*)?$");

    public BpelProcess parse(Path bpelPath) {
        Document doc = XmlDomUtils.parseDocument(bpelPath);
        Element root = doc.getDocumentElement();

        String processName = root.getAttribute("name");
        String targetNamespace = root.getAttribute("targetNamespace");

        List<BpelProcess.ImportDecl> imports = parseImports(root);
        Map<String, BpelProcess.PartnerLinkDecl> partnerLinks = parsePartnerLinks(root);
        Map<String, BpelProcess.VariableDecl> variables = parseVariables(root);
        List<String> correlationSets = parseCorrelationSets(root);

        boolean hasFaultHandlers = XmlDomUtils.firstChildElement(root, BPEL_2_0_NS, "faultHandlers").isPresent();
        boolean hasEventHandlers = XmlDomUtils.firstChildElement(root, BPEL_2_0_NS, "eventHandlers").isPresent();

        BpelActivity mainActivity = findPrimaryActivity(root)
                .map(this::parseActivity)
                .orElseGet(() -> new EmptyNode("empty-process", "empty"));
        List<BpelActivity> processHandlerActivities = parseHandlerActivities(root);

        return new BpelProcess(
                bpelPath.toAbsolutePath().normalize(),
                processName,
                targetNamespace,
                imports,
                partnerLinks,
                variables,
                correlationSets,
                hasFaultHandlers,
                hasEventHandlers,
                mainActivity,
                processHandlerActivities
        );
    }

    private BpelActivity parseActivity(Element el) {
        String name = el.getAttribute("name");
        return switch (el.getLocalName()) {
            case "receive" -> new ReceiveNode(
                    name,
                    el.getAttribute("partnerLink"),
                    XmlDomUtils.resolveQName(el, el.getAttribute("portType")),
                    el.getAttribute("operation"),
                    el.getAttribute("variable"),
                    "yes".equalsIgnoreCase(el.getAttribute("createInstance")),
                    parseCorrelations(el)
            );
            case "reply" -> new ReplyNode(
                    name,
                    el.getAttribute("partnerLink"),
                    XmlDomUtils.resolveQName(el, el.getAttribute("portType")),
                    el.getAttribute("operation"),
                    el.getAttribute("variable"),
                    el.hasAttribute("faultName")
                            ? Optional.of(XmlDomUtils.resolveQName(el, el.getAttribute("faultName")))
                            : Optional.empty()
            );
            case "invoke" -> new InvokeNode(
                    name,
                    el.getAttribute("partnerLink"),
                    XmlDomUtils.resolveQName(el, el.getAttribute("portType")),
                    el.getAttribute("operation"),
                    attrOpt(el, "inputVariable"),
                    attrOpt(el, "outputVariable"),
                    parseCorrelations(el)
            );
            case "pick" -> parsePick(el, name);
            case "assign" -> parseAssign(el, name);
            case "sequence" -> new SequenceNode(
                    name,
                    XmlDomUtils.childElements(el).stream()
                            .filter(c -> !NON_ACTIVITY_TAGS.contains(c.getLocalName()))
                            .map(this::parseActivity)
                            .toList()
            );
            case "flow" -> {
                boolean hasLinks = XmlDomUtils.firstChildElement(el, BPEL_2_0_NS, "links").isPresent();
                List<BpelActivity> branches = XmlDomUtils.childElements(el).stream()
                        .filter(c -> !"links".equals(c.getLocalName()) && !NON_ACTIVITY_TAGS.contains(c.getLocalName()))
                        .map(this::parseActivity)
                        .toList();
                yield new FlowNode(name, branches, hasLinks);
            }
            case "if" -> parseIf(el, name);
            case "while", "repeatUntil", "forEach" -> {
                boolean parallel = "yes".equalsIgnoreCase(el.getAttribute("parallel"));
                BpelActivity body = findPrimaryActivity(el)
                        .map(this::parseActivity)
                        .orElseGet(() -> new EmptyNode("empty-loop", el.getLocalName()));
                yield new LoopNode(name, el.getLocalName(), parallel, body);
            }
            case "scope" -> parseScope(el, name);
            case "wait" -> new WaitNode(name, el.getTextContent().trim());
            case "throw" -> new ThrowNode(
                    name,
                    el.hasAttribute("faultName")
                            ? Optional.of(XmlDomUtils.resolveQName(el, el.getAttribute("faultName")))
                            : Optional.empty()
            );
            case "compensate", "compensateScope" -> new CompensateNode(name, attrOpt(el, "target"));
            default -> new EmptyNode(name, el.getLocalName());
        };
    }

    private AssignNode parseAssign(Element assignEl, String name) {
        List<CopyOperation> copies = new ArrayList<>();
        for (Element child : XmlDomUtils.childElements(assignEl)) {
            if ("copy".equals(child.getLocalName())) {
                boolean ignoreMissing = "yes".equalsIgnoreCase(child.getAttribute("ignoreMissingFromData"));
                DataEndpoint from = XmlDomUtils.firstChildElement(child, BPEL_2_0_NS, "from")
                        .map(this::parseEndpoint)
                        .orElse(new DataEndpoint(DataEndpoint.EndpointKind.UNKNOWN, Optional.empty(), Optional.empty(), Optional.empty(), false));
                DataEndpoint to = XmlDomUtils.firstChildElement(child, BPEL_2_0_NS, "to")
                        .map(this::parseEndpoint)
                        .orElse(new DataEndpoint(DataEndpoint.EndpointKind.UNKNOWN, Optional.empty(), Optional.empty(), Optional.empty(), false));
                copies.add(new CopyOperation(from, to, ignoreMissing));
            }
        }
        return new AssignNode(name, List.copyOf(copies));
    }

    private DataEndpoint parseEndpoint(Element endpointEl) {
        if (endpointEl.hasAttribute("variable")) {
            Optional<String> query = XmlDomUtils.childText(endpointEl, BPEL_2_0_NS, "query");
            return new DataEndpoint(
                    DataEndpoint.EndpointKind.VARIABLE_PART,
                    attrOpt(endpointEl, "variable"),
                    attrOpt(endpointEl, "part"),
                    query,
                    false
            );
        }
        Optional<Element> literalOpt = XmlDomUtils.firstChildElement(endpointEl, BPEL_2_0_NS, "literal");
        if (literalOpt.isPresent()) {
            boolean isSkeleton = literalOpt.get().getTextContent().trim().isEmpty();
            return new DataEndpoint(
                    DataEndpoint.EndpointKind.LITERAL,
                    Optional.empty(),
                    Optional.empty(),
                    Optional.empty(),
                    isSkeleton
            );
        }
        if (endpointEl.hasAttribute("partnerLink")) {
            return new DataEndpoint(
                    DataEndpoint.EndpointKind.PARTNER_LINK,
                    attrOpt(endpointEl, "partnerLink"),
                    Optional.empty(),
                    Optional.empty(),
                    false
            );
        }
        String expr = endpointEl.getTextContent().trim();
        Matcher matcher = VAR_PART_XPATH_PATTERN.matcher(expr);
        if (matcher.matches()) {
            return new DataEndpoint(
                    DataEndpoint.EndpointKind.VARIABLE_PART,
                    Optional.ofNullable(matcher.group(1)),
                    Optional.ofNullable(matcher.group(2)),
                    Optional.ofNullable(matcher.group(3)),
                    false
            );
        }
        return new DataEndpoint(
                DataEndpoint.EndpointKind.EXPRESSION,
                Optional.empty(),
                Optional.empty(),
                Optional.of(expr),
                false
        );
    }

    private PickNode parsePick(Element pickEl, String name) {
        boolean createInstance = "yes".equalsIgnoreCase(pickEl.getAttribute("createInstance"));
        List<OnMessageBranch> messages = new ArrayList<>();
        List<OnAlarmBranch> alarms = new ArrayList<>();

        for (Element child : XmlDomUtils.childElements(pickEl)) {
            if ("onMessage".equals(child.getLocalName())) {
                BpelActivity act = findPrimaryActivity(child)
                        .map(this::parseActivity)
                        .orElseGet(() -> new EmptyNode("empty-onMessage", "empty"));
                messages.add(new OnMessageBranch(
                        child.getAttribute("partnerLink"),
                        XmlDomUtils.resolveQName(child, child.getAttribute("portType")),
                        child.getAttribute("operation"),
                        child.getAttribute("variable"),
                        parseCorrelations(child),
                        act
                ));
            } else if ("onAlarm".equals(child.getLocalName())) {
                BpelActivity act = findPrimaryActivity(child)
                        .map(this::parseActivity)
                        .orElseGet(() -> new EmptyNode("empty-onAlarm", "empty"));
                String expr = XmlDomUtils.childText(child, BPEL_2_0_NS, "for")
                        .or(() -> XmlDomUtils.childText(child, BPEL_2_0_NS, "until"))
                        .or(() -> XmlDomUtils.childText(child, BPEL_2_0_NS, "repeatEvery"))
                        .orElse("");
                alarms.add(new OnAlarmBranch(expr, act));
            }
        }
        return new PickNode(name, createInstance, List.copyOf(messages), List.copyOf(alarms));
    }

    private IfNode parseIf(Element ifEl, String name) {
        List<ConditionalBranch> branches = new ArrayList<>();
        Optional<String> ifCond = XmlDomUtils.childText(ifEl, BPEL_2_0_NS, "condition");
        findPrimaryActivity(ifEl).map(this::parseActivity)
                .ifPresent(act -> branches.add(new ConditionalBranch(ifCond, act)));

        for (Element child : XmlDomUtils.childElements(ifEl)) {
            if ("elseif".equals(child.getLocalName())) {
                Optional<String> cond = XmlDomUtils.childText(child, BPEL_2_0_NS, "condition");
                findPrimaryActivity(child).map(this::parseActivity)
                        .ifPresent(act -> branches.add(new ConditionalBranch(cond, act)));
            } else if ("else".equals(child.getLocalName())) {
                findPrimaryActivity(child).map(this::parseActivity)
                        .ifPresent(act -> branches.add(new ConditionalBranch(Optional.empty(), act)));
            }
        }
        return new IfNode(name, List.copyOf(branches));
    }

    private static final Set<String> NON_ACTIVITY_TAGS = Set.of(
            "extensions", "import", "partnerLinks", "messageExchanges",
            "variables", "correlationSets", "faultHandlers",
            "compensationHandler", "terminationHandler", "eventHandlers",
            "correlations", "condition", "sources", "targets", "for", "until", "repeatEvery"
    );

    private ScopeNode parseScope(Element scopeEl, String name) {
        boolean hasFh = XmlDomUtils.firstChildElement(scopeEl, BPEL_2_0_NS, "faultHandlers").isPresent();
        boolean hasCh = XmlDomUtils.firstChildElement(scopeEl, BPEL_2_0_NS, "compensationHandler").isPresent();
        boolean hasEh = XmlDomUtils.firstChildElement(scopeEl, BPEL_2_0_NS, "eventHandlers").isPresent();

        BpelActivity primary = findPrimaryActivity(scopeEl)
                .map(this::parseActivity)
                .orElseGet(() -> new EmptyNode("empty-scope", "empty"));

        List<BpelActivity> handlerActs = parseHandlerActivities(scopeEl);
        return new ScopeNode(name, hasFh, hasCh, hasEh, primary, handlerActs);
    }

    private List<BpelActivity> parseHandlerActivities(Element container) {
        List<BpelActivity> handlerActs = new ArrayList<>();
        for (String hTag : List.of("faultHandlers", "eventHandlers")) {
            XmlDomUtils.firstChildElement(container, BPEL_2_0_NS, hTag).ifPresent(hEl -> {
                for (Element sub : XmlDomUtils.childElements(hEl)) {
                    findPrimaryActivity(sub).map(this::parseActivity).ifPresent(handlerActs::add);
                }
            });
        }
        XmlDomUtils.firstChildElement(container, BPEL_2_0_NS, "compensationHandler")
                .flatMap(this::findPrimaryActivity)
                .map(this::parseActivity)
                .ifPresent(handlerActs::add);
        return List.copyOf(handlerActs);
    }

    private Optional<Element> findPrimaryActivity(Element container) {
        return XmlDomUtils.childElements(container).stream()
                .filter(c -> BPEL_2_0_NS.equals(c.getNamespaceURI()))
                .filter(c -> !NON_ACTIVITY_TAGS.contains(c.getLocalName()))
                .findFirst();
    }

    private List<BpelProcess.ImportDecl> parseImports(Element root) {
        List<BpelProcess.ImportDecl> imports = new ArrayList<>();
        for (Element child : XmlDomUtils.childElements(root)) {
            if (BPEL_2_0_NS.equals(child.getNamespaceURI()) && "import".equals(child.getLocalName())) {
                imports.add(new BpelProcess.ImportDecl(
                        child.getAttribute("namespace"),
                        attrOpt(child, "location"),
                        attrOpt(child, "importType")
                ));
            }
        }
        return List.copyOf(imports);
    }

    private Map<String, BpelProcess.PartnerLinkDecl> parsePartnerLinks(Element root) {
        Map<String, BpelProcess.PartnerLinkDecl> map = new LinkedHashMap<>();
        XmlDomUtils.firstChildElement(root, BPEL_2_0_NS, "partnerLinks").ifPresent(pls -> {
            for (Element pl : XmlDomUtils.childElements(pls)) {
                String name = pl.getAttribute("name");
                map.put(name, new BpelProcess.PartnerLinkDecl(
                        name,
                        XmlDomUtils.resolveQName(pl, pl.getAttribute("partnerLinkType")),
                        attrOpt(pl, "myRole"),
                        attrOpt(pl, "partnerRole")
                ));
            }
        });
        return Map.copyOf(map);
    }

    private Map<String, BpelProcess.VariableDecl> parseVariables(Element root) {
        Map<String, BpelProcess.VariableDecl> map = new LinkedHashMap<>();
        XmlDomUtils.firstChildElement(root, BPEL_2_0_NS, "variables").ifPresent(vars -> {
            for (Element v : XmlDomUtils.childElements(vars)) {
                String name = v.getAttribute("name");
                map.put(name, new BpelProcess.VariableDecl(
                        name,
                        qNameOpt(v, "messageType"),
                        qNameOpt(v, "element"),
                        qNameOpt(v, "type")
                ));
            }
        });
        return Map.copyOf(map);
    }

    private List<String> parseCorrelationSets(Element root) {
        List<String> sets = new ArrayList<>();
        XmlDomUtils.firstChildElement(root, BPEL_2_0_NS, "correlationSets").ifPresent(cs -> {
            for (Element c : XmlDomUtils.childElements(cs)) {
                sets.add(c.getAttribute("name"));
            }
        });
        return List.copyOf(sets);
    }

    private List<CorrelationRef> parseCorrelations(Element activityEl) {
        List<CorrelationRef> refs = new ArrayList<>();
        XmlDomUtils.firstChildElement(activityEl, BPEL_2_0_NS, "correlations").ifPresent(cs -> {
            for (Element c : XmlDomUtils.childElements(cs)) {
                refs.add(new CorrelationRef(c.getAttribute("set"), c.getAttribute("initiate")));
            }
        });
        return List.copyOf(refs);
    }

    private Optional<String> attrOpt(Element el, String attr) {
        return el.hasAttribute(attr) && !el.getAttribute(attr).isBlank()
                ? Optional.of(el.getAttribute(attr))
                : Optional.empty();
    }

    private Optional<QName> qNameOpt(Element el, String attr) {
        return attrOpt(el, attr).map(raw -> XmlDomUtils.resolveQName(el, raw));
    }
}
