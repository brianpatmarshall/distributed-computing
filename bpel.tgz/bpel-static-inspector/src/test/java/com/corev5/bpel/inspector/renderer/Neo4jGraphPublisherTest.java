package com.corev5.bpel.inspector.renderer;

import com.corev5.bpel.inspector.model.report.*;
import org.junit.jupiter.api.Test;
import org.neo4j.driver.*;

import javax.xml.namespace.QName;
import java.lang.reflect.Proxy;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class Neo4jGraphPublisherTest {

    record RecordedQuery(String cypher, Map<String, Object> params) {}

    @Test
    void publishesConstraintsNodesAndAllDependencyRelationships() {
        List<RecordedQuery> sessionQueries = new ArrayList<>();
        List<RecordedQuery> txQueries = new ArrayList<>();
        boolean[] connectivityVerified = {false};

        Result emptyResult = (Result) Proxy.newProxyInstance(
                Result.class.getClassLoader(),
                new Class<?>[]{Result.class},
                (proxy, method, args) -> null
        );

        TransactionContext tx = (TransactionContext) Proxy.newProxyInstance(
                TransactionContext.class.getClassLoader(),
                new Class<?>[]{TransactionContext.class},
                (proxy, method, args) -> {
                    if ("run".equals(method.getName())) {
                        String cypher = args[0].toString();
                        @SuppressWarnings("unchecked")
                        Map<String, Object> params = (args.length > 1 && args[1] instanceof Map<?, ?> m)
                                ? (Map<String, Object>) m
                                : Map.of();
                        txQueries.add(new RecordedQuery(cypher, params));
                        return emptyResult;
                    }
                    return null;
                }
        );

        Session session = (Session) Proxy.newProxyInstance(
                Session.class.getClassLoader(),
                new Class<?>[]{Session.class},
                (proxy, method, args) -> switch (method.getName()) {
                    case "run" -> {
                        sessionQueries.add(new RecordedQuery(args[0].toString(), Map.of()));
                        yield emptyResult;
                    }
                    case "executeWrite" -> {
                        @SuppressWarnings("unchecked")
                        TransactionCallback<Object> cb = (TransactionCallback<Object>) args[0];
                        yield cb.execute(tx);
                    }
                    case "close" -> null;
                    default -> null;
                }
        );

        Driver driver = (Driver) Proxy.newProxyInstance(
                Driver.class.getClassLoader(),
                new Class<?>[]{Driver.class},
                (proxy, method, args) -> switch (method.getName()) {
                    case "verifyConnectivity" -> {
                        connectivityVerified[0] = true;
                        yield null;
                    }
                    case "session" -> session;
                    case "close" -> null;
                    default -> null;
                }
        );

        QName billingSvc = new QName("http://corev5.com/billing", "BillingService");
        QName externalSvc = new QName("http://ext.example.com", "BankService");

        BpelComponentGraph billingComponents = new BpelComponentGraph(
                new BpelComponentGraph.BpelExplanation("Summary", "Trigger", "Deploy", List.of(), List.of(), List.of()),
                List.of(
                        new BpelComponentGraph.ComponentNode("pl:billing/BillingProcess.bpel:client", "BpelPartnerLink", "PARTNER_LINK", "client", null, Map.of()),
                        new BpelComponentGraph.ComponentNode("act:billing/BillingProcess.bpel:1", "BpelActivity", "RECEIVE", "ReceiveCharge", null, Map.of("operation", "charge"))
                ),
                List.of(
                        new BpelComponentGraph.ComponentEdge("e1", "bpel:billing/BillingProcess.bpel", "pl:billing/BillingProcess.bpel:client", "HAS_PARTNER_LINK", Map.of()),
                        new BpelComponentGraph.ComponentEdge("e2", "bpel:billing/BillingProcess.bpel", "act:billing/BillingProcess.bpel:1", "HAS_ROOT_ACTIVITY", Map.of()),
                        new BpelComponentGraph.ComponentEdge("e3", "act:billing/BillingProcess.bpel:1", "pl:billing/BillingProcess.bpel:client", "USES_PARTNER_LINK", Map.of("operation", "charge"))
                )
        );

        ProcessAuditReport billingReport = new ProcessAuditReport(
                "BillingProcess",
                "http://corev5.com/billing",
                Path.of("/tmp/billing/BillingProcess.bpel"),
                "billing/BillingProcess.bpel",
                MigrationCategory.STATELESS_PIPELINE,
                true,
                new ProcessDependencies(
                        Optional.of(new ProcessDependencies.DeployDependency(
                                Path.of("/tmp/billing/deploy.xml"),
                                "billing/deploy.xml",
                                true,
                                List.of(new ProcessDependencies.ServiceBindingRef(
                                        "client", billingSvc, "BillingPort",
                                        Optional.of(Path.of("/tmp/billing/Billing.wsdl")),
                                        Optional.of("billing/Billing.wsdl")
                                )),
                                List.of(new ProcessDependencies.ServiceBindingRef(
                                        "bank", externalSvc, "BankPort",
                                        Optional.empty(),
                                        Optional.empty()
                                ))
                        )),
                        List.of(new ProcessDependencies.WsdlDependency(
                                Path.of("/tmp/billing/Billing.wsdl"),
                                "billing/Billing.wsdl",
                                "http://corev5.com/billing",
                                List.of("bpel:import(Billing.wsdl)"),
                                List.of("common/Faults.wsdl"),
                                List.of("schemas/Billing.xsd")
                        )),
                        List.of(new ProcessDependencies.XsdDependency(
                                Path.of("/tmp/schemas/Billing.xsd"),
                                "schemas/Billing.xsd",
                                "http://corev5.com/billing/types",
                                List.of("wsdl:schema(from billing/Billing.wsdl)"),
                                List.of("schemas/Base.xsd")
                        ))
                ),
                billingComponents,
                new ReactorBlueprint("/api/v1/billing-process", "Mono<ResponseEntity<BillingProcessResponse>>", List.of(), List.of()),
                List.of(),
                "sequenceDiagram\n"
        );

        ProcessAuditReport orderReport = new ProcessAuditReport(
                "OrderProcess",
                "http://corev5.com/order",
                Path.of("/tmp/order/OrderProcess.bpel"),
                "order/OrderProcess.bpel",
                MigrationCategory.STATELESS_PIPELINE,
                false,
                new ProcessDependencies(
                        Optional.of(new ProcessDependencies.DeployDependency(
                                Path.of("/tmp/order/deploy.xml"),
                                "order/deploy.xml",
                                false,
                                List.of(),
                                List.of(new ProcessDependencies.ServiceBindingRef(
                                        "billing", billingSvc, "BillingPort",
                                        Optional.of(Path.of("/tmp/billing/Billing.wsdl")),
                                        Optional.of("billing/Billing.wsdl")
                                ))
                        )),
                        List.of(new ProcessDependencies.WsdlDependency(
                                Path.of("/tmp/billing/Billing.wsdl"),
                                "billing/Billing.wsdl",
                                "http://corev5.com/billing",
                                List.of("deploy.xml:invoke(billing)"),
                                List.of(),
                                List.of()
                        )),
                        List.of()
                ),
                null,
                new ReactorBlueprint("/api/v1/order-process", "Mono<ResponseEntity<OrderProcessResponse>>", List.of(), List.of()),
                List.of(),
                "sequenceDiagram\n"
        );

        Neo4jGraphPublisher.PublishSummary summary;
        try (Neo4jGraphPublisher publisher = new Neo4jGraphPublisher(driver, "neo4j")) {
            summary = publisher.publish(List.of(billingReport, orderReport), true);
        }

        assertTrue(connectivityVerified[0]);
        assertEquals(9, sessionQueries.size());
        assertTrue(sessionQueries.stream().allMatch(q -> q.cypher().startsWith("CREATE CONSTRAINT")));

        assertEquals(2, summary.bpelCount());
        assertEquals(2, summary.deployEdges());
        assertEquals(2, summary.wsdlEdges());
        assertEquals(1, summary.xsdEdges());
        assertEquals(1, summary.crossProcessEdges());
        assertEquals(2, summary.componentNodes());
        assertEquals(3, summary.componentEdges());

        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("DETACH DELETE n")));
        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("MERGE (b)-[r:DEPLOYED_BY]->(d)")));
        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("MERGE (d)-[r:BINDS_SERVICE") && q.cypher().contains(":ExternalService")));
        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("MERGE (w1)-[:IMPORTS_WSDL]->(w2)")));
        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("MERGE (w)-[:USES_XSD]->(x)")));
        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("MERGE (x1)-[:IMPORTS_XSD]->(x2)")));
        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("MERGE (c:BpelActivity")));
        assertTrue(txQueries.stream().anyMatch(q -> q.cypher().contains("MERGE (src)-[r:USES_PARTNER_LINK]->(tgt)")));
        assertTrue(txQueries.stream().anyMatch(q ->
                q.cypher().contains("MERGE (caller)-[r:INVOKES_PROCESS")
                        && "order/OrderProcess.bpel".equals(q.params().get("callerPath"))
                        && "billing/BillingProcess.bpel".equals(q.params().get("calleePath"))
        ));
    }
}
