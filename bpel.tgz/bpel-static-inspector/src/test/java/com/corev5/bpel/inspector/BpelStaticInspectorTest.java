package com.corev5.bpel.inspector;

import com.corev5.bpel.inspector.analyzer.ProcessAnalyzer;
import com.corev5.bpel.inspector.model.ast.BpelProcess;
import com.corev5.bpel.inspector.model.contract.SymbolTable;
import com.corev5.bpel.inspector.model.report.MigrationCategory;
import com.corev5.bpel.inspector.model.report.ProcessAuditReport;
import com.corev5.bpel.inspector.model.report.ProcessDependencies;
import com.corev5.bpel.inspector.parser.BpelAstParser;
import com.corev5.bpel.inspector.parser.ContractIndexer;
import com.corev5.bpel.inspector.renderer.Neo4jCypherRenderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import picocli.CommandLine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BpelStaticInspectorTest {

    @Test
    void inspectsStatelessOrderProcessWithXsdAndReactorBlueprint(@TempDir Path tempDir) throws Exception {
        Files.writeString(tempDir.resolve("OrderTypes.xsd"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
                           targetNamespace="http://corev5.com/order/types"
                           elementFormDefault="qualified">
                    <xs:element name="OrderRequest">
                        <xs:complexType>
                            <xs:sequence>
                                <xs:element name="OrderId" type="xs:string"/>
                                <xs:element name="SSN" type="xs:string"/>
                                <xs:element name="UnusedLegacyField" type="xs:string" minOccurs="0"/>
                            </xs:sequence>
                        </xs:complexType>
                    </xs:element>
                    <xs:element name="OrderResponse">
                        <xs:complexType>
                            <xs:sequence>
                                <xs:element name="Status" type="xs:string"/>
                            </xs:sequence>
                        </xs:complexType>
                    </xs:element>
                </xs:schema>
                """);

        Files.writeString(tempDir.resolve("OrderProcess.wsdl"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <wsdl:definitions xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/"
                                  xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype"
                                  xmlns:tns="http://corev5.com/order/wsdl"
                                  xmlns:ord="http://corev5.com/order/types"
                                  targetNamespace="http://corev5.com/order/wsdl">
                    <wsdl:message name="OrderInputMsg">
                        <wsdl:part name="payload" element="ord:OrderRequest"/>
                    </wsdl:message>
                    <wsdl:message name="OrderOutputMsg">
                        <wsdl:part name="payload" element="ord:OrderResponse"/>
                    </wsdl:message>
                    <plnk:partnerLinkType name="OrderPLT">
                        <plnk:role name="OrderProvider" portType="tns:OrderPortType"/>
                    </plnk:partnerLinkType>
                </wsdl:definitions>
                """);

        Path bpelPath = tempDir.resolve("OrderProcess.bpel");
        Files.writeString(bpelPath, """
                <?xml version="1.0" encoding="UTF-8"?>
                <process name="OrderProcess"
                         targetNamespace="http://corev5.com/order/bpel"
                         xmlns="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                         xmlns:wsdl="http://corev5.com/order/wsdl"
                         xmlns:ord="http://corev5.com/order/types">
                    <partnerLinks>
                        <partnerLink name="client" partnerLinkType="wsdl:OrderPLT" myRole="OrderProvider"/>
                    </partnerLinks>
                    <variables>
                        <variable name="orderInput" messageType="wsdl:OrderInputMsg"/>
                        <variable name="orderOutput" messageType="wsdl:OrderOutputMsg"/>
                    </variables>
                    <sequence>
                        <receive name="ReceiveOrder" partnerLink="client" portType="wsdl:OrderPortType"
                                 operation="submitOrder" variable="orderInput" createInstance="yes"/>
                        <assign name="MapResponse">
                            <copy>
                                <from variable="orderInput" part="payload">
                                    <query>/ord:OrderRequest/ord:OrderId</query>
                                </from>
                                <to variable="orderOutput" part="payload">
                                    <query>/ord:OrderResponse/ord:Status</query>
                                </to>
                            </copy>
                        </assign>
                        <reply name="ReplyOrder" partnerLink="client" portType="wsdl:OrderPortType"
                               operation="submitOrder" variable="orderOutput"/>
                    </sequence>
                </process>
                """);

        SymbolTable symbols = new ContractIndexer().indexDirectory(tempDir);
        BpelProcess process = new BpelAstParser().parse(bpelPath);
        ProcessAuditReport report = new ProcessAnalyzer(symbols).analyze(process);

        assertEquals(MigrationCategory.STATELESS_PIPELINE, report.category());
        assertEquals("/api/v1/order-process", report.reactorBlueprint().suggestedRestControllerPath());
        assertEquals(2, report.touchpoints().size());

        var inboundFields = report.touchpoints().getFirst().inputDtoTree().getFirst().children();
        assertTrue(inboundFields.stream().anyMatch(f -> f.fieldName().equals("OrderId") && f.usedByBpel()));
        assertTrue(inboundFields.stream().anyMatch(f -> f.fieldName().equals("UnusedLegacyField") && !f.usedByBpel()));

        assertTrue(report.dependencies().deployXml().isEmpty());
        assertEquals(1, report.dependencies().wsdlFiles().size());
        assertEquals("OrderProcess.wsdl", report.dependencies().wsdlFiles().getFirst().relativePath());
        assertEquals(1, report.dependencies().xsdFiles().size());
        assertEquals("OrderTypes.xsd", report.dependencies().xsdFiles().getFirst().relativePath());
    }

    @Test
    void resolvesDeployXmlAndWsdlDependenciesAndGeneratesNeo4jExports(@TempDir Path tempDir) throws Exception {
        Path inputDir = Files.createDirectories(tempDir.resolve("project"));
        Path outputDir = tempDir.resolve("out");

        Files.writeString(inputDir.resolve("OrderTypes.xsd"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
                           targetNamespace="http://corev5.com/order/types"
                           elementFormDefault="qualified">
                    <xs:element name="OrderRequest" type="xs:string"/>
                    <xs:element name="OrderResponse" type="xs:string"/>
                </xs:schema>
                """);

        Files.writeString(inputDir.resolve("CommonFaults.wsdl"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <wsdl:definitions xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/"
                                  targetNamespace="http://corev5.com/common/faults">
                    <wsdl:message name="CommonFaultMsg"/>
                </wsdl:definitions>
                """);

        Files.writeString(inputDir.resolve("OrderProcess.wsdl"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <wsdl:definitions xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/"
                                  xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype"
                                  xmlns:tns="http://corev5.com/order/wsdl"
                                  xmlns:ord="http://corev5.com/order/types"
                                  targetNamespace="http://corev5.com/order/wsdl">
                    <wsdl:import namespace="http://corev5.com/common/faults" location="CommonFaults.wsdl"/>
                    <wsdl:message name="OrderInputMsg">
                        <wsdl:part name="payload" element="ord:OrderRequest"/>
                    </wsdl:message>
                    <wsdl:message name="OrderOutputMsg">
                        <wsdl:part name="payload" element="ord:OrderResponse"/>
                    </wsdl:message>
                    <wsdl:portType name="OrderPortType">
                        <wsdl:operation name="submitOrder">
                            <wsdl:input message="tns:OrderInputMsg"/>
                            <wsdl:output message="tns:OrderOutputMsg"/>
                        </wsdl:operation>
                    </wsdl:portType>
                    <wsdl:service name="OrderService">
                        <wsdl:port name="OrderPort" binding="tns:OrderBinding"/>
                    </wsdl:service>
                    <plnk:partnerLinkType name="OrderPLT">
                        <plnk:role name="OrderProvider" portType="tns:OrderPortType"/>
                    </plnk:partnerLinkType>
                </wsdl:definitions>
                """);

        Files.writeString(inputDir.resolve("Billing.wsdl"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <wsdl:definitions xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/"
                                  xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype"
                                  xmlns:tns="http://corev5.com/billing/wsdl"
                                  targetNamespace="http://corev5.com/billing/wsdl">
                    <wsdl:message name="ChargeReq"/>
                    <wsdl:message name="ChargeRes"/>
                    <wsdl:portType name="BillingPortType">
                        <wsdl:operation name="charge">
                            <wsdl:input message="tns:ChargeReq"/>
                            <wsdl:output message="tns:ChargeRes"/>
                        </wsdl:operation>
                    </wsdl:portType>
                    <wsdl:service name="BillingService">
                        <wsdl:port name="BillingPort" binding="tns:BillingBinding"/>
                    </wsdl:service>
                    <plnk:partnerLinkType name="BillingPLT">
                        <plnk:role name="BillingProvider" portType="tns:BillingPortType"/>
                    </plnk:partnerLinkType>
                </wsdl:definitions>
                """);

        Files.writeString(inputDir.resolve("deploy.xml"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <deploy xmlns="http://www.apache.org/ode/schemas/dd/2007/03"
                        xmlns:pns="http://corev5.com/order/bpel"
                        xmlns:ordw="http://corev5.com/order/wsdl"
                        xmlns:bill="http://corev5.com/billing/wsdl">
                    <process name="pns:OrderProcess">
                        <in-memory>true</in-memory>
                        <provide partnerLink="client">
                            <service name="ordw:OrderService" port="OrderPort"/>
                        </provide>
                        <invoke partnerLink="billing">
                            <service name="bill:BillingService" port="BillingPort"/>
                        </invoke>
                    </process>
                </deploy>
                """);

        Path bpelPath = inputDir.resolve("OrderProcess.bpel");
        Files.writeString(bpelPath, """
                <?xml version="1.0" encoding="UTF-8"?>
                <process name="OrderProcess"
                         targetNamespace="http://corev5.com/order/bpel"
                         xmlns="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                         xmlns:ordw="http://corev5.com/order/wsdl"
                         xmlns:bill="http://corev5.com/billing/wsdl">
                    <import namespace="http://corev5.com/order/wsdl"
                            location="OrderProcess.wsdl"
                            importType="http://schemas.xmlsoap.org/wsdl/"/>
                    <partnerLinks>
                        <partnerLink name="client" partnerLinkType="ordw:OrderPLT" myRole="OrderProvider"/>
                        <partnerLink name="billing" partnerLinkType="bill:BillingPLT" partnerRole="BillingProvider"/>
                    </partnerLinks>
                    <variables>
                        <variable name="orderInput" messageType="ordw:OrderInputMsg"/>
                        <variable name="orderOutput" messageType="ordw:OrderOutputMsg"/>
                        <variable name="chargeReq" messageType="bill:ChargeReq"/>
                        <variable name="chargeRes" messageType="bill:ChargeRes"/>
                    </variables>
                    <sequence>
                        <receive name="ReceiveOrder" partnerLink="client" portType="ordw:OrderPortType"
                                 operation="submitOrder" variable="orderInput" createInstance="yes"/>
                        <invoke name="ChargeCustomer" partnerLink="billing" portType="bill:BillingPortType"
                                operation="charge" inputVariable="chargeReq" outputVariable="chargeRes"/>
                        <reply name="ReplyOrder" partnerLink="client" portType="ordw:OrderPortType"
                               operation="submitOrder" variable="orderOutput"/>
                    </sequence>
                </process>
                """);

        SymbolTable symbols = new ContractIndexer().indexDirectory(inputDir);
        BpelProcess process = new BpelAstParser().parse(bpelPath);
        ProcessAuditReport report = new ProcessAnalyzer(symbols).analyze(process);

        ProcessDependencies deps = report.dependencies();
        assertTrue(deps.deployXml().isPresent());
        ProcessDependencies.DeployDependency deploy = deps.deployXml().get();
        assertEquals("deploy.xml", deploy.relativePath());
        assertTrue(deploy.inMemory());
        assertEquals(1, deploy.providedServices().size());
        assertEquals("OrderProcess.wsdl", deploy.providedServices().getFirst().wsdlRelativePath().orElseThrow());
        assertEquals(1, deploy.invokedServices().size());
        assertEquals("Billing.wsdl", deploy.invokedServices().getFirst().wsdlRelativePath().orElseThrow());

        List<String> wsdlPaths = deps.wsdlFiles().stream().map(ProcessDependencies.WsdlDependency::relativePath).toList();
        assertEquals(List.of("Billing.wsdl", "CommonFaults.wsdl", "OrderProcess.wsdl"), wsdlPaths);

        List<String> xsdPaths = deps.xsdFiles().stream().map(ProcessDependencies.XsdDependency::relativePath).toList();
        assertEquals(List.of("OrderTypes.xsd"), xsdPaths);

        String cypher = new Neo4jCypherRenderer().renderCypher(List.of(report));
        assertTrue(cypher.contains("MERGE (b:BpelFile {path: 'OrderProcess.bpel'})"));
        assertTrue(cypher.contains("MERGE (d:DeployXml {path: 'deploy.xml'})"));
        assertTrue(cypher.contains("MERGE (b)-[r:DEPLOYED_BY]->(d)"));
        assertTrue(cypher.contains("MERGE (d)-[r:BINDS_SERVICE {processName: 'OrderProcess', partnerLink: 'billing', direction: 'INVOKE'}]->(w)"));
        assertTrue(cypher.contains("MERGE (b)-[r:DEPENDS_ON_WSDL]->(w)"));
        assertTrue(cypher.contains("MERGE (w1)-[:IMPORTS_WSDL]->(w2)"));
        assertTrue(cypher.contains("MERGE (w)-[:USES_XSD]->(x)"));
        assertTrue(cypher.contains("MERGE (c:BpelActivity"));
        assertTrue(cypher.contains("MERGE (src)-[r:HAS_ROOT_ACTIVITY]->(tgt)"));
        assertTrue(cypher.contains("MERGE (src)-[r:USES_PARTNER_LINK]->(tgt)"));

        assertNotNull(report.components());
        assertFalse(report.components().nodes().isEmpty());
        assertTrue(report.components().explanation().summary().contains("OrderProcess"));
        assertTrue(report.components().explanation().steps().size() >= 3);

        int exitCode = new CommandLine(new InspectorCli())
                .execute("-i", inputDir.toString(), "-o", outputDir.toString());
        assertEquals(0, exitCode);
        assertTrue(Files.isRegularFile(outputDir.resolve("neo4j-dependencies.cypher")));
        assertTrue(Files.isRegularFile(outputDir.resolve("neo4j-style.grass")));
        assertTrue(Files.isRegularFile(outputDir.resolve("bpel-dependencies.txt")));
        assertTrue(Files.isRegularFile(outputDir.resolve("migration-audit.json")));

        String txt = Files.readString(outputDir.resolve("bpel-dependencies.txt"));
        assertTrue(txt.contains("BPEL: OrderProcess.bpel"));
        assertTrue(txt.contains("deploy.xml : deploy.xml"));
        assertTrue(txt.contains("Billing.wsdl"));
        assertTrue(txt.contains("CommonFaults.wsdl"));
        assertTrue(txt.contains("OrderProcess.wsdl"));
    }

    @Test
    void detectsCrossProcessInvocationsExternalServicesTransitiveXsdsAndSagaCompensation(@TempDir Path tempDir) throws Exception {
        Path root = Files.createDirectories(tempDir.resolve("workspace"));
        Path orderDir = Files.createDirectories(root.resolve("orders"));
        Path billingDir = Files.createDirectories(root.resolve("billing"));
        Path schemasDir = Files.createDirectories(root.resolve("schemas"));

        Files.writeString(schemasDir.resolve("BaseTypes.xsd"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
                           targetNamespace="http://corev5.com/base/types">
                    <xs:simpleType name="MoneyType">
                        <xs:restriction base="xs:decimal"/>
                    </xs:simpleType>
                </xs:schema>
                """);

        Files.writeString(schemasDir.resolve("BillingTypes.xsd"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
                           xmlns:base="http://corev5.com/base/types"
                           targetNamespace="http://corev5.com/billing/types">
                    <xs:import namespace="http://corev5.com/base/types" schemaLocation="BaseTypes.xsd"/>
                    <xs:element name="ChargeRequest" type="base:MoneyType"/>
                </xs:schema>
                """);

        Files.writeString(billingDir.resolve("Billing.wsdl"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <wsdl:definitions xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/"
                                  xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype"
                                  xmlns:tns="http://corev5.com/billing/wsdl"
                                  xmlns:bt="http://corev5.com/billing/types"
                                  targetNamespace="http://corev5.com/billing/wsdl">
                    <wsdl:message name="ChargeReq">
                        <wsdl:part name="payload" element="bt:ChargeRequest"/>
                    </wsdl:message>
                    <wsdl:portType name="BillingPortType">
                        <wsdl:operation name="charge">
                            <wsdl:input message="tns:ChargeReq"/>
                        </wsdl:operation>
                    </wsdl:portType>
                    <wsdl:service name="BillingService">
                        <wsdl:port name="BillingPort" binding="tns:BillingBinding"/>
                    </wsdl:service>
                    <plnk:partnerLinkType name="BillingPLT">
                        <plnk:role name="BillingProvider" portType="tns:BillingPortType"/>
                    </plnk:partnerLinkType>
                </wsdl:definitions>
                """);

        Files.writeString(billingDir.resolve("deploy.xml"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <deploy xmlns="http://www.apache.org/ode/schemas/dd/2007/03"
                        xmlns:pns="http://corev5.com/billing/bpel"
                        xmlns:bill="http://corev5.com/billing/wsdl"
                        xmlns:ext="http://external.example.com/bank">
                    <process name="pns:BillingProcess">
                        <provide partnerLink="client">
                            <service name="bill:BillingService" port="BillingPort"/>
                        </provide>
                        <invoke partnerLink="bankGateway">
                            <service name="ext:BankGatewayService" port="BankPort"/>
                        </invoke>
                    </process>
                </deploy>
                """);

        Path billingBpel = billingDir.resolve("BillingProcess.bpel");
        Files.writeString(billingBpel, """
                <?xml version="1.0" encoding="UTF-8"?>
                <process name="BillingProcess"
                         targetNamespace="http://corev5.com/billing/bpel"
                         xmlns="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                         xmlns:bill="http://corev5.com/billing/wsdl">
                    <partnerLinks>
                        <partnerLink name="client" partnerLinkType="bill:BillingPLT" myRole="BillingProvider"/>
                    </partnerLinks>
                    <variables>
                        <variable name="req" messageType="bill:ChargeReq"/>
                    </variables>
                    <scope name="ChargeScope">
                        <compensationHandler>
                            <invoke name="RefundCharge" partnerLink="bankGateway" operation="refund"/>
                        </compensationHandler>
                        <sequence>
                            <receive name="ReceiveCharge" partnerLink="client" portType="bill:BillingPortType"
                                     operation="charge" variable="req" createInstance="yes"/>
                        </sequence>
                    </scope>
                </process>
                """);

        Files.writeString(orderDir.resolve("deploy.xml"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <deploy xmlns="http://www.apache.org/ode/schemas/dd/2007/03"
                        xmlns:pns="http://corev5.com/order/bpel"
                        xmlns:bill="http://corev5.com/billing/wsdl">
                    <process name="pns:OrderOrchestrator">
                        <invoke partnerLink="billing">
                            <service name="bill:BillingService" port="BillingPort"/>
                        </invoke>
                    </process>
                </deploy>
                """);

        Path orderBpel = orderDir.resolve("OrderOrchestrator.bpel");
        Files.writeString(orderBpel, """
                <?xml version="1.0" encoding="UTF-8"?>
                <process name="OrderOrchestrator"
                         targetNamespace="http://corev5.com/order/bpel"
                         xmlns="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                         xmlns:bill="http://corev5.com/billing/wsdl">
                    <partnerLinks>
                        <partnerLink name="billing" partnerLinkType="bill:BillingPLT" partnerRole="BillingProvider"/>
                    </partnerLinks>
                    <variables>
                        <variable name="chargeReq" messageType="bill:ChargeReq"/>
                    </variables>
                    <sequence>
                        <invoke name="CallBilling" partnerLink="billing" portType="bill:BillingPortType"
                                operation="charge" inputVariable="chargeReq"/>
                        <wait name="WaitForSettlement"><for>'PT5M'</for></wait>
                    </sequence>
                </process>
                """);

        SymbolTable symbols = new ContractIndexer().indexDirectory(root);
        BpelAstParser parser = new BpelAstParser();
        ProcessAnalyzer analyzer = new ProcessAnalyzer(symbols);

        ProcessAuditReport billingReport = analyzer.analyze(parser.parse(billingBpel));
        ProcessAuditReport orderReport = analyzer.analyze(parser.parse(orderBpel));

        // Direct <compensationHandler><invoke .../></compensationHandler> is now parsed and produces SAGA_COMPENSATING + touchpoint
        assertEquals(MigrationCategory.SAGA_COMPENSATING, billingReport.category());
        assertTrue(billingReport.touchpoints().stream().anyMatch(tp -> tp.operation().equals("refund")));

        // OrderOrchestrator has <wait> -> STATEFUL_ASYNC and 202 Accepted blueprint
        assertEquals(MigrationCategory.STATEFUL_ASYNC, orderReport.category());
        assertTrue(orderReport.reactorBlueprint().reactiveReturnSignature().contains("202 Accepted"));

        // Transitive XSD import: Billing.wsdl -> BillingTypes.xsd -> BaseTypes.xsd
        List<String> billingXsds = billingReport.dependencies().xsdFiles().stream()
                .map(ProcessDependencies.XsdDependency::relativePath)
                .toList();
        assertEquals(List.of("schemas/BaseTypes.xsd", "schemas/BillingTypes.xsd"), billingXsds);

        String cypher = new Neo4jCypherRenderer().renderCypher(List.of(billingReport, orderReport));
        assertTrue(cypher.contains("MERGE (x1)-[:IMPORTS_XSD]->(x2)"));
        assertTrue(cypher.contains("MERGE (s:ExternalService {key: '{http://external.example.com/bank}BankGatewayService#BankPort'})"));
        assertTrue(cypher.contains("MERGE (caller)-[r:INVOKES_PROCESS {partnerLink: 'billing'}]->(callee)"));
    }
}
