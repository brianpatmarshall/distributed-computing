package com.corev5.bpel.inspector.web;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class InspectorWebServerTest {

    @Test
    void analyzesMultiModuleJavaProjectOverHttpApi(@TempDir Path tempDir) throws Exception {
        Path modA = Files.createDirectories(tempDir.resolve("order-bpel"));
        Path modB = Files.createDirectories(tempDir.resolve("billing-bpel"));

        Files.writeString(modA.resolve("pom.xml"), "<project><artifactId>order-bpel</artifactId></project>");
        Files.writeString(modB.resolve("pom.xml"), "<project><artifactId>billing-bpel</artifactId></project>");

        Files.writeString(modB.resolve("Billing.wsdl"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <wsdl:definitions xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/"
                                  xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype"
                                  xmlns:tns="http://corev5.com/billing"
                                  targetNamespace="http://corev5.com/billing">
                    <wsdl:message name="ChargeReq"/>
                    <wsdl:portType name="BillingPT">
                        <wsdl:operation name="charge"><wsdl:input message="tns:ChargeReq"/></wsdl:operation>
                    </wsdl:portType>
                    <wsdl:service name="BillingSvc"><wsdl:port name="BillingPort" binding="tns:B"/></wsdl:service>
                    <plnk:partnerLinkType name="BillingPLT">
                        <plnk:role name="Provider" portType="tns:BillingPT"/>
                    </plnk:partnerLinkType>
                </wsdl:definitions>
                """);

        Files.writeString(modB.resolve("deploy.xml"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <deploy xmlns="http://www.apache.org/ode/schemas/dd/2007/03"
                        xmlns:p="http://corev5.com/billing/bpel"
                        xmlns:b="http://corev5.com/billing">
                    <process name="p:BillingProcess">
                        <provide partnerLink="client"><service name="b:BillingSvc" port="BillingPort"/></provide>
                    </process>
                </deploy>
                """);

        Files.writeString(modB.resolve("BillingProcess.bpel"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <process name="BillingProcess" targetNamespace="http://corev5.com/billing/bpel"
                         xmlns="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                         xmlns:b="http://corev5.com/billing">
                    <partnerLinks>
                        <partnerLink name="client" partnerLinkType="b:BillingPLT" myRole="Provider"/>
                    </partnerLinks>
                    <variables><variable name="req" messageType="b:ChargeReq"/></variables>
                    <receive name="Recv" partnerLink="client" portType="b:BillingPT" operation="charge" variable="req" createInstance="yes"/>
                </process>
                """);

        Files.writeString(modA.resolve("deploy.xml"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <deploy xmlns="http://www.apache.org/ode/schemas/dd/2007/03"
                        xmlns:p="http://corev5.com/order/bpel"
                        xmlns:b="http://corev5.com/billing">
                    <process name="p:OrderProcess">
                        <invoke partnerLink="billing"><service name="b:BillingSvc" port="BillingPort"/></invoke>
                    </process>
                </deploy>
                """);

        Files.writeString(modA.resolve("OrderProcess.bpel"), """
                <?xml version="1.0" encoding="UTF-8"?>
                <process name="OrderProcess" targetNamespace="http://corev5.com/order/bpel"
                         xmlns="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                         xmlns:b="http://corev5.com/billing">
                    <partnerLinks>
                        <partnerLink name="billing" partnerLinkType="b:BillingPLT" partnerRole="Provider"/>
                    </partnerLinks>
                    <variables><variable name="req" messageType="b:ChargeReq"/></variables>
                    <invoke name="CallBilling" partnerLink="billing" portType="b:BillingPT" operation="charge" inputVariable="req"/>
                </process>
                """);

        InspectorWebServer server = new InspectorWebServer(0, null, "http://localhost:7474");
        server.start();
        try {
            HttpClient client = HttpClient.newHttpClient();
            String body = new ObjectMapper().writeValueAsString(java.util.Map.of("projectPath", tempDir.toString()));
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create("http://127.0.0.1:" + server.getPort() + "/api/analyze"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
            assertEquals(200, resp.statusCode());

            JsonNode root = new ObjectMapper().readTree(resp.body());
            assertEquals(2, root.path("counts").path("subProjects").asInt());
            assertEquals(2, root.path("counts").path("bpelFiles").asInt());
            assertEquals(2, root.path("counts").path("deployXmls").asInt());
            assertEquals(1, root.path("counts").path("wsdlFiles").asInt());
            assertTrue(root.path("graph").path("edges").toString().contains("INVOKES_PROCESS"));
        } finally {
            server.stop();
        }
    }
}
