# BPEL Static Inspector (`bpel-static-inspector`)

Java 25 static analyzer for Apache ODE WS-BPEL 2.0 workflows, designed to audit legacy BPEL/WSDL/XSD/deploy.xml artifacts, map per-BPEL file dependencies, visualize them in **Neo4j**, and produce migration blueprints for **Spring Boot WebFlux + Project Reactor 3 + REST/JSON**.

## Build & Run

### 1. CLI Analysis

```bash
mvn clean test
mvn exec:java -Dexec.args="-i /path/to/ode-bpel-projects -o ./bpel-audit-output"
```

### 2. React Web UI + Embedded Neo4j Visualizer (Irish Green & Yellow Theme)

Start the Java HTTP API (and Neo4j Browser iframe proxy):

```bash
mvn exec:java -Dexec.args="--serve --port 8080 --neo4j-http http://localhost:7474"
```

Then either open the built UI directly at `http://localhost:8080` (after `cd frontend && npm install && npm run build`), or run Vite dev mode with hot reload:

```bash
cd frontend
npm install
npm run dev
# Opens on http://localhost:5173 (proxies /api and /neo4j-browser to :8080)
```

### Push Directly to Neo4j (Optional)

```bash
mvn exec:java -Dexec.args="-i /path/to/ode-bpel-projects -o ./bpel-audit-output --neo4j-uri bolt://localhost:7687 --neo4j-user neo4j --neo4j-password secret --neo4j-clear"
```

You can also pass the password via the `NEO4J_PASSWORD` environment variable instead of `--neo4j-password`, and select a target database with `--neo4j-database <name>`.

## Outputs
- `migration-audit.json`: Full classification (`STATELESS_PIPELINE`, `STATEFUL_ASYNC`, `SAGA_COMPENSATING`), per-BPEL `dependencies` (`deploy.xml`, `.wsdl`, `.xsd` with reasons), Reactor 3 operator blueprints, external touchpoints, and XSD -> Java DTO field trees (`usedByBpel` flagged).
- `bpel-dependencies.txt`: Human-readable per-BPEL dependency report (also printed to stdout).
- `neo4j-dependencies.cypher`: Idempotent Cypher script creating `:BpelFile`, `:DeployXml`, `:WsdlFile`, `:XsdFile`, and `:ExternalService` nodes and `:DEPLOYED_BY`, `:DEPENDS_ON_WSDL`, `:DEPENDS_ON_XSD`, `:BINDS_SERVICE`, `:IMPORTS_WSDL`, `:USES_XSD`, `:IMPORTS_XSD`, and `:INVOKES_PROCESS` relationships.
- `neo4j-style.grass`: Neo4j Browser stylesheet for color-coded graph visualization.
- `global-topology.mmd`: System-wide Mermaid dependency graph across all processes.
- `diagrams/<ProcessName>.mmd`: Individual Mermaid sequence diagrams per `.bpel` workflow.

## Visualizing in Neo4j

If you did not push directly with `--neo4j-uri`, load the generated Cypher file with `cypher-shell`:

```bash
cypher-shell -u neo4j -p <password> < ./bpel-audit-output/neo4j-dependencies.cypher
```

Then open **Neo4j Browser** (`http://localhost:7474`), drag `bpel-audit-output/neo4j-style.grass` onto the Browser window (optional, for color-coding), and run:

```cypher
MATCH (n) WHERE n:BpelFile OR n:DeployXml OR n:WsdlFile OR n:XsdFile OR n:ExternalService
OPTIONAL MATCH (n)-[r]->(m)
RETURN n, r, m;
```
