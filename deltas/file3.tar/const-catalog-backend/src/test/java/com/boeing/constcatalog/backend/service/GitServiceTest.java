package com.boeing.constcatalog.backend.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Tests for {@link GitService} using a temporary git repo created via the git CLI.
 */
class GitServiceTest {

    private final GitService gitService = new GitService();

    @TempDir
    Path tempDir;

    /** Initialises a bare git repo with one commit so branches can be created. */
    @BeforeEach
    void initRepo() throws Exception {
        run("git", "init");
        run("git", "config", "user.email", "test@example.com");
        run("git", "config", "user.name", "Test");
        Files.writeString(tempDir.resolve("README.md"), "init");
        run("git", "add", "-A");
        run("git", "commit", "-m", "initial commit");
    }

    @Nested
    @DisplayName("isGitRepo")
    class IsGitRepo {
        @Test
        void returnsTrueForGitRepo() {
            assertThat(gitService.isGitRepo(tempDir)).isTrue();
        }

        @Test
        void returnsFalseForNonGitDir(@TempDir Path otherDir) {
            assertThat(gitService.isGitRepo(otherDir)).isFalse();
        }
    }

    @Nested
    @DisplayName("getCurrentBranch")
    class GetCurrentBranch {
        @Test
        void returnsDefaultBranch() throws Exception {
            String branch = gitService.getCurrentBranch(tempDir);
            // Could be "main" or "master" depending on git config
            assertThat(branch).isNotBlank();
        }
    }

    @Nested
    @DisplayName("createAndCheckoutBranch")
    class CreateAndCheckoutBranch {
        @Test
        void createsAndSwitchesToNewBranch() throws Exception {
            gitService.createAndCheckoutBranch(tempDir, "feature-test");
            assertThat(gitService.getCurrentBranch(tempDir)).isEqualTo("feature-test");
        }

        @Test
        void failsIfBranchAlreadyExists() throws Exception {
            gitService.createAndCheckoutBranch(tempDir, "duplicate");
            gitService.checkoutBranch(tempDir, gitService.getCurrentBranch(tempDir).equals("duplicate") ? "master" : "main");

            // Branch "duplicate" already exists — cannot create again
            // First get back to a branch that isn't "duplicate"
            String defaultBranch = run("git", "rev-parse", "--abbrev-ref", "HEAD").trim();
            if (defaultBranch.equals("duplicate")) {
                run("git", "checkout", "-b", "temp-branch");
            }
            assertThatThrownBy(() -> gitService.createAndCheckoutBranch(tempDir, "duplicate"))
                    .isInstanceOf(GitService.GitException.class);
        }
    }

    @Nested
    @DisplayName("checkoutBranch")
    class CheckoutBranch {
        @Test
        void switchesToExistingBranch() throws Exception {
            String original = gitService.getCurrentBranch(tempDir);
            gitService.createAndCheckoutBranch(tempDir, "other-branch");
            assertThat(gitService.getCurrentBranch(tempDir)).isEqualTo("other-branch");

            gitService.checkoutBranch(tempDir, original);
            assertThat(gitService.getCurrentBranch(tempDir)).isEqualTo(original);
        }

        @Test
        void failsForNonexistentBranch() {
            assertThatThrownBy(() -> gitService.checkoutBranch(tempDir, "no-such-branch"))
                    .isInstanceOf(GitService.GitException.class);
        }
    }

    @Nested
    @DisplayName("addAndCommit")
    class AddAndCommit {
        @Test
        void commitsNewFiles() throws Exception {
            Files.writeString(tempDir.resolve("hello.txt"), "world");
            assertThatCode(() -> gitService.addAndCommit(tempDir, "add hello"))
                    .doesNotThrowAnyException();

            // Verify the commit exists in the log
            String log = run("git", "log", "--oneline", "-1");
            assertThat(log).contains("add hello");
        }

        @Test
        void commitsModifiedFiles() throws Exception {
            Files.writeString(tempDir.resolve("README.md"), "updated content");
            gitService.addAndCommit(tempDir, "update readme");

            String log = run("git", "log", "--oneline", "-1");
            assertThat(log).contains("update readme");
        }
    }

    @Nested
    @DisplayName("full branch workflow")
    class FullWorkflow {
        @Test
        void createBranchCommitAndSwitchBack() throws Exception {
            String originalBranch = gitService.getCurrentBranch(tempDir);

            // Create branch and add a file
            gitService.createAndCheckoutBranch(tempDir, originalBranch + "-transformed");
            Files.writeString(tempDir.resolve("transformed.java"), "public class Transformed {}");
            gitService.addAndCommit(tempDir, "Transform constants to config lookups");

            // Switch back to original
            gitService.checkoutBranch(tempDir, originalBranch);
            assertThat(gitService.getCurrentBranch(tempDir)).isEqualTo(originalBranch);

            // File should not exist on original branch
            assertThat(tempDir.resolve("transformed.java")).doesNotExist();

            // File should exist on the transformed branch
            gitService.checkoutBranch(tempDir, originalBranch + "-transformed");
            assertThat(tempDir.resolve("transformed.java")).exists();
            assertThat(Files.readString(tempDir.resolve("transformed.java")))
                    .isEqualTo("public class Transformed {}");
        }
    }

    @Nested
    @DisplayName("initRepoWithInitialCommit")
    class InitRepoWithInitialCommit {

        @Test
        void initialisesRepoInBareDirectory(@TempDir Path dir) throws Exception {
            assertThat(gitService.isGitRepo(dir)).isFalse();

            String branch = gitService.initRepoWithInitialCommit(dir);

            assertThat(branch).isEqualTo("main");
            assertThat(gitService.isGitRepo(dir)).isTrue();
            assertThat(gitService.getCurrentBranch(dir)).isEqualTo("main");
        }

        @Test
        void commitsExistingFilesAsBaseline(@TempDir Path dir) throws Exception {
            Files.writeString(dir.resolve("Foo.java"), "public class Foo {}");
            Files.writeString(dir.resolve("Bar.java"), "public class Bar {}");

            gitService.initRepoWithInitialCommit(dir);

            String log = runIn(dir, "git", "log", "--oneline");
            assertThat(log).contains("Initial state (pre-transformation)");

            String tracked = runIn(dir, "git", "ls-files");
            assertThat(tracked).contains("Foo.java").contains("Bar.java");
        }

        @Test
        void branchIsAlwaysMain(@TempDir Path dir) throws Exception {
            Files.writeString(dir.resolve("file.txt"), "content");

            gitService.initRepoWithInitialCommit(dir);

            assertThat(gitService.getCurrentBranch(dir)).isEqualTo("main");
        }

        @Test
        void transformedBranchCanBeGitDiffedAgainstMain(@TempDir Path dir) throws Exception {
            // Set up a "project" with an existing Java file
            Path javaFile = dir.resolve("Config.java");
            Files.writeString(javaFile,
                    "public class Config { static final String HOST = \"localhost\"; }");

            String originalBranch = gitService.initRepoWithInitialCommit(dir);

            // Simulate the transformation: create branch, modify file, commit
            gitService.createAndCheckoutBranch(dir, originalBranch + "-transformed");
            Files.writeString(javaFile,
                    "public class Config { @Autowired private SiteConfigurationService config; }");
            gitService.addAndCommit(dir, "Transform constants to config lookups");

            // Switch back — original file should be restored by git
            gitService.checkoutBranch(dir, originalBranch);
            assertThat(gitService.getCurrentBranch(dir)).isEqualTo("main");
            assertThat(Files.readString(javaFile)).contains("localhost");

            // Diff between branches must be non-empty
            String diff = runIn(dir, "git", "diff", "main..main-transformed");
            assertThat(diff).isNotBlank();
            assertThat(diff).contains("localhost");
            assertThat(diff).contains("SiteConfigurationService");
        }
    }

    // ── Helpers ─────────────────────────────────────────────────────────

    private String run(String... args) throws Exception {
        return runIn(tempDir, args);
    }

    private String runIn(Path dir, String... args) throws Exception {
        ProcessBuilder pb = new ProcessBuilder(args)
                .directory(dir.toFile())
                .redirectErrorStream(true);
        Process p = pb.start();
        String output = new String(p.getInputStream().readAllBytes());
        int exit = p.waitFor();
        if (exit != 0 && !args[1].equals("rev-parse")) {
            throw new RuntimeException("Command failed: " + String.join(" ", args) + "\n" + output);
        }
        return output;
    }
}
