package com.boeing.constcatalog.backend.store;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.junit.jupiter.api.*;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for {@link MongoConfigStore}.
 *
 * <p>Connects to the MongoDB instance running via Docker Compose:
 * <pre>docker compose --profile mongodb up -d</pre>
 *
 * <p>Each test method gets a clean collection via {@link #clearCollection()}.
 * A dedicated test database ({@code const-catalog-test}) is used to avoid
 * interfering with production data.
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class MongoConfigStoreTest {

    static final String MONGO_URI = "mongodb://localhost:27017";
    static final String TEST_DATABASE = "const-catalog-test";

    MongoClient mongoClient;
    MongoDatabase database;
    MongoConfigStore store;

    @BeforeAll
    void startMongo() {
        try {
            mongoClient = MongoClients.create(MONGO_URI);
            database = mongoClient.getDatabase(TEST_DATABASE);
            // Verify connection
            database.runCommand(new Document("ping", 1));
        } catch (Exception e) {
            Assumptions.assumeTrue(false,
                "MongoDB not available on localhost:27017 — skipping. " +
                "Start with: docker compose --profile mongodb up -d");
        }
    }

    @AfterAll
    void stopMongo() {
        if (database != null) database.drop(); // clean up test database
        if (mongoClient != null) mongoClient.close();
    }

    @BeforeEach
    void setUp() {
        store = new MongoConfigStore(database);
        clearCollection();
    }

    void clearCollection() {
        database.getCollection(MongoConfigStore.COLLECTION_NAME).drop();
    }

    // ========================================================================
    // Connection tests
    // ========================================================================

    @Test
    void testMongoIsReachable() {
        Document result = database.runCommand(new Document("ping", 1));
        assertEquals(1.0, result.getDouble("ok"));
    }

    @Test
    void testCanConnectToMongo() {
        // Verify the connection works by running a ping
        Document result = database.runCommand(new Document("ping", 1));
        assertEquals(1.0, result.getDouble("ok"));
    }

    @Test
    void testStoreNameIsMongoDB() {
        assertEquals("MongoDB", store.storeName());
    }

    // ========================================================================
    // Basic get/set tests
    // ========================================================================

    @Test
    void testSetAndGet() {
        store.set("db.host", "localhost");

        String value = store.get("db.host");
        assertEquals("localhost", value);
    }

    @Test
    void testGetMissingKeyReturnsNull() {
        assertNull(store.get("nonexistent.key"));
    }

    @Test
    void testSetOverwritesExistingValue() {
        store.set("db.host", "localhost");
        store.set("db.host", "prod-db.example.com");

        assertEquals("prod-db.example.com", store.get("db.host"));
    }

    @Test
    void testSetEmptyValue() {
        store.set("empty.key", "");

        assertEquals("", store.get("empty.key"));
    }

    @Test
    void testSetValueWithSpecialCharacters() {
        store.set("jdbc.url", "jdbc:postgresql://host:5432/db?ssl=true&user=admin");

        assertEquals("jdbc:postgresql://host:5432/db?ssl=true&user=admin", store.get("jdbc.url"));
    }

    @Test
    void testSetValueWithUnicode() {
        store.set("greeting", "こんにちは世界");

        assertEquals("こんにちは世界", store.get("greeting"));
    }

    @Test
    void testKeyWithDots() {
        store.set("app.server.http.port", "8080");

        assertEquals("8080", store.get("app.server.http.port"));
    }

    // ========================================================================
    // Delete tests
    // ========================================================================

    @Test
    void testDeleteExistingKey() {
        store.set("db.host", "localhost");

        assertTrue(store.delete("db.host"));
        assertNull(store.get("db.host"));
    }

    @Test
    void testDeleteMissingKeyReturnsFalse() {
        assertFalse(store.delete("nonexistent.key"));
    }

    @Test
    void testDeleteDoesNotAffectOtherKeys() {
        store.set("db.host", "localhost");
        store.set("db.port", "5432");

        store.delete("db.host");

        assertNull(store.get("db.host"));
        assertEquals("5432", store.get("db.port"));
    }

    // ========================================================================
    // Batch operations
    // ========================================================================

    @Test
    void testSetBatch() {
        Map<String, String> entries = Map.of(
            "db.host", "localhost",
            "db.port", "5432",
            "db.name", "mydb"
        );

        store.setBatch(entries);

        assertEquals("localhost", store.get("db.host"));
        assertEquals("5432", store.get("db.port"));
        assertEquals("mydb", store.get("db.name"));
    }

    @Test
    void testSetBatchOverwritesExisting() {
        store.set("db.host", "old-host");

        store.setBatch(Map.of(
            "db.host", "new-host",
            "db.port", "5432"
        ));

        assertEquals("new-host", store.get("db.host"));
        assertEquals("5432", store.get("db.port"));
    }

    @Test
    void testSetBatchEmptyMap() {
        store.setBatch(Map.of());
        // Should not throw — no-op
    }

    // ========================================================================
    // Prefix queries
    // ========================================================================

    @Test
    void testKeysByPrefix() {
        store.set("db.host", "localhost");
        store.set("db.port", "5432");
        store.set("db.name", "mydb");
        store.set("app.name", "catalog");

        List<String> dbKeys = store.keysByPrefix("db.");

        assertEquals(3, dbKeys.size());
        assertTrue(dbKeys.containsAll(List.of("db.host", "db.port", "db.name")));
        assertFalse(dbKeys.contains("app.name"));
    }

    @Test
    void testKeysByPrefixNoMatches() {
        store.set("db.host", "localhost");

        List<String> keys = store.keysByPrefix("cache.");
        assertTrue(keys.isEmpty());
    }

    @Test
    void testGetByPrefix() {
        store.set("mail.host", "smtp.example.com");
        store.set("mail.port", "587");
        store.set("mail.from", "noreply@example.com");
        store.set("db.host", "localhost");

        Map<String, String> mailConfig = store.getByPrefix("mail.");

        assertEquals(3, mailConfig.size());
        assertEquals("smtp.example.com", mailConfig.get("mail.host"));
        assertEquals("587", mailConfig.get("mail.port"));
        assertEquals("noreply@example.com", mailConfig.get("mail.from"));
        assertFalse(mailConfig.containsKey("db.host"));
    }

    @Test
    void testGetByPrefixNoMatches() {
        store.set("db.host", "localhost");

        Map<String, String> result = store.getByPrefix("nonexistent.");
        assertTrue(result.isEmpty());
    }

    @Test
    void testPrefixWithRegexSpecialCharacters() {
        // The dot in "db." is a regex special character — must be escaped
        store.set("db.host", "localhost");
        store.set("dbahost", "should-not-match");

        List<String> keys = store.keysByPrefix("db.");

        assertEquals(1, keys.size());
        assertEquals("db.host", keys.getFirst());
    }

    // ========================================================================
    // Pub/sub (no-op for MongoDB standalone)
    // ========================================================================

    @Test
    void testPublishChangeDoesNotThrow() {
        // MongoDB standalone doesn't support pub/sub — should be a no-op
        assertDoesNotThrow(() -> store.publishChange("db.host"));
    }

    // ========================================================================
    // Create: storing key-value pairs
    // ========================================================================

    @Test
    void testCreateSingleKeyValue() {
        store.set("server.port", "8080");

        assertEquals(1, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
        assertEquals("8080", store.get("server.port"));
    }

    @Test
    void testCreateMultipleDistinctKeys() {
        store.set("db.host", "localhost");
        store.set("db.port", "5432");
        store.set("db.name", "catalog");
        store.set("db.username", "admin");
        store.set("db.password", "secret");

        assertEquals(5, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
        assertEquals("localhost", store.get("db.host"));
        assertEquals("5432", store.get("db.port"));
        assertEquals("catalog", store.get("db.name"));
        assertEquals("admin", store.get("db.username"));
        assertEquals("secret", store.get("db.password"));
    }

    @Test
    void testCreateWithNullValueThrowsOrStoresNull() {
        // Storing null is a valid edge case — MongoDB allows null fields
        store.set("nullable.key", null);

        // get() should return null (the stored null value)
        assertNull(store.get("nullable.key"));
    }

    @Test
    void testCreateWithVeryLongKey() {
        String longKey = "a.b.c.d.e.f.g.h.i.j.k.l.m.n.o.p.q.r.s.t.u.v.w.x.y.z."
            .repeat(10) + "final.key";
        store.set(longKey, "deep");

        assertEquals("deep", store.get(longKey));
    }

    @Test
    void testCreateWithMultilineValue() {
        String multiline = "line1\nline2\nline3\n\ttabbed";
        store.set("multiline.config", multiline);

        assertEquals(multiline, store.get("multiline.config"));
    }

    @Test
    void testCreateWithJsonValue() {
        String json = "{\"host\":\"localhost\",\"port\":5432,\"ssl\":true}";
        store.set("db.connection", json);

        assertEquals(json, store.get("db.connection"));
    }

    @Test
    void testCreateWithEqualsAndColonsInValue() {
        // Common in property file values
        store.set("jdbc.url", "jdbc:mysql://host:3306/db?useSSL=true&serverTimezone=UTC");

        assertEquals("jdbc:mysql://host:3306/db?useSSL=true&serverTimezone=UTC",
            store.get("jdbc.url"));
    }

    @Test
    void testCreateWithEmptyKey() {
        store.set("", "value-for-empty-key");

        assertEquals("value-for-empty-key", store.get(""));
    }

    @Test
    void testCreatePreservesWhitespace() {
        store.set("padded.value", "  leading and trailing spaces  ");

        assertEquals("  leading and trailing spaces  ", store.get("padded.value"));
    }

    @Test
    void testCreateWithPathLikeKey() {
        store.set("/opt/app/config/db.host", "localhost");

        assertEquals("localhost", store.get("/opt/app/config/db.host"));
    }

    // ========================================================================
    // Read: retrieving values
    // ========================================================================

    @Test
    void testReadNonexistentKeyReturnsNull() {
        store.set("exists", "yes");

        assertNull(store.get("does.not.exist"));
    }

    @Test
    void testReadAfterMultipleWrites() {
        // Verify that reading returns the latest value
        store.set("counter", "1");
        assertEquals("1", store.get("counter"));

        store.set("counter", "2");
        assertEquals("2", store.get("counter"));

        store.set("counter", "3");
        assertEquals("3", store.get("counter"));
    }

    @Test
    void testReadDoesNotModifyStore() {
        store.set("immutable.read", "original");

        // Read multiple times
        store.get("immutable.read");
        store.get("immutable.read");
        store.get("immutable.read");

        // Value unchanged, count unchanged
        assertEquals("original", store.get("immutable.read"));
        assertEquals(1, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    @Test
    void testReadDistinguishesSimilarKeys() {
        store.set("app.timeout", "30");
        store.set("app.timeoutMs", "30000");
        store.set("app.timeout.read", "5");

        assertEquals("30", store.get("app.timeout"));
        assertEquals("30000", store.get("app.timeoutMs"));
        assertEquals("5", store.get("app.timeout.read"));
    }

    @Test
    void testReadFromEmptyStore() {
        assertNull(store.get("anything"));
    }

    // ========================================================================
    // Update: overwriting existing values
    // ========================================================================

    @Test
    void testUpdateValueInPlace() {
        store.set("db.host", "localhost");
        store.set("db.host", "production-db.internal");

        assertEquals("production-db.internal", store.get("db.host"));
        // Should still be 1 document, not 2
        assertEquals(1, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    @Test
    void testUpdateToEmptyValue() {
        store.set("feature.flag", "enabled");
        store.set("feature.flag", "");

        assertEquals("", store.get("feature.flag"));
    }

    @Test
    void testUpdateToLongerValue() {
        store.set("description", "short");
        store.set("description", "a much longer value that replaces the short one");

        assertEquals("a much longer value that replaces the short one", store.get("description"));
    }

    @Test
    void testUpdateToShorterValue() {
        store.set("description", "a very long description that takes up space");
        store.set("description", "short");

        assertEquals("short", store.get("description"));
    }

    @Test
    void testUpdateDoesNotAffectOtherKeys() {
        store.set("key.a", "value-a");
        store.set("key.b", "value-b");
        store.set("key.c", "value-c");

        store.set("key.b", "updated-b");

        assertEquals("value-a", store.get("key.a"));
        assertEquals("updated-b", store.get("key.b"));
        assertEquals("value-c", store.get("key.c"));
    }

    @Test
    void testUpdateManyTimesInSuccession() {
        for (int i = 0; i < 100; i++) {
            store.set("rapid.update", "value-" + i);
        }

        assertEquals("value-99", store.get("rapid.update"));
        assertEquals(1, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    @Test
    void testUpdateViaBatchOverwritesSingle() {
        store.set("batch.key", "original");

        store.setBatch(Map.of("batch.key", "from-batch"));

        assertEquals("from-batch", store.get("batch.key"));
        assertEquals(1, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    @Test
    void testBatchUpdateMixedNewAndExisting() {
        store.set("existing.a", "old-a");
        store.set("existing.b", "old-b");

        store.setBatch(Map.of(
            "existing.a", "new-a",     // update
            "existing.b", "new-b",     // update
            "brand.new", "fresh"       // create
        ));

        assertEquals("new-a", store.get("existing.a"));
        assertEquals("new-b", store.get("existing.b"));
        assertEquals("fresh", store.get("brand.new"));
        assertEquals(3, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    // ========================================================================
    // Delete: removing values
    // ========================================================================

    @Test
    void testDeleteReducesCount() {
        store.set("a", "1");
        store.set("b", "2");
        store.set("c", "3");
        assertEquals(3, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());

        store.delete("b");
        assertEquals(2, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    @Test
    void testDeleteThenRecreate() {
        store.set("recycled", "first-life");
        store.delete("recycled");
        assertNull(store.get("recycled"));

        store.set("recycled", "second-life");
        assertEquals("second-life", store.get("recycled"));
    }

    @Test
    void testDeleteAllKeys() {
        store.set("a", "1");
        store.set("b", "2");
        store.set("c", "3");

        store.delete("a");
        store.delete("b");
        store.delete("c");

        assertEquals(0, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
        assertNull(store.get("a"));
        assertNull(store.get("b"));
        assertNull(store.get("c"));
    }

    @Test
    void testDeleteSameKeyTwice() {
        store.set("once", "value");

        assertTrue(store.delete("once"));
        assertFalse(store.delete("once")); // second delete returns false
    }

    @Test
    void testDeleteFromEmptyStore() {
        assertFalse(store.delete("ghost"));
    }

    @Test
    void testDeleteWithSimilarKeyNames() {
        store.set("app.timeout", "30");
        store.set("app.timeoutMs", "30000");

        store.delete("app.timeout");

        assertNull(store.get("app.timeout"));
        assertEquals("30000", store.get("app.timeoutMs")); // must survive
    }

    // ========================================================================
    // CRUD lifecycle: full create-read-update-delete sequences
    // ========================================================================

    @Test
    void testFullCrudLifecycle() {
        // Create
        store.set("lifecycle.key", "created");
        assertEquals("created", store.get("lifecycle.key"));

        // Read
        String value = store.get("lifecycle.key");
        assertEquals("created", value);

        // Update
        store.set("lifecycle.key", "updated");
        assertEquals("updated", store.get("lifecycle.key"));

        // Delete
        assertTrue(store.delete("lifecycle.key"));
        assertNull(store.get("lifecycle.key"));

        // Verify gone
        assertFalse(store.delete("lifecycle.key"));
    }

    @Test
    void testCrudWithBatchOperations() {
        // Batch create
        store.setBatch(Map.of(
            "batch.a", "1",
            "batch.b", "2",
            "batch.c", "3"
        ));

        // Read all via prefix
        Map<String, String> all = store.getByPrefix("batch.");
        assertEquals(3, all.size());

        // Update one via set
        store.set("batch.b", "updated");
        assertEquals("updated", store.get("batch.b"));

        // Delete one
        store.delete("batch.a");

        // Verify final state
        assertNull(store.get("batch.a"));
        assertEquals("updated", store.get("batch.b"));
        assertEquals("3", store.get("batch.c"));
        assertEquals(2, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    @Test
    void testSimulateConfigurationScenario() {
        // Simulate: scan exports constants to config store
        store.setBatch(Map.of(
            "com.example.AppConfig.DB_HOST", "localhost",
            "com.example.AppConfig.DB_PORT", "5432",
            "com.example.AppConfig.MAX_RETRIES", "3",
            "com.example.AppConfig.TIMEOUT_MS", "5000",
            "com.example.SecurityConfig.JWT_SECRET", "my-secret-key"
        ));

        // Verify all stored
        assertEquals(5, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());

        // Lookup individual values (as SiteConfigurationService would)
        assertEquals("localhost", store.get("com.example.AppConfig.DB_HOST"));
        assertEquals("5432", store.get("com.example.AppConfig.DB_PORT"));

        // Lookup by prefix (as ConfigurationExportService would)
        Map<String, String> appConfig = store.getByPrefix("com.example.AppConfig.");
        assertEquals(4, appConfig.size());
        assertFalse(appConfig.containsKey("com.example.SecurityConfig.JWT_SECRET"));

        // Update a value (as SiteConfigurationService.store() would)
        store.set("com.example.AppConfig.MAX_RETRIES", "5");
        assertEquals("5", store.get("com.example.AppConfig.MAX_RETRIES"));

        // Delete obsolete key
        store.delete("com.example.AppConfig.TIMEOUT_MS");
        assertEquals(4, database.getCollection(MongoConfigStore.COLLECTION_NAME).countDocuments());
    }

    // ========================================================================
    // Document structure verification
    // ========================================================================

    @Test
    void testDocumentStructure() {
        store.set("db.host", "localhost");

        Document doc = database.getCollection(MongoConfigStore.COLLECTION_NAME)
            .find(new Document("_id", "db.host"))
            .first();

        assertNotNull(doc);
        assertEquals("db.host", doc.getString("_id"));
        assertEquals("db.host", doc.getString("key"));
        assertEquals("localhost", doc.getString("value"));
    }

    @Test
    void testLargeValue() {
        String largeValue = "x".repeat(100_000);
        store.set("large.key", largeValue);

        assertEquals(largeValue, store.get("large.key"));
    }

    @Test
    void testManyKeys() {
        for (int i = 0; i < 500; i++) {
            store.set("bulk.key." + i, "value-" + i);
        }

        assertEquals("value-0", store.get("bulk.key.0"));
        assertEquals("value-499", store.get("bulk.key.499"));
        assertEquals(500, store.keysByPrefix("bulk.key.").size());
    }
}
