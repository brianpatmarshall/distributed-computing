package com.boeing.constcatalog.transformer;

import com.boeing.constcatalog.model.ConstantTarget;
import com.boeing.constcatalog.model.TransformationEntry;
import com.boeing.constcatalog.model.TransformationResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ConfigLookupTransformerTest {

    private ConfigLookupTransformer transformer;

    @TempDir
    Path tempDir;

    private Path backupsDir;

    @BeforeEach
    void setUp() {
        transformer = new ConfigLookupTransformer();
        backupsDir = tempDir.resolve("backups");
    }

    /**
     * Computes the path where the transformer writes the transformed file.
     */
    private Path outputPath(Path sourceFile) {
        Path abs = sourceFile.toAbsolutePath();
        return backupsDir.resolve(abs.getRoot().relativize(abs));
    }

    @Test
    void testReplacesStringConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class MyService {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("MyService.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "MyService", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookup(\"db.host\")"),
            "Expected config.lookup call, got:\n" + transformed);
    }

    @Test
    void testReplacesIntConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class ServerConfig {
                public static final int SSH_PORT = 22;

                public void connect() {
                    int port = SSH_PORT;
                }
            }
            """;

        Path javaFile = writeSource("ServerConfig.java", source);

        ConstantTarget target = new ConstantTarget(
            "SSH_PORT", "ssh.port", "22", "int", "ServerConfig", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupInt(\"ssh.port\""),
            "Expected config.lookupInt call, got:\n" + transformed);
    }

    @Test
    void testReplacesLongConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class TimeoutConfig {
                public static final long TIMEOUT_MS = 30000L;

                public void configure() {
                    long timeout = TIMEOUT_MS;
                }
            }
            """;

        Path javaFile = writeSource("TimeoutConfig.java", source);

        ConstantTarget target = new ConstantTarget(
            "TIMEOUT_MS", "timeout.ms", "30000", "long", "TimeoutConfig", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupLong(\"timeout.ms\""),
            "Expected config.lookupLong call, got:\n" + transformed);
    }

    @Test
    void testReplacesBooleanConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class FeatureFlags {
                public static final boolean DEBUG_ENABLED = true;

                public void check() {
                    boolean debug = DEBUG_ENABLED;
                }
            }
            """;

        Path javaFile = writeSource("FeatureFlags.java", source);

        ConstantTarget target = new ConstantTarget(
            "DEBUG_ENABLED", "debug.enabled", "true", "boolean", "FeatureFlags", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupBoolean(\"debug.enabled\""),
            "Expected config.lookupBoolean call, got:\n" + transformed);
    }

    @Test
    void testReplacesDoubleConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class MathConstants {
                public static final double RATE = 0.15;

                public void calculate() {
                    double r = RATE;
                }
            }
            """;

        Path javaFile = writeSource("MathConstants.java", source);

        ConstantTarget target = new ConstantTarget(
            "RATE", "rate", "0.15", "double", "MathConstants", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupDouble(\"rate\""),
            "Expected config.lookupDouble call, got:\n" + transformed);
    }

    @Test
    void testReplacesMultipleUsagesInSameFile() throws IOException {
        String source = """
            package com.example;

            public class MultiUsage {
                public static final String API_HOST = "api.example.com";
                public static final int API_PORT = 443;

                public void connect() {
                    String host = API_HOST;
                    int port = API_PORT;
                }
            }
            """;

        Path javaFile = writeSource("MultiUsage.java", source);

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("API_HOST", "api.host", "\"api.example.com\"", "String", "MultiUsage", 4),
            new ConstantTarget("API_PORT", "api.port", "443", "int", "MultiUsage", 5)
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, targets, backupsDir);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(2, transformed);

        String output = Files.readString(outputPath(javaFile));
        assertTrue(output.contains("config.lookup(\"api.host\")"));
        assertTrue(output.contains("config.lookupInt(\"api.port\""));
    }

    @Test
    void testDryRunDoesNotModifyFile() throws IOException {
        String source = """
            package com.example;

            public class DryRunTest {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("DryRunTest.java", source);
        String originalContent = Files.readString(javaFile);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "DryRunTest", 4
        );

        List<TransformationEntry> results = transformer.dryRun(javaFile, List.of(target));

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        // File should be unchanged
        String afterContent = Files.readString(javaFile);
        assertEquals(originalContent, afterContent, "Dry run should not modify the file");
    }

    @Test
    void testAddsConfigFieldIfMissing() throws IOException {
        String source = """
            package com.example;

            public class NoConfigField {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("NoConfigField.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "NoConfigField", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("@Autowired"),
            "Expected @Autowired annotation, got:\n" + transformed);
        assertTrue(transformed.contains("SiteConfigurationService config"),
            "Expected config field, got:\n" + transformed);
    }

    @Test
    void testSkipsAlreadyTransformedUsages() throws IOException {
        String source = """
            package com.example;

            public class AlreadyDone {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    // No usages of DB_HOST here
                    String host = "hardcoded";
                }
            }
            """;

        Path javaFile = writeSource("AlreadyDone.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "AlreadyDone", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.SKIPPED, results.getFirst().status());
    }

    @Test
    void testPreservesOriginalFileAsBackup() throws IOException {
        String source = """
            package com.example;

            public class BackupTest {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("BackupTest.java", source);
        String originalContent = Files.readString(javaFile);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "BackupTest", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        Path backupFile = Path.of(outputPath(javaFile) + ".orig");
        assertTrue(Files.exists(backupFile), "Backup file should exist in backups directory");

        String backupContent = Files.readString(backupFile);
        assertEquals(originalContent, backupContent, "Backup should contain original content");
    }

    @Test
    void testHandlesEnumConstantUsages() throws IOException {
        String source = """
            package com.example;

            public class EnumUser {
                public static final String ENV_MODE = "production";

                public void configure() {
                    String mode = ENV_MODE;
                }
            }
            """;

        Path javaFile = writeSource("EnumUser.java", source);

        ConstantTarget target = new ConstantTarget(
            "ENV_MODE", "env.mode", "\"production\"", "String", "EnumUser", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());
    }

    @Test
    void testChooseLookupMethod() {
        assertEquals("lookup", ConfigLookupTransformer.chooseLookupMethod("String"));
        assertEquals("lookup", ConfigLookupTransformer.chooseLookupMethod("java.lang.String"));
        assertEquals("lookupInt", ConfigLookupTransformer.chooseLookupMethod("int"));
        assertEquals("lookupInt", ConfigLookupTransformer.chooseLookupMethod("Integer"));
        assertEquals("lookupLong", ConfigLookupTransformer.chooseLookupMethod("long"));
        assertEquals("lookupLong", ConfigLookupTransformer.chooseLookupMethod("Long"));
        assertEquals("lookupBoolean", ConfigLookupTransformer.chooseLookupMethod("boolean"));
        assertEquals("lookupBoolean", ConfigLookupTransformer.chooseLookupMethod("Boolean"));
        assertEquals("lookupDouble", ConfigLookupTransformer.chooseLookupMethod("double"));
        assertEquals("lookupDouble", ConfigLookupTransformer.chooseLookupMethod("Double"));
        assertEquals("lookup", ConfigLookupTransformer.chooseLookupMethod("SomeOtherType"));
    }

    @Test
    void testDeriveConfigLookupCall() {
        ConstantTarget stringTarget = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "Config", 1
        );
        assertEquals("config.lookup(\"db.host\")", transformer.deriveConfigLookupCall(stringTarget));

        ConstantTarget intTarget = new ConstantTarget(
            "SSH_PORT", "ssh.port", "22", "int", "Config", 2
        );
        assertEquals("config.lookupInt(\"ssh.port\", 22)", transformer.deriveConfigLookupCall(intTarget));
    }

    // ========================================================================
    // Parameter getter replacement tests
    // ========================================================================

    @Test
    void testReplacesGetPropertyCall() throws IOException {
        String source = """
            package com.example;

            import java.util.Properties;

            public class DbService {
                private Properties props;

                public void connect() {
                    String host = props.getProperty("database.host");
                }
            }
            """;

        Path javaFile = writeSource("DbService.java", source);

        ConstantTarget target = new ConstantTarget(
            "database.host", "database.host", "", "String", "DbService", 9,
            ConstantTarget.SourceKind.PARAMETER
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookup(\"database.host\")"),
            "Expected config.lookup call, got:\n" + transformed);
        assertFalse(transformed.contains("getProperty"),
            "getProperty should be replaced");
    }

    @Test
    void testReplacesGetIntCall() throws IOException {
        String source = """
            package com.example;

            public class PortService {
                private Object config;

                public void setup() {
                    int port = config.getInt("server.port");
                }
            }
            """;

        Path javaFile = writeSource("PortService.java", source);

        ConstantTarget target = new ConstantTarget(
            "server.port", "server.port", "", "String", "PortService", 7,
            ConstantTarget.SourceKind.PARAMETER
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupInt(\"server.port\")"),
            "Expected config.lookupInt for getInt, got:\n" + transformed);
    }

    @Test
    void testReplacesGetBooleanCall() throws IOException {
        String source = """
            package com.example;

            public class FeatureService {
                private Object props;

                public boolean isEnabled() {
                    return props.getBoolean("feature.enabled");
                }
            }
            """;

        Path javaFile = writeSource("FeatureService.java", source);

        ConstantTarget target = new ConstantTarget(
            "feature.enabled", "feature.enabled", "", "String", "FeatureService", 7,
            ConstantTarget.SourceKind.PARAMETER
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupBoolean(\"feature.enabled\")"),
            "Expected config.lookupBoolean for getBoolean, got:\n" + transformed);
    }

    @Test
    void testReplacesGetLongCall() throws IOException {
        String source = """
            package com.example;

            public class TimeoutService {
                private Object config;

                public void configure() {
                    long timeout = config.getLong("request.timeout.ms");
                }
            }
            """;

        Path javaFile = writeSource("TimeoutService.java", source);

        ConstantTarget target = new ConstantTarget(
            "request.timeout.ms", "request.timeout.ms", "", "String", "TimeoutService", 7,
            ConstantTarget.SourceKind.PARAMETER
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupLong(\"request.timeout.ms\")"),
            "Expected config.lookupLong for getLong, got:\n" + transformed);
    }

    @Test
    void testReplacesGetDoubleCall() throws IOException {
        String source = """
            package com.example;

            public class RateService {
                private Object props;

                public double getRate() {
                    return props.getDouble("interest.rate");
                }
            }
            """;

        Path javaFile = writeSource("RateService.java", source);

        ConstantTarget target = new ConstantTarget(
            "interest.rate", "interest.rate", "", "String", "RateService", 7,
            ConstantTarget.SourceKind.PARAMETER
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupDouble(\"interest.rate\")"),
            "Expected config.lookupDouble for getDouble, got:\n" + transformed);
    }

    @Test
    void testReplacesGetStringCall() throws IOException {
        String source = """
            package com.example;

            public class MailService {
                private Object config;

                public String getHost() {
                    return config.getString("mail.smtp.host");
                }
            }
            """;

        Path javaFile = writeSource("MailService.java", source);

        ConstantTarget target = new ConstantTarget(
            "mail.smtp.host", "mail.smtp.host", "", "String", "MailService", 7,
            ConstantTarget.SourceKind.PARAMETER
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookup(\"mail.smtp.host\")"),
            "Expected config.lookup for getString, got:\n" + transformed);
    }

    @Test
    void testReplacesMultipleParameterGetters() throws IOException {
        String source = """
            package com.example;

            import java.util.Properties;

            public class MultiParamService {
                private Properties props;

                public void init() {
                    String host = props.getProperty("db.host");
                    String port = props.getProperty("db.port");
                    String name = props.getProperty("db.name");
                }
            }
            """;

        Path javaFile = writeSource("MultiParamService.java", source);

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("db.host", "db.host", "", "String", "MultiParamService", 9, ConstantTarget.SourceKind.PARAMETER),
            new ConstantTarget("db.port", "db.port", "", "String", "MultiParamService", 10, ConstantTarget.SourceKind.PARAMETER),
            new ConstantTarget("db.name", "db.name", "", "String", "MultiParamService", 11, ConstantTarget.SourceKind.PARAMETER)
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, targets, backupsDir);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(3, transformed);

        String output = Files.readString(outputPath(javaFile));
        assertTrue(output.contains("config.lookup(\"db.host\")"));
        assertTrue(output.contains("config.lookup(\"db.port\")"));
        assertTrue(output.contains("config.lookup(\"db.name\")"));
        assertFalse(output.contains("getProperty"));
    }

    @Test
    void testSkipsParameterNotFoundInFile() throws IOException {
        String source = """
            package com.example;

            public class NoParams {
                public void doWork() {
                    String x = "hardcoded";
                }
            }
            """;

        Path javaFile = writeSource("NoParams.java", source);

        ConstantTarget target = new ConstantTarget(
            "missing.param", "missing.param", "", "String", "NoParams", 5,
            ConstantTarget.SourceKind.PARAMETER
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.SKIPPED, results.getFirst().status());
    }

    // ========================================================================
    // Field access expression tests (ClassName.CONSTANT)
    // ========================================================================

    @Test
    void testReplacesQualifiedConstantReference() throws IOException {
        String source = """
            package com.example;

            public class Consumer {
                public void use() {
                    String host = AppConfig.DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("Consumer.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "AppConfig", 5
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookup(\"db.host\")"),
            "Expected config.lookup for FieldAccessExpr, got:\n" + transformed);
        assertFalse(transformed.contains("AppConfig.DB_HOST"),
            "Qualified reference should be replaced");
    }

    @Test
    void testReplacesMultipleQualifiedReferences() throws IOException {
        String source = """
            package com.example;

            public class Consumer {
                public void connect() {
                    String host = AppConfig.DB_HOST;
                    int port = AppConfig.DB_PORT;
                    boolean ssl = AppConfig.USE_SSL;
                }
            }
            """;

        Path javaFile = writeSource("Consumer.java", source);

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("DB_HOST", "db.host", "\"localhost\"", "String", "AppConfig", 5),
            new ConstantTarget("DB_PORT", "db.port", "5432", "int", "AppConfig", 6),
            new ConstantTarget("USE_SSL", "use.ssl", "true", "boolean", "AppConfig", 7)
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, targets, backupsDir);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(3, transformed);

        String output = Files.readString(outputPath(javaFile));
        assertTrue(output.contains("config.lookup(\"db.host\")"));
        assertTrue(output.contains("config.lookupInt(\"db.port\""));
        assertTrue(output.contains("config.lookupBoolean(\"use.ssl\""));
    }

    // ========================================================================
    // Mixed constants and parameters in same file
    // ========================================================================

    @Test
    void testMixedConstantsAndParameters() throws IOException {
        String source = """
            package com.example;

            import java.util.Properties;

            public class MixedService {
                public static final String API_KEY = "secret123";
                private Properties props;

                public void init() {
                    String key = API_KEY;
                    String host = props.getProperty("api.host");
                }
            }
            """;

        Path javaFile = writeSource("MixedService.java", source);

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("API_KEY", "api.key", "\"secret123\"", "String", "MixedService", 6),
            new ConstantTarget("api.host", "api.host", "", "String", "MixedService", 10,
                ConstantTarget.SourceKind.PARAMETER)
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, targets, backupsDir);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(2, transformed);

        String output = Files.readString(outputPath(javaFile));
        assertTrue(output.contains("config.lookup(\"api.key\")"),
            "Constant should be replaced");
        assertTrue(output.contains("config.lookup(\"api.host\")"),
            "Parameter getter should be replaced");
    }

    // ========================================================================
    // Import and field injection tests
    // ========================================================================

    @Test
    void testAddsImportsWhenTransformed() throws IOException {
        String source = """
            package com.example;

            public class ImportTest {
                public static final String HOST = "localhost";

                public void use() {
                    String h = HOST;
                }
            }
            """;

        Path javaFile = writeSource("ImportTest.java", source);

        ConstantTarget target = new ConstantTarget(
            "HOST", "host", "\"localhost\"", "String", "ImportTest", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("import org.springframework.beans.factory.annotation.Autowired"),
            "Should add Autowired import");
        assertTrue(transformed.contains("import com.boeing.constcatalog.backend.service.SiteConfigurationService"),
            "Should add SiteConfigurationService import");
    }

    @Test
    void testDoesNotDuplicateExistingImports() throws IOException {
        String source = """
            package com.example;

            import org.springframework.beans.factory.annotation.Autowired;
            import com.boeing.constcatalog.backend.service.SiteConfigurationService;

            public class HasImports {
                public static final String HOST = "localhost";

                public void use() {
                    String h = HOST;
                }
            }
            """;

        Path javaFile = writeSource("HasImports.java", source);

        ConstantTarget target = new ConstantTarget(
            "HOST", "host", "\"localhost\"", "String", "HasImports", 7
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        // Count occurrences — should be exactly 1 each
        int autowiredCount = countOccurrences(transformed, "import org.springframework.beans.factory.annotation.Autowired");
        int serviceCount = countOccurrences(transformed, "import com.boeing.constcatalog.backend.service.SiteConfigurationService");
        assertEquals(1, autowiredCount, "Should not duplicate Autowired import");
        assertEquals(1, serviceCount, "Should not duplicate SiteConfigurationService import");
    }

    @Test
    void testDoesNotAddConfigFieldWhenAlreadyPresent() throws IOException {
        String source = """
            package com.example;

            import org.springframework.beans.factory.annotation.Autowired;
            import com.boeing.constcatalog.backend.service.SiteConfigurationService;

            public class HasConfigField {
                public static final String HOST = "localhost";

                @Autowired
                private SiteConfigurationService config;

                public void use() {
                    String h = HOST;
                }
            }
            """;

        Path javaFile = writeSource("HasConfigField.java", source);

        ConstantTarget target = new ConstantTarget(
            "HOST", "host", "\"localhost\"", "String", "HasConfigField", 7
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        int configFieldCount = countOccurrences(transformed, "SiteConfigurationService config");
        assertEquals(1, configFieldCount, "Should not duplicate config field");
    }

    // ========================================================================
    // Same constant used multiple times in a file
    // ========================================================================

    @Test
    void testReplacesAllOccurrencesOfSameConstant() throws IOException {
        String source = """
            package com.example;

            public class MultiRef {
                public static final String DB_HOST = "localhost";

                public void method1() {
                    String a = DB_HOST;
                }

                public void method2() {
                    String b = DB_HOST;
                }

                public String method3() {
                    return DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("MultiRef.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "MultiRef", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        int lookupCount = countOccurrences(transformed, "config.lookup(\"db.host\")");
        assertEquals(3, lookupCount, "All 3 usages should be replaced");
        assertFalse(transformed.contains("= DB_HOST"), "No bare references should remain");
    }

    // ========================================================================
    // Default value in typed lookups
    // ========================================================================

    @Test
    void testIntLookupIncludesDefaultValue() throws IOException {
        String source = """
            package com.example;

            public class Defaults {
                public static final int MAX_RETRIES = 3;

                public void retry() {
                    int max = MAX_RETRIES;
                }
            }
            """;

        Path javaFile = writeSource("Defaults.java", source);

        ConstantTarget target = new ConstantTarget(
            "MAX_RETRIES", "max.retries", "3", "int", "Defaults", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupInt(\"max.retries\", 3)"),
            "Should include default value 3, got:\n" + transformed);
    }

    @Test
    void testLongLookupIncludesDefaultValue() throws IOException {
        String source = """
            package com.example;

            public class LongDefaults {
                public static final long CACHE_TTL = 60000L;

                public void configure() {
                    long ttl = CACHE_TTL;
                }
            }
            """;

        Path javaFile = writeSource("LongDefaults.java", source);

        ConstantTarget target = new ConstantTarget(
            "CACHE_TTL", "cache.ttl", "60000", "long", "LongDefaults", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupLong(\"cache.ttl\", 60000L)"),
            "Should include default value 60000L, got:\n" + transformed);
    }

    @Test
    void testBooleanLookupIncludesDefaultValue() throws IOException {
        String source = """
            package com.example;

            public class BoolDefaults {
                public static final boolean VERBOSE = false;

                public void check() {
                    boolean v = VERBOSE;
                }
            }
            """;

        Path javaFile = writeSource("BoolDefaults.java", source);

        ConstantTarget target = new ConstantTarget(
            "VERBOSE", "verbose", "false", "boolean", "BoolDefaults", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupBoolean(\"verbose\", false)"),
            "Should include default value false, got:\n" + transformed);
    }

    @Test
    void testDoubleLookupIncludesDefaultValue() throws IOException {
        String source = """
            package com.example;

            public class DoubleDefaults {
                public static final double TAX_RATE = 0.075;

                public void calculate() {
                    double r = TAX_RATE;
                }
            }
            """;

        Path javaFile = writeSource("DoubleDefaults.java", source);

        ConstantTarget target = new ConstantTarget(
            "TAX_RATE", "tax.rate", "0.075", "double", "DoubleDefaults", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupDouble(\"tax.rate\", 0.075)"),
            "Should include default value 0.075, got:\n" + transformed);
    }

    @Test
    void testStringLookupHasNoDefaultValue() throws IOException {
        String source = """
            package com.example;

            public class StringDefaults {
                public static final String URL = "https://example.com";

                public void fetch() {
                    String u = URL;
                }
            }
            """;

        Path javaFile = writeSource("StringDefaults.java", source);

        ConstantTarget target = new ConstantTarget(
            "URL", "url", "\"https://example.com\"", "String", "StringDefaults", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookup(\"url\")"),
            "String lookup should NOT include a default value, got:\n" + transformed);
        assertFalse(transformed.contains("config.lookup(\"url\","),
            "Should not have a second argument");
    }

    // ========================================================================
    // Edge cases
    // ========================================================================

    @Test
    void testEmptyTargetList() throws IOException {
        Path javaFile = writeSource("Empty.java", """
            package com.example;
            public class Empty {}
            """);

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(), backupsDir);
        assertTrue(results.isEmpty());
    }

    @Test
    void testUnparseableFile() throws IOException {
        Path javaFile = writeSource("Broken.java", """
            package com.example;
            public class Broken {
                this is not valid java
            """);

        ConstantTarget target = new ConstantTarget(
            "X", "x", "1", "int", "Broken", 3
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.FAILED, results.getFirst().status());
    }

    @Test
    void testConstantUsedInMethodArgument() throws IOException {
        String source = """
            package com.example;

            public class ArgUsage {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    createConnection(DB_HOST, 5432);
                }

                void createConnection(String host, int port) {}
            }
            """;

        Path javaFile = writeSource("ArgUsage.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "ArgUsage", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("createConnection(config.lookup(\"db.host\")"),
            "Usage in method argument should be replaced, got:\n" + transformed);
    }

    @Test
    void testConstantUsedInReturnStatement() throws IOException {
        String source = """
            package com.example;

            public class ReturnUsage {
                public static final String DEFAULT_HOST = "localhost";

                public String getHost() {
                    return DEFAULT_HOST;
                }
            }
            """;

        Path javaFile = writeSource("ReturnUsage.java", source);

        ConstantTarget target = new ConstantTarget(
            "DEFAULT_HOST", "default.host", "\"localhost\"", "String", "ReturnUsage", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("return config.lookup(\"default.host\")"),
            "Usage in return statement should be replaced, got:\n" + transformed);
    }

    @Test
    void testConstantUsedInStringConcatenation() throws IOException {
        String source = """
            package com.example;

            public class ConcatUsage {
                public static final String BASE_URL = "https://api.example.com";

                public String buildUrl(String path) {
                    return BASE_URL + "/" + path;
                }
            }
            """;

        Path javaFile = writeSource("ConcatUsage.java", source);

        ConstantTarget target = new ConstantTarget(
            "BASE_URL", "base.url", "\"https://api.example.com\"", "String", "ConcatUsage", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookup(\"base.url\")"),
            "Usage in concatenation should be replaced, got:\n" + transformed);
    }

    @Test
    void testConstantUsedInConditional() throws IOException {
        String source = """
            package com.example;

            public class ConditionUsage {
                public static final int MAX_RETRIES = 3;

                public boolean shouldRetry(int attempt) {
                    return attempt < MAX_RETRIES;
                }
            }
            """;

        Path javaFile = writeSource("ConditionUsage.java", source);

        ConstantTarget target = new ConstantTarget(
            "MAX_RETRIES", "max.retries", "3", "int", "ConditionUsage", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupInt(\"max.retries\", 3)"),
            "Usage in conditional should be replaced, got:\n" + transformed);
    }

    @Test
    void testDryRunConstantsAndParameters() throws IOException {
        String source = """
            package com.example;

            import java.util.Properties;

            public class DryRunMixed {
                public static final String API_KEY = "key123";
                private Properties props;

                public void init() {
                    String key = API_KEY;
                    String host = props.getProperty("api.host");
                }
            }
            """;

        Path javaFile = writeSource("DryRunMixed.java", source);

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("API_KEY", "api.key", "\"key123\"", "String", "DryRunMixed", 6),
            new ConstantTarget("api.host", "api.host", "", "String", "DryRunMixed", 10,
                ConstantTarget.SourceKind.PARAMETER)
        );

        List<TransformationEntry> results = transformer.dryRun(javaFile, targets);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(2, transformed, "Both constant and parameter should be detected in dry run");

        // File should not be modified
        String content = Files.readString(javaFile);
        assertTrue(content.contains("API_KEY"), "Dry run should not modify file");
        assertTrue(content.contains("getProperty"), "Dry run should not modify file");
    }

    @Test
    void testTransformProjectMultipleFiles() throws IOException {
        String source1 = """
            package com.example;

            public class ServiceA {
                public static final String HOST_A = "host-a";

                public void use() {
                    String h = HOST_A;
                }
            }
            """;

        String source2 = """
            package com.example;

            public class ServiceB {
                public static final int PORT_B = 9090;

                public void use() {
                    int p = PORT_B;
                }
            }
            """;

        Path file1 = writeSource("ServiceA.java", source1);
        Path file2 = writeSource("ServiceB.java", source2);

        Map<Path, List<ConstantTarget>> targetsByFile = Map.of(
            file1, List.of(new ConstantTarget("HOST_A", "host.a", "\"host-a\"", "String", "ServiceA", 4)),
            file2, List.of(new ConstantTarget("PORT_B", "port.b", "9090", "int", "ServiceB", 4))
        );

        TransformationResult result = transformer.transformProject(tempDir.toString(), targetsByFile);

        assertEquals(2, result.totalTransformed());
        assertEquals(0, result.totalSkipped());
        assertEquals(0, result.totalFailed());
    }

    // ========================================================================
    // Helpers
    // ========================================================================

    private int countOccurrences(String text, String substring) {
        int count = 0;
        int idx = 0;
        while ((idx = text.indexOf(substring, idx)) != -1) {
            count++;
            idx += substring.length();
        }
        return count;
    }

    private Path writeSource(String fileName, String content) throws IOException {
        Path file = tempDir.resolve(fileName);
        Files.writeString(file, content);
        return file;
    }
}
