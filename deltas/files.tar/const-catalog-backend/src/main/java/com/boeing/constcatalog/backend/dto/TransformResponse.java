package com.boeing.constcatalog.backend.dto;

import com.boeing.constcatalog.model.TransformationEntry;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Response payload containing transformation results.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Response containing code transformation results")
public class TransformResponse {

    @Schema(description = "Whether the transformation completed successfully", example = "true")
    private boolean success;

    @Schema(description = "Status message", example = "Transformed 12 constants across 5 files")
    private String message;

    @Schema(description = "Path to the transformed project")
    private String projectPath;

    @Schema(description = "When the transformation was performed")
    private LocalDateTime transformedAt;

    @Schema(description = "Whether this was a dry run (no files modified)")
    private boolean dryRun;

    @Schema(description = "Number of constants successfully transformed", example = "12")
    private long totalTransformed;

    @Schema(description = "Number of constants skipped", example = "3")
    private long totalSkipped;

    @Schema(description = "Number of constants that failed to transform", example = "1")
    private long totalFailed;

    @Schema(description = "Name of the git branch created with transformed files, if requested")
    private String branchName;

    @Schema(description = "Individual transformation entries")
    private List<EntryDto> entries;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Individual constant or parameter transformation result")
    public static class EntryDto {
        private String filePath;
        private String className;
        private String constantName;
        private String propertyKey;
        private String originalValue;
        private String originalType;
        private int lineNumber;
        private String status;
        private String message;

        @Schema(description = "Whether this entry is a CONSTANT or PARAMETER")
        private String sourceKind;

        @Schema(description = "Original file content before transformation")
        private String originalContent;

        @Schema(description = "Transformed file content after transformation")
        private String transformedContent;

        @Schema(description = "Path to the backup file (.java.orig)")
        private String backupFilePath;

        public static EntryDto from(TransformationEntry entry) {
            return EntryDto.builder()
                .filePath(entry.filePath())
                .className(entry.className())
                .constantName(entry.constantName())
                .propertyKey(entry.propertyKey())
                .originalValue(entry.originalValue())
                .originalType(entry.originalType())
                .lineNumber(entry.lineNumber())
                .status(entry.status().name())
                .message(entry.message())
                .sourceKind(entry.sourceKind().name())
                .backupFilePath(entry.backupFilePath())
                .build();
        }
    }
}
