package com.boeing.constcatalog.backend.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.neo4j.core.schema.RelationshipId;
import org.springframework.data.neo4j.core.schema.RelationshipProperties;
import org.springframework.data.neo4j.core.schema.TargetNode;

/*
 * Relationship properties in Neo4J allow us to annotate edges with data.
 * The USED_IN relationship between a Parameter and a File carries additional
 * context: where exactly in the file is it used, and what does the code look like?
 *
 * This "rich relationship" pattern is powerful for graph queries. We can ask
 * not just "what parameters does this file use?" but "show me the actual code
 * context where each parameter is accessed."
 *
 * The context field preserves the method call expression (e.g.,
 * "getProperty('database.host')") which helps developers understand
 * the usage pattern without opening the source file.
 */
@RelationshipProperties
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UsageRelationship {

    @RelationshipId
    private Long id;

    @TargetNode
    private FileNode file;

    private String className;
    private int lineNumber;
    private String context;

    /*
     * Factory method for creating a usage relationship from scan data.
     */
    public static UsageRelationship create(FileNode file, String className, int lineNumber, String context) {
        return UsageRelationship.builder()
            .file(file)
            .className(className)
            .lineNumber(lineNumber)
            .context(context)
            .build();
    }
}
