package com.boeing.constcatalog.transformer;

import com.boeing.constcatalog.model.ConstantTarget;
import com.boeing.constcatalog.model.TransformationEntry;
import com.boeing.constcatalog.model.TransformationResult;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MusketeerLogTest {

    @TempDir
    Path tempDir;

    @Test
    void testLogHasTitleAndSubtitle() {
        TransformationResult result = createResult(List.of(
            transformedEntry("DB_HOST", "db.host", "String", "AppConfig",
                "/src/AppConfig.java", 10)
        ));

        String log = MusketeerLog.generate(result, "ALL", "main-transform");

        assertTrue(log.contains("# The Musketeer Log"));
        assertTrue(log.contains("In the service of Louis XIII"));
    }

    @Test
    void testLogHasMetadata() {
        TransformationResult result = createResult(List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5)
        ));

        String log = MusketeerLog.generate(result, "CONSTANTS_ONLY", "main-transform");

        assertTrue(log.contains("**Project**"));
        assertTrue(log.contains("**Scope**"));
        assertTrue(log.contains("CONSTANTS_ONLY"));
        assertTrue(log.contains("**Branch**"));
        assertTrue(log.contains("`main-transform`"));
        assertTrue(log.contains("**Transformed**"));
    }

    @Test
    void testLogHasTableOfContents() {
        TransformationResult result = createResult(List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5),
            transformedEntry("PORT", "port", "int", "Server",
                "/src/Server.java", 8)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("## Table of Contents"));
        assertTrue(log.contains("Config.java"));
        assertTrue(log.contains("Server.java"));
    }

    @Test
    void testLogShowsBeforeAndAfterForStringConstant() {
        TransformationResult result = createResult(List.of(
            transformedEntry("DB_HOST", "db.host", "String", "AppConfig",
                "/src/AppConfig.java", 10)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("### Line 10: `DB_HOST`"));
        assertTrue(log.contains("**Before:**"));
        assertTrue(log.contains("AppConfig.DB_HOST"));
        assertTrue(log.contains("**After:**"));
        assertTrue(log.contains("config.lookup(\"db.host\")"));
    }

    @Test
    void testLogShowsBeforeAndAfterForIntConstant() {
        TransformationResult result = createResult(List.of(
            transformedEntry("MAX_RETRIES", "max.retries", "int", "Config",
                "/src/Config.java", 7)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("config.lookupInt(\"max.retries\""),
            "Should use lookupInt for int type, got:\n" + log);
    }

    @Test
    void testLogShowsBeforeAndAfterForLongConstant() {
        TransformationResult result = createResult(List.of(
            transformedEntry("TIMEOUT_MS", "timeout.ms", "long", "Config",
                "/src/Config.java", 8)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("config.lookupLong(\"timeout.ms\""));
    }

    @Test
    void testLogShowsBeforeAndAfterForBooleanConstant() {
        TransformationResult result = createResult(List.of(
            transformedEntry("DEBUG", "debug", "boolean", "Config",
                "/src/Config.java", 9)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("config.lookupBoolean(\"debug\""));
    }

    @Test
    void testLogShowsBeforeAndAfterForDoubleConstant() {
        TransformationResult result = createResult(List.of(
            transformedEntry("RATE", "rate", "double", "Config",
                "/src/Config.java", 10)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("config.lookupDouble(\"rate\""));
    }

    @Test
    void testLogShowsParameterReplacement() {
        TransformationEntry paramEntry = new TransformationEntry(
            "/src/DbService.java", "DbService", "database.host",
            "database.host", "", "String", 15,
            TransformationEntry.Status.TRANSFORMED,
            "Replaced with config.lookup(\"database.host\")",
            ConstantTarget.SourceKind.PARAMETER
        );

        TransformationResult result = createResult(List.of(paramEntry));

        String log = MusketeerLog.generate(result, "PARAMETERS_ONLY", null);

        assertTrue(log.contains("getProperty(\"database.host\")"),
            "Before should show getProperty call");
        assertTrue(log.contains("config.lookup(\"database.host\")"),
            "After should show config.lookup call");
    }

    @Test
    void testLogShowsRemovedConstant() {
        TransformationEntry removedEntry = new TransformationEntry(
            "/src/OldConfig.java", "OldConfig", "DEAD_HOST",
            "dead.host", "\"nowhere\"", "String", 4,
            TransformationEntry.Status.TRANSFORMED,
            "Removed unused constant 'DEAD_HOST'",
            ConstantTarget.SourceKind.CONSTANT
        );

        TransformationResult result = createResult(List.of(removedEntry));

        String log = MusketeerLog.generate(result, "REMOVE_UNUSED", null);

        assertTrue(log.contains("public static final String DEAD_HOST = \"nowhere\""),
            "Before should show the declaration");
        assertTrue(log.contains("// removed"),
            "After should show '// removed'");
    }

    @Test
    void testLogGroupsEntriesByFile() {
        TransformationResult result = createResult(List.of(
            transformedEntry("HOST", "host", "String", "DbConfig",
                "/src/DbConfig.java", 5),
            transformedEntry("PORT", "port", "int", "DbConfig",
                "/src/DbConfig.java", 6),
            transformedEntry("SMTP_HOST", "smtp.host", "String", "MailConfig",
                "/src/MailConfig.java", 4)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        // Should have separate sections for each file
        assertTrue(log.contains("## 1. DbConfig.java"));
        assertTrue(log.contains("## 2. MailConfig.java"));

        // DbConfig section should have 2 entries
        assertTrue(log.contains("2/2 changes"));

        // MailConfig section should have 1 entry
        assertTrue(log.contains("1/1 changes"));
    }

    @Test
    void testAppendixASkippedTransformations() {
        TransformationEntry skipped = TransformationEntry.skipped(
            new ConstantTarget("VERSION", "version", "\"1.0\"", "String", "Config", 3),
            "/src/Config.java",
            "Protected name 'VERSION' — not removed"
        );

        TransformationResult result = createResult(List.of(skipped));

        String log = MusketeerLog.generate(result, "REMOVE_UNUSED", null);

        assertTrue(log.contains("Appendix A: Skipped Transformations"));
        assertTrue(log.contains("not transformed"));
        assertTrue(log.contains("`Config.java`"));
        assertTrue(log.contains("`/src/Config.java`"));
        assertTrue(log.contains("`VERSION`"));
        assertTrue(log.contains("| 3 |"));
        assertTrue(log.contains("Protected name 'VERSION' — not removed"));
    }

    @Test
    void testAppendixBFailedTransformations() {
        TransformationEntry failed = TransformationEntry.failed(
            new ConstantTarget("USED_CONST", "used.const", "\"value\"", "String", "Service", 10),
            "/src/Service.java",
            "Removal would break compilation — 'USED_CONST' is still referenced in this file"
        );

        TransformationResult result = createResult(List.of(failed));

        String log = MusketeerLog.generate(result, "REMOVE_UNUSED", null);

        assertTrue(log.contains("Appendix B: Failed Transformations"));
        assertTrue(log.contains("failed"));
        assertTrue(log.contains("`Service.java`"));
        assertTrue(log.contains("`/src/Service.java`"));
        assertTrue(log.contains("`USED_CONST`"));
        assertTrue(log.contains("| 10 |"));
        assertTrue(log.contains("still referenced"));
    }

    @Test
    void testAppendixSkippedGroupedByFile() {
        List<TransformationEntry> entries = List.of(
            TransformationEntry.skipped(
                new ConstantTarget("A", "a", "\"1\"", "String", "Config", 5),
                "/src/Config.java", "No usages found"),
            TransformationEntry.skipped(
                new ConstantTarget("B", "b", "\"2\"", "String", "Config", 6),
                "/src/Config.java", "Protected name"),
            TransformationEntry.skipped(
                new ConstantTarget("C", "c", "\"3\"", "String", "Other", 10),
                "/src/Other.java", "Line mismatch")
        );

        TransformationResult result = createResult(entries);

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("Appendix A: Skipped Transformations"));
        // Should have subheadings for each file
        assertTrue(log.contains("### `Config.java`"));
        assertTrue(log.contains("### `Other.java`"));
        // Full paths shown
        assertTrue(log.contains("`/src/Config.java`"));
        assertTrue(log.contains("`/src/Other.java`"));
    }

    @Test
    void testNoAppendixWhenNoSkippedOrFailed() {
        TransformationResult result = createResult(List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertFalse(log.contains("Appendix A"));
        assertFalse(log.contains("Appendix B"));
    }

    @Test
    void testLogMixedTransformedSkippedFailed() {
        List<TransformationEntry> entries = List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5),
            TransformationEntry.skipped(
                new ConstantTarget("VERSION", "version", "\"1.0\"", "String", "Config", 6),
                "/src/Config.java", "Protected name"),
            TransformationEntry.failed(
                new ConstantTarget("USED", "used", "\"val\"", "String", "Config", 7),
                "/src/Config.java", "Still referenced")
        );

        TransformationResult result = createResult(entries);

        String log = MusketeerLog.generate(result, "ALL", "main-transform");

        assertTrue(log.contains("**Transformed** | 1"));
        assertTrue(log.contains("**Skipped** | 1"));
        assertTrue(log.contains("**Failed** | 1"));
        assertTrue(log.contains("Appendix A: Skipped Transformations"));
        assertTrue(log.contains("Appendix B: Failed Transformations"));
        assertTrue(log.contains("Protected name"));
        assertTrue(log.contains("Still referenced"));
    }

    @Test
    void testTableOfContentsIncludesAppendixLinks() {
        List<TransformationEntry> entries = List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5),
            TransformationEntry.skipped(
                new ConstantTarget("VER", "ver", "\"1\"", "String", "Config", 6),
                "/src/Config.java", "Protected"),
            TransformationEntry.failed(
                new ConstantTarget("X", "x", "\"y\"", "String", "Config", 7),
                "/src/Config.java", "Referenced")
        );

        TransformationResult result = createResult(entries);
        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("Appendix A: Skipped Transformations"));
        assertTrue(log.contains("Appendix B: Failed Transformations"));
        assertTrue(log.contains("1 entries"), "TOC should show count for skipped appendix");
    }

    @Test
    void testLogWritesToFile() throws IOException {
        TransformationResult result = createResult(List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5)
        ));

        Path logFile = tempDir.resolve("musketeer-test.md");
        MusketeerLog.writeLog(result, "ALL", "main-transform", logFile);

        assertTrue(Files.exists(logFile));
        String content = Files.readString(logFile);
        assertTrue(content.contains("The Musketeer Log"));
        assertTrue(content.contains("Config.java"));
    }

    @Test
    void testLogWithNoBranchName() {
        TransformationResult result = createResult(List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        // No branch row in metadata
        assertFalse(log.contains("**Branch**"));
    }

    @Test
    void testLogFooter() {
        TransformationResult result = createResult(List.of(
            transformedEntry("HOST", "host", "String", "Config",
                "/src/Config.java", 5)
        ));

        String log = MusketeerLog.generate(result, "ALL", null);

        assertTrue(log.contains("Generated by The Musketeer Log"));
    }

    // ========================================================================
    // Helpers
    // ========================================================================

    private TransformationResult createResult(List<TransformationEntry> entries) {
        return new TransformationResult("/test/project", LocalDateTime.now(), entries);
    }

    private TransformationEntry transformedEntry(String name, String key, String type,
                                                  String className, String filePath, int line) {
        return TransformationEntry.transformed(
            new ConstantTarget(name, key, "\"default\"", type, className, line),
            filePath
        );
    }
}
