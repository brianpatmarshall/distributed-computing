package com.boeing.constcatalog.transformer;

import com.boeing.constcatalog.model.ConstantTarget;
import com.boeing.constcatalog.model.TransformationEntry;
import com.boeing.constcatalog.model.TransformationResult;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests the git-based transformation workflow end-to-end.
 *
 * <p>Each test creates a temporary "project" with Java source files, initialises
 * a git repo, runs transformations in-place, and verifies that:
 * <ul>
 *   <li>The transform branch has the modified files</li>
 *   <li>The original branch has the untouched files</li>
 *   <li>The transformed files are valid Java (constants replaced/removed correctly)</li>
 *   <li>Git diff between branches shows exactly what changed</li>
 * </ul>
 *
 * <p>These tests use real git operations — they require git to be installed.
 */
class GitTransformWorkflowTest {

    private ConfigLookupTransformer transformer;
    private UnusedConstantRemover remover;

    @TempDir
    Path projectDir;

    @BeforeEach
    void setUp() throws Exception {
        transformer = new ConfigLookupTransformer();
        remover = new UnusedConstantRemover();
    }

    // ========================================================================
    // Helpers: git operations
    // ========================================================================

    private void gitInit() throws Exception {
        git("init");
        git("config", "user.email", "test@test.local");
        git("config", "user.name", "Test");
    }

    private void gitAddAll() throws Exception {
        git("add", "-A");
    }

    private void gitCommit(String message) throws Exception {
        git("commit", "-m", message);
    }

    private void gitCheckout(String branch) throws Exception {
        git("checkout", branch);
    }

    private void gitCheckoutNewBranch(String branch) throws Exception {
        git("checkout", "-b", branch);
    }

    private String gitCurrentBranch() throws Exception {
        return git("rev-parse", "--abbrev-ref", "HEAD").trim();
    }

    private String gitDiff(String from, String to) throws Exception {
        return git("diff", from + ".." + to);
    }

    private String gitLog() throws Exception {
        return git("log", "--oneline");
    }

    private String gitShow(String branchAndPath) throws Exception {
        return git("show", branchAndPath);
    }

    private boolean gitBranchExists(String branch) {
        try {
            git("rev-parse", "--verify", branch);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private String git(String... args) throws Exception {
        String[] command = new String[args.length + 1];
        command[0] = "git";
        System.arraycopy(args, 0, command, 1, args.length);
        ProcessBuilder pb = new ProcessBuilder(command)
            .directory(projectDir.toFile())
            .redirectErrorStream(true);
        Process p = pb.start();
        String output = new String(p.getInputStream().readAllBytes());
        int exit = p.waitFor();
        if (exit != 0) {
            throw new RuntimeException("git " + String.join(" ", args) + " failed: " + output);
        }
        return output;
    }

    private Path writeJava(String relativePath, String content) throws IOException {
        Path file = projectDir.resolve(relativePath);
        Files.createDirectories(file.getParent());
        Files.writeString(file, content);
        return file;
    }

    // ========================================================================
    // ConfigLookupTransformer in-place tests
    // ========================================================================

    @Test
    @DisplayName("Transform in-place: constant replaced on branch, original preserved")
    void transformInPlacePreservesOriginalOnMainBranch() throws Exception {
        // Setup: create project with a Java file
        String original = """
            package com.example;

            public class AppConfig {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;
        Path javaFile = writeJava("src/AppConfig.java", original);

        // Git init and commit
        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();

        // Create transform branch
        gitCheckoutNewBranch(mainBranch + "-transform");

        // Transform in-place
        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "AppConfig", 4
        );
        List<TransformationEntry> results = transformer.transformFileInPlace(javaFile, List.of(target));

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        // Verify transformed content on this branch
        String transformed = Files.readString(javaFile);
        assertTrue(transformed.contains("config.lookup(\"db.host\")"));
        assertFalse(transformed.contains("= DB_HOST"));

        // Commit and switch back
        gitAddAll();
        gitCommit("Transform constants to config lookups");
        gitCheckout(mainBranch);

        // Original is restored on main
        String restored = Files.readString(javaFile);
        assertTrue(restored.contains("DB_HOST"));
        assertTrue(restored.contains("\"localhost\""));
        assertFalse(restored.contains("config.lookup"));
    }

    @Test
    @DisplayName("Transform in-place: git diff shows the changes")
    void transformInPlaceShowsInGitDiff() throws Exception {
        Path javaFile = writeJava("src/Config.java", """
            package com.example;

            public class Config {
                public static final int SERVER_PORT = 8080;

                public int getPort() {
                    return SERVER_PORT;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();

        gitCheckoutNewBranch(mainBranch + "-transform");

        ConstantTarget target = new ConstantTarget(
            "SERVER_PORT", "server.port", "8080", "int", "Config", 4
        );
        transformer.transformFileInPlace(javaFile, List.of(target));

        gitAddAll();
        gitCommit("Transform constants");
        gitCheckout(mainBranch);

        // Git diff should show the transformation
        String diff = gitDiff(mainBranch, mainBranch + "-transform");
        assertFalse(diff.isBlank(), "Diff should not be empty");
        assertTrue(diff.contains("SERVER_PORT"), "Diff should mention the old constant");
        assertTrue(diff.contains("config.lookupInt"), "Diff should mention the new lookup");
    }

    @Test
    @DisplayName("Transform in-place: multiple files across directories")
    void transformInPlaceMultipleFiles() throws Exception {
        Path file1 = writeJava("src/main/java/com/example/DbConfig.java", """
            package com.example;

            public class DbConfig {
                public static final String DB_URL = "jdbc:mysql://localhost/mydb";

                public String getUrl() {
                    return DB_URL;
                }
            }
            """);

        Path file2 = writeJava("src/main/java/com/example/MailConfig.java", """
            package com.example;

            public class MailConfig {
                public static final String SMTP_HOST = "smtp.example.com";

                public String getHost() {
                    return SMTP_HOST;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();

        gitCheckoutNewBranch(mainBranch + "-transform");

        Map<Path, List<ConstantTarget>> targets = Map.of(
            file1, List.of(new ConstantTarget("DB_URL", "db.url", "\"jdbc:mysql://localhost/mydb\"", "String", "DbConfig", 4)),
            file2, List.of(new ConstantTarget("SMTP_HOST", "smtp.host", "\"smtp.example.com\"", "String", "MailConfig", 4))
        );

        TransformationResult result = transformer.transformProjectInPlace(projectDir.toString(), targets);
        assertEquals(2, result.totalTransformed());

        // Both files transformed
        assertTrue(Files.readString(file1).contains("config.lookup(\"db.url\")"));
        assertTrue(Files.readString(file2).contains("config.lookup(\"smtp.host\")"));

        gitAddAll();
        gitCommit("Transform constants");
        gitCheckout(mainBranch);

        // Both files restored on main
        assertTrue(Files.readString(file1).contains("DB_URL"));
        assertTrue(Files.readString(file2).contains("SMTP_HOST"));
    }

    @Test
    @DisplayName("Transform in-place: injects @Autowired config field and imports")
    void transformInPlaceInjectsConfigField() throws Exception {
        Path javaFile = writeJava("src/MyService.java", """
            package com.example;

            public class MyService {
                public static final String API_KEY = "secret123";

                public String getKey() {
                    return API_KEY;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        gitCheckoutNewBranch("main-transform");

        ConstantTarget target = new ConstantTarget(
            "API_KEY", "api.key", "\"secret123\"", "String", "MyService", 4
        );
        transformer.transformFileInPlace(javaFile, List.of(target));

        String transformed = Files.readString(javaFile);
        assertTrue(transformed.contains("@Autowired"));
        assertTrue(transformed.contains("SiteConfigurationService config"));
        assertTrue(transformed.contains("import org.springframework.beans.factory.annotation.Autowired"));
        assertTrue(transformed.contains("import com.boeing.constcatalog.backend.service.SiteConfigurationService"));
    }

    @Test
    @DisplayName("Transform in-place: parameter getter replacement")
    void transformInPlaceReplacesParameterGetters() throws Exception {
        Path javaFile = writeJava("src/DbService.java", """
            package com.example;

            import java.util.Properties;

            public class DbService {
                private Properties props;

                public void connect() {
                    String host = props.getProperty("database.host");
                    String port = props.getProperty("database.port");
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        gitCheckoutNewBranch("main-transform");

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("database.host", "database.host", "", "String", "DbService", 9, ConstantTarget.SourceKind.PARAMETER),
            new ConstantTarget("database.port", "database.port", "", "String", "DbService", 10, ConstantTarget.SourceKind.PARAMETER)
        );
        List<TransformationEntry> results = transformer.transformFileInPlace(javaFile, targets);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(2, transformed);

        String content = Files.readString(javaFile);
        assertTrue(content.contains("config.lookup(\"database.host\")"));
        assertTrue(content.contains("config.lookup(\"database.port\")"));
        assertFalse(content.contains("getProperty"));
    }

    @Test
    @DisplayName("Transform in-place: skips file with no usages")
    void transformInPlaceSkipsNoUsages() throws Exception {
        Path javaFile = writeJava("src/NoUsage.java", """
            package com.example;

            public class NoUsage {
                public static final String UNUSED = "value";

                public void doWork() {
                    System.out.println("no constant usage here");
                }
            }
            """);

        ConstantTarget target = new ConstantTarget(
            "UNUSED", "unused", "\"value\"", "String", "NoUsage", 4
        );

        List<TransformationEntry> results = transformer.transformFileInPlace(javaFile, List.of(target));

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.SKIPPED, results.getFirst().status());

        // File should be unchanged
        assertTrue(Files.readString(javaFile).contains("UNUSED"));
    }

    @Test
    @DisplayName("Transform in-place: type-aware lookup methods")
    void transformInPlaceUsesCorrectLookupMethods() throws Exception {
        Path javaFile = writeJava("src/TypedConfig.java", """
            package com.example;

            public class TypedConfig {
                public static final String HOST = "localhost";
                public static final int PORT = 8080;
                public static final long TIMEOUT = 30000L;
                public static final boolean DEBUG = true;
                public static final double RATE = 0.5;

                public void configure() {
                    String h = HOST;
                    int p = PORT;
                    long t = TIMEOUT;
                    boolean d = DEBUG;
                    double r = RATE;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        gitCheckoutNewBranch("main-transform");

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("HOST", "host", "\"localhost\"", "String", "TypedConfig", 4),
            new ConstantTarget("PORT", "port", "8080", "int", "TypedConfig", 5),
            new ConstantTarget("TIMEOUT", "timeout", "30000", "long", "TypedConfig", 6),
            new ConstantTarget("DEBUG", "debug", "true", "boolean", "TypedConfig", 7),
            new ConstantTarget("RATE", "rate", "0.5", "double", "TypedConfig", 8)
        );

        TransformationResult result = transformer.transformProjectInPlace(projectDir.toString(),
            Map.of(javaFile, targets));
        assertEquals(5, result.totalTransformed());

        String content = Files.readString(javaFile);
        assertTrue(content.contains("config.lookup(\"host\")"));
        assertTrue(content.contains("config.lookupInt(\"port\""));
        assertTrue(content.contains("config.lookupLong(\"timeout\""));
        assertTrue(content.contains("config.lookupBoolean(\"debug\""));
        assertTrue(content.contains("config.lookupDouble(\"rate\""));
    }

    // ========================================================================
    // UnusedConstantRemover in-place tests
    // ========================================================================

    @Test
    @DisplayName("Remove in-place: constant removed on branch, original preserved")
    void removeInPlacePreservesOriginalOnMainBranch() throws Exception {
        String original = """
            package com.example;

            public class OldConfig {
                public static final String DEAD_HOST = "nowhere";
                public static final String LIVE_HOST = "somewhere";

                public String getHost() {
                    return LIVE_HOST;
                }
            }
            """;
        Path javaFile = writeJava("src/OldConfig.java", original);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();

        gitCheckoutNewBranch(mainBranch + "-transform");

        ConstantTarget target = new ConstantTarget(
            "DEAD_HOST", "dead.host", "\"nowhere\"", "String", "OldConfig", 4
        );
        List<TransformationEntry> results = remover.removeFromFileInPlace(javaFile, List.of(target));

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        // DEAD_HOST removed, LIVE_HOST preserved
        String modified = Files.readString(javaFile);
        assertFalse(modified.contains("DEAD_HOST"));
        assertTrue(modified.contains("LIVE_HOST"));

        gitAddAll();
        gitCommit("Remove unused constants");
        gitCheckout(mainBranch);

        // Original is restored on main
        String restored = Files.readString(javaFile);
        assertTrue(restored.contains("DEAD_HOST"));
        assertTrue(restored.contains("LIVE_HOST"));
    }

    @Test
    @DisplayName("Remove in-place: multiple constants from multiple files")
    void removeInPlaceMultipleFiles() throws Exception {
        Path file1 = writeJava("src/ServiceA.java", """
            package com.example;

            public class ServiceA {
                public static final String OLD_URL = "http://old.example.com";
            }
            """);

        Path file2 = writeJava("src/ServiceB.java", """
            package com.example;

            public class ServiceB {
                public static final int OLD_PORT = 9999;
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        gitCheckoutNewBranch("main-transform");

        Map<Path, List<ConstantTarget>> targets = Map.of(
            file1, List.of(new ConstantTarget("OLD_URL", "old.url", "\"http://old.example.com\"", "String", "ServiceA", 4)),
            file2, List.of(new ConstantTarget("OLD_PORT", "old.port", "9999", "int", "ServiceB", 4))
        );

        TransformationResult result = remover.removeFromProjectInPlace(projectDir.toString(), targets);
        assertEquals(2, result.totalTransformed());

        assertFalse(Files.readString(file1).contains("OLD_URL"));
        assertFalse(Files.readString(file2).contains("OLD_PORT"));
    }

    @Test
    @DisplayName("Remove in-place: dangling reference prevents removal")
    void removeInPlaceDanglingReferencePreventsRemoval() throws Exception {
        Path javaFile = writeJava("src/Referenced.java", """
            package com.example;

            public class Referenced {
                public static final String USED_CONST = "important";

                public String getValue() {
                    return USED_CONST;
                }
            }
            """);

        ConstantTarget target = new ConstantTarget(
            "USED_CONST", "used.const", "\"important\"", "String", "Referenced", 4
        );

        List<TransformationEntry> results = remover.removeFromFileInPlace(javaFile, List.of(target));

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.FAILED, results.getFirst().status());
        assertTrue(results.getFirst().message().contains("still referenced"));

        // File should be unchanged
        assertTrue(Files.readString(javaFile).contains("USED_CONST"));
    }

    @Test
    @DisplayName("Remove in-place: mixed safe and unsafe removals")
    void removeInPlaceMixedSafeAndUnsafe() throws Exception {
        Path javaFile = writeJava("src/Mixed.java", """
            package com.example;

            public class Mixed {
                public static final String REFERENCED = "used";
                public static final String TRULY_DEAD = "unused";

                public String get() {
                    return REFERENCED;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        gitCheckoutNewBranch("main-transform");

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("REFERENCED", "referenced", "\"used\"", "String", "Mixed", 4),
            new ConstantTarget("TRULY_DEAD", "truly.dead", "\"unused\"", "String", "Mixed", 5)
        );

        List<TransformationEntry> results = remover.removeFromFileInPlace(javaFile, targets);

        TransformationEntry refEntry = results.stream()
            .filter(e -> e.constantName().equals("REFERENCED"))
            .findFirst().orElseThrow();
        assertEquals(TransformationEntry.Status.FAILED, refEntry.status());

        TransformationEntry deadEntry = results.stream()
            .filter(e -> e.constantName().equals("TRULY_DEAD"))
            .findFirst().orElseThrow();
        assertEquals(TransformationEntry.Status.TRANSFORMED, deadEntry.status());

        String content = Files.readString(javaFile);
        assertTrue(content.contains("REFERENCED"), "Referenced constant must survive");
        assertFalse(content.contains("TRULY_DEAD"), "Unused constant must be removed");
    }

    @Test
    @DisplayName("Remove in-place: protected names are skipped")
    void removeInPlaceProtectsLoggerAndVersion() throws Exception {
        Path javaFile = writeJava("src/Protected.java", """
            package com.example;

            import org.slf4j.Logger;
            import org.slf4j.LoggerFactory;

            public class Protected {
                public static final Logger LOG = LoggerFactory.getLogger(Protected.class);
                public static final String VERSION = "2.0";
                public static final String REMOVE_ME = "gone";
            }
            """);

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("LOG", "log", "", "Logger", "Protected", 7),
            new ConstantTarget("VERSION", "version", "\"2.0\"", "String", "Protected", 8),
            new ConstantTarget("REMOVE_ME", "remove.me", "\"gone\"", "String", "Protected", 9)
        );

        List<TransformationEntry> results = remover.removeFromFileInPlace(javaFile, targets);

        long skipped = results.stream().filter(e -> e.status() == TransformationEntry.Status.SKIPPED).count();
        long transformed = results.stream().filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED).count();
        assertEquals(2, skipped, "LOG and VERSION should be skipped");
        assertEquals(1, transformed, "REMOVE_ME should be removed");
    }

    // ========================================================================
    // Full git workflow: branch, transform, commit, verify both branches
    // ========================================================================

    @Test
    @DisplayName("Full workflow: git show reads transformed file from branch")
    void fullWorkflowGitShowReadsFromBranch() throws Exception {
        Path javaFile = writeJava("src/Config.java", """
            package com.example;

            public class Config {
                public static final String DB_HOST = "localhost";

                public void use() {
                    String h = DB_HOST;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();

        gitCheckoutNewBranch(mainBranch + "-transform");

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "Config", 4
        );
        transformer.transformFileInPlace(javaFile, List.of(target));
        gitAddAll();
        gitCommit("Transform constants");

        gitCheckout(mainBranch);

        // Read transformed file from the transform branch without checking it out
        String fromBranch = gitShow(mainBranch + "-transform:src/Config.java");
        assertTrue(fromBranch.contains("config.lookup(\"db.host\")"));
        assertFalse(fromBranch.contains("= DB_HOST"));

        // Read original file from main branch
        String fromMain = gitShow(mainBranch + ":src/Config.java");
        assertTrue(fromMain.contains("DB_HOST"));
        assertTrue(fromMain.contains("\"localhost\""));
    }

    @Test
    @DisplayName("Full workflow: non-git project gets initialised correctly")
    void fullWorkflowInitialisesNonGitProject() throws Exception {
        // No gitInit() — project is not a git repo
        writeJava("src/App.java", """
            package com.example;

            public class App {
                public static final String HOST = "localhost";
            }
            """);

        // Simulate what CodeTransformationService does
        assertFalse(gitBranchExists("main"));

        gitInit();
        // Create .gitignore
        Files.writeString(projectDir.resolve(".gitignore"), "target/\n*.class\n");
        gitAddAll();
        gitCommit("Pre-transform code");

        String mainBranch = gitCurrentBranch();

        // Verify initialisation
        assertTrue(gitBranchExists(mainBranch));
        String log = gitLog();
        assertTrue(log.contains("Pre-transform code"));
        assertTrue(Files.exists(projectDir.resolve(".gitignore")));
    }

    @Test
    @DisplayName("Full workflow: transform branch can be reused (delete and recreate)")
    void fullWorkflowReusesTransformBranch() throws Exception {
        Path javaFile = writeJava("src/Reuse.java", """
            package com.example;

            public class Reuse {
                public static final String FIRST = "1";
                public static final String SECOND = "2";

                public void use() {
                    String a = FIRST;
                    String b = SECOND;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();

        // First transform: remove FIRST
        gitCheckoutNewBranch(mainBranch + "-transform");
        ConstantTarget t1 = new ConstantTarget("FIRST", "first", "\"1\"", "String", "Reuse", 4);
        transformer.transformFileInPlace(javaFile, List.of(t1));
        gitAddAll();
        gitCommit("Transform round 1");
        gitCheckout(mainBranch);

        assertTrue(gitBranchExists(mainBranch + "-transform"));

        // Delete the transform branch for a fresh run
        git("branch", "-D", mainBranch + "-transform");
        assertFalse(gitBranchExists(mainBranch + "-transform"));

        // Second transform: remove SECOND
        gitCheckoutNewBranch(mainBranch + "-transform");
        ConstantTarget t2 = new ConstantTarget("SECOND", "second", "\"2\"", "String", "Reuse", 5);
        transformer.transformFileInPlace(javaFile, List.of(t2));
        gitAddAll();
        gitCommit("Transform round 2");
        gitCheckout(mainBranch);

        // Transform branch should have round 2 changes
        String fromBranch = gitShow(mainBranch + "-transform:src/Reuse.java");
        assertTrue(fromBranch.contains("config.lookup(\"second\")"));
    }

    @Test
    @DisplayName("Full workflow: realistic service class with multiple constants")
    void fullWorkflowRealisticService() throws Exception {
        Path javaFile = writeJava("src/main/java/com/example/UserService.java", """
            package com.example;

            public class UserService {
                public static final String DEFAULT_ROLE = "USER";
                public static final int MAX_LOGIN_ATTEMPTS = 5;

                public void init() {
                    String role = DEFAULT_ROLE;
                    int maxAttempts = MAX_LOGIN_ATTEMPTS;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();
        gitCheckoutNewBranch(mainBranch + "-transform");

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("DEFAULT_ROLE", "default.role", "\"USER\"", "String", "UserService", 4),
            new ConstantTarget("MAX_LOGIN_ATTEMPTS", "max.login.attempts", "5", "int", "UserService", 5)
        );

        List<TransformationEntry> results = transformer.transformFileInPlace(javaFile, targets);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(2, transformed);

        String content = Files.readString(javaFile);
        assertTrue(content.contains("config.lookup(\"default.role\")"));
        assertTrue(content.contains("config.lookupInt(\"max.login.attempts\""));
        assertFalse(content.contains("role = DEFAULT_ROLE"));
        assertFalse(content.contains("maxAttempts = MAX_LOGIN_ATTEMPTS"));
        assertTrue(content.contains("@Autowired"));

        gitAddAll();
        gitCommit("Transform constants");
        gitCheckout(mainBranch);

        // Original restored on main
        String original = Files.readString(javaFile);
        assertTrue(original.contains("DEFAULT_ROLE"));
        assertTrue(original.contains("MAX_LOGIN_ATTEMPTS"));
        assertFalse(original.contains("config.lookup"));
    }

    @Test
    @DisplayName("Full workflow: remove unused from realistic class")
    void fullWorkflowRemoveUnusedRealistic() throws Exception {
        Path javaFile = writeJava("src/main/java/com/example/LegacyConfig.java", """
            package com.example;

            public class LegacyConfig {
                public static final String OLD_HOST = "legacy.example.com";
                public static final int OLD_PORT = 9999;
                public static final String CURRENT_HOST = "current.example.com";

                public String getHost() {
                    return CURRENT_HOST;
                }
            }
            """);

        gitInit();
        gitAddAll();
        gitCommit("Pre-transform code");
        String mainBranch = gitCurrentBranch();
        gitCheckoutNewBranch(mainBranch + "-transform");

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("OLD_HOST", "old.host", "\"legacy.example.com\"", "String", "LegacyConfig", 4),
            new ConstantTarget("OLD_PORT", "old.port", "9999", "int", "LegacyConfig", 5),
            new ConstantTarget("CURRENT_HOST", "current.host", "\"current.example.com\"", "String", "LegacyConfig", 6)
        );

        List<TransformationEntry> results = remover.removeFromFileInPlace(javaFile, targets);

        // OLD_HOST and OLD_PORT should be removed (truly unused)
        // CURRENT_HOST should FAIL (still referenced in getHost())
        TransformationEntry oldHost = results.stream().filter(e -> e.constantName().equals("OLD_HOST")).findFirst().orElseThrow();
        TransformationEntry oldPort = results.stream().filter(e -> e.constantName().equals("OLD_PORT")).findFirst().orElseThrow();
        TransformationEntry currentHost = results.stream().filter(e -> e.constantName().equals("CURRENT_HOST")).findFirst().orElseThrow();

        assertEquals(TransformationEntry.Status.TRANSFORMED, oldHost.status());
        assertEquals(TransformationEntry.Status.TRANSFORMED, oldPort.status());
        assertEquals(TransformationEntry.Status.FAILED, currentHost.status());

        String content = Files.readString(javaFile);
        assertFalse(content.contains("OLD_HOST"));
        assertFalse(content.contains("OLD_PORT"));
        assertTrue(content.contains("CURRENT_HOST"), "Referenced constant must survive");
        assertTrue(content.contains("return CURRENT_HOST"));

        gitAddAll();
        gitCommit("Remove unused constants");
        gitCheckout(mainBranch);

        // All constants restored on main
        String restored = Files.readString(javaFile);
        assertTrue(restored.contains("OLD_HOST"));
        assertTrue(restored.contains("OLD_PORT"));
        assertTrue(restored.contains("CURRENT_HOST"));
    }
}
