package com.boeing.constcatalog.backend.service;

import com.boeing.constcatalog.backend.dto.ScanProgressEvent;
import com.boeing.constcatalog.backend.dto.ScanRequest;
import com.boeing.constcatalog.backend.dto.ScanResponse;
import com.boeing.constcatalog.scanner.ProjectScanner;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

/*
 * The ScanService orchestrates the complete scanning workflow. It bridges
 * the gap between the HTTP request and the core scanning logic, handling
 * validation, orchestration, and result transformation.
 *
 * Scanning is a two-phase process:
 * 1. Parse: Walk the filesystem, extract constants and parameters
 * 2. Populate: Transform results into graph nodes and persist
 *
 * We separate these concerns because parsing is CPU-bound (AST analysis)
 * while population is IO-bound (database writes). This separation enables
 * future optimizations like parallel parsing or batched inserts.
 */
@Service
@Slf4j
public class ScanService {

    private final GraphPopulatorService graphPopulator;
    private final ProjectScanner projectScanner;

    public ScanService(GraphPopulatorService graphPopulator) {
        this.graphPopulator = graphPopulator;
        this.projectScanner = new ProjectScanner();
    }

    /*
     * Entry point for project scanning. Validates the path, performs the scan,
     * populates the graph, and returns a summary of results.
     */
    public ScanResponse scanProject(ScanRequest request) {
        log.info("Starting scan for project: {}", request.getProjectPath());

        Path projectPath = Paths.get(request.getProjectPath()).toAbsolutePath();

        validateProjectPath(projectPath);

        try {
            LocalDateTime startTime = LocalDateTime.now();

            /*
             * Phase 1: Parse the project using core scanning logic.
             * This walks the filesystem and extracts structured data
             * from Java files and property files.
             */
            ProjectScanner.ScanResult scanResult = projectScanner.scan(projectPath);

            log.info("Scan complete. Found {} constants, {} parameters, {} param usages, {} constant usages",
                scanResult.constants().size(),
                scanResult.parameters().size(),
                scanResult.parameterUsages().size(),
                scanResult.constantUsages().size());

            /*
             * Phase 2: Populate the graph database.
             * This transforms the flat scan results into a rich graph
             * with nodes, relationships, and properties.
             */
            graphPopulator.populateGraph(
                projectPath.toString(),
                extractProjectName(projectPath),
                scanResult
            );

            LocalDateTime endTime = LocalDateTime.now();

            ProjectScanner.FileTypeStats coreStats = scanResult.fileTypeStats();
            ScanResponse.FileTypeStats fileTypeStats = ScanResponse.FileTypeStats.builder()
                .propertiesFiles(coreStats.propertiesFiles())
                .ymlFiles(coreStats.ymlFiles())
                .xmlFiles(coreStats.xmlFiles())
                .jsonFiles(coreStats.jsonFiles())
                .envFiles(coreStats.envFiles())
                .publicStaticFinals(coreStats.publicStaticFinals())
                .build();

            return ScanResponse.builder()
                .success(true)
                .projectPath(projectPath.toString())
                .projectName(extractProjectName(projectPath))
                .scannedAt(startTime)
                .javaFilesScanned(scanResult.javaFilesScanned())
                .propertyFilesScanned(scanResult.propertyFilesScanned())
                .constantsFound(scanResult.constants().size())
                .parametersFound(scanResult.parameters().size())
                .parameterUsagesFound(scanResult.parameterUsages().size())
                .constantUsagesFound(scanResult.constantUsages().size())
                .fileTypeStats(fileTypeStats)
                .message("Scan completed successfully")
                .build();

        } catch (IOException e) {
            log.error("Scan failed for project: {}", projectPath, e);
            return ScanResponse.builder()
                .success(false)
                .projectPath(projectPath.toString())
                .message("Scan failed: " + e.getMessage())
                .build();
        }
    }

    /**
     * Scans a project with SSE progress reporting.
     * Runs asynchronously so SSE events can stream while the scan processes.
     */
    @Async
    public void scanProjectWithProgress(ScanRequest request, SseEmitter emitter, ObjectMapper objectMapper) {
        Path projectPath = Paths.get(request.getProjectPath()).toAbsolutePath();

        try {
            validateProjectPath(projectPath);

            ProjectScanner.ScanProgressListener listener = (fileName, filePath, fileIndex, totalFiles,
                                                             constantsFound, parametersFound) -> {
                try {
                    ScanProgressEvent event = ScanProgressEvent.builder()
                        .eventType(ScanProgressEvent.EventType.FILE_PARSING)
                        .fileName(fileName)
                        .filePath(filePath)
                        .fileIndex(fileIndex)
                        .totalFiles(totalFiles)
                        .constantsFound(constantsFound)
                        .parametersFound(parametersFound)
                        .timestamp(LocalDateTime.now())
                        .build();

                    emitter.send(SseEmitter.event()
                        .name("progress")
                        .data(objectMapper.writeValueAsString(event)));
                } catch (Exception e) {
                    log.debug("Failed to send SSE event: {}", e.getMessage());
                }
            };

            ProjectScanner.ScanResult scanResult = projectScanner.scan(projectPath, listener);

            // Notify client that parsing is done and graph population is starting
            try {
                ScanProgressEvent graphEvent = ScanProgressEvent.builder()
                    .eventType(ScanProgressEvent.EventType.FILE_PARSED)
                    .fileName("Populating graph database...")
                    .fileIndex(scanResult.javaFilesScanned() + scanResult.propertyFilesScanned())
                    .totalFiles(scanResult.javaFilesScanned() + scanResult.propertyFilesScanned())
                    .constantsFound(scanResult.constants().size())
                    .parametersFound(scanResult.parameters().size())
                    .timestamp(LocalDateTime.now())
                    .build();
                emitter.send(SseEmitter.event()
                    .name("progress")
                    .data(objectMapper.writeValueAsString(graphEvent)));
            } catch (Exception e) {
                log.debug("Failed to send graph population event: {}", e.getMessage());
            }

            graphPopulator.populateGraph(
                projectPath.toString(),
                extractProjectName(projectPath),
                scanResult
            );

            // Send completion event
            ScanProgressEvent completeEvent = ScanProgressEvent.builder()
                .eventType(ScanProgressEvent.EventType.SCAN_COMPLETE)
                .constantsFound(scanResult.constants().size())
                .parametersFound(scanResult.parameters().size())
                .totalFiles(scanResult.javaFilesScanned() + scanResult.propertyFilesScanned())
                .fileIndex(scanResult.javaFilesScanned() + scanResult.propertyFilesScanned())
                .timestamp(LocalDateTime.now())
                .build();

            emitter.send(SseEmitter.event()
                .name("complete")
                .data(objectMapper.writeValueAsString(completeEvent)));
            emitter.complete();

        } catch (Exception e) {
            log.error("SSE scan failed for project: {}", projectPath, e);
            try {
                ScanProgressEvent errorEvent = ScanProgressEvent.builder()
                    .eventType(ScanProgressEvent.EventType.ERROR)
                    .timestamp(LocalDateTime.now())
                    .build();
                emitter.send(SseEmitter.event()
                    .name("error")
                    .data(objectMapper.writeValueAsString(errorEvent)));
            } catch (Exception ex) {
                log.debug("Failed to send error event: {}", ex.getMessage());
            }
            emitter.completeWithError(e);
        }
    }

    private void validateProjectPath(Path projectPath) {
        if (!Files.exists(projectPath)) {
            throw new IllegalArgumentException("Project path does not exist: " + projectPath);
        }
        if (!Files.isDirectory(projectPath)) {
            throw new IllegalArgumentException("Project path is not a directory: " + projectPath);
        }
    }

    private String extractProjectName(Path projectPath) {
        return projectPath.getFileName().toString();
    }
}
