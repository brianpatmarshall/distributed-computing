package com.boeing.constcatalog.backend.config;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.neo4j.driver.AuthTokens;
import org.neo4j.driver.Driver;
import org.neo4j.driver.GraphDatabase;
import org.neo4j.driver.Session;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/*
 * Neo4J configuration for Spring Data Neo4J.
 *
 * This configuration establishes the connection to the Neo4J database
 * and enables repository scanning for @Repository annotated interfaces.
 *
 * Connection parameters are externalized to application.yml and can be
 * overridden via environment variables for deployment flexibility.
 *
 * We only define the Driver bean here - Spring Boot auto-configures
 * the rest (Neo4jClient, Neo4jTemplate, TransactionManager).
 */
@Configuration
@EnableNeo4jRepositories(basePackages = "com.boeing.constcatalog.backend.repository")
@EnableTransactionManagement
@Slf4j
public class Neo4jConfig {

    @Value("${spring.neo4j.uri:bolt://localhost:7687}")
    private String uri;

    @Value("${spring.neo4j.authentication.username:}")
    private String username;

    @Value("${spring.neo4j.authentication.password:}")
    private String password;

    /*
     * Create the Neo4J driver bean. This is the low-level connection
     * that Spring Data Neo4J uses for all database operations.
     *
     * Authentication is optional - if no username is provided, we
     * connect without authentication (suitable for local development
     * with NEO4J_AUTH=none).
     */
    @Bean
    public Driver neo4jDriver() {
        if (username != null && !username.isEmpty()) {
            return GraphDatabase.driver(uri, AuthTokens.basic(username, password));
        } else {
            return GraphDatabase.driver(uri, AuthTokens.none());
        }
    }

    /**
     * Creates Neo4j indexes at startup for faster queries.
     * Uses IF NOT EXISTS so it's safe to run repeatedly.
     * Runs as a separate bean init method to avoid circular reference with the Driver bean.
     */
    @Bean
    public IndexCreator neo4jIndexCreator(Driver driver) {
        return new IndexCreator(driver);
    }

    static class IndexCreator {
        IndexCreator(Driver driver) {
            try (Session session = driver.session()) {
                String[] indexes = {
                    "CREATE INDEX IF NOT EXISTS FOR (c:Constant) ON (c.name)",
                    "CREATE INDEX IF NOT EXISTS FOR (c:Constant) ON (c.className)",
                    "CREATE INDEX IF NOT EXISTS FOR (c:Constant) ON (c.accessModifier)",
                    "CREATE INDEX IF NOT EXISTS FOR (f:File) ON (f.path)",
                    "CREATE INDEX IF NOT EXISTS FOR (f:File) ON (f.fileName)",
                    "CREATE INDEX IF NOT EXISTS FOR (p:Parameter) ON (p.name)",
                    "CREATE INDEX IF NOT EXISTS FOR (pr:Project) ON (pr.rootPath)",
                };
                for (String index : indexes) {
                    session.run(index);
                }
                log.info("Neo4j indexes created/verified ({} indexes)", indexes.length);
            } catch (Exception e) {
                log.warn("Failed to create Neo4j indexes: {}", e.getMessage());
            }
        }
    }
}
