#!/bin/sh
# Ensure the backups and logs directories exist and are writable.
# The volume mount from docker-compose may create them as root,
# so this script runs as root, fixes permissions, then drops to appuser.
mkdir -p /app/backups /app/logs
chown appuser:appgroup /app/backups /app/logs

JAVA_BIN=$(which java || echo /opt/java/openjdk/bin/java)
exec su -s /bin/sh appuser -c "PATH=/opt/java/openjdk/bin:$PATH $JAVA_BIN -jar /app/app.jar $*"
