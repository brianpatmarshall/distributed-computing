package com.boeing.constcatalog.backend.store;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.junit.jupiter.api.*;
import org.testcontainers.containers.MongoDBContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for {@link MongoConfigStore} using Testcontainers.
 *
 * <p>A real MongoDB instance is started in a Docker container for each test class run.
 * Each test method gets a clean collection via {@link #clearCollection()}.
 */
@Testcontainers
class MongoConfigStoreTest {

    @Container
    static MongoDBContainer mongoContainer = new MongoDBContainer("mongo:7");

    static MongoClient mongoClient;
    static MongoDatabase database;
    MongoConfigStore store;

    @BeforeAll
    static void startMongo() {
        mongoClient = MongoClients.create(mongoContainer.getConnectionString());
        database = mongoClient.getDatabase("test-config");
    }

    @AfterAll
    static void stopMongo() {
        if (mongoClient != null) mongoClient.close();
    }

    @BeforeEach
    void setUp() {
        store = new MongoConfigStore(database);
        clearCollection();
    }

    void clearCollection() {
        database.getCollection(MongoConfigStore.COLLECTION_NAME).drop();
    }

    // ========================================================================
    // Connection tests
    // ========================================================================

    @Test
    void testMongoContainerIsRunning() {
        assertTrue(mongoContainer.isRunning());
    }

    @Test
    void testCanConnectToMongo() {
        // Verify the connection works by running a ping
        Document result = database.runCommand(new Document("ping", 1));
        assertEquals(1.0, result.getDouble("ok"));
    }

    @Test
    void testStoreNameIsMongoDB() {
        assertEquals("MongoDB", store.storeName());
    }

    // ========================================================================
    // Basic get/set tests
    // ========================================================================

    @Test
    void testSetAndGet() {
        store.set("db.host", "localhost");

        String value = store.get("db.host");
        assertEquals("localhost", value);
    }

    @Test
    void testGetMissingKeyReturnsNull() {
        assertNull(store.get("nonexistent.key"));
    }

    @Test
    void testSetOverwritesExistingValue() {
        store.set("db.host", "localhost");
        store.set("db.host", "prod-db.example.com");

        assertEquals("prod-db.example.com", store.get("db.host"));
    }

    @Test
    void testSetEmptyValue() {
        store.set("empty.key", "");

        assertEquals("", store.get("empty.key"));
    }

    @Test
    void testSetValueWithSpecialCharacters() {
        store.set("jdbc.url", "jdbc:postgresql://host:5432/db?ssl=true&user=admin");

        assertEquals("jdbc:postgresql://host:5432/db?ssl=true&user=admin", store.get("jdbc.url"));
    }

    @Test
    void testSetValueWithUnicode() {
        store.set("greeting", "こんにちは世界");

        assertEquals("こんにちは世界", store.get("greeting"));
    }

    @Test
    void testKeyWithDots() {
        store.set("app.server.http.port", "8080");

        assertEquals("8080", store.get("app.server.http.port"));
    }

    // ========================================================================
    // Delete tests
    // ========================================================================

    @Test
    void testDeleteExistingKey() {
        store.set("db.host", "localhost");

        assertTrue(store.delete("db.host"));
        assertNull(store.get("db.host"));
    }

    @Test
    void testDeleteMissingKeyReturnsFalse() {
        assertFalse(store.delete("nonexistent.key"));
    }

    @Test
    void testDeleteDoesNotAffectOtherKeys() {
        store.set("db.host", "localhost");
        store.set("db.port", "5432");

        store.delete("db.host");

        assertNull(store.get("db.host"));
        assertEquals("5432", store.get("db.port"));
    }

    // ========================================================================
    // Batch operations
    // ========================================================================

    @Test
    void testSetBatch() {
        Map<String, String> entries = Map.of(
            "db.host", "localhost",
            "db.port", "5432",
            "db.name", "mydb"
        );

        store.setBatch(entries);

        assertEquals("localhost", store.get("db.host"));
        assertEquals("5432", store.get("db.port"));
        assertEquals("mydb", store.get("db.name"));
    }

    @Test
    void testSetBatchOverwritesExisting() {
        store.set("db.host", "old-host");

        store.setBatch(Map.of(
            "db.host", "new-host",
            "db.port", "5432"
        ));

        assertEquals("new-host", store.get("db.host"));
        assertEquals("5432", store.get("db.port"));
    }

    @Test
    void testSetBatchEmptyMap() {
        store.setBatch(Map.of());
        // Should not throw — no-op
    }

    // ========================================================================
    // Prefix queries
    // ========================================================================

    @Test
    void testKeysByPrefix() {
        store.set("db.host", "localhost");
        store.set("db.port", "5432");
        store.set("db.name", "mydb");
        store.set("app.name", "catalog");

        List<String> dbKeys = store.keysByPrefix("db.");

        assertEquals(3, dbKeys.size());
        assertTrue(dbKeys.containsAll(List.of("db.host", "db.port", "db.name")));
        assertFalse(dbKeys.contains("app.name"));
    }

    @Test
    void testKeysByPrefixNoMatches() {
        store.set("db.host", "localhost");

        List<String> keys = store.keysByPrefix("cache.");
        assertTrue(keys.isEmpty());
    }

    @Test
    void testGetByPrefix() {
        store.set("mail.host", "smtp.example.com");
        store.set("mail.port", "587");
        store.set("mail.from", "noreply@example.com");
        store.set("db.host", "localhost");

        Map<String, String> mailConfig = store.getByPrefix("mail.");

        assertEquals(3, mailConfig.size());
        assertEquals("smtp.example.com", mailConfig.get("mail.host"));
        assertEquals("587", mailConfig.get("mail.port"));
        assertEquals("noreply@example.com", mailConfig.get("mail.from"));
        assertFalse(mailConfig.containsKey("db.host"));
    }

    @Test
    void testGetByPrefixNoMatches() {
        store.set("db.host", "localhost");

        Map<String, String> result = store.getByPrefix("nonexistent.");
        assertTrue(result.isEmpty());
    }

    @Test
    void testPrefixWithRegexSpecialCharacters() {
        // The dot in "db." is a regex special character — must be escaped
        store.set("db.host", "localhost");
        store.set("dbahost", "should-not-match");

        List<String> keys = store.keysByPrefix("db.");

        assertEquals(1, keys.size());
        assertEquals("db.host", keys.getFirst());
    }

    // ========================================================================
    // Pub/sub (no-op for MongoDB standalone)
    // ========================================================================

    @Test
    void testPublishChangeDoesNotThrow() {
        // MongoDB standalone doesn't support pub/sub — should be a no-op
        assertDoesNotThrow(() -> store.publishChange("db.host"));
    }

    // ========================================================================
    // Document structure verification
    // ========================================================================

    @Test
    void testDocumentStructure() {
        store.set("db.host", "localhost");

        Document doc = database.getCollection(MongoConfigStore.COLLECTION_NAME)
            .find(new Document("_id", "db.host"))
            .first();

        assertNotNull(doc);
        assertEquals("db.host", doc.getString("_id"));
        assertEquals("db.host", doc.getString("key"));
        assertEquals("localhost", doc.getString("value"));
    }

    @Test
    void testLargeValue() {
        String largeValue = "x".repeat(100_000);
        store.set("large.key", largeValue);

        assertEquals(largeValue, store.get("large.key"));
    }

    @Test
    void testManyKeys() {
        for (int i = 0; i < 500; i++) {
            store.set("bulk.key." + i, "value-" + i);
        }

        assertEquals("value-0", store.get("bulk.key.0"));
        assertEquals("value-499", store.get("bulk.key.499"));
        assertEquals(500, store.keysByPrefix("bulk.key.").size());
    }
}
