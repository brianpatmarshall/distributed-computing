package com.boeing.constcatalog.backend.store;

import com.boeing.constcatalog.backend.config.ValKeyConfig;
import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import org.junit.jupiter.api.*;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for {@link ValKeyConfigStore}.
 *
 * <p>Requires a running ValKey/Redis instance on localhost:6379.
 * Start with: {@code docker compose up -d valkey}
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ValKeyConfigStoreTest {

    RedisClient client;
    StatefulRedisConnection<String, String> connection;
    StatefulRedisPubSubConnection<String, String> pubSubConnection;
    ValKeyConfigStore store;

    @BeforeAll
    void startRedis() {
        try {
            client = RedisClient.create(RedisURI.builder()
                .withHost("localhost").withPort(6379).build());
            connection = client.connect();
            pubSubConnection = client.connectPubSub();
            store = new ValKeyConfigStore(connection, pubSubConnection);
        } catch (Exception e) {
            Assumptions.assumeTrue(false,
                "ValKey/Redis not available on localhost:6379 — skipping. Start with: docker compose up -d valkey");
        }
    }

    @AfterAll
    void stopRedis() {
        if (pubSubConnection != null) pubSubConnection.close();
        if (connection != null) connection.close();
        if (client != null) client.shutdown();
    }

    @BeforeEach
    void clearTestKeys() {
        if (connection == null) return;
        RedisCommands<String, String> cmd = connection.sync();
        List<String> keys = cmd.keys(ValKeyConfig.CONFIG_KEY_PREFIX + "test.*");
        if (!keys.isEmpty()) cmd.del(keys.toArray(new String[0]));
    }

    @Test
    void testStoreNameIsValKey() {
        assertEquals("ValKey", store.storeName());
    }

    @Test
    void testSetAndGet() {
        store.set("test.host", "localhost");
        assertEquals("localhost", store.get("test.host"));
    }

    @Test
    void testGetMissingReturnsNull() {
        assertNull(store.get("test.nonexistent"));
    }

    @Test
    void testDelete() {
        store.set("test.delete.me", "value");
        assertTrue(store.delete("test.delete.me"));
        assertNull(store.get("test.delete.me"));
    }

    @Test
    void testDeleteMissingReturnsFalse() {
        assertFalse(store.delete("test.does.not.exist"));
    }

    @Test
    void testSetBatch() {
        store.setBatch(Map.of(
            "test.batch.a", "1",
            "test.batch.b", "2"
        ));

        assertEquals("1", store.get("test.batch.a"));
        assertEquals("2", store.get("test.batch.b"));
    }

    @Test
    void testKeysByPrefix() {
        store.set("test.prefix.a", "1");
        store.set("test.prefix.b", "2");
        store.set("test.other.c", "3");

        List<String> keys = store.keysByPrefix("test.prefix.");

        assertEquals(2, keys.size());
        assertTrue(keys.containsAll(List.of("test.prefix.a", "test.prefix.b")));
    }

    @Test
    void testGetByPrefix() {
        store.set("test.byprefix.x", "10");
        store.set("test.byprefix.y", "20");

        Map<String, String> result = store.getByPrefix("test.byprefix.");

        assertEquals(2, result.size());
        assertEquals("10", result.get("test.byprefix.x"));
        assertEquals("20", result.get("test.byprefix.y"));
    }

    @Test
    void testPublishChangeDoesNotThrow() {
        assertDoesNotThrow(() -> store.publishChange("test.key"));
    }
}
