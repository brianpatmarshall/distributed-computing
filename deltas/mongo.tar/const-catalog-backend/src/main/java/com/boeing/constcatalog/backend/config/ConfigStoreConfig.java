package com.boeing.constcatalog.backend.config;

import com.boeing.constcatalog.backend.store.ConfigStore;
import com.boeing.constcatalog.backend.store.MongoConfigStore;
import com.boeing.constcatalog.backend.store.ValKeyConfigStore;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configures the {@link ConfigStore} implementation based on the
 * {@code config.store.type} property.
 *
 * <ul>
 *   <li>{@code config.store.type=valkey} (default) — uses ValKey/Redis</li>
 *   <li>{@code config.store.type=mongodb} — uses MongoDB</li>
 * </ul>
 */
@Configuration
@Slf4j
public class ConfigStoreConfig {

    @Bean
    @ConditionalOnProperty(name = "config.store.type", havingValue = "valkey", matchIfMissing = true)
    public ConfigStore valKeyConfigStore(
            @Qualifier("redisConnection") StatefulRedisConnection<String, String> redisConnection,
            StatefulRedisPubSubConnection<String, String> pubSubConnection) {
        log.info("Using ValKey config store backend");
        return new ValKeyConfigStore(redisConnection, pubSubConnection);
    }

    @Bean
    @ConditionalOnProperty(name = "config.store.type", havingValue = "mongodb")
    public MongoClient mongoClient(
            @Value("${config.store.mongodb.uri:mongodb://localhost:27017}") String uri) {
        return MongoClients.create(uri);
    }

    @Bean
    @ConditionalOnProperty(name = "config.store.type", havingValue = "mongodb")
    public MongoDatabase mongoDatabase(
            MongoClient mongoClient,
            @Value("${config.store.mongodb.database:const-catalog}") String databaseName) {
        return mongoClient.getDatabase(databaseName);
    }

    @Bean
    @ConditionalOnProperty(name = "config.store.type", havingValue = "mongodb")
    public ConfigStore mongoConfigStore(MongoDatabase mongoDatabase) {
        log.info("Using MongoDB config store backend");
        return new MongoConfigStore(mongoDatabase);
    }
}
