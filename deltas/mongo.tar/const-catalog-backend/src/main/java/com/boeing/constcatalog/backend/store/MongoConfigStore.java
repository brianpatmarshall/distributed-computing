package com.boeing.constcatalog.backend.store;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.ReplaceOptions;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MongoDB implementation of {@link ConfigStore}.
 *
 * <p>Stores configuration values as JSON documents in a {@code config} collection:
 * <pre>
 * {
 *   "_id": "db.host",
 *   "key": "db.host",
 *   "value": "localhost"
 * }
 * </pre>
 *
 * <p>Using the key as {@code _id} provides:
 * <ul>
 *   <li>Natural uniqueness — no duplicates possible</li>
 *   <li>Fast lookups — queries by {@code _id} use the default index</li>
 *   <li>Upsert semantics — {@code replaceOne} with {@code upsert=true} handles both insert and update</li>
 * </ul>
 *
 * <p>Pub/sub is not supported in this implementation. Distributed cache invalidation
 * would require MongoDB Change Streams (available in replica set deployments).
 */
@Slf4j
public class MongoConfigStore implements ConfigStore {

    static final String COLLECTION_NAME = "config";
    static final String FIELD_KEY = "key";
    static final String FIELD_VALUE = "value";

    private final MongoCollection<Document> collection;

    public MongoConfigStore(MongoDatabase database) {
        this.collection = database.getCollection(COLLECTION_NAME);
    }

    @Override
    public String get(String key) {
        Document doc = collection.find(Filters.eq("_id", key)).first();
        if (doc == null) return null;
        return doc.getString(FIELD_VALUE);
    }

    @Override
    public void set(String key, String value) {
        Document doc = new Document("_id", key)
            .append(FIELD_KEY, key)
            .append(FIELD_VALUE, value);

        collection.replaceOne(
            Filters.eq("_id", key),
            doc,
            new ReplaceOptions().upsert(true)
        );
    }

    @Override
    public boolean delete(String key) {
        return collection.deleteOne(Filters.eq("_id", key)).getDeletedCount() > 0;
    }

    @Override
    public void setBatch(Map<String, String> entries) {
        for (Map.Entry<String, String> entry : entries.entrySet()) {
            set(entry.getKey(), entry.getValue());
        }
        log.debug("Batch stored {} configuration entries in MongoDB", entries.size());
    }

    @Override
    public List<String> keysByPrefix(String prefix) {
        List<String> keys = new ArrayList<>();
        collection.find(Filters.regex("_id", "^" + escapeRegex(prefix)))
            .forEach(doc -> keys.add(doc.getString(FIELD_KEY)));
        return keys;
    }

    @Override
    public Map<String, String> getByPrefix(String prefix) {
        Map<String, String> result = new HashMap<>();
        collection.find(Filters.regex("_id", "^" + escapeRegex(prefix)))
            .forEach(doc -> result.put(doc.getString(FIELD_KEY), doc.getString(FIELD_VALUE)));
        return result;
    }

    @Override
    public void publishChange(String key) {
        // MongoDB pub/sub would require Change Streams (replica set only).
        // For standalone deployments, this is a no-op.
        log.trace("publishChange is a no-op for MongoDB standalone: {}", key);
    }

    @Override
    public String storeName() {
        return "MongoDB";
    }

    private static String escapeRegex(String input) {
        return input.replaceAll("([.^$*+?()\\[\\]{}|\\\\])", "\\\\$1");
    }
}
