package com.boeing.constcatalog.backend.store;

import com.boeing.constcatalog.backend.config.ValKeyConfig;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;
import io.lettuce.core.pubsub.StatefulRedisPubSubConnection;
import io.lettuce.core.pubsub.api.sync.RedisPubSubCommands;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * ValKey (Redis-compatible) implementation of {@link ConfigStore}.
 *
 * <p>Stores configuration values as simple key-value pairs with a {@code config:} prefix.
 * Supports pub/sub for distributed cache invalidation via the {@code config:changes} channel.
 */
@Slf4j
public class ValKeyConfigStore implements ConfigStore {

    private final RedisCommands<String, String> syncCommands;
    private final StatefulRedisPubSubConnection<String, String> pubSubConnection;

    public ValKeyConfigStore(
            StatefulRedisConnection<String, String> redisConnection,
            StatefulRedisPubSubConnection<String, String> pubSubConnection) {
        this.syncCommands = redisConnection.sync();
        this.pubSubConnection = pubSubConnection;
    }

    @Override
    public String get(String key) {
        return syncCommands.get(ValKeyConfig.CONFIG_KEY_PREFIX + key);
    }

    @Override
    public void set(String key, String value) {
        syncCommands.set(ValKeyConfig.CONFIG_KEY_PREFIX + key, value);
    }

    @Override
    public boolean delete(String key) {
        return syncCommands.del(ValKeyConfig.CONFIG_KEY_PREFIX + key) > 0;
    }

    @Override
    public void setBatch(Map<String, String> entries) {
        Map<String, String> prefixed = entries.entrySet().stream()
            .collect(Collectors.toMap(
                e -> ValKeyConfig.CONFIG_KEY_PREFIX + e.getKey(),
                Map.Entry::getValue
            ));
        syncCommands.mset(prefixed);
    }

    @Override
    public List<String> keysByPrefix(String prefix) {
        String pattern = ValKeyConfig.CONFIG_KEY_PREFIX + prefix + "*";
        return syncCommands.keys(pattern).stream()
            .map(k -> k.substring(ValKeyConfig.CONFIG_KEY_PREFIX.length()))
            .toList();
    }

    @Override
    public Map<String, String> getByPrefix(String prefix) {
        String pattern = ValKeyConfig.CONFIG_KEY_PREFIX + prefix + "*";
        List<String> keys = syncCommands.keys(pattern);

        return keys.stream()
            .collect(Collectors.toMap(
                k -> k.substring(ValKeyConfig.CONFIG_KEY_PREFIX.length()),
                k -> Optional.ofNullable(syncCommands.get(k)).orElse(""),
                (v1, v2) -> v1
            ));
    }

    @Override
    public void publishChange(String key) {
        try {
            RedisPubSubCommands<String, String> pubSub = pubSubConnection.sync();
            pubSub.publish(ValKeyConfig.CONFIG_CHANGE_CHANNEL, key);
        } catch (Exception e) {
            log.warn("Failed to publish configuration change for key '{}': {}", key, e.getMessage());
        }
    }

    @Override
    public String storeName() {
        return "ValKey";
    }
}
