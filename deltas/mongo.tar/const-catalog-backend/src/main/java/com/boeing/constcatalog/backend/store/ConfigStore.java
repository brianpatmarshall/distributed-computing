package com.boeing.constcatalog.backend.store;

import java.util.List;
import java.util.Map;

/**
 * Abstraction for a key-value configuration store backend.
 *
 * <p>Implementations provide persistent storage for configuration values
 * (constants and parameters) that have been scanned from Java projects.
 * The {@link com.boeing.constcatalog.backend.service.SiteConfigurationService}
 * uses this interface through a two-tier cache (Caffeine L1 + ConfigStore L2).
 *
 * <p>All keys are plain configuration keys (e.g., {@code "db.host"}).
 * Implementations are responsible for any key prefixing or namespacing
 * needed by the underlying storage technology.
 *
 * <p>Current implementations:
 * <ul>
 *   <li>{@link ValKeyConfigStore} — ValKey/Redis via Lettuce</li>
 *   <li>{@link MongoConfigStore} — MongoDB document store</li>
 * </ul>
 */
public interface ConfigStore {

    /**
     * Retrieves a configuration value by key.
     *
     * @param key the configuration key
     * @return the value, or {@code null} if not found
     */
    String get(String key);

    /**
     * Stores a configuration value.
     *
     * @param key   the configuration key
     * @param value the value to store
     */
    void set(String key, String value);

    /**
     * Deletes a configuration value.
     *
     * @param key the configuration key
     * @return {@code true} if the key existed and was deleted
     */
    boolean delete(String key);

    /**
     * Stores multiple configuration values in a batch.
     * Implementations should optimize this for their storage backend
     * (e.g., MSET for Redis, bulk insert for MongoDB).
     *
     * @param entries map of key-value pairs to store
     */
    void setBatch(Map<String, String> entries);

    /**
     * Retrieves all configuration keys matching a prefix.
     *
     * @param prefix the key prefix to match (e.g., {@code "db."})
     * @return list of full keys matching the prefix
     */
    List<String> keysByPrefix(String prefix);

    /**
     * Retrieves all configuration values matching a key prefix.
     *
     * @param prefix the key prefix to match
     * @return map of matching keys to their values
     */
    Map<String, String> getByPrefix(String prefix);

    /**
     * Publishes a change notification for a key.
     * Used for distributed cache invalidation across application instances.
     * Implementations that don't support pub/sub may no-op.
     *
     * @param key the key that changed
     */
    void publishChange(String key);

    /**
     * Returns the name of this store implementation (e.g., "ValKey", "MongoDB").
     * Used for logging and diagnostics.
     */
    String storeName();
}
