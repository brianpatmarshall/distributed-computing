package com.boeing.constcatalog.parser;

import com.boeing.constcatalog.model.MicroServiceInfo;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Scans a real project directory for microservice classes and prints the results.
 * Uses the single-parse parseAll() approach — each file is parsed once and all
 * data (constants, parameter usages, FQN, microservice info) is extracted together.
 *
 * Run from the command line:
 *   mvn test -pl const-catalog-core -Dtest=MicroServiceScanTest -Dproject.path=/path/to/project
 *
 * Skips automatically if -Dproject.path is not provided.
 */
@EnabledIfSystemProperty(named = "project.path", matches = ".+")
class MicroServiceScanTest {

    private static final Set<String> EXCLUDED_DIRS = Set.of(
        "target", "build", "out", ".git", ".idea", ".gradle",
        "node_modules", ".mvn", "bin", ".settings"
    );

    @Test
    void scanProjectForMicroServices() throws IOException {
        String projectPath = System.getProperty("project.path");
        Path root = Paths.get(projectPath);
        assertThat(root).isDirectory();

        JavaFileParser parser = new JavaFileParser();

        // Collect all Java files
        List<Path> javaFiles = new ArrayList<>();
        Files.walkFileTree(root, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                String dirName = dir.getFileName().toString();
                if (EXCLUDED_DIRS.contains(dirName)) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (file.toString().endsWith(".java")) {
                    javaFiles.add(file);
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) {
                return FileVisitResult.CONTINUE;
            }
        });

        System.out.println("\n========================================");
        System.out.println("Microservice Scan: " + root);
        System.out.println("Java files found: " + javaFiles.size());
        System.out.println("========================================\n");

        // Scan each file using parseAll (single parse per file)
        Map<String, List<String>> byType = new TreeMap<>();
        int microServiceCount = 0;
        int totalConstants = 0;

        for (Path javaFile : javaFiles) {
            JavaFileParseResult result = parser.parseAll(javaFile, Collections.emptySet());
            MicroServiceInfo info = result.microServiceInfo();
            totalConstants += result.constants().size();

            if (info.isMicroService()) {
                microServiceCount++;
                String className = javaFile.getFileName().toString().replace(".java", "");
                String relativePath = root.relativize(javaFile).toString();
                String fqn = result.fqn() != null ? result.fqn() : className;

                System.out.printf("  %s is a MicroService of type %s%n", className, info.microServiceType());
                System.out.printf("    -> %s%n", relativePath);
                System.out.printf("    -> FQN: %s  |  constants: %d%n", fqn, result.constants().size());

                byType.computeIfAbsent(info.microServiceType(), k -> new ArrayList<>()).add(className);
            }
        }

        // Summary
        System.out.println("\n========================================");
        System.out.println("Summary");
        System.out.println("========================================");
        System.out.printf("Total Java files scanned: %d%n", javaFiles.size());
        System.out.printf("Total constants found: %d%n", totalConstants);
        System.out.printf("Microservices found: %d%n", microServiceCount);

        if (!byType.isEmpty()) {
            System.out.println("\nBy type:");
            for (Map.Entry<String, List<String>> entry : byType.entrySet()) {
                System.out.printf("  %-25s %d%n", entry.getKey(), entry.getValue().size());
            }
        } else {
            System.out.println("\nNo microservices detected.");
        }
        System.out.println("========================================\n");
    }
}
