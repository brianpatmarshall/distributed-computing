package com.boeing.constcatalog.parser;

import com.boeing.constcatalog.model.Constant;
import com.boeing.constcatalog.model.MicroServiceInfo;
import com.boeing.constcatalog.model.ParameterUsage;

import java.util.List;

/**
 * Composite result from parsing a single Java file in one pass.
 * Contains everything the scanner needs: constants, parameter usages,
 * FQN, and microservice info — all extracted from a single AST parse.
 */
public record JavaFileParseResult(
    List<Constant> constants,
    List<ParameterUsage> parameterUsages,
    String fqn,
    MicroServiceInfo microServiceInfo
) {}
