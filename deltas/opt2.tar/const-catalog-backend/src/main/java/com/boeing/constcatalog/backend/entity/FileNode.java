package com.boeing.constcatalog.backend.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.neo4j.core.schema.GeneratedValue;
import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;
import org.springframework.data.neo4j.core.support.UUIDStringGenerator;

/*
 * Files are the fundamental containers in our graph model. Every constant
 * is defined in a file, every parameter originates from a file, and every
 * usage occurs within a file. This makes FileNode the central hub through
 * which we can navigate the entire configuration graph.
 *
 * We store both the full path (for uniqueness) and the filename (for display).
 * The file type helps us understand context: a constant in a "Config" file
 * carries different semantics than one in a "Utils" file.
 *
 * Why not embed file info directly in constants/parameters? Because files are
 * shared: one file might contain dozens of constants and be referenced by
 * multiple parameter usages. The graph model lets us query "all things in
 * this file" efficiently.
 */
@Node("File")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FileNode {

    @Id
    @GeneratedValue(generatorClass = UUIDStringGenerator.class)
    private String id;

    private String path;
    private String fileName;
    private String fileType;
    private String fqn;
    private boolean isMicroService;
    private String microServiceType;

    /*
     * Factory method for creating FileNode from a path string.
     * Extracts the filename and determines the file type from extension.
     */
    public static FileNode fromPath(String path) {
        String fileName = path.substring(path.lastIndexOf('/') + 1);
        if (fileName.contains("\\")) {
            fileName = fileName.substring(fileName.lastIndexOf('\\') + 1);
        }
        String fileType = determineFileType(fileName);

        return FileNode.builder()
            .path(path)
            .fileName(fileName)
            .fileType(fileType)
            .build();
    }

    private static String determineFileType(String fileName) {
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".java")) return "JAVA";
        if (lower.endsWith(".properties")) return "PROPERTIES";
        if (lower.endsWith(".yml") || lower.endsWith(".yaml")) return "YAML";
        if (lower.endsWith(".env")) return "ENV";
        if (lower.endsWith(".xml")) return "XML";
        return "UNKNOWN";
    }
}
