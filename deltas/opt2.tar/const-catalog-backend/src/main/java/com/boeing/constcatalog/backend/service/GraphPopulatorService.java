package com.boeing.constcatalog.backend.service;

import com.boeing.constcatalog.backend.entity.*;
import com.boeing.constcatalog.backend.repository.*;
import com.boeing.constcatalog.model.Constant;
import com.boeing.constcatalog.model.ConstantUsage;
import com.boeing.constcatalog.model.MicroServiceInfo;
import com.boeing.constcatalog.model.Parameter;
import com.boeing.constcatalog.model.ParameterUsage;
import com.boeing.constcatalog.scanner.ProjectScanner;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/*
 * The graph is our source of truth for configuration knowledge.
 * This service translates ephemeral scan results into persistent
 * graph nodes and relationships. We use a two-phase approach:
 * first create all nodes, then create relationships. This ensures
 * referential integrity and enables efficient batch operations.
 *
 * Why not single-phase? Because parameters reference files, and
 * files reference projects. Without ordering, we'd have dangling
 * references or need multiple passes anyway.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class GraphPopulatorService {

    private final ProjectRepository projectRepository;
    private final FileRepository fileRepository;
    private final ConstantRepository constantRepository;
    private final ParameterRepository parameterRepository;

    /**
     * Populates the Neo4j graph with scan results. Each step (files, constants,
     * parameters, relationships) commits independently so data becomes visible
     * incrementally during long-running scans.
     */
    public void populateGraph(String projectPath, String projectName, ProjectScanner.ScanResult scanResult) {
        log.info("Populating graph for project: {}", projectName);

        /*
         * Step 1: Create or update the project node.
         * We use the path as the unique identifier to support re-scanning.
         */
        ProjectNode project = projectRepository.findByRootPath(projectPath)
            .map(existing -> updateProject(existing, scanResult))
            .orElseGet(() -> createProject(projectPath, projectName, scanResult));
        /*
         * Step 2: Collect all unique file paths.
         * Files appear in multiple contexts: constant definitions,
         * parameter definitions, and parameter usages.
         */
        Set<String> allFilePaths = collectAllFilePaths(scanResult);

        /*
         * Step 3: Create file nodes with a cache for relationship building.
         * The cache maps file paths to their saved entities, enabling
         * efficient lookup when creating relationships.
         */
        Map<String, FileNode> fileCache = createFileNodes(allFilePaths, project);

        /*
         * Step 4: Create constant nodes with DEFINED_IN relationships.
         * Each constant points to exactly one file.
         */
        Map<String, ConstantNode> constantCache = createConstantNodes(scanResult, fileCache);

        /*
         * Step 5: Create parameter nodes with DEFINED_IN relationships.
         * Parameters are defined in property files.
         */
        Map<String, ParameterNode> parameterCache = createParameterNodes(scanResult, fileCache);

        /*
         * Step 6: Add USED_IN relationships to parameters.
         * This connects parameters to the Java files that consume them.
         */
        createUsageRelationships(scanResult, fileCache, parameterCache);

        /*
         * Step 7: Add USED_IN relationships to constants.
         * This connects constants to the Java files that reference them.
         */
        createConstantUsageRelationships(scanResult, fileCache, constantCache);

        /*
         * Step 8: Set FQN on Java file nodes.
         */
        setJavaFileFqns(scanResult, fileCache);

        /*
         * Step 9: Set microservice info on Java file nodes.
         */
        setMicroServiceInfo(scanResult, fileCache);

        log.info("Graph population complete for project: {}", projectName);
    }

    private ProjectNode createProject(String path, String name, ProjectScanner.ScanResult result) {
        ProjectNode project = ProjectNode.builder()
            .name(name)
            .rootPath(path)
            .scannedAt(LocalDateTime.now())
            .totalFiles(result.javaFilesScanned() + result.propertyFilesScanned())
            .totalConstants(result.constants().size())
            .totalParameters(result.parameters().size())
            .build();

        return projectRepository.save(project);
    }

    private ProjectNode updateProject(ProjectNode existing, ProjectScanner.ScanResult result) {
        existing.setScannedAt(LocalDateTime.now());
        existing.setTotalFiles(result.javaFilesScanned() + result.propertyFilesScanned());
        existing.setTotalConstants(result.constants().size());
        existing.setTotalParameters(result.parameters().size());

        return projectRepository.save(existing);
    }

    private Set<String> collectAllFilePaths(ProjectScanner.ScanResult result) {
        Set<String> paths = result.constants().stream()
            .map(Constant::fileName)
            .collect(Collectors.toSet());

        result.parameters().stream()
            .map(Parameter::definitionFile)
            .forEach(paths::add);

        result.parameterUsages().stream()
            .map(ParameterUsage::usedInFile)
            .forEach(paths::add);

        result.constantUsages().stream()
            .map(ConstantUsage::usedInFile)
            .forEach(paths::add);

        return paths;
    }

    private Map<String, FileNode> createFileNodes(Set<String> filePaths, ProjectNode project) {
        Map<String, FileNode> cache = new HashMap<>();

        // Batch create new file nodes
        List<FileNode> newFiles = new ArrayList<>();
        for (String path : filePaths) {
            FileNode file = fileRepository.findByPath(path).orElse(null);
            if (file != null) {
                cache.put(path, file);
                project.addFile(file);
            } else {
                FileNode newFile = FileNode.fromPath(path);
                newFiles.add(newFile);
            }
        }

        if (!newFiles.isEmpty()) {
            fileRepository.saveAll(newFiles).forEach(saved -> {
                cache.put(saved.getPath(), saved);
                project.addFile(saved);
            });
        }

        projectRepository.save(project);
        log.debug("Created {} file nodes ({} new)", filePaths.size(), newFiles.size());
        return cache;
    }

    private static final int BATCH_SIZE = 500;

    private Map<String, ConstantNode>
    createConstantNodes(ProjectScanner.ScanResult result, Map<String, FileNode> fileCache) {
        Map<String, ConstantNode> cache = new HashMap<>();

        List<ConstantNode> batch = new ArrayList<>();
        for (Constant constant : result.constants()) {
            FileNode file = fileCache.get(constant.fileName());
            ConstantNode node = ConstantNode.fromConstant(constant, file);
            batch.add(node);

            if (batch.size() >= BATCH_SIZE) {
                constantRepository.saveAll(batch).forEach(saved -> {
                    String key = saved.getClassName() + "." + saved.getName();
                    cache.put(key, saved);
                });
                batch.clear();
            }
        }
        // Save remaining
        if (!batch.isEmpty()) {
            constantRepository.saveAll(batch).forEach(saved -> {
                String key = saved.getClassName() + "." + saved.getName();
                cache.put(key, saved);
            });
        }

        log.debug("Created {} constant nodes (batch size {})", result.constants().size(), BATCH_SIZE);
        return cache;
    }

    private Map<String, ParameterNode> createParameterNodes(
            ProjectScanner.ScanResult result,
            Map<String, FileNode> fileCache) {

        Map<String, ParameterNode> cache = new HashMap<>();

        List<ParameterNode> batch = new ArrayList<>();
        for (Parameter parameter : result.parameters()) {
            FileNode file = fileCache.get(parameter.definitionFile());
            ParameterNode node = ParameterNode.fromParameter(parameter, file);
            batch.add(node);

            if (batch.size() >= BATCH_SIZE) {
                parameterRepository.saveAll(batch).forEach(saved ->
                    cache.put(saved.getName(), saved));
                batch.clear();
            }
        }
        if (!batch.isEmpty()) {
            parameterRepository.saveAll(batch).forEach(saved ->
                cache.put(saved.getName(), saved));
        }

        log.debug("Created {} parameter nodes (batch size {})", result.parameters().size(), BATCH_SIZE);
        return cache;
    }

    private void createUsageRelationships(
            ProjectScanner.ScanResult result,
            Map<String, FileNode> fileCache,
            Map<String, ParameterNode> parameterCache) {

        Set<ParameterNode> modified = new java.util.LinkedHashSet<>();

        for (ParameterUsage usage : result.parameterUsages()) {
            ParameterNode parameter = parameterCache.get(usage.parameterName());
            if (parameter == null) {
                log.warn("Usage references unknown parameter: {}", usage.parameterName());
                continue;
            }

            FileNode file = fileCache.get(usage.usedInFile());
            if (file == null) {
                log.warn("Usage references unknown file: {}", usage.usedInFile());
                continue;
            }

            UsageRelationship usageRel = UsageRelationship.create(
                file,
                usage.usedInClass(),
                usage.lineNumber(),
                usage.context()
            );

            parameter.addUsage(usageRel);
            modified.add(parameter);
        }

        modified.forEach(parameterRepository::save);
        log.debug("Created {} usage relationships", result.parameterUsages().size());
    }

    private void createConstantUsageRelationships(
            ProjectScanner.ScanResult result,
            Map<String, FileNode> fileCache,
            Map<String, ConstantNode> constantCache) {

        Set<ConstantNode> modified = new java.util.LinkedHashSet<>();

        for (ConstantUsage usage : result.constantUsages()) {
            String key = usage.definingClassName() + "." + usage.constantName();
            ConstantNode constant = constantCache.get(key);
            if (constant == null) {
                log.warn("Usage references unknown constant: {}", key);
                continue;
            }

            FileNode file = fileCache.get(usage.usedInFile());
            if (file == null) {
                log.warn("Usage references unknown file: {}", usage.usedInFile());
                continue;
            }

            UsageRelationship usageRel = UsageRelationship.create(
                file,
                usage.usedInClass(),
                usage.lineNumber(),
                usage.context()
            );

            constant.addUsage(usageRel);
            modified.add(constant);
        }

        modified.forEach(constantRepository::save);
        log.debug("Created {} constant usage relationships", result.constantUsages().size());
    }

    private void setJavaFileFqns(
            ProjectScanner.ScanResult result,
            Map<String, FileNode> fileCache) {

        for (Map.Entry<String, String> entry : result.javaFileFqns().entrySet()) {
            FileNode file = fileCache.get(entry.getKey());
            if (file != null) {
                file.setFqn(entry.getValue());
                fileRepository.save(file);
            }
        }

        log.debug("Set FQN on {} Java file nodes", result.javaFileFqns().size());
    }

    private void setMicroServiceInfo(
            ProjectScanner.ScanResult result,
            Map<String, FileNode> fileCache) {

        for (Map.Entry<String, MicroServiceInfo> entry : result.microServiceInfos().entrySet()) {
            FileNode file = fileCache.get(entry.getKey());
            if (file != null) {
                file.setMicroService(true);
                file.setMicroServiceType(entry.getValue().microServiceType());
                fileRepository.save(file);
            }
        }

        log.debug("Set microservice info on {} file nodes", result.microServiceInfos().size());
    }

    /*
     * Clear all data for a project. Useful for clean re-scans.
     */
    @Transactional
    public void clearProject(String projectPath) {
        projectRepository.findByRootPath(projectPath)
            .ifPresent(project -> {
                log.info("Clearing existing data for project: {}", projectPath);
                projectRepository.delete(project);
            });
    }
}
