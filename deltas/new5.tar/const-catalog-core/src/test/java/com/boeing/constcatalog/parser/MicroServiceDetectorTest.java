package com.boeing.constcatalog.parser;

import com.boeing.constcatalog.model.MicroServiceInfo;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class MicroServiceDetectorTest {

    private MicroServiceDetector detector;
    private JavaParser javaParser;

    @BeforeEach
    void setUp() {
        detector = new MicroServiceDetector();
        javaParser = new JavaParser();
    }

    private MicroServiceInfo detect(String source) {
        ParseResult<CompilationUnit> result = javaParser.parse(source);
        assertThat(result.isSuccessful()).isTrue();
        return detector.detect(result.getResult().get());
    }

    @Test
    void springBootApplication() {
        MicroServiceInfo info = detect("""
            import org.springframework.boot.autoconfigure.SpringBootApplication;
            @SpringBootApplication
            public class MyApp {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("SPRING_BOOT");
    }

    @Test
    void restController() {
        MicroServiceInfo info = detect("""
            import org.springframework.web.bind.annotation.RestController;
            @RestController
            public class MyController {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("REST_CONTROLLER");
    }

    @Test
    void jaxRsPath() {
        MicroServiceInfo info = detect("""
            import jakarta.ws.rs.Path;
            @Path("/api")
            public class MyResource {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("REST_CONTROLLER");
    }

    @Test
    void feignClient() {
        MicroServiceInfo info = detect("""
            import org.springframework.cloud.openfeign.FeignClient;
            @FeignClient(name = "user-service")
            public interface UserClient {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("FEIGN_CLIENT");
    }

    @Test
    void grpcServiceAnnotation() {
        MicroServiceInfo info = detect("""
            import net.devh.boot.grpc.server.service.GrpcService;
            @GrpcService
            public class GreeterService {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("GRPC_SERVICE");
    }

    @Test
    void grpcImplBaseSuperclass() {
        MicroServiceInfo info = detect("""
            public class GreeterService extends GreeterGrpc.GreeterImplBase {
                public void sayHello() {}
            }
            """);
        // JavaParser parses the extends type — we check the simple name ends with ImplBase
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("GRPC_SERVICE");
    }

    @Test
    void kafkaListenerOnMethod() {
        MicroServiceInfo info = detect("""
            import org.springframework.kafka.annotation.KafkaListener;
            public class EventConsumer {
                @KafkaListener(topics = "events")
                public void onEvent(String event) {}
            }
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("KAFKA_LISTENER");
    }

    @Test
    void scheduledOnMethod() {
        MicroServiceInfo info = detect("""
            import org.springframework.scheduling.annotation.Scheduled;
            public class JobRunner {
                @Scheduled(fixedRate = 5000)
                public void runJob() {}
            }
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("SCHEDULED_SERVICE");
    }

    @Test
    void eurekaClient() {
        MicroServiceInfo info = detect("""
            import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
            @EnableEurekaClient
            public class MyApp {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("EUREKA_CLIENT");
    }

    @Test
    void discoveryClient() {
        MicroServiceInfo info = detect("""
            import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
            @EnableDiscoveryClient
            public class MyApp {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("EUREKA_CLIENT");
    }

    @Test
    void noMicroServiceAnnotations() {
        MicroServiceInfo info = detect("""
            public class PlainClass {
                public static final String FOO = "bar";
            }
            """);
        assertThat(info.isMicroService()).isFalse();
        assertThat(info.microServiceType()).isNull();
    }

    @Test
    void multipleAnnotationsReturnsHighestPriority() {
        // SpringBootApplication has higher priority than EnableEurekaClient
        MicroServiceInfo info = detect("""
            import org.springframework.boot.autoconfigure.SpringBootApplication;
            import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
            @SpringBootApplication
            @EnableEurekaClient
            public class MyApp {}
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("SPRING_BOOT");
    }

    @Test
    void interfaceWithFeignClient() {
        MicroServiceInfo info = detect("""
            import org.springframework.cloud.openfeign.FeignClient;
            import org.springframework.web.bind.annotation.GetMapping;
            @FeignClient(name = "order-service", url = "http://localhost:8081")
            public interface OrderClient {
                @GetMapping("/orders")
                String getOrders();
            }
            """);
        assertThat(info.isMicroService()).isTrue();
        assertThat(info.microServiceType()).isEqualTo("FEIGN_CLIENT");
    }

    @Test
    void classWithOnlyNonMicroserviceAnnotations() {
        MicroServiceInfo info = detect("""
            import lombok.Data;
            import lombok.Builder;
            @Data
            @Builder
            public class MyDto {
                private String name;
            }
            """);
        assertThat(info.isMicroService()).isFalse();
        assertThat(info.microServiceType()).isNull();
    }

    @Test
    void emptyClass() {
        MicroServiceInfo info = detect("public class Empty {}");
        assertThat(info.isMicroService()).isFalse();
        assertThat(info.microServiceType()).isNull();
    }
}
