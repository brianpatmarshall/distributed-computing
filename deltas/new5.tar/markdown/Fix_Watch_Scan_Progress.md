# Fix: "Watch Scan Progress" Checkbox

A complete record of every change made to fix the SSE-based scan progress feature. The "Watch scan progress" checkbox was non-functional in the Docker environment due to four layered issues, each masking the next. This document explains every file changed, what changed, and — most importantly — why.

---

## Table of Contents

1. [ConstCatalogApplication.java — Enable Spring Async Support](#1-constcatalogapplicationjava--enable-spring-async-support)
2. [ScanController.java — Explicit @RequestParam Name](#2-scancontrollerjava--explicit-requestparam-name)
3. [nginx.conf — SSE Proxy Configuration](#3-nginxconf--sse-proxy-configuration)
4. [ScanPage.tsx — Eliminate Double Scan](#4-scanpagetsx--eliminate-double-scan)
5. [useScanProgress.ts — Expose Completion State](#5-usescanprogressts--expose-completion-state)
6. [Summary of Root Causes](#6-summary-of-root-causes)

---

## 1. ConstCatalogApplication.java — Enable Spring Async Support

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/ConstCatalogApplication.java`

### Change 1.1: Add `@EnableAsync` annotation

**Before (lines 3–4, 20–21):**
```java
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConstCatalogApplication {
```

**After (lines 3–5, 21–22):**
```java
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class ConstCatalogApplication {
```

**Why this change was needed:**

`ScanService.scanProjectWithProgress()` is annotated with `@Async`, which tells Spring to run the method on a background thread rather than the caller's thread. This is essential for SSE because:

1. The controller creates an `SseEmitter`, then calls `scanProjectWithProgress()`
2. The controller must return the `SseEmitter` to the client immediately so the browser can start listening
3. The scan method runs on a background thread and sends events to the emitter as it progresses

Without `@EnableAsync`, Spring ignores the `@Async` annotation entirely. The method runs synchronously on the HTTP request thread:

```
WITHOUT @EnableAsync (broken):
  1. Controller creates SseEmitter
  2. Controller calls scanProjectWithProgress() — BLOCKS
  3. Entire scan runs to completion on this thread
  4. All SSE events sent to emitter that hasn't been returned to client yet
  5. Method returns
  6. Controller returns emitter to browser
  7. Browser connects — but emitter is already complete, no events

WITH @EnableAsync (fixed):
  1. Controller creates SseEmitter
  2. Controller calls scanProjectWithProgress() — Spring submits to thread pool, returns immediately
  3. Controller returns emitter to browser
  4. Browser connects and starts listening
  5. Scan runs on background thread, events stream to browser in real time
```

`@EnableAsync` must be placed on a `@Configuration` class (or a composed annotation that includes it). `@SpringBootApplication` includes `@Configuration`, making the main application class the natural location.

---

## 2. ScanController.java — Explicit @RequestParam Name

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/controller/ScanController.java`

### Change 2.1: Add explicit parameter name to `@RequestParam`

**Before (line 174):**
```java
public SseEmitter streamScan(@RequestParam String projectPath) {
```

**After (line 174):**
```java
public SseEmitter streamScan(@RequestParam("projectPath") String projectPath) {
```

**Why this change was needed:**

The endpoint was returning HTTP 500 with this error:

```
Name for argument of type [java.lang.String] not specified, and parameter name
information not available via reflection. Ensure that the compiler uses the
'-parameters' flag.
```

When you write `@RequestParam String projectPath`, Spring needs to know that the query parameter `projectPath` in the URL maps to the Java argument `projectPath`. There are two ways it can discover this:

1. **Compiler `-parameters` flag** — If `javac` is invoked with `-parameters`, parameter names are preserved in the bytecode. Spring reads them via reflection. This is how it worked locally (the local IDE/Maven likely had this flag enabled).

2. **Explicit annotation value** — `@RequestParam("projectPath")` hard-codes the mapping. No reflection needed.

The Docker build uses `maven:3.9-eclipse-temurin-21` which does not include `-parameters` by default. The compiled class has `arg0` instead of `projectPath`, so Spring can't match the URL parameter. Adding the explicit name makes the mapping work regardless of compiler flags.

This issue only affected the SSE endpoint because the other controllers likely use `@RequestBody` (which maps by JSON field names, not parameter reflection) or already had explicit names.

---

## 3. nginx.conf — SSE Proxy Configuration

**File:** `const-catalog-frontend/nginx.conf`

### Change 3.1: Remove WebSocket headers from general API block

**Before (lines 12–26):**
```nginx
location /api/ {
    proxy_pass http://backend:8080/api/;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    proxy_connect_timeout 6000s;
    proxy_send_timeout 6000s;
    proxy_read_timeout 6000s;
}
```

**After (lines 12–23):**
```nginx
location /api/ {
    proxy_pass http://backend:8080/api/;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

    proxy_connect_timeout 6000s;
    proxy_send_timeout 6000s;
    proxy_read_timeout 6000s;
}
```

**Why this change was needed:**

The original block included `proxy_set_header Upgrade $http_upgrade` and `proxy_set_header Connection 'upgrade'`. These are WebSocket handshake headers — they tell the backend to upgrade the HTTP connection to the WebSocket protocol. This application does not use WebSockets. These headers were likely copied from a template.

For regular REST API calls (POST, GET returning JSON), these headers are harmless — the backend ignores `Upgrade` headers it doesn't understand. But they shouldn't be there because:
- They add unnecessary headers to every API request
- They could interfere if the backend ever implemented WebSocket rejection logic
- They were confusing when debugging the SSE issue

### Change 3.2: Add dedicated SSE location block

**Before:** No SSE-specific configuration existed.

**After (lines 25–43):**
```nginx
# SSE endpoint needs buffering disabled so events stream in real time
location /api/scan/stream {
    proxy_pass http://backend:8080/api/scan/stream;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header Connection '';

    # Disable buffering — nginx must forward each SSE event immediately
    proxy_buffering off;
    proxy_cache off;

    # Disable gzip — compressed chunks break SSE framing
    gzip off;

    # Extended timeout for long-running scans
    proxy_read_timeout 600s;
}
```

**Why this change was needed:**

Nginx buffers proxy responses by default. It collects the backend's output into an internal buffer (typically 4–8KB) and only forwards it to the browser when the buffer is full or the connection closes. This is efficient for normal HTTP responses but fatal for SSE.

SSE events are small — each progress event is roughly 200 bytes of JSON. Without `proxy_buffering off`, events accumulate silently in nginx's buffer. The browser's `EventSource` receives nothing, times out, and reports an error. The scan runs successfully on the backend, but the frontend never sees a single event.

Each directive serves a specific purpose:

| Directive | Why |
|---|---|
| `proxy_buffering off` | Forward each SSE event immediately instead of accumulating in a buffer. This is the critical fix. |
| `proxy_cache off` | Prevent nginx from caching the stream response. Each SSE connection is unique and real-time. |
| `gzip off` | Gzip compression collects data into blocks before compressing. This re-introduces buffering at the encoding layer, defeating `proxy_buffering off`. |
| `proxy_set_header Connection ''` | Keep the connection open for streaming. The original `Connection 'upgrade'` told the backend to switch to WebSocket protocol — SSE is not WebSocket, so the backend rejected it. An empty string uses HTTP/1.1's default keep-alive behavior. |
| `proxy_read_timeout 600s` | 10-minute timeout matching the `SseEmitter` timeout in `ScanController.java` (`new SseEmitter(600_000L)`). Without this, nginx would close the connection after its default 60-second read timeout if events are spaced far apart. |

**Why a separate location block?** Nginx uses longest-prefix matching. A request to `/api/scan/stream?projectPath=...` matches both `/api/` and `/api/scan/stream`. Nginx picks `/api/scan/stream` because it's more specific. This lets us disable buffering for SSE without affecting regular REST calls, which benefit from nginx's default buffering (it reduces the number of small writes to the client socket).

**Why this doesn't affect `npm run dev`:** The Vite dev server handles proxying when running outside Docker. Vite doesn't buffer SSE responses — it passes events through natively. The nginx config only applies inside the Docker container.

---

## 4. ScanPage.tsx — Eliminate Double Scan

**File:** `const-catalog-frontend/src/pages/ScanPage.tsx`

### Change 4.1: Add `useEffect` import

**Before (line 1):**
```tsx
import { useState } from 'react'
```

**After (line 1):**
```tsx
import { useState, useEffect } from 'react'
```

**Why:** Needed for the new `useEffect` that reacts to SSE scan completion (see Change 4.4).

### Change 4.2: Destructure `isComplete` from hook, remove `stopStreaming`

**Before (lines 20–21):**
```tsx
const { isConnected, latestFiles, currentEvent, startStreaming, stopStreaming } =
  useScanProgress()
```

**After (lines 20–21):**
```tsx
const { isConnected, isComplete, latestFiles, currentEvent, startStreaming } =
  useScanProgress()
```

**Why `stopStreaming` was removed:** It was previously called in the mutation's `onSuccess` and `onError` callbacks to stop the SSE stream when the POST scan completed. Since we no longer fire the POST mutation when progress watching is enabled (see Change 4.5), `stopStreaming` is never called from this component. The `useScanProgress` hook manages its own lifecycle — it calls `stopStreaming()` internally when it receives the `'complete'` or `'error'` event from the backend. Leaving the unused destructured variable caused a TypeScript build error (`TS6133: 'stopStreaming' is declared but its value is never read`).

**Why `isComplete` was added:** The new `isComplete` flag (exposed by the hook — see Section 5) tells the component when the SSE scan has finished. This is used to build a scan result and show the results panel (see Change 4.4).

### Change 4.3: Remove `stopStreaming()` from mutation callbacks

**Before (lines 25–36):**
```tsx
const scanMutation = useMutation({
  mutationFn: scanProject,
  onSuccess: (data) => {
    setScanResult(data)
    stopStreaming()
    queryClient.invalidateQueries({ queryKey: ['stats'] })
  },
  onError: (error) => {
    setScanResult({
      success: false,
      message: error instanceof Error ? error.message : 'Unknown error',
    })
    stopStreaming()
  },
})
```

**After (lines 37–49):**
```tsx
const scanMutation = useMutation({
  mutationFn: scanProject,
  onSuccess: (data) => {
    setScanResult(data)
    queryClient.invalidateQueries({ queryKey: ['stats'] })
  },
  onError: (error) => {
    setScanResult({
      success: false,
      message: error instanceof Error ? error.message : 'Unknown error',
    })
  },
})
```

**Why:** The mutation callbacks no longer need to manage the SSE stream. When the POST mutation runs (progress watching off), there is no SSE stream to stop. When progress watching is on, the mutation doesn't run at all. The `stopStreaming()` calls were remnants of the original design where both POST and SSE ran concurrently.

### Change 4.4: Add `useEffect` for SSE scan completion

**After (lines 23–35, new code):**
```tsx
// When SSE scan completes, build a result from the completion event
useEffect(() => {
  if (isComplete && currentEvent) {
    setScanResult({
      success: true,
      message: 'Scan completed successfully',
      constantsFound: currentEvent.constantsFound,
      parametersFound: currentEvent.parametersFound,
      javaFilesScanned: currentEvent.totalFiles,
    })
    queryClient.invalidateQueries({ queryKey: ['stats'] })
  }
}, [isComplete, currentEvent, queryClient])
```

**Why this was needed:** In the original design, the POST mutation always ran and its response populated the results panel. Now, when progress watching is enabled, only the SSE scan runs — there is no POST response. The results panel still needs data to display.

The SSE `'complete'` event from the backend includes `constantsFound`, `parametersFound`, and `totalFiles`. This `useEffect` watches for `isComplete` to become `true` and constructs a `ScanResponse` object from the event data. It also invalidates the `['stats']` cache so the Dashboard reflects the new scan data.

The SSE completion event has fewer fields than the full POST response (no `projectName`, no `fileTypeStats`, no `propertyFilesScanned`). The results panel gracefully handles missing fields via optional chaining (`scanResult.projectName || '-'`), so this works without modification to the JSX.

### Change 4.5: Make POST and SSE mutually exclusive

**Before (lines 37–47):**
```tsx
const handleScan = (e: React.FormEvent) => {
  e.preventDefault()
  if (!projectPath.trim()) return
  setScanResult(null)

  if (watchProgress) {
    startStreaming(projectPath.trim())
  }

  scanMutation.mutate({ projectPath: projectPath.trim() })
}
```

**After (lines 51–65):**
```tsx
const handleScan = (e: React.FormEvent) => {
  e.preventDefault()
  if (!projectPath.trim()) return
  setScanResult(null)

  if (watchProgress) {
    // Use the SSE endpoint only — it runs its own scan with progress events.
    // Do NOT also fire the POST mutation, as two concurrent scans on the same
    // project cause a ConcurrentModificationException in the backend.
    startStreaming(projectPath.trim())
  } else {
    // No progress watching — use the POST endpoint for the final result.
    scanMutation.mutate({ projectPath: projectPath.trim() })
  }
}
```

**Why this was the most critical frontend change:**

The original code always called `scanMutation.mutate()` regardless of the checkbox state. When progress watching was enabled, it also called `startStreaming()`. This meant two independent scans ran concurrently on the backend:

1. **SSE scan** — `GET /api/scan/stream` → `scanService.scanProjectWithProgress()` (async thread)
2. **POST scan** — `POST /api/scan` → `scanService.scanProject()` (request thread)

Both scans call `projectScanner.scan()` which walks the same directory tree and populates the same Neo4j graph. The `ProjectScanner` uses shared `ArrayList` and `HashMap` instances internally. Two threads reading and writing these unsynchronized collections concurrently caused:

```
java.util.ConcurrentModificationException: null
```

The POST scan crashed with HTTP 500, and the frontend displayed "Scan Failed."

The fix is simple: when the checkbox is checked, only use the SSE endpoint (which runs its own scan). When unchecked, only use the POST endpoint. Never both.

### Change 4.6: Disable button during SSE scan

**Before (lines 101, 104):**
```tsx
disabled={scanMutation.isPending || !projectPath.trim()}
...
{scanMutation.isPending ? (
```

**After (lines 101, 104):**
```tsx
disabled={scanMutation.isPending || isConnected || !projectPath.trim()}
...
{(scanMutation.isPending || isConnected) ? (
```

**Why:** When using the SSE-only scan path, `scanMutation.isPending` is never `true` (the mutation doesn't fire). Without checking `isConnected`, the user could click "Scan Project" multiple times while an SSE scan is in progress, launching parallel SSE connections. Adding `isConnected` to both the `disabled` check and the spinner condition ensures the button shows "Scanning..." and is disabled during both POST and SSE scans.

---

## 5. useScanProgress.ts — Expose Completion State

**File:** `const-catalog-frontend/src/hooks/useScanProgress.ts`

### Change 5.1: Add `isComplete` to the return interface

**Before (lines 5–12):**
```tsx
interface UseScanProgressReturn {
  events: ScanProgressEvent[]
  isConnected: boolean
  latestFiles: string[]
  currentEvent: ScanProgressEvent | null
  startStreaming: (projectPath: string) => void
  stopStreaming: () => void
}
```

**After (lines 5–13):**
```tsx
interface UseScanProgressReturn {
  events: ScanProgressEvent[]
  isConnected: boolean
  isComplete: boolean
  latestFiles: string[]
  currentEvent: ScanProgressEvent | null
  startStreaming: (projectPath: string) => void
  stopStreaming: () => void
}
```

### Change 5.2: Add `isComplete` state

**Before (lines 20–21):**
```tsx
const [events, setEvents] = useState<ScanProgressEvent[]>([])
const [isConnected, setIsConnected] = useState(false)
const [currentEvent, setCurrentEvent] = useState<ScanProgressEvent | null>(null)
```

**After (lines 20–23):**
```tsx
const [events, setEvents] = useState<ScanProgressEvent[]>([])
const [isConnected, setIsConnected] = useState(false)
const [isComplete, setIsComplete] = useState(false)
const [currentEvent, setCurrentEvent] = useState<ScanProgressEvent | null>(null)
```

### Change 5.3: Reset `isComplete` when starting a new stream

**Before (lines 36–38):**
```tsx
stopStreaming()
setEvents([])
setCurrentEvent(null)
```

**After (lines 36–39):**
```tsx
stopStreaming()
setEvents([])
setCurrentEvent(null)
setIsComplete(false)
```

**Why:** Without resetting `isComplete` to `false` when a new scan starts, the `useEffect` in `ScanPage` would immediately fire from the previous scan's completion state and set a stale result.

### Change 5.4: Set `isComplete` on the `'complete'` event

**Before (lines 59–65):**
```tsx
eventSource.addEventListener('complete', (event: MessageEvent) => {
  try {
    const data: ScanProgressEvent = JSON.parse(event.data)
    setCurrentEvent(data)
    setEvents((prev) => [...prev, data])
  } catch {
    // Ignore parse errors
  }
  stopStreaming()
})
```

**After (lines 59–69):**
```tsx
eventSource.addEventListener('complete', (event: MessageEvent) => {
  try {
    const data: ScanProgressEvent = JSON.parse(event.data)
    setCurrentEvent(data)
    setEvents((prev) => [...prev, data])
    setIsComplete(true)
  } catch {
    // Ignore parse errors
  }
  stopStreaming()
})
```

### Change 5.5: Include `isComplete` in return value

**Before (lines 86–89):**
```tsx
return {
  events,
  isConnected,
  latestFiles,
  currentEvent,
  startStreaming,
  stopStreaming,
}
```

**After (lines 86–94):**
```tsx
return {
  events,
  isConnected,
  isComplete,
  latestFiles,
  currentEvent,
  startStreaming,
  stopStreaming,
}
```

**Why all five changes were needed:**

Previously, the hook had no way to signal "the scan finished successfully." It tracked `isConnected` (stream is open) and `currentEvent` (latest event), but neither of these cleanly indicates completion:

- `isConnected` becomes `false` on both success and error
- `currentEvent` holds the last event, but the component would need to check `currentEvent.eventType === 'SCAN_COMPLETE'` — coupling the component to SSE protocol details

The `isComplete` flag provides a clean, unambiguous signal that `ScanPage` can react to with a `useEffect`. It's:
- Set to `true` only on the `'complete'` event (not on errors)
- Reset to `false` when a new scan starts (preventing stale triggers)
- Part of the public interface so the component doesn't need to know about SSE event types

---

## 6. Summary of Root Causes

The "Watch scan progress" feature had four layered issues, each masking the next. Fixing one revealed the next:

| # | Layer | Issue | Fix | File |
|---|---|---|---|---|
| 1 | Backend | `@Async` was silently ignored — scan ran synchronously, all events sent before browser connected | Added `@EnableAsync` to application class | `ConstCatalogApplication.java` |
| 2 | Backend | `@RequestParam` couldn't resolve parameter name in Docker build — endpoint returned 500 | Added explicit name `@RequestParam("projectPath")` | `ScanController.java` |
| 3 | Nginx | Response buffering held SSE events in memory instead of forwarding them | Added SSE-specific location block with `proxy_buffering off` | `nginx.conf` |
| 4 | Frontend | POST and SSE scans ran concurrently, causing `ConcurrentModificationException`; POST completed first and killed the SSE stream | Made POST and SSE mutually exclusive; added completion state to hook | `ScanPage.tsx`, `useScanProgress.ts` |

**Diagnosis approach:** Each fix was discovered by working from the outside in:
1. Browser Network tab showed the stream request failing → investigated nginx
2. Curl bypassing nginx also returned nothing → investigated backend
3. Backend logs showed 500 with `-parameters` error → fixed `@RequestParam`
4. Still no events via curl → discovered missing `@EnableAsync`
5. Events streamed but UI didn't update → found the race condition and `ConcurrentModificationException` in logs
