# Git Plumbing Commands — Deep Dive

This guide explains how low-level ("plumbing") Git commands relate to each other and how Git internally tracks files.

---

# 🧠 Core Mental Model

Git tracks content using three layers:

Working Directory → Index (Staging Area) → HEAD (Last Commit)

- Working Directory: Your actual files on disk
- Index: Snapshot of what will go into the next commit
- HEAD: The last committed snapshot

---

# 🔑 Key Plumbing Commands

## 1. git ls-files

Lists files from the index and compares against working directory.

git ls-files           # tracked files
git ls-files -m        # modified (unstaged)
git ls-files -d        # deleted
git ls-files -o --exclude-standard  # untracked
git ls-files -s        # staged details

---

## 2. git diff

Compares differences between layers.

git diff               # working directory vs index
git diff --cached      # index vs HEAD
git diff HEAD          # working directory vs HEAD

---

## 3. git update-index

Manually manipulate the index.

git update-index --add file.txt
git update-index --remove file.txt

Used internally by `git add`.

---

## 4. git hash-object

Creates a blob (object) from file content.

git hash-object file.txt

To write it into Git’s object database:

git hash-object -w file.txt

---

## 5. git cat-file

Inspect Git objects.

git cat-file -p <hash>

Types:
- blob (file content)
- tree (directory)
- commit (metadata)

---

## 6. git write-tree

Creates a tree object from the current index.

git write-tree

---

## 7. git read-tree

Loads a tree into the index.

git read-tree <tree-hash>

---

## 8. git commit-tree

Creates a commit manually.

echo "message" | git commit-tree <tree-hash>

---

# 🧭 Porcelain → Plumbing Mapping

| Porcelain (what you use) | What it does under the hood (simplified) |
|--------------------------|------------------------------------------|
| git add <file> | git hash-object -w → git update-index --add |
| git commit | git write-tree → git commit-tree → update HEAD |
| git status | git ls-files + git diff comparisons |
| git diff | Compares Working Dir ↔ Index ↔ HEAD |
| git checkout <ref> | git read-tree + update working directory |

---

# 🧱 Build Git From Scratch (Mini Walkthrough)

## 1) Create a file

echo "hello world" > file.txt

## 2) Create a blob

git hash-object -w file.txt

## 3) Add file to the index

git update-index --add file.txt

## 4) Create a tree

git write-tree

## 5) Create a commit object

echo "my first commit" | git commit-tree <tree-hash>

## 6) Point HEAD to the commit

git update-ref refs/heads/main <commit-hash>

---

# 🌳 How Git Stores Data Internally

Commit → Tree → Blob

- Blob: raw file contents
- Tree: directory structure
- Commit: snapshot + metadata

---

# 🔬 Inspecting Objects

git cat-file -p <commit-hash>
git cat-file -p <tree-hash>
git cat-file -p <blob-hash>

---

# ⚠️ Safety Notes

- These commands bypass safety checks
- You can corrupt your repo if used incorrectly
- Use for learning/debugging

---

# 🧠 Final Insight

Git is a snapshot system, not a diff system.

---

# 🎯 Next Steps

git ls-files -s
git cat-file -p <hash>
