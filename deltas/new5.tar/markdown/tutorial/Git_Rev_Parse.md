# Git Rev-Parse Tutorial

## What Is `git rev-parse`?

`git rev-parse` is a low-level git utility that translates human-readable references (branch names, tags, `HEAD`, relative expressions) into the concrete values that git uses internally -- primarily SHA-1 commit hashes, but also paths, booleans, and configuration data.

It is the command that other git commands and scripts use behind the scenes to resolve "what does this name actually point to?"

---

## 1. Resolving References to Commit Hashes

The most common use: turn a branch name, tag, or symbolic reference into a full 40-character SHA-1 hash.

```bash
# Resolve HEAD to its commit hash
git rev-parse HEAD
# Output: a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2

# Resolve a branch name
git rev-parse main
# Output: 7f8e9d0c1b2a3f4e5d6c7b8a9f0e1d2c3b4a5f6e

# Resolve a tag
git rev-parse v1.0.0
# Output: 3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d
```

### Short Hash

```bash
# Get the abbreviated (short) hash
git rev-parse --short HEAD
# Output: a1b2c3d

# Specify the length
git rev-parse --short=10 HEAD
# Output: a1b2c3d4e5
```

---

## 2. Relative References

Git supports a syntax for walking the commit graph relative to a known reference.

| Syntax | Meaning | Example |
|--------|---------|---------|
| `~N` | Go back N commits (first parent) | `HEAD~3` = three commits before HEAD |
| `^N` | Select the Nth parent of a merge | `HEAD^2` = second parent of a merge commit |

```bash
# The commit two steps before HEAD
git rev-parse HEAD~2

# The grandparent of the main branch
git rev-parse main~2

# The second parent of a merge commit
git rev-parse HEAD^2
```

---

## 3. Checking If You Are in a Git Repository

This is how `git rev-parse` is used in the Constants Catalog project. `GitService.java` runs:

```bash
git rev-parse --is-inside-work-tree
```

- **Inside a repo**: prints `true`, exits with code 0.
- **Outside a repo**: prints an error message, exits with code 128.

This is the standard programmatic way to answer "is this directory part of a git repo?"

### Related Checks

```bash
# Are we inside a bare repository?
git rev-parse --is-bare-repository
# Output: true or false

# Are we inside the .git directory itself?
git rev-parse --is-inside-git-dir
# Output: true or false
```

---

## 4. Finding Repository Paths

`git rev-parse` can tell you where key directories are, regardless of your current working directory within the repo.

```bash
# The root of the working tree (the top-level project directory)
git rev-parse --show-toplevel
# Output: /home/user/projects/my-app

# The path to the .git directory
git rev-parse --git-dir
# Output: /home/user/projects/my-app/.git

# Your current directory relative to the repo root
git rev-parse --show-prefix
# Output: src/main/java/   (if you are in that subdirectory)
```

### Practical Use

These are useful in scripts that need to work regardless of where the user invokes them:

```bash
# Always run from the repo root
cd "$(git rev-parse --show-toplevel)"
```

---

## 5. Verifying That a Reference Exists

The `--verify` flag checks whether a reference resolves to a valid object. It exits with code 0 on success and code 1 on failure, making it ideal for scripts.

```bash
# Does this branch exist?
git rev-parse --verify main
# Output: 7f8e9d0c1b2a... (exit code 0)

# Does this branch exist?
git rev-parse --verify nonexistent-branch
# fatal: Needed a single revision (exit code 1)
```

### Common Pattern: Check Before Acting

```bash
# Only create the branch if it does not already exist
if ! git rev-parse --verify my-feature 2>/dev/null; then
    git checkout -b my-feature
fi
```

---

## 6. Parsing Ranges

`git rev-parse` expands range expressions that commands like `git log` use.

```bash
# What does main..HEAD mean in terms of actual commits?
git rev-parse main..HEAD
# Output:
# ^7f8e9d0c1b2a3f4e5d6c7b8a9f0e1d2c3b4a5f6e   (exclude main)
#  a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2     (include HEAD)

# Triple-dot: symmetric difference (commits on either side, not both)
git rev-parse main...feature
```

The `^` prefix means "exclude this commit and its ancestors."

---

## 7. Disambiguating Arguments

When writing scripts, you may need to tell git "everything after this point is a file path, not a branch name." `git rev-parse` provides the separator:

```bash
# Separate revisions from file paths
git rev-parse --revs-only HEAD main feature
# Output: only the resolved hashes

git rev-parse --no-revs HEAD -- file.txt
# Output: only the non-revision arguments (file paths)
```

This matters when a file and a branch have the same name:

```bash
# Ambiguous: is "main" a branch or a file?
git log main

# Unambiguous
git log main --
```

---

## 8. Quick Reference

| Command | Output |
|---------|--------|
| `git rev-parse HEAD` | Full SHA-1 of current commit |
| `git rev-parse --short HEAD` | Abbreviated SHA-1 |
| `git rev-parse --verify <ref>` | SHA-1 if valid, error if not |
| `git rev-parse --is-inside-work-tree` | `true` or error |
| `git rev-parse --show-toplevel` | Absolute path to repo root |
| `git rev-parse --git-dir` | Path to `.git` directory |
| `git rev-parse --show-prefix` | Current dir relative to root |
| `git rev-parse --is-bare-repository` | `true` or `false` |
| `git rev-parse HEAD~3` | SHA-1 of 3 commits ago |
| `git rev-parse --abbrev-ref HEAD` | Current branch name (e.g., `main`) |

---

## 9. How the Constants Catalog Uses It

In `GitService.java`, the `isGitRepo()` method runs:

```java
private String runGitCommand(Path workingDir, String... args) throws GitException {
    // Builds: ["git", "rev-parse", "--is-inside-work-tree"]
    // Runs via ProcessBuilder with workingDir as the CWD
    // Returns stdout.trim() on success, throws GitException on failure
}

public boolean isGitRepo(Path projectDir) throws GitException {
    try {
        String result = runGitCommand(projectDir, "rev-parse", "--is-inside-work-tree");
        return "true".equals(result);
    } catch (GitException e) {
        return false;
    }
}
```

Similarly, `getCurrentBranch()` uses:

```bash
git rev-parse --abbrev-ref HEAD
```

This returns the human-readable branch name (e.g., `feature/auth`) rather than the full commit hash -- the `--abbrev-ref` flag resolves the symbolic reference to its short name.
