# GitService Usage in the Constants Catalog

This document maps every place `GitService` is referenced in the codebase, with file paths, line numbers, and context to help you understand and extend the git-based transformation workflow.

---

## 1. GitService Definition

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/GitService.java`

A Spring `@Service` that wraps git CLI commands via `ProcessBuilder`. No external dependencies (no JGit). All commands enforce a 30-second timeout.

### Public Methods

| Method | Line | Signature | What It Does |
|--------|------|-----------|--------------|
| `isGitRepo` | 24 | `boolean isGitRepo(Path projectDir)` | Runs `git rev-parse --is-inside-work-tree`. Returns `true` if inside a git repo, `false` otherwise. Never throws. |
| `getCurrentBranch` | 36 | `String getCurrentBranch(Path projectDir) throws GitException` | Runs `git rev-parse --abbrev-ref HEAD`. Returns the branch name (e.g., `"main"`, `"feature/auth"`). |
| `createAndCheckoutBranch` | 43 | `void createAndCheckoutBranch(Path projectDir, String branchName) throws GitException` | Runs `git checkout -b <branchName>`. Fails if the branch already exists. |
| `checkoutBranch` | 51 | `void checkoutBranch(Path projectDir, String branchName) throws GitException` | Runs `git checkout <branchName>`. Fails if the branch does not exist. |
| `addAndCommit` | 59 | `void addAndCommit(Path projectDir, String message) throws GitException` | Runs `git add -A` then `git commit -m <message>`. Stages everything and commits. |
| `initRepoWithInitialCommit` | 76 | `String initRepoWithInitialCommit(Path projectDir) throws GitException` | Runs `git init`, sets local user identity, stages all files, commits as "Initial state (pre-transformation)", renames branch to `main`. Returns `"main"`. |

### Internal Helpers

| Method | Line | Purpose |
|--------|------|---------|
| `runGit` | 94 | Executes a git command, returns exit code. Throws `GitException` on non-zero exit or timeout. |
| `runGitOutput` | 127 | Same as `runGit` but returns the stdout string instead of the exit code. Used by `getCurrentBranch`. |

### Exception Class

| Class | Line | Description |
|-------|------|-------------|
| `GitException` | 163 | Checked exception. Inner class of `GitService`. Two constructors: `(String message)` and `(String message, Throwable cause)`. |

---

## 2. GitService Consumer: CodeTransformationService

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/CodeTransformationService.java`

This is where `GitService` is called to create branches with transformed files. There are **6 references** to `GitService` in this file:

### 2.1 Field Declaration

**Line 44:**
```java
private final GitService gitService;
```
Holds the injected `GitService` instance.

### 2.2 Constructor Injection

**Line 46-50:**
```java
public CodeTransformationService(Neo4jClient neo4jClient, GitService gitService) {
    this.neo4jClient = neo4jClient;
    this.transformer = new ConfigLookupTransformer();
    this.gitService = gitService;
}
```
Spring injects `GitService` alongside `Neo4jClient`. No `@Autowired` annotation needed because there is only one constructor.

### 2.3 Branch Creation Method

**Method:** `createBranchWithTransformedFiles` (line 207)

This private method is the heart of the git integration. It is called at **line 129** from the `transform` method during Phase 2.5:

```java
if (request.isCreateBranch() && !request.isDryRun() && result.totalTransformed() > 0) {
    branchResult = createBranchWithTransformedFiles(projectPath, result);
}
```

**Three preconditions** must all be true:
1. `createBranch == true` (user checked the checkbox)
2. `dryRun == false` (not a preview)
3. At least one file was actually transformed

### 2.4 GitService Calls Inside `createBranchWithTransformedFiles`

The method calls `GitService` methods in this sequence:

| Step | Line | Call | Purpose |
|------|------|------|---------|
| 1 | 212 | `gitService.isGitRepo(projectDir)` | Check if the project is a git repo |
| 2a | 214 | `gitService.initRepoWithInitialCommit(projectDir)` | If NOT a git repo: initialise one with a baseline commit on `main` |
| 2b | 216 | `gitService.getCurrentBranch(projectDir)` | If IS a git repo: get the current branch name |
| 3 | 230 | `gitService.createAndCheckoutBranch(projectDir, newBranch)` | Create `<original>-transformed` and switch to it |
| 4 | 247 | `gitService.addAndCommit(projectDir, "Transform constants to config lookups")` | Stage and commit the copied transformed files |
| 5 | 248 | `gitService.checkoutBranch(projectDir, originalBranch)` | Switch back to the original branch |

### 2.5 Error Handling and Rollback

**Lines 253-264:**
```java
} catch (GitService.GitException | IOException e) {
    log.error("Failed to create branch with transformed files", e);
    if (originalBranch != null) {
        try {
            gitService.checkoutBranch(projectDir, originalBranch);
        } catch (GitService.GitException rollbackEx) {
            log.error("Rollback failed — could not checkout original branch '{}'",
                       originalBranch, rollbackEx);
        }
    }
    return BranchResult.failure(e.getMessage());
}
```

If any step fails:
1. The catch block catches both `GitService.GitException` and `IOException` (from file copy)
2. It attempts to roll back by checking out the original branch
3. If rollback itself fails, it logs the error (manual intervention needed)
4. Returns `BranchResult.failure(...)` so the response includes the error message but the transformation results (in `backups/`) are still available

### 2.6 File Copy Logic Between Git Steps

**Lines 233-245** (between `createAndCheckoutBranch` and `addAndCommit`):
```java
Path backupsDir = Path.of("backups").toAbsolutePath();
for (String filePath : transformedFiles) {
    Path absSource = Paths.get(filePath).toAbsolutePath();
    Path relPath = absSource.getRoot().relativize(absSource);
    Path backupPath = backupsDir.resolve(relPath);

    if (Files.exists(backupPath)) {
        Files.copy(backupPath, absSource, StandardCopyOption.REPLACE_EXISTING);
    }
}
```

This copies each transformed file from `backups/<relative-path>` back to its original source location. The files are deduplicated using a `LinkedHashSet` (line 221-224) so each file is copied exactly once.

---

## 3. BranchResult Record

**File:** `CodeTransformationService.java`, **lines 184-194**

```java
private record BranchResult(String branchName, String error) {
    static final BranchResult SKIPPED = new BranchResult(null, null);

    static BranchResult success(String branchName) {
        return new BranchResult(branchName, null);
    }

    static BranchResult failure(String error) {
        return new BranchResult(null, error);
    }
}
```

Three states:
| Factory | `branchName` | `error` | Meaning |
|---------|-------------|---------|---------|
| `SKIPPED` | `null` | `null` | Branch creation was not attempted |
| `success(name)` | `"main-transformed"` | `null` | Branch created and committed |
| `failure(msg)` | `null` | `"branch exists"` | Branch creation failed |

---

## 4. Test Coverage

**File:** `const-catalog-backend/src/test/java/com/boeing/constcatalog/backend/service/GitServiceTest.java`

Plain JUnit 5 tests (no Spring context). Each test creates a temporary git repo in a `@TempDir`.

| Nested Class | Test Method | Line | What It Verifies |
|---|---|---|---|
| `IsGitRepo` | `returnsTrueForGitRepo` | 41 | `isGitRepo` returns `true` inside a git repo |
| `IsGitRepo` | `returnsFalseForNonGitDir` | 46 | `isGitRepo` returns `false` for a plain directory |
| `GetCurrentBranch` | `returnsDefaultBranch` | 55 | `getCurrentBranch` returns a non-blank string |
| `CreateAndCheckoutBranch` | `createsAndSwitchesToNewBranch` | 66 | Creates branch, verifies `getCurrentBranch` returns new name |
| `CreateAndCheckoutBranch` | `failsIfBranchAlreadyExists` | 72 | Throws `GitException` when creating a duplicate branch |
| `CheckoutBranch` | `switchesToExistingBranch` | 91 | Switches away and back, verifies branch name |
| `CheckoutBranch` | `failsForNonexistentBranch` | 101 | Throws `GitException` for a branch that does not exist |
| `AddAndCommit` | `commitsNewFiles` | 111 | Writes a new file, commits, verifies git log |
| `AddAndCommit` | `commitsModifiedFiles` | 122 | Modifies an existing file, commits, verifies git log |
| `FullWorkflow` | `createBranchCommitAndSwitchBack` | 135 | End-to-end: create branch, add file, commit, switch back, verify file absent on original, present on new branch |
| `InitRepoWithInitialCommit` | `initialisesRepoInBareDirectory` | 163 | Initialises repo in a non-git directory, verifies branch is `main` |
| `InitRepoWithInitialCommit` | `commitsExistingFilesAsBaseline` | 174 | Verifies pre-existing files are committed |
| `InitRepoWithInitialCommit` | `branchIsAlwaysMain` | 188 | Branch name is always normalised to `main` |
| `InitRepoWithInitialCommit` | `transformedBranchCanBeGitDiffedAgainstMain` | 197 | Full flow: init, create branch, transform, switch back, `git diff` is non-empty |

### Test Helper Methods

| Method | Line | Purpose |
|--------|------|---------|
| `run(String... args)` | 226 | Runs a command in the `@TempDir` |
| `runIn(Path dir, String... args)` | 230 | Runs a command in an arbitrary directory; throws on non-zero exit (except `rev-parse`) |

### Running the Tests

```bash
# Run only GitService tests
mvn test -pl const-catalog-backend -am \
    -Dtest=GitServiceTest \
    -Dsurefire.failIfNoSpecifiedTests=false

# Run all backend tests
mvn test -pl const-catalog-backend -am
```

---

## 5. Call Flow Summary

```
TransformPage.tsx
  └─ POST /api/transform { createBranch: true, dryRun: false }
      └─ TransformController.transformProject()
          └─ CodeTransformationService.transform()              [line 57]
              ├─ Phase 1: Query Neo4j for candidates
              ├─ Phase 2: ConfigLookupTransformer writes to backups/
              ├─ Phase 2.5: createBranchWithTransformedFiles()  [line 129]
              │   ├─ gitService.isGitRepo()                     [line 212]
              │   ├─ gitService.initRepoWithInitialCommit()     [line 214, if not a repo]
              │   │   └─ git init → config → add -A → commit → branch -m main
              │   ├─ gitService.getCurrentBranch()              [line 216, if already a repo]
              │   ├─ gitService.createAndCheckoutBranch()       [line 230]
              │   │   └─ git checkout -b <branch>-transformed
              │   ├─ Files.copy() for each transformed file     [lines 234-245]
              │   ├─ gitService.addAndCommit()                  [line 247]
              │   │   └─ git add -A → git commit -m "..."
              │   ├─ gitService.checkoutBranch()                [line 248]
              │   │   └─ git checkout <original-branch>
              │   └─ On failure: gitService.checkoutBranch()    [line 258, rollback]
              └─ Phase 3: Build TransformResponse
```

---

## 6. Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| **ProcessBuilder over JGit** | Avoids a heavyweight dependency. The five git operations needed are simple CLI commands. `ProcessBuilder` is JDK-standard. |
| **30-second timeout** | Prevents hanging if git encounters lock files, prompts for credentials, or network issues. |
| **Checked exception (`GitException`)** | Forces callers to handle failures explicitly. The caller (`CodeTransformationService`) catches and rolls back. |
| **Inner class for `GitException`** | Keeps it scoped to `GitService` since no other service throws git errors. |
| **`initRepoWithInitialCommit` for non-git projects** | Allows the "Create Branch" feature to work even on projects not yet under version control. Creates a clean baseline for `git diff`. |
| **Copy from backups, not in-place modification** | The transformer always writes to `backups/`. The branch workflow copies from there. This keeps the original read-only source safe and reuses the existing backup mechanism. |
| **`LinkedHashSet` for file deduplication** | Multiple transformation entries can target the same file. The set ensures each file is copied exactly once while preserving insertion order. |
| **Mutual exclusion with dry run** | A dry run produces no transformed files, so creating a branch would be meaningless. Enforced in both UI (checkbox disabling) and backend (conditional check). |
