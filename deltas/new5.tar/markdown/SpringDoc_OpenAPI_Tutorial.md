# SpringDoc OpenAPI Tutorial

SpringDoc OpenAPI is a library that auto-generates OpenAPI 3.0 documentation from Spring Boot applications and serves an interactive Swagger UI for testing endpoints. It inspects your controllers, DTOs, and annotations to produce a live API specification without maintaining a separate document.

**Library:** [springdoc-openapi](https://springdoc.org/)

## Table of Contents

1. [What Problem Does SpringDoc Solve?](#what-problem-does-springdoc-solve)
2. [Getting Started](#getting-started)
3. [How It Works](#how-it-works)
4. [Annotation Reference](#annotation-reference)
5. [Annotating Controllers](#annotating-controllers)
6. [Annotating DTOs](#annotating-dtos)
7. [Annotating Request Parameters](#annotating-request-parameters)
8. [Annotating Request Bodies](#annotating-request-bodies)
9. [Providing Response Examples](#providing-response-examples)
10. [Multiple Examples](#multiple-examples)
11. [How This Project Uses SpringDoc](#how-this-project-uses-springdoc)
12. [Configuration](#configuration)
13. [Best Practices](#best-practices)
14. [Common Pitfalls](#common-pitfalls)
15. [Quick Reference](#quick-reference)

---

## What Problem Does SpringDoc Solve?

REST APIs need documentation. Without it, consumers have to read source code or guess at endpoints. The two traditional approaches each have drawbacks:

| Approach | Pros | Cons |
|----------|------|------|
| **Manual docs** (Wiki, Confluence) | Flexible formatting | Gets stale as code changes |
| **Postman collections** | Testable | Separate artifact to maintain |
| **SpringDoc OpenAPI** | Auto-generated, always current, interactive | Requires annotations for rich docs |

SpringDoc bridges the gap: it auto-generates an OpenAPI 3.0 spec from your code and serves an interactive UI where developers can read documentation *and* test endpoints directly.

```mermaid
graph LR
    subgraph "Your Spring Boot App"
        C["@RestController<br/>+ OpenAPI Annotations"]
        D["DTOs<br/>+ @Schema Annotations"]
    end

    subgraph "SpringDoc"
        GEN["Annotation Scanner"]
        SPEC["OpenAPI 3.0 Spec<br/>/v3/api-docs"]
        UI["Swagger UI<br/>/swagger-ui.html"]
    end

    C --> GEN
    D --> GEN
    GEN --> SPEC
    SPEC --> UI
```

**Without annotations**, SpringDoc still generates basic documentation by inspecting your `@RequestMapping`, method parameters, and return types. **With annotations**, you add descriptions, examples, and response codes that make the docs genuinely useful.

---

## Getting Started

### Maven Dependency

```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.3.0</version>
</dependency>
```

That's it. No additional configuration required. Start your application and visit:

- **Swagger UI:** `http://localhost:8080/swagger-ui.html`
- **OpenAPI JSON:** `http://localhost:8080/v3/api-docs`

### Gradle Dependency

```groovy
implementation 'org.springdoc:springdoc-openapi-starter-webmvc-ui:2.3.0'
```

---

## How It Works

SpringDoc operates at startup and request time:

```mermaid
sequenceDiagram
    participant App as Spring Boot App
    participant SD as SpringDoc
    participant UI as Swagger UI
    participant Dev as Developer

    App->>SD: Application starts
    SD->>SD: Scan @RestController classes
    SD->>SD: Scan @Schema-annotated DTOs
    SD->>SD: Build OpenAPI 3.0 model

    Dev->>UI: GET /swagger-ui.html
    UI->>SD: GET /v3/api-docs
    SD->>UI: Return OpenAPI JSON spec
    UI->>Dev: Render interactive documentation

    Dev->>UI: Click "Try it out"
    UI->>App: Send actual HTTP request
    App->>UI: Return response
    UI->>Dev: Display formatted response
```

1. **Startup**: SpringDoc scans all `@RestController` classes and their annotations
2. **Model Building**: It constructs an OpenAPI 3.0 model from `@Operation`, `@Schema`, `@ApiResponse`, etc.
3. **Serving**: The `/v3/api-docs` endpoint returns the JSON spec; Swagger UI renders it
4. **Testing**: Developers can execute requests directly from the UI

---

## Annotation Reference

All annotations come from the `io.swagger.v3.oas.annotations` package. Here's the hierarchy:

```mermaid
graph TD
    TAG["@Tag<br/><i>Groups endpoints</i>"]
    OP["@Operation<br/><i>Documents one endpoint</i>"]
    AR["@ApiResponses<br/><i>Container for responses</i>"]
    RESP["@ApiResponse<br/><i>One HTTP status code</i>"]
    CONT["@Content<br/><i>Response body format</i>"]
    SCH["@Schema<br/><i>Data model shape</i>"]
    EX["@ExampleObject<br/><i>JSON example</i>"]
    PARAM["@Parameter<br/><i>Query/path param</i>"]
    RB["@RequestBody<br/><i>Request body docs</i>"]

    TAG --> OP
    OP --> AR
    AR --> RESP
    RESP --> CONT
    CONT --> SCH
    CONT --> EX
    OP --> PARAM
    OP --> RB
    RB --> CONT
```

| Annotation | Applies To | Purpose |
|-----------|-----------|---------|
| `@Tag` | Class | Groups endpoints under a collapsible section |
| `@Operation` | Method | Describes a single endpoint (summary, description) |
| `@ApiResponses` | Method | Container for multiple `@ApiResponse` entries |
| `@ApiResponse` | Method | Documents one HTTP status code and its body |
| `@Content` | Inside `@ApiResponse` | Specifies media type, schema, and examples |
| `@Schema` | Class or Field | Describes a data model or individual field |
| `@ExampleObject` | Inside `@Content` | Provides a concrete JSON example |
| `@Parameter` | Method param | Documents a query or path parameter |
| `@RequestBody` | Method param | Documents the request body |

---

## Annotating Controllers

### @Tag - Grouping Endpoints

`@Tag` is placed on the controller class. It creates a named, collapsible section in Swagger UI:

```java
@RestController
@RequestMapping("/api/scan")
@Tag(name = "Scan",
     description = "Project scanning operations - discover constants and parameters")
public class ScanController {
    // All endpoints in this class appear under the "Scan" group
}
```

**In Swagger UI, this renders as:**

```
v Scan
  Project scanning operations - discover constants and parameters
  ├── POST /api/scan          Scan a Java project
  └── GET  /api/scan/stream   Stream scan progress via SSE
```

### @Operation - Documenting an Endpoint

`@Operation` is placed on each handler method. It provides a short `summary` (shown in the collapsed view) and a longer `description` (shown when expanded):

```java
@Operation(
    summary = "Scan a Java project",
    description = """
        Scans a Java project directory to discover constants and configuration parameters.

        **The scan process:**
        1. Validates the path exists and is a directory
        2. Walks the file tree to find Java and property files
        3. Parses each file to extract constants
        4. Populates the Neo4j graph with nodes and relationships

        **Scanning is idempotent:** Re-scanning updates existing nodes rather than
        creating duplicates.
        """
)
@PostMapping
public ResponseEntity<ScanResponse> scanProject(@RequestBody ScanRequest request) {
    // ...
}
```

The `description` supports **Markdown formatting** - bold, lists, code blocks, and links all render correctly in Swagger UI. Use text blocks (`"""`) for multi-line descriptions.

### @ApiResponses and @ApiResponse - Documenting Status Codes

`@ApiResponses` wraps multiple `@ApiResponse` entries, each documenting a possible HTTP status code:

```java
@ApiResponses({
    @ApiResponse(
        responseCode = "200",
        description = "Scan completed successfully",
        content = @Content(
            mediaType = "application/json",
            schema = @Schema(implementation = ScanResponse.class)
        )
    ),
    @ApiResponse(
        responseCode = "400",
        description = "Invalid request - path does not exist or is not a directory"
    ),
    @ApiResponse(
        responseCode = "500",
        description = "Internal server error during scan"
    )
})
@PostMapping
public ResponseEntity<ScanResponse> scanProject(...) { ... }
```

Each `@ApiResponse` has:

| Attribute | Purpose | Example |
|-----------|---------|---------|
| `responseCode` | HTTP status code as a string | `"200"`, `"400"`, `"500"` |
| `description` | Human-readable explanation | `"Scan completed successfully"` |
| `content` | Optional body schema and examples | `@Content(...)` |

### Putting It All Together

Here's a complete annotated endpoint from the project's `StatsController`:

```java
@RestController
@RequestMapping("/api/stats")
@Tag(name = "Statistics",
     description = "Database statistics and dashboard data from Neo4j")
public class StatsController {

    @Operation(
        summary = "Get database statistics",
        description = """
            Returns high-level statistics about the graph database.

            Includes:
            - Total counts of projects, files, constants, and parameters
            - Constants grouped by type (String, int, etc.)
            - Most used parameters by usage count
            """
    )
    @ApiResponses({
        @ApiResponse(
            responseCode = "200",
            description = "Statistics retrieved successfully",
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = StatsResponse.class),
                examples = @ExampleObject(
                    value = """
                        {
                            "projectCount": 3,
                            "fileCount": 450,
                            "constantCount": 1250,
                            "parameterCount": 95
                        }
                        """
                )
            )
        )
    })
    @GetMapping
    public ResponseEntity<StatsResponse> getStats() { ... }
}
```

---

## Annotating DTOs

### @Schema on Classes

`@Schema` at the class level describes what the DTO represents:

```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request to scan a Java project for constants and parameters")
public class ScanRequest {
    // ...
}
```

### @Schema on Fields

Field-level `@Schema` adds description, example values, and constraints to each property:

```java
@Schema(description = "Response containing scan results and statistics")
public class ScanResponse {

    @Schema(description = "Whether the scan completed successfully", example = "true")
    private boolean success;

    @Schema(description = "Status message or error description",
            example = "Scan completed successfully")
    private String message;

    @Schema(description = "Path to the scanned project",
            example = "/home/user/projects/my-app")
    private String projectPath;

    @Schema(description = "Number of Java source files scanned", example = "150")
    private int javaFilesScanned;

    @Schema(description = "Number of static final constants discovered", example = "487")
    private int constantsFound;
}
```

**In Swagger UI**, these render as a structured model with each field's description and example value shown alongside it. The `example` values also pre-populate the "Try it out" form.

### @Schema Attributes

| Attribute | Type | Purpose |
|-----------|------|---------|
| `description` | String | Explains what the field represents |
| `example` | String | A sample value shown in the UI |
| `required` | boolean | Whether the field is mandatory |
| `implementation` | Class | Links to a Java class for the schema |
| `defaultValue` | String | Default value if not provided |
| `allowableValues` | String[] | Enumerated valid values |
| `minimum` | String | Minimum numeric value |
| `maximum` | String | Maximum numeric value |

### Combining @Schema with Jakarta Validation

`@Schema` documents what Swagger UI shows. Jakarta validation annotations (`@NotBlank`, `@NotNull`, etc.) enforce the rules at runtime. Use both together:

```java
@Schema(description = "Request to transform constants into property lookups")
public class TransformRequest {

    @NotBlank(message = "Project path is required")          // Runtime validation
    @Schema(                                                  // Documentation
        description = "Absolute path to the project",
        example = "/home/user/projects/my-app",
        required = true
    )
    private String projectPath;

    @Builder.Default
    @Schema(
        description = "If true, report what would change without modifying files",
        example = "false"
    )
    private boolean dryRun = false;
}
```

SpringDoc detects Jakarta validation annotations and automatically marks `@NotBlank`/`@NotNull` fields as required in the OpenAPI spec. The `@Schema(required = true)` reinforces this in the UI.

### Nested DTOs

For response objects with inner classes, annotate each level:

```java
@Schema(description = "Response containing code transformation results")
public class TransformResponse {

    @Schema(description = "Whether the transformation completed successfully")
    private boolean success;

    @Schema(description = "Individual transformation entries")
    private List<EntryDto> entries;

    @Schema(description = "Individual constant transformation result")
    public static class EntryDto {

        @Schema(description = "Path to the source file")
        private String filePath;

        @Schema(description = "Original file content before transformation")
        private String originalContent;
    }
}
```

Swagger UI renders this as an expandable tree - clicking on `entries` expands to show the `EntryDto` schema with all its fields.

---

## Annotating Request Parameters

### @Parameter - Query and Path Parameters

Use `@Parameter` to document `@RequestParam` and `@PathVariable` arguments:

```java
@GetMapping("/constants")
public ResponseEntity<List<ConstantNode>> getConstants(

        @Parameter(description = "Filter by Java type", example = "String")
        @RequestParam(name = "type", required = false) String type,

        @Parameter(description = "Filter by declaring class name", example = "Config")
        @RequestParam(name = "className", required = false) String className) {
    // ...
}
```

For path variables:

```java
@GetMapping("/precanned/{queryId}")
public ResponseEntity<QueryResponse> executePreCannedQuery(

        @Parameter(
            description = "ID of the pre-canned query to execute",
            example = "config-candidates",
            required = true
        )
        @PathVariable("queryId") String queryId) {
    // ...
}
```

**In Swagger UI**, each parameter gets its own input field with the description as a label and the example pre-filled.

---

## Annotating Request Bodies

### @RequestBody (OpenAPI version)

Spring's `@RequestBody` deserializes JSON. The OpenAPI `@RequestBody` (from `io.swagger.v3.oas.annotations.parameters`) documents what the body should look like:

```java
@PostMapping
public ResponseEntity<ScanResponse> scanProject(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Scan request with project path",
            required = true,
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = ScanRequest.class)
            )
        )
        @Valid @RequestBody ScanRequest request) {
    // ...
}
```

Note: Both annotations are named `@RequestBody`. The OpenAPI one must be fully qualified (`io.swagger.v3.oas.annotations.parameters.RequestBody`) to avoid conflict with Spring's `org.springframework.web.bind.annotation.RequestBody`.

---

## Providing Response Examples

### @ExampleObject - Inline JSON Examples

`@ExampleObject` provides concrete JSON that appears in Swagger UI's response section:

```java
@ApiResponse(
    responseCode = "200",
    description = "Query executed successfully",
    content = @Content(
        mediaType = "application/json",
        schema = @Schema(implementation = QueryResponse.class),
        examples = @ExampleObject(
            value = """
                {
                    "success": true,
                    "columns": ["name", "value", "type"],
                    "rows": [
                        {"name": "DB_HOST", "value": "localhost", "type": "String"},
                        {"name": "DB_PORT", "value": "5432", "type": "int"}
                    ],
                    "rowCount": 2
                }
                """
        )
    )
)
```

The `schema` tells Swagger UI the data structure (for model documentation). The `examples` show what an actual response looks like (for human readability). Use both together.

---

## Multiple Examples

### Named Examples for Different Scenarios

When an endpoint can return different shapes of data, provide multiple named examples:

```java
@PostMapping
public ResponseEntity<ScanResponse> scanProject(
        @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Scan request with project path",
            required = true,
            content = @Content(
                mediaType = "application/json",
                schema = @Schema(implementation = ScanRequest.class),
                examples = {
                    @ExampleObject(
                        name = "Unix Path",
                        value = """
                            {"projectPath": "/home/user/projects/my-app"}
                            """
                    ),
                    @ExampleObject(
                        name = "Windows Path",
                        value = """
                            {"projectPath": "C:\\\\Users\\\\dev\\\\projects\\\\my-app"}
                            """
                    )
                }
            )
        )
        @Valid @RequestBody ScanRequest request) {
    // ...
}
```

**In Swagger UI**, a dropdown appears letting the user switch between "Unix Path" and "Windows Path" examples.

### Multiple Response Examples

The same technique works for responses - show success and failure cases:

```java
@ApiResponses({
    @ApiResponse(
        responseCode = "200",
        description = "Service is healthy",
        content = @Content(
            mediaType = "application/json",
            examples = @ExampleObject(
                value = """
                    {
                        "status": "healthy",
                        "database": "connected",
                        "projectCount": 5
                    }
                    """
            )
        )
    ),
    @ApiResponse(
        responseCode = "500",
        description = "Service is unhealthy",
        content = @Content(
            mediaType = "application/json",
            examples = @ExampleObject(
                value = """
                    {
                        "status": "unhealthy",
                        "error": "Connection refused"
                    }
                    """
            )
        )
    )
})
@GetMapping("/health")
public ResponseEntity<Map<String, Object>> healthCheck() { ... }
```

---

## How This Project Uses SpringDoc

The Constants Catalog uses SpringDoc across all controllers. Here's the annotation map:

```mermaid
graph TD
    subgraph "Controllers"
        SCAN["ScanController<br/>@Tag: Scan"]
        QUERY["QueryController<br/>@Tag: Query"]
        STATS["StatsController<br/>@Tag: Statistics"]
        TRANSFORM["TransformController<br/>@Tag: Transform"]
        FILES["FileController<br/>@Tag: Files"]
    end

    subgraph "DTOs with @Schema"
        SR["ScanRequest"]
        SRESP["ScanResponse"]
        QR["QueryRequest"]
        QRESP["QueryResponse"]
        TR["TransformRequest"]
        TRESP["TransformResponse"]
        STRESP["StatsResponse"]
    end

    SCAN --> SR
    SCAN --> SRESP
    QUERY --> QR
    QUERY --> QRESP
    STATS --> STRESP
    TRANSFORM --> TR
    TRANSFORM --> TRESP
```

### Swagger UI Access

With the backend running:

| URL | Content |
|-----|---------|
| `http://localhost:8080/swagger-ui.html` | Interactive API browser |
| `http://localhost:8080/v3/api-docs` | Raw OpenAPI 3.0 JSON spec |

### Configuration in application.yml

```yaml
springdoc:
  api-docs:
    path: /v3/api-docs
    enabled: true
  swagger-ui:
    path: /swagger-ui.html
    enabled: true
    operations-sorter: method        # Sort by HTTP method (GET, POST, etc.)
    tags-sorter: alpha               # Sort tag groups alphabetically
    display-request-duration: true   # Show how long requests take
    filter: true                     # Add a search/filter bar
    show-extensions: true
    show-common-extensions: true
  default-consumes-media-type: application/json
  default-produces-media-type: application/json
```

---

## Configuration

### Disabling in Production

If you don't want Swagger UI exposed in production:

```yaml
# application-prod.yml
springdoc:
  api-docs:
    enabled: false
  swagger-ui:
    enabled: false
```

### Customizing the API Info

Add global metadata with a `@Bean`:

```java
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Constants Catalog API")
                .version("1.0.0")
                .description("REST API for scanning, querying, and transforming Java constants")
            );
    }
}
```

### Grouping APIs

For large applications, split the spec into groups:

```yaml
springdoc:
  group-configs:
    - group: scan
      paths-to-match: /api/scan/**
    - group: query
      paths-to-match: /api/query/**
    - group: transform
      paths-to-match: /api/transform/**
```

---

## Best Practices

1. **Always add `@Tag` to controllers.** Without it, Swagger UI groups endpoints under a default name derived from the class name (e.g., "scan-controller" instead of "Scan").

2. **Write the `summary` for scanning, the `description` for reading.** Keep `summary` under 60 characters - it's the one-liner shown in the collapsed endpoint list. Put details, lists, and code examples in `description`.

3. **Use text blocks for descriptions and examples.** Java text blocks (`"""`) make multi-line JSON and Markdown readable in source code:

    ```java
    @Operation(
        summary = "Short one-liner",
        description = """
            Detailed explanation with **Markdown** support.

            - Bullet points work
            - So do `code spans`
            """
    )
    ```

4. **Provide `@ExampleObject` for non-trivial responses.** The `@Schema` tells consumers the *structure*; the `@ExampleObject` shows them a *realistic* response. Both are valuable.

5. **Annotate DTOs with `@Schema` descriptions and examples.** Field-level `@Schema(example = "...")` values pre-populate the "Try it out" form, making the API immediately testable.

6. **Document error responses, not just successes.** Show what a 400 or 500 response looks like so consumers can handle errors correctly:

    ```java
    @ApiResponse(
        responseCode = "400",
        description = "Invalid request",
        content = @Content(
            examples = @ExampleObject(
                value = """
                    {"success": false, "message": "Path does not exist: /invalid/path"}
                    """
            )
        )
    )
    ```

7. **Use Jakarta validation alongside `@Schema`.** `@NotBlank` enforces at runtime; `@Schema(required = true)` documents in the UI. Both serve different purposes.

---

## Common Pitfalls

### 1. Confusing the Two @RequestBody Annotations

Spring and OpenAPI both define `@RequestBody`. You need both, and the OpenAPI one must be fully qualified:

```java
// WRONG - compiler error, ambiguous import
@RequestBody  // Which one?

// CORRECT - fully qualify the OpenAPI one
@io.swagger.v3.oas.annotations.parameters.RequestBody(
    description = "Scan request with project path",
    content = @Content(schema = @Schema(implementation = ScanRequest.class))
)
@org.springframework.web.bind.annotation.RequestBody ScanRequest request
```

### 2. Missing @Content Wrapper

`@Schema` and `@ExampleObject` must be wrapped in `@Content`:

```java
// WRONG - @Schema directly in @ApiResponse
@ApiResponse(responseCode = "200", schema = @Schema(...))

// CORRECT - @Schema inside @Content
@ApiResponse(
    responseCode = "200",
    content = @Content(
        mediaType = "application/json",
        schema = @Schema(implementation = ScanResponse.class)
    )
)
```

### 3. Forgetting mediaType

If you omit `mediaType` in `@Content`, Swagger UI may default to `*/*` instead of `application/json`:

```java
// Specify the media type explicitly
content = @Content(mediaType = "application/json", ...)
```

Or set the global default in `application.yml`:

```yaml
springdoc:
  default-produces-media-type: application/json
```

### 4. Example Strings Must Be Valid JSON

`@ExampleObject(value = "...")` must contain valid JSON. Common mistakes:

```java
// WRONG - single quotes aren't valid JSON
value = "{'success': true}"

// WRONG - trailing comma
value = """
    {"success": true, "count": 5,}
    """

// CORRECT
value = """
    {"success": true, "count": 5}
    """
```

### 5. Boolean Field Getters in Lombok

Lombok generates `isSuccess()` for `boolean success`, not `getSuccess()`. Jackson handles this correctly, but be aware when writing `@Schema(example = "...")` - the JSON key is `"success"`, not `"isSuccess"`.

---

## Quick Reference

### Minimal Annotated Controller

```java
@RestController
@RequestMapping("/api/example")
@Tag(name = "Example", description = "Example operations")
public class ExampleController {

    @Operation(summary = "Get an item by ID")
    @ApiResponse(responseCode = "200", description = "Item found")
    @ApiResponse(responseCode = "404", description = "Item not found")
    @GetMapping("/{id}")
    public ResponseEntity<Item> getItem(
            @Parameter(description = "Item ID", example = "42")
            @PathVariable Long id) {
        // ...
    }
}
```

### Minimal Annotated DTO

```java
@Data
@Schema(description = "An item in the catalog")
public class Item {

    @Schema(description = "Unique identifier", example = "42")
    private Long id;

    @Schema(description = "Display name", example = "Widget")
    private String name;
}
```

### Annotation Cheat Sheet

```
Controller class:
  @Tag(name, description)

Endpoint method:
  @Operation(summary, description)
  @ApiResponses({
      @ApiResponse(responseCode, description, content)
  })

Response body:
  @Content(mediaType, schema, examples)
  @Schema(implementation = MyDto.class)
  @ExampleObject(name, value)

Method parameters:
  @Parameter(description, example, required)

Request body:
  @io.swagger.v3.oas.annotations.parameters.RequestBody(
      description, required, content)

DTO class:
  @Schema(description)

DTO field:
  @Schema(description, example, required, defaultValue)
```

### Import Statements

```java
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
```
