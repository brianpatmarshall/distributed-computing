# Constants Catalog - High Level Architecture Document

## 1. System Overview

The Constants Catalog is a multi-module Java 21 application that scans Java projects to discover hardcoded constants and configuration parameters, stores them as a graph in Neo4j, and provides tools to query, visualize, export, and transform them into externalized Spring `@Value` property lookups.

```mermaid
graph TB
    subgraph "User Interfaces"
        UI[React Frontend<br/>Space Command Theme]
        CLI[CLI Tool<br/>const-catalog-cli]
    end

    subgraph "Backend Services"
        API[Spring Boot REST API<br/>const-catalog-backend]
    end

    subgraph "Data Stores"
        NEO[Neo4j Graph Database<br/>Constants & Parameters Graph]
        VK[ValKey / Redis<br/>Configuration Cache]
    end

    subgraph "Source Code"
        SRC[Java Project<br/>Source Files]
    end

    UI -->|HTTP/REST| API
    CLI -->|CSV Export| NEO
    API -->|Spring Data Neo4j| NEO
    API -->|Lettuce Client| VK
    API -->|JavaParser AST| SRC
    UI -.->|nginx proxy| API

    style UI fill:#0d1117,stroke:#22d3ee,color:#22d3ee
    style CLI fill:#0d1117,stroke:#a78bfa,color:#a78bfa
    style API fill:#0d1117,stroke:#34d399,color:#34d399
    style NEO fill:#0d1117,stroke:#60a5fa,color:#60a5fa
    style VK fill:#0d1117,stroke:#f472b6,color:#f472b6
    style SRC fill:#0d1117,stroke:#fbbf24,color:#fbbf24
```

## 2. Module Architecture

The project follows a multi-module Maven structure where each module has a clear responsibility boundary.

```mermaid
graph LR
    subgraph "const-catalog-core"
        M[Model Records]
        P[Parsers]
        S[Scanner]
        E[CSV Exporter]
        T[Transformer]
    end

    subgraph "const-catalog-backend"
        C[REST Controllers]
        SVC[Services]
        R[Repositories]
        CFG[Configuration]
        DTO[DTOs]
        ENT[Entities]
    end

    subgraph "const-catalog-cli"
        MAIN[Main CLI Entry]
    end

    subgraph "const-catalog-frontend"
        PAGES[React Pages]
        COMP[Components]
        APIC[API Client]
    end

    MAIN --> M
    MAIN --> P
    MAIN --> S
    MAIN --> E

    SVC --> M
    SVC --> P
    SVC --> S
    SVC --> T

    PAGES --> APIC
    APIC -->|HTTP| C
    C --> SVC
    SVC --> R
    R --> ENT
```

| Module | Artifact | Purpose |
|--------|----------|---------|
| **const-catalog-core** | Library JAR | Parsing, scanning, exporting, transforming - zero Spring dependency |
| **const-catalog-backend** | Spring Boot App | REST API, Neo4j graph persistence, ValKey caching, Pub/Sub |
| **const-catalog-cli** | Executable JAR | Offline scanning and CSV export for Neo4j bulk import |
| **const-catalog-frontend** | Static SPA | React 18 + TypeScript dashboard served via nginx |

## 3. Technology Stack

```mermaid
graph TB
    subgraph "Frontend"
        R18[React 18]
        TS[TypeScript]
        RQ[TanStack React Query]
        RR[React Router v6]
        TW[Tailwind CSS]
        AX[Axios]
        VT[Vite]
    end

    subgraph "Backend"
        SB[Spring Boot 3.4.1]
        SDN[Spring Data Neo4j]
        LET[Lettuce 6.x]
        CAF[Caffeine Cache]
        JP[JavaParser 3.26]
        LOM[Lombok]
        SW[Swagger / OpenAPI 3]
    end

    subgraph "Infrastructure"
        N4J[Neo4j 5.x]
        VAL[ValKey 8.x]
        NGX[nginx]
        DOC[Docker Compose]
    end

    subgraph "Runtime"
        J21[Java 21 LTS]
        MVN[Maven 3.9+]
        NOD[Node 20+]
    end
```

## 4. Data Flow

### 4.1 Scan Flow

The scan operation discovers constants and parameters in a Java project and persists them as a graph.

```mermaid
sequenceDiagram
    actor User
    participant UI as Frontend
    participant API as Backend API
    participant SS as ScanService
    participant PS as ProjectScanner
    participant JP as JavaFileParser
    participant PP as PropertyFileParser
    participant GP as GraphPopulatorService
    participant DB as Neo4j

    User->>UI: Enter project path, click Scan
    UI->>API: POST /api/scan {projectPath}
    API->>SS: scanProject(request)
    SS->>PS: scan(projectRoot)

    par Parse property files
        PS->>PP: parseParameters(*.properties, *.yml, *.env)
        PP-->>PS: List<Parameter>
    and Parse Java files
        PS->>JP: parseConstants(*.java)
        JP-->>PS: List<Constant>
        PS->>JP: parseParameterUsages(*.java, knownParams)
        JP-->>PS: List<ParameterUsage>
    end

    PS-->>SS: ScanResult

    SS->>GP: populateGraph(name, path, result)
    GP->>DB: Create ProjectNode
    GP->>DB: Create FileNodes
    GP->>DB: Create ConstantNodes + DEFINED_IN
    GP->>DB: Create ParameterNodes + DEFINED_IN
    GP->>DB: Create UsageRelationships (USED_IN)
    GP-->>SS: Done

    SS-->>API: ScanResponse
    API-->>UI: JSON response
    UI-->>User: Display results
```

### 4.2 Query Flow

```mermaid
sequenceDiagram
    actor User
    participant UI as Frontend
    participant API as Backend API
    participant QS as QueryService
    participant DB as Neo4j

    User->>UI: Select pre-canned query or write Cypher
    UI->>API: GET /api/query/precanned/{id}<br/>or POST /api/query/execute
    API->>QS: executeQuery(request)
    QS->>QS: Validate read-only query
    QS->>DB: Execute Cypher
    DB-->>QS: Result records
    QS-->>API: QueryResponse {columns, rows}
    API-->>UI: JSON response
    UI-->>User: Render ResultsTable
```

### 4.3 Transform Flow

The transformer replaces hardcoded constants with Spring `@Value` property lookups.

```mermaid
sequenceDiagram
    actor User
    participant API as Backend API
    participant CTS as CodeTransformationService
    participant DB as Neo4j
    participant JCT as JavaCodeTransformer
    participant AST as JavaParser AST
    participant FS as File System

    User->>API: POST /api/transform {projectPath, dryRun}
    API->>CTS: transform(request)
    CTS->>DB: MATCH config-candidate constants with file paths
    DB-->>CTS: List<ConstantWithFile>
    CTS->>CTS: Group targets by file path

    loop For each source file
        CTS->>JCT: transformFile(path, targets)
        JCT->>AST: Parse source to CompilationUnit
        loop For each constant target
            JCT->>AST: Find field by name + line number
            JCT->>AST: Remove static/final modifiers
            JCT->>AST: Rename SCREAMING_SNAKE to camelCase
            JCT->>AST: Add @Value("${property.key}")
        end
        JCT->>AST: Add @Component if not Spring bean
        JCT->>AST: Add required imports
        JCT->>FS: Write modified source
        JCT-->>CTS: List<TransformationEntry>
    end

    CTS-->>API: TransformResponse
    API-->>User: JSON result
```

### 4.4 Configuration Export & Caching Flow

```mermaid
sequenceDiagram
    participant API as ConfigurationController
    participant EXP as ConfigurationExportService
    participant SCS as SiteConfigurationService
    participant DB as Neo4j
    participant VK as ValKey
    participant CAF as Caffeine Cache
    participant PS as Pub/Sub
    participant CL as ChangeListener

    Note over API,CL: Export Phase
    API->>EXP: export(strategy)
    EXP->>DB: Query constants & parameters
    DB-->>EXP: Nodes
    EXP->>VK: MSET config:key = value
    EXP-->>API: ExportResult

    Note over API,CL: Lookup Phase (Cache-Aside)
    API->>SCS: lookup("db.host")
    SCS->>CAF: getIfPresent("db.host")
    alt Cache Hit
        CAF-->>SCS: value
    else Cache Miss
        SCS->>VK: GET config:db.host
        VK-->>SCS: value
        SCS->>CAF: put("db.host", value)
    end
    SCS-->>API: value

    Note over API,CL: Invalidation Phase
    API->>SCS: store("db.host", "newvalue")
    SCS->>VK: SET config:db.host newvalue
    SCS->>PS: PUBLISH config:changes db.host
    PS-->>CL: message(db.host)
    CL->>SCS: invalidateLocal("db.host")
    SCS->>CAF: invalidate("db.host")
```

## 5. Neo4j Graph Model

```mermaid
graph LR
    P((Project)) -->|CONTAINS| F((File))
    C((Constant)) -->|DEFINED_IN| F
    PM((Parameter)) -->|DEFINED_IN| F
    PM -->|USED_IN| F

    style P fill:#22d3ee,stroke:#22d3ee,color:#0d1117
    style F fill:#60a5fa,stroke:#60a5fa,color:#0d1117
    style C fill:#34d399,stroke:#34d399,color:#0d1117
    style PM fill:#a78bfa,stroke:#a78bfa,color:#0d1117
```

| Node | Properties |
|------|------------|
| **Project** | id, name, rootPath, scannedAt, totalFiles, totalConstants, totalParameters |
| **File** | id, path, fileName |
| **Constant** | id, name, type, value, className, lineNumber |
| **Parameter** | id, name, value, definitionFile, lineNumber |

| Relationship | From | To | Properties |
|-------------|------|-----|------------|
| **CONTAINS** | Project | File | - |
| **DEFINED_IN** | Constant | File | lineNumber |
| **DEFINED_IN** | Parameter | File | lineNumber |
| **USED_IN** | Parameter | File | className, lineNumber, context |

## 6. Deployment Architecture

```mermaid
graph TB
    subgraph "Docker Compose Network"
        subgraph "Frontend Container"
            NGX[nginx:alpine<br/>Port 3000]
            STATIC[React Static Build]
        end

        subgraph "Backend Container"
            BOOT[Spring Boot<br/>Port 8080]
        end

        subgraph "Neo4j Container"
            N4J[Neo4j 5.x<br/>Bolt: 7687<br/>HTTP: 7474]
        end

        subgraph "ValKey Container"
            VK[ValKey 8.x<br/>Port 6379]
        end

        subgraph "ValKey CLI Container"
            VCLI[valkey-cli<br/>Debug/Admin]
        end
    end

    subgraph "Host Machine"
        SRC["/src, /esrc, /csrc<br/>(bind mounts)"]
    end

    NGX -->|proxy /api/*| BOOT
    BOOT -->|bolt://| N4J
    BOOT -->|redis://| VK
    VCLI -->|redis://| VK
    BOOT -->|read/write| SRC

    style NGX fill:#0d1117,stroke:#22d3ee,color:#22d3ee
    style BOOT fill:#0d1117,stroke:#34d399,color:#34d399
    style N4J fill:#0d1117,stroke:#60a5fa,color:#60a5fa
    style VK fill:#0d1117,stroke:#f472b6,color:#f472b6
```

### Environment Configuration

| Variable | Purpose | Default |
|----------|---------|---------|
| `HOST_SRC_PATH` | Bind mount for /src in container | /src |
| `HOST_ESRC_PATH` | Bind mount for /esrc in container | /esrc |
| `HOST_CSRC_PATH` | Bind mount for /csrc in container | /csrc |
| `NEO4J_AUTH` | Neo4j credentials | neo4j/constcatalog |
| `VALKEY_HOST` | ValKey hostname | valkey |
| `VALKEY_PORT` | ValKey port | 6379 |

## 7. REST API Surface

```mermaid
graph LR
    subgraph "POST"
        S["/api/scan"]
        QE["/api/query/execute"]
        TR["/api/transform"]
        EX["/api/config/export"]
        EP["/api/config/export/project"]
        ST["/api/config/store"]
        SB["/api/config/store/batch"]
        CI["/api/config/cache/invalidate"]
    end

    subgraph "GET"
        QP["/api/query/precanned"]
        QPI["/api/query/precanned/{id}"]
        STAT["/api/stats"]
        SH["/api/stats/health"]
        SC["/api/stats/constants"]
        SP["/api/stats/parameters"]
        FC["/api/files/content"]
        CL["/api/config/lookup/{key}"]
        CLB["/api/config/lookup/batch"]
        CLP["/api/config/lookup/prefix/{p}"]
        CS["/api/config/stats"]
        CC["/api/config/stats/cache"]
        CH["/api/config/health"]
    end

    subgraph "DELETE"
        DE["/api/config/export"]
        DK["/api/config/{key}"]
    end
```

| Endpoint | Method | Controller | Description |
|----------|--------|------------|-------------|
| `/api/scan` | POST | ScanController | Scan a Java project |
| `/api/query/precanned` | GET | QueryController | List pre-canned queries |
| `/api/query/precanned/{id}` | GET | QueryController | Execute pre-canned query |
| `/api/query/execute` | POST | QueryController | Execute ad-hoc Cypher |
| `/api/stats` | GET | StatsController | Database statistics |
| `/api/stats/health` | GET | StatsController | Health check |
| `/api/stats/constants` | GET | StatsController | List constants |
| `/api/stats/parameters` | GET | StatsController | List parameters |
| `/api/files/content` | GET | FileController | Read source file contents |
| `/api/transform` | POST | TransformController | Transform constants to @Value |
| `/api/config/export` | POST | ConfigurationController | Export config to ValKey |
| `/api/config/lookup/{key}` | GET | ConfigurationController | Lookup config value |
| `/api/config/store` | POST | ConfigurationController | Store config value |
| `/api/config/cache/invalidate` | POST | ConfigurationController | Invalidate cache |

## 8. Frontend Architecture

```mermaid
graph TB
    subgraph "React Application"
        MAIN[main.tsx<br/>QueryClient Setup]
        APP[App.tsx<br/>Router]

        subgraph "Layout Shell"
            LAYOUT[Layout.tsx]
            HEADER[Header.tsx<br/>Health HUD]
            SIDEBAR[Sidebar.tsx<br/>Navigation]
            CMD[CommandLine.tsx<br/>Terminal Footer]
        end

        subgraph "Pages"
            DASH[Dashboard.tsx<br/>Stats Overview]
            SCAN[ScanPage.tsx<br/>Project Scanner]
            QUERY[QueryPage.tsx<br/>Cypher Editor]
        end

        subgraph "Shared Components"
            RT[ResultsTable.tsx<br/>Data Grid]
            FVM[FileViewerModal.tsx<br/>Source Viewer]
        end

        subgraph "Services"
            APIC[api.ts<br/>Axios Client]
            TYPES[types/index.ts<br/>Type Definitions]
        end
    end

    MAIN --> APP
    APP --> LAYOUT
    LAYOUT --> HEADER
    LAYOUT --> SIDEBAR
    LAYOUT --> CMD
    LAYOUT --> DASH
    LAYOUT --> SCAN
    LAYOUT --> QUERY
    QUERY --> RT
    QUERY --> FVM
    DASH --> APIC
    SCAN --> APIC
    QUERY --> APIC
    HEADER --> APIC
    APIC --> TYPES
```

## 9. Security Considerations

- **File Access Control**: `FileController` restricts file reads to allowed prefixes (`/src`, `/esrc`, `/csrc`, `/projects`) preventing path traversal
- **Read-Only Queries**: `QueryService` validates that ad-hoc Cypher contains only read operations (MATCH, RETURN) and blocks write operations (CREATE, DELETE, SET, MERGE)
- **Input Validation**: All request DTOs use Jakarta `@Valid` and `@NotBlank` annotations
- **Sensitive Value Masking**: `SiteConfigurationService` masks values for keys containing PASSWORD, SECRET, KEY, TOKEN in log output
- **CORS**: Development CORS allows localhost:3000/3001/5173; production is same-origin behind nginx

## 10. Caching Strategy

The system employs a **two-tier cache-aside** pattern:

1. **L1 - Caffeine** (in-process): Sub-millisecond lookups, bounded by size (10,000 entries) and TTL (60 minutes)
2. **L2 - ValKey** (network): Shared across instances, persisted, sub-millisecond over loopback

**Invalidation**: Pub/Sub channel `config:changes` broadcasts key changes. `ConfigurationChangeListener` subscribes and evicts from the Caffeine L1 cache, ensuring cross-instance consistency.

## 11. Pre-Canned Queries

The system ships with 10 built-in Neo4j queries:

| ID | Name | Category |
|----|------|----------|
| `all-constants` | All Constants | Discovery |
| `all-parameters` | All Parameters | Discovery |
| `config-candidates` | Configuration Candidates | Analysis |
| `unused-parameters` | Unused Parameters | Analysis |
| `cross-file-params` | Cross-File Parameters | Analysis |
| `duplicate-values` | Duplicate Values | Analysis |
| `sensitive-params` | Sensitive Parameters | Security |
| `connection-strings` | Connection Strings | Security |
| `param-by-prefix` | Parameters by Prefix | Organization |
| `file-summary` | File Summary | Statistics |
