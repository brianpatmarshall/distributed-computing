# Addendum: Adding Git Branching Functionality

This addendum documents the "Create New Branch" feature added to the Constants Catalog's Transform page. When enabled, the system creates a dedicated git branch in the target project, commits the transformed files to that branch, and switches back to the original branch — leaving the developer's working branch completely untouched.

---

## 1. Motivation

Prior to this feature, the transformer wrote all output to a `backups/` directory mounted as a Docker volume. While this protected the original source files (which are mounted read-only), the developer still had to manually copy transformed files into their project and create a branch themselves. The "Create New Branch" option automates that workflow: one checkbox produces a ready-to-review branch with all transformations committed.

---

## 2. How It Works

### 2.1 User Workflow

1. Navigate to the **Transform** page
2. Enter the project path and select the candidate scope as usual
3. Uncheck **Dry run** (the branch option is disabled during dry runs)
4. Check **Create new branch with transformed files committed**
5. Click **Transform**

When the transformation completes, the results area shows the new branch name (e.g., `feature/my-work-transformed`) alongside the usual statistics. The developer's original branch remains exactly as it was before the transformation.

### 2.2 Branch Naming

The new branch name is derived by appending `-transformed` to the current branch name:

| Current Branch | Created Branch |
|---|---|
| `main` | `main-transformed` |
| `feature/auth` | `feature/auth-transformed` |
| `develop` | `develop-transformed` |

### 2.3 End-to-End Sequence

The transformation pipeline adds a new **Phase 2.5** between the existing Phase 2 (AST transformation) and Phase 3 (response building):

```
Phase 1: Query Neo4j for candidates
Phase 2: Transform files (writes to backups/)
Phase 2.5: Create branch with transformed files    <-- NEW
Phase 3: Build and return response
```

Phase 2.5 executes the following steps:

```mermaid
sequenceDiagram
    participant Service as CodeTransformationService
    participant Git as GitService
    participant FS as File System

    Service->>Git: isGitRepo(projectDir)
    Git-->>Service: true

    Service->>Git: getCurrentBranch(projectDir)
    Git-->>Service: "feature/my-work"

    Service->>Git: createAndCheckoutBranch(projectDir, "feature/my-work-transformed")
    Git-->>Service: OK

    loop For each transformed file
        Service->>FS: Copy backups/<rel-path>/File.java → original source path
    end

    Service->>Git: addAndCommit(projectDir, "Transform constants to config lookups")
    Git-->>Service: OK

    Service->>Git: checkoutBranch(projectDir, "feature/my-work")
    Git-->>Service: OK (back on original branch)
```

### 2.4 Mutual Exclusion with Dry Run

The **Dry run** and **Create new branch** options are mutually exclusive:

- Checking **Dry run** disables and unchecks **Create new branch**
- Checking **Create new branch** unchecks **Dry run**
- The backend also enforces this: branch creation is skipped when `dryRun` is `true`

This prevents a confusing state where the user expects a branch but no files were actually modified.

---

## 3. Files Changed

### 3.1 New File: `GitService.java`

**Path:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/GitService.java`

A Spring `@Service` that executes git CLI commands via `ProcessBuilder`. This approach avoids adding a JGit dependency — the standard JDK `ProcessBuilder` is sufficient for the small set of operations needed.

**Public methods:**

| Method | Description |
|---|---|
| `isGitRepo(Path)` | Returns `true` if the directory is inside a git working tree |
| `getCurrentBranch(Path)` | Returns the current branch name (e.g., `"main"`) |
| `createAndCheckoutBranch(Path, String)` | Creates a new branch and switches to it; fails if it already exists |
| `checkoutBranch(Path, String)` | Switches to an existing branch |
| `addAndCommit(Path, String)` | Stages all changes (`git add -A`) and commits with the given message |

All git operations enforce a **30-second timeout**. If a command hangs, the process is forcibly destroyed and a `GitException` is thrown.

**Error handling:** All methods throw `GitService.GitException` (a checked exception) on failure. This is an inner class of `GitService` with both message-only and message+cause constructors.

### 3.2 Modified: `TransformRequest.java`

**Path:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/dto/TransformRequest.java`

Added one field:

```java
@Builder.Default
@Schema(
    description = "If true, create a new git branch with the transformed files committed",
    example = "false"
)
private boolean createBranch = false;
```

The field defaults to `false`, so existing API consumers are unaffected. Jackson automatically deserializes the new field from the request JSON.

### 3.3 Modified: `TransformResponse.java`

**Path:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/dto/TransformResponse.java`

Added one field:

```java
@Schema(description = "Name of the git branch created with transformed files, if requested")
private String branchName;
```

This field is `null` when no branch was created (dry run, branch not requested, or non-git project).

### 3.4 Modified: `CodeTransformationService.java`

**Path:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/CodeTransformationService.java`

Two changes:

1. **Constructor injection of `GitService`** — The service now accepts `GitService` alongside `Neo4jClient` in its constructor.

2. **New private method `createBranchWithTransformedFiles`** — Called after Phase 2 when `createBranch == true` and `dryRun == false` and at least one file was transformed. The method:
   - Validates the project is a git repo
   - Gets the current branch name
   - Creates `<current-branch>-transformed`
   - Copies each transformed file from `backups/<root-relativized-path>` to its original source location (deduplicated by file path)
   - Runs `git add -A && git commit`
   - Checks out the original branch
   - Returns the new branch name (set on the response)

   If any step fails, the catch block attempts to **roll back** by checking out the original branch. The branch name is set to `null` on the response, and the transformation results (in `backups/`) are still available.

The response message is also updated when a branch is created:

```
Transformed 12 items, skipped 3, failed 1 — committed to branch 'main-transformed'
```

### 3.5 Modified: `types/index.ts`

**Path:** `const-catalog-frontend/src/types/index.ts`

Added `createBranch?: boolean` to `TransformRequest` and `branchName?: string` to `TransformResponse`.

### 3.6 Modified: `TransformPage.tsx`

**Path:** `const-catalog-frontend/src/pages/TransformPage.tsx`

- Imported `GitBranch` icon from `lucide-react`
- Added `createBranch` state variable (default `false`)
- Added a checkbox below the dry run checkbox, paired with the `GitBranch` icon
- Implemented mutual exclusion: checking one unchecks/disables the other
- Included `createBranch` in the mutation payload (forced to `false` when `dryRun` is `true`)
- Displays the branch name with a git branch icon in the results area when a branch was created

### 3.7 New Test: `GitServiceTest.java`

**Path:** `const-catalog-backend/src/test/java/com/boeing/constcatalog/backend/service/GitServiceTest.java`

A plain JUnit 5 test (no Spring context required) that creates a temporary git repository in a `@TempDir` for each test. Covers:

| Test Class | Tests | What It Verifies |
|---|---|---|
| `IsGitRepo` | 2 | Returns `true` for a git repo, `false` for a plain directory |
| `GetCurrentBranch` | 1 | Returns a non-blank branch name |
| `CreateAndCheckoutBranch` | 2 | Creates and switches to a new branch; throws `GitException` if the branch already exists |
| `CheckoutBranch` | 2 | Switches to an existing branch; throws `GitException` for a nonexistent branch |
| `AddAndCommit` | 2 | Commits new files; commits modified files |
| `FullWorkflow` | 1 | End-to-end: create branch, add file, commit, switch back, verify file absent on original branch and present on new branch |

**Total: 10 tests, all passing.**

---

## 4. Files NOT Modified

| File | Reason |
|---|---|
| `ConfigLookupTransformer.java` | Continues writing to `backups/` as before. The branch feature copies from backups after the transform completes. |
| `TransformController.java` | Passes the `TransformRequest` through to the service. Jackson auto-deserializes the new `createBranch` field. |
| `api.ts` (Axios client) | Already sends the full `TransformRequest` object; the new field is included automatically. |
| `pom.xml` | No new dependencies. `ProcessBuilder` is part of the JDK standard library. |

---

## 5. Edge Cases and Error Handling

| Scenario | Behavior |
|---|---|
| **`createBranch` + `dryRun`** | Branch creation is skipped. The checkbox is disabled in the UI, and the backend checks `!dryRun` before proceeding. |
| **Project is not a git repo** | A warning is logged, `branchName` is `null` on the response, and the transformation still succeeds in `backups/`. |
| **Branch already exists** | `git checkout -b` fails, the exception is caught, the original branch is restored (rollback), and `branchName` is `null`. |
| **No files were transformed** | Branch creation is skipped entirely (early return before any git operations). |
| **Multiple entries for the same file** | File paths are collected into a `LinkedHashSet`, so each file is copied exactly once. |
| **Git command times out** | The process is killed after 30 seconds and a `GitException` is thrown, triggering rollback. |
| **Rollback itself fails** | An error is logged. The developer may need to manually `git checkout` their original branch. |

---

## 6. Testing the Feature

### 6.1 Automated Tests

Run the `GitServiceTest` to verify the git operations:

```bash
mvn test -pl const-catalog-backend -am \
    -Dtest=GitServiceTest \
    -Dsurefire.failIfNoSpecifiedTests=false
```

Run the existing `ConfigLookupTransformerTest` to confirm no regressions:

```bash
mvn test -pl const-catalog-core -Dtest=ConfigLookupTransformerTest
```

### 6.2 Manual End-to-End Test

1. Scan a Java project that contains configuration-candidate constants
2. On the Transform page, enter the project path
3. Uncheck **Dry run** and check **Create new branch**
4. Click **Transform**
5. Verify:
   - The results area displays the branch name (e.g., `main-transformed`)
   - In the target project, run `git branch` to confirm the new branch exists
   - Run `git log main-transformed --oneline -1` to see the commit
   - Run `git diff main..main-transformed` to see the transformations
   - Confirm the original branch has no changes (`git status` is clean)

---

## 7. Architecture Diagram

```
┌──────────────────────────────────────────────────────────┐
│                    TransformPage.tsx                      │
│  ┌──────────┐  ┌──────────────┐  ┌────────────────────┐  │
│  │ Dry Run  │  │ Create       │  │ Candidate Scope    │  │
│  │ checkbox │  │ Branch       │  │ radio buttons      │  │
│  │          │◄─┤ checkbox     │  │                    │  │
│  └──────────┘  └──────────────┘  └────────────────────┘  │
│       ▲              │ mutually                           │
│       └──────────────┘ exclusive                          │
└──────────────────────────┬───────────────────────────────┘
                           │ POST /api/transform
                           ▼
┌──────────────────────────────────────────────────────────┐
│                 TransformController                       │
│           (pass-through, no changes needed)               │
└──────────────────────────┬───────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│              CodeTransformationService                    │
│                                                          │
│  Phase 1: Query Neo4j for candidates                     │
│  Phase 2: Transform files → backups/                     │
│  Phase 2.5: if createBranch && !dryRun ──────┐           │
│  Phase 3: Build response                     │           │
└──────────────────────────────────────────────┼───────────┘
                                               │
                                               ▼
                              ┌─────────────────────────┐
                              │       GitService         │
                              │                         │
                              │  isGitRepo()            │
                              │  getCurrentBranch()     │
                              │  createAndCheckout()    │
                              │  addAndCommit()         │
                              │  checkoutBranch()       │
                              │                         │
                              │  (ProcessBuilder → git) │
                              └─────────────────────────┘
```
