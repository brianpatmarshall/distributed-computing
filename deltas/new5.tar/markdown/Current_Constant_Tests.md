# Current Constant Transformation Tests

This document catalogs the existing unit tests that verify the constant-to-lookup transformation logic in `ConfigLookupTransformer`.

---

## Test Classes

There are two test classes in `const-catalog-core/src/test/java/com/boeing/constcatalog/transformer/`:

1. **`ConfigLookupTransformerTest`** — Core transformation behaviors (13 tests)
2. **`ConfigLookupTransformerDiagnosticTest`** — Failure modes, edge cases, and batch scenarios (~20 tests)

All tests use JUnit 5 `@TempDir` to write inline Java source as text blocks, then call `transformFile()` or `dryRun()` and assert on status and output content.

---

## 1. ConfigLookupTransformerTest

### Type-Specific Replacement Tests

Each test writes a Java file containing a `public static final` field and a usage of that field, then verifies the transformer produces the correct `config.lookupType()` call.

| Test | Constant | Type | Expected Replacement |
|------|----------|------|----------------------|
| `testReplacesStringConstantUsage` | `DB_HOST` | `String` | `config.lookup("db.host")` |
| `testReplacesIntConstantUsage` | `SSH_PORT` | `int` | `config.lookupInt("ssh.port", ...)` |
| `testReplacesLongConstantUsage` | `TIMEOUT_MS` | `long` | `config.lookupLong("timeout.ms", ...)` |
| `testReplacesBooleanConstantUsage` | `DEBUG_ENABLED` | `boolean` | `config.lookupBoolean("debug.enabled", ...)` |
| `testReplacesDoubleConstantUsage` | `RATE` | `double` | `config.lookupDouble("rate", ...)` |

### Multi-Constant and Enum Tests

| Test | What It Verifies |
|------|------------------|
| `testReplacesMultipleUsagesInSameFile` | Two constants (`API_HOST` String + `API_PORT` int) replaced in one file |
| `testHandlesEnumConstantUsages` | Enum-style constant (`ENV_MODE`) replaced correctly |

### Infrastructure Tests

| Test | What It Verifies |
|------|------------------|
| `testDryRunDoesNotModifyFile` | Dry run reports TRANSFORMED status but file content is unchanged |
| `testAddsConfigFieldIfMissing` | `@Autowired SiteConfigurationService config` field injected into the class |
| `testSkipsAlreadyTransformedUsages` | Constant defined but not used in file produces SKIPPED status |
| `testPreservesOriginalFileAsBackup` | `.orig` backup file created with original content in backups directory |

### Static Method Tests

| Test | What It Verifies |
|------|------------------|
| `testChooseLookupMethod` | Maps all type strings to correct lookup method names (`String` -> `lookup`, `int` -> `lookupInt`, `Integer` -> `lookupInt`, `long` -> `lookupLong`, `Long` -> `lookupLong`, `boolean` -> `lookupBoolean`, `Boolean` -> `lookupBoolean`, `double` -> `lookupDouble`, `Double` -> `lookupDouble`, unknown -> `lookup`) |
| `testDeriveConfigLookupCall` | Generates correct call strings: `config.lookup("db.host")` for String, `config.lookupInt("ssh.port", 22)` for int |

---

## 2. ConfigLookupTransformerDiagnosticTest

Organized into nested test classes using `@Nested` and `@DisplayName`.

### Parse Failures

Tests that verify the transformer handles unparseable or unusual Java syntax gracefully.

| Test | Scenario | Expected Outcome |
|------|----------|------------------|
| `unparseableFileFailsAllTargets` | Invalid Java source (`"this is not valid java at all {{{{"`) with 3 targets | All 3 entries FAILED (fan-out) |
| `emptyFile` | Empty file | Diagnostic output (may parse to empty CU or fail) |
| `packageOnlyFile` | File with only `package com.example;` | Diagnostic output |
| `syntaxErrorInMethod` | Missing semicolon in method body | Diagnostic output |
| `recordSyntax` | Java 17+ `record` class with constant usage | Verifies Java 21 support |
| `sealedClassSyntax` | `sealed class` with constant usage | Verifies Java 21 support |
| `patternMatchingInstanceof` | `instanceof String s` pattern with constant usage | Verifies Java 21 support |
| `textBlockStrings` | File containing text block (`"""..."""`) alongside constants | Verifies parser handles text blocks |
| `switchExpressions` | Arrow-style `switch` expression with constant in default arm | Verifies Java 21 support |
| `heavilyAnnotatedClass` | Spring `@Service` class with `@Value`, `@PostConstruct`, `@Cacheable` + constant usages | Verifies annotation-heavy parsing |
| `interfaceConstants` | Interface with implicit `public static final` fields | Verifies interface constant handling |

### IO Errors

| Test | Scenario | Expected Outcome |
|------|----------|------------------|
| `nonExistentFile` | Path to missing file (dry run) | 2 FAILED entries |
| `nonExistentFileRealMode` | Path to missing file (real transform) | 1 FAILED entry |
| `pathSeparatorMismatch` | Forward slashes on Windows (or vice versa) | Diagnostic output |

### Skipped Entries (No Usages Found)

| Test | Scenario | Expected Outcome |
|------|----------|------------------|
| `definedButNotUsed` | Constants declared but never referenced in the file | SKIPPED |
| `usedOnlyInDeclaration` | Constant appears only at its declaration site | SKIPPED (declaration guard) |
| `nameInCommentOrString` | Constant name in a comment and a string literal but not as a `NameExpr` | SKIPPED |

### Parameter Transformations

| Test | Scenario | Expected Outcome |
|------|----------|------------------|
| `getPropertyReplaced` | `props.getProperty("database.host")` with matching PARAMETER target | TRANSFORMED |
| `getIntReplaced` | `config.getInt("server.port")` with matching PARAMETER target | TRANSFORMED |
| `unknownGetterMethodSkipped` | `settings.fetchSetting("database.host")` — not in `PROPERTY_GETTER_METHODS` | SKIPPED |
| `paramKeyNotFoundInFile` | PARAMETER target key `"database.host"` but file only has `"some.other.key"` | SKIPPED |

### Batch / Fan-out Scenarios

| Test | Scenario | Expected Outcome |
|------|----------|------------------|
| `fanOutAmplification` | 1 unparseable file with 10 targets | 10 FAILED entries |
| `mixedProjectTransform` | 3 files: 1 good (usage exists), 1 bad (unparseable), 1 unused | 1 TRANSFORMED, 2 FAILED, 1 SKIPPED |
| `largeBatchDiagnostic` | 5 files (2 bad x 5 targets + 3 good x 3 targets, no usages) | 10 FAILED, 9 SKIPPED, 0 TRANSFORMED; groups failures by file |

### Cross-file Usage Patterns

| Test | Scenario | Expected Outcome |
|------|----------|------------------|
| `constantUsedInDifferentFile` | `DB_HOST` defined in `Constants.java`, target points to `UserService.java` where it is used as `NameExpr` | TRANSFORMED |
| `qualifiedFieldAccess` | `Constants.DB_HOST` used as `FieldAccessExpr` in a different file | TRANSFORMED |

### Edge Cases

| Test | Scenario | Expected Outcome |
|------|----------|------------------|
| `emptyTargets` | Empty target list passed to `dryRun()` | Empty results |
| `constantInAnnotation` | Constant used in a return statement (annotation context test) | TRANSFORMED |
| `duplicateConstantNames` | Two targets with same `constantName` from different classes | Dedup keeps first (`Collectors.toMap` merge `(a, b) -> a`); 1 result entry |
| `mixedConstantAndParameter` | One CONSTANT target (`DB_HOST`) + one PARAMETER target (`server.port`) in same file | 2 results, both checked independently |

---

## Test Patterns

All tests follow the same structure:

1. Write a Java source string using a text block
2. Write it to a `@TempDir` file via `writeSource(fileName, content)`
3. Create `ConstantTarget` objects describing what to transform
4. Call `transformFile(path, targets, backupsDir)` or `dryRun(path, targets)`
5. Assert on result count, status (`TRANSFORMED`, `SKIPPED`, `FAILED`), and output file content

The diagnostic tests additionally print to `System.out` for visual inspection when run directly.
