# Transformation Process: Externalizing Hardcoded Values to Config Lookups

This document describes how the Constants Catalog transforms hardcoded values in Java source code into centralized `config.lookupType()` calls backed by ValKey and Caffeine caching.

## Overview

The system handles two distinct source kinds:

| Source Kind | What it is | Example before | Example after |
|-------------|-----------|----------------|---------------|
| **Constant** | `public static final` field | `int port = SSH_PORT;` | `int port = config.lookupInt("ssh.port", 22);` |
| **Parameter** | Property getter call | `props.getProperty("db.host")` | `config.lookup("db.host")` |

Both are ultimately replaced with calls to `SiteConfigurationService`, which reads from a two-tier cache (Caffeine local cache + ValKey distributed store).

---

## Phase 1: Scanning (Discovery)

Before transformation can happen, the project must be scanned. Scanning populates Neo4j with nodes and relationships that the transformer queries later.

### 1.1 Constant Discovery

The `JavaFileParser` parses every `.java` file using JavaParser (AST) and extracts:

- **`public static final` fields** — e.g., `public static final String DB_HOST = "localhost";`
- **Enum constants** — e.g., `enum Protocol { HTTP, HTTPS }`

Each becomes a `Constant` node in Neo4j with:

```
(:Constant {
    name: "DB_HOST",
    type: "String",
    value: "\"localhost\"",
    className: "AppConfig",
    lineNumber: 15,
    isEnum: false
})
--[:DEFINED_IN]-->(:File {path: "/src/main/java/com/example/AppConfig.java"})
```

### 1.2 Parameter Discovery

The `PropertyFileParser` parses configuration files in five formats:

| Format | Files | Example entry |
|--------|-------|---------------|
| Java Properties | `.properties` | `server.port=8080` |
| YAML | `.yml`, `.yaml` | `server:\n  port: 8080` (flattened to `server.port=8080`) |
| JSON | `.json` | `{"server": {"port": 8080}}` (flattened to `server.port=8080`) |
| XML | `.xml` | `<property name="server.port" value="8080"/>` |
| Environment | `.env` | `SERVER_PORT=8080` |

Each key-value pair becomes a `Parameter` node in Neo4j:

```
(:Parameter {
    name: "server.port",
    value: "8080",
    lineNumber: 3
})
--[:DEFINED_IN]-->(:File {path: "/src/main/resources/application.properties"})
```

### 1.3 Parameter Usage Discovery

After discovering parameters, the scanner re-scans all Java files looking for **usages** of those parameter names. It detects two patterns:

**Pattern A — Property getter methods:**

The following method names are recognized:
`getProperty`, `get`, `getString`, `getInt`, `getInteger`, `getLong`, `getBoolean`, `getDouble`, `getFloat`, `getValue`, `getConfig`, `getenv`, `getOrDefault`, `getPropertyValue`

When the scanner finds `props.getProperty("server.port")` and `server.port` is a known parameter, it creates a `USED_IN` relationship:

```
(:Parameter {name: "server.port"})
--[:USED_IN {className: "WebServer", lineNumber: 42, context: "props.getProperty(\"server.port\")"}]-->
(:File {path: "/src/main/java/com/example/WebServer.java"})
```

**Pattern B — @Value annotations:**

```java
@Value("${server.port}")
private int port;
```

Also creates a `USED_IN` relationship with the annotation as context.

---

## Phase 2: Transformation

The Transform page triggers the transformation flow. The user selects a scope:

- **All** — transform both constants and parameters
- **Constants Only** — only transform `public static final` usages
- **Parameters Only** — only transform property getter calls

### 2.1 Candidate Selection (CodeTransformationService)

The service queries Neo4j for candidates based on the selected scope.

**For constants** — queries for `Constant` nodes matching config-like names:

```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE c.name =~ '(?i).*(HOST|PORT|URL|URI|PATH|KEY|SECRET|PASSWORD|TIMEOUT|ENDPOINT|DATABASE|CONNECTION|SERVER|CLIENT).*'
RETURN c.name, c.type, c.value, c.className, c.lineNumber, f.path
```

**For parameters** — queries for `Parameter` nodes with usage locations:

```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(param:Parameter)
      -[usage:USED_IN]->(usageFile:File)
RETURN param.name, param.value, usage.className, usage.lineNumber, usageFile.path
```

Both are converted to `ConstantTarget` objects and grouped by file path.

### 2.2 AST Transformation (ConfigLookupTransformer)

For each Java file, the transformer parses it into an AST using JavaParser and visits nodes to replace usages.

#### Constant Replacement (NameExpr / FieldAccessExpr)

The transformer looks for `NameExpr` and `FieldAccessExpr` nodes matching constant names.

**Before:**
```java
public class EmailService {
    public void send() {
        String host = MAIL_HOST;           // NameExpr
        int port = AppConfig.MAIL_PORT;    // FieldAccessExpr
    }
}
```

**After:**
```java
public class EmailService {
    @Autowired
    private SiteConfigurationService config;

    public void send() {
        String host = config.lookup("mail.host");
        int port = config.lookupInt("mail.port", 587);
    }
}
```

The declaration site (`public static final String MAIL_HOST = "smtp.example.com"`) is intentionally left unchanged — only **usages** of the constant are rewritten.

#### Parameter Replacement (MethodCallExpr)

The transformer looks for `MethodCallExpr` nodes where:
1. The method name is in the recognized property getter set
2. One argument is a `StringLiteralExpr` matching a known parameter name

**Before:**
```java
String host = props.getProperty("db.host");
int port = config.getInt("db.port");
long timeout = settings.getLong("db.timeout");
boolean ssl = env.getBoolean("db.ssl");
```

**After:**
```java
String host = config.lookup("db.host");
int port = config.lookupInt("db.port");
long timeout = config.lookupLong("db.timeout");
boolean ssl = config.lookupBoolean("db.ssl");
```

The entire `MethodCallExpr` (including the scope expression like `props.`) is replaced.

### 2.3 Type-Aware Lookup Method Selection

The transformer selects the appropriate `SiteConfigurationService` method based on type information. The mechanism differs between constants and parameters:

#### For Constants: Type comes from the field declaration

The constant's declared Java type (stored in Neo4j as `c.type`) drives the method selection:

| Java Type | Lookup Method | Example Output |
|-----------|--------------|----------------|
| `String`, `java.lang.String` | `config.lookup(key)` | `config.lookup("mail.host")` |
| `int`, `Integer` | `config.lookupInt(key, default)` | `config.lookupInt("mail.port", 587)` |
| `long`, `Long` | `config.lookupLong(key, default)` | `config.lookupLong("timeout.ms", 30000L)` |
| `boolean`, `Boolean` | `config.lookupBoolean(key, default)` | `config.lookupBoolean("ssl.enabled", false)` |
| `double`, `Double` | `config.lookupDouble(key, default)` | `config.lookupDouble("rate.limit", 1.5)` |

For typed lookups (`int`, `long`, `boolean`, `double`), the constant's original hardcoded value is passed as the default/fallback argument.

#### For Parameters: Type comes from the getter method name

Property files don't have type information — everything is a string. So the transformer infers the intended type from **which getter method the code was already using**:

| Original Method | Lookup Method |
|-----------------|---------------|
| `getProperty()`, `get()`, `getString()`, `getValue()`, `getConfig()`, `getenv()`, `getOrDefault()`, `getPropertyValue()` | `config.lookup()` |
| `getInt()`, `getInteger()` | `config.lookupInt()` |
| `getLong()` | `config.lookupLong()` |
| `getBoolean()` | `config.lookupBoolean()` |
| `getDouble()`, `getFloat()` | `config.lookupDouble()` |

This preserves the type intent of the original code.

### 2.4 Automatic Code Injection

When at least one replacement is made in a file, the transformer also:

1. **Adds the config field** (if not already present):
   ```java
   @Autowired
   private SiteConfigurationService config;
   ```

2. **Adds required imports** (if not already present):
   ```java
   import org.springframework.beans.factory.annotation.Autowired;
   import com.boeing.constcatalog.backend.service.SiteConfigurationService;
   ```

### 2.5 Backup

Before modifying any file, the original is copied to `*.java.orig` for comparison and rollback.

---

## Phase 3: Runtime Resolution

After transformation, `SiteConfigurationService` resolves values at runtime through a two-tier cache:

```
config.lookup("db.host")
       │
       ▼
┌─────────────┐    miss     ┌─────────────┐
│  Caffeine   │────────────>│   ValKey     │
│  (local)    │<────────────│  (distributed)│
└─────────────┘    value    └─────────────┘
```

- **Tier 1 — Caffeine**: Sub-millisecond, in-process cache. Invalidated via ValKey pub/sub when values change.
- **Tier 2 — ValKey**: Distributed key-value store (Redis-compatible). Shared across all application instances. Populated by `ConfigurationExportService` which reads the same property files and pushes values into ValKey.

When a configuration value changes, `ValKey.PUBLISH("config:changes", "db.host")` is broadcast, and all instances invalidate their local Caffeine entry for that key.

---

## End-to-End Example

Given this project:

**application.properties:**
```properties
db.host=localhost
db.port=5432
```

**AppConfig.java:**
```java
public class AppConfig {
    public static final String API_URL = "https://api.example.com";
    public static final int MAX_RETRIES = 3;
}
```

**DataService.java:**
```java
public class DataService {
    private Properties props;

    public void connect() {
        String host = props.getProperty("db.host");
        int port = props.getInt("db.port");
        String api = AppConfig.API_URL;
        int retries = MAX_RETRIES;
    }
}
```

**After transformation, DataService.java becomes:**
```java
import org.springframework.beans.factory.annotation.Autowired;
import com.boeing.constcatalog.backend.service.SiteConfigurationService;

public class DataService {
    @Autowired
    private SiteConfigurationService config;

    private Properties props;

    public void connect() {
        String host = config.lookup("db.host");
        int port = config.lookupInt("db.port");
        String api = config.lookup("api.url");
        int retries = config.lookupInt("max.retries", 3);
    }
}
```

Note the differences:
- `getProperty("db.host")` (String getter) became `config.lookup("db.host")`
- `getInt("db.port")` (int getter) became `config.lookupInt("db.port")`
- `AppConfig.API_URL` (String constant) became `config.lookup("api.url")`
- `MAX_RETRIES` (int constant) became `config.lookupInt("max.retries", 3)` — with `3` as the default value
