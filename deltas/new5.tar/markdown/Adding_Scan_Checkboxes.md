# Adding "Scan Constants" and "Scan Parameters" Checkboxes to the Scan Page

This document walks through adding two checkboxes to the Scan page that let the user choose whether to scan for constants, parameters, or both. Both are checked by default, preserving current behavior.

The change touches four layers: TypeScript types, React UI, the backend DTO, and the backend service. The API client (`api.ts`) requires no changes.

---

## Prerequisites

- Create a new branch for this work (e.g., `feature/scan-checkboxes`)
- The application should build cleanly before you start

---

## Step 1: Add Fields to the TypeScript Type

**File:** `const-catalog-frontend/src/types/index.ts`

Find the `ScanRequest` interface (around line 6):

```typescript
export interface ScanRequest {
  projectPath: string
}
```

Add two optional boolean fields:

```typescript
export interface ScanRequest {
  projectPath: string
  scanConstants?: boolean
  scanParameters?: boolean
}
```

### Why optional?

The `?` means these fields can be `undefined`. When `undefined`, they are omitted from the JSON body that Axios sends. The backend will treat missing fields as `true` (scan everything), which keeps backward compatibility with any other callers of the API.

---

## Step 2: Add State Variables to the Scan Page

**File:** `const-catalog-frontend/src/pages/ScanPage.tsx`

Find the existing state declarations near the top of the component (around lines 15-17):

```typescript
const [projectPath, setProjectPath] = useState('')
const [scanResult, setScanResult] = useState<ScanResponse | null>(null)
const [watchProgress, setWatchProgress] = useState(true)
```

Add two new state variables immediately after:

```typescript
const [projectPath, setProjectPath] = useState('')
const [scanResult, setScanResult] = useState<ScanResponse | null>(null)
const [watchProgress, setWatchProgress] = useState(true)
const [scanConstants, setScanConstants] = useState(true)
const [scanParameters, setScanParameters] = useState(true)
```

Both default to `true` so the initial behavior matches what users expect.

---

## Step 3: Pass the New State into the Mutation Call

**File:** `const-catalog-frontend/src/pages/ScanPage.tsx`

Find the `handleScan` function (around line 37). The mutation call currently looks like this:

```typescript
scanMutation.mutate({ projectPath: projectPath.trim() })
```

Change it to include the two new fields:

```typescript
scanMutation.mutate({
  projectPath: projectPath.trim(),
  scanConstants,
  scanParameters,
})
```

---

## Step 4: Add the Checkbox UI

**File:** `const-catalog-frontend/src/pages/ScanPage.tsx`

Find the existing "Watch scan progress" checkbox block (around lines 101-113):

```tsx
<div className="flex items-center gap-2">
  <input
    type="checkbox"
    id="watchProgress"
    checked={watchProgress}
    onChange={(e) => setWatchProgress(e.target.checked)}
    className="rounded border-space-light"
  />
  <label htmlFor="watchProgress" className="text-terminal-dim text-sm flex items-center gap-1">
    <Radio className="w-3 h-3" />
    Watch scan progress (live file updates)
  </label>
</div>
```

Immediately **after** that `</div>`, add a new row with both scan-scope checkboxes:

```tsx
<div className="flex items-center gap-6">
  <div className="flex items-center gap-2">
    <input
      type="checkbox"
      id="scanConstants"
      checked={scanConstants}
      onChange={(e) => setScanConstants(e.target.checked)}
      className="rounded border-space-light"
    />
    <label htmlFor="scanConstants" className="text-terminal-dim text-sm">
      Scan for Constants
    </label>
  </div>

  <div className="flex items-center gap-2">
    <input
      type="checkbox"
      id="scanParameters"
      checked={scanParameters}
      onChange={(e) => setScanParameters(e.target.checked)}
      className="rounded border-space-light"
    />
    <label htmlFor="scanParameters" className="text-terminal-dim text-sm">
      Scan for Parameters
    </label>
  </div>
</div>
```

### Layout notes

- The outer `div` uses `gap-6` to put horizontal space between the two checkboxes.
- Each checkbox uses `gap-2` between the input and its label, matching the existing "Watch scan progress" style.
- The `text-terminal-dim text-sm` classes match the existing label styling from the Space Command theme.

---

## Step 5: Confirm the API Client Needs No Changes

**File:** `const-catalog-frontend/src/services/api.ts`

The `scanProject` function already sends the entire `ScanRequest` object as the POST body:

```typescript
export async function scanProject(request: ScanRequest): Promise<ScanResponse> {
  const response = await api.post<ScanResponse>('/scan', request)
  return response.data
}
```

Because it passes the whole typed object, any new fields added to `ScanRequest` in Step 1 are automatically included in the JSON payload. No changes needed here.

---

## Step 6: Add Fields to the Backend DTO

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/dto/ScanRequest.java`

The current class has only `projectPath`:

```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request to scan a Java project for constants and parameters")
public class ScanRequest {

    @NotBlank(message = "Project path is required")
    @Schema(
        description = "Absolute or relative path to the Java project root directory",
        example = "/home/user/projects/my-app",
        required = true
    )
    private String projectPath;
}
```

Add two `Boolean` fields after `projectPath`:

```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Request to scan a Java project for constants and parameters")
public class ScanRequest {

    @NotBlank(message = "Project path is required")
    @Schema(
        description = "Absolute or relative path to the Java project root directory",
        example = "/home/user/projects/my-app",
        required = true
    )
    private String projectPath;

    @Schema(description = "Whether to scan for constants (default: true)")
    @Builder.Default
    private Boolean scanConstants = true;

    @Schema(description = "Whether to scan for parameters (default: true)")
    @Builder.Default
    private Boolean scanParameters = true;
}
```

### Why `Boolean` (boxed) instead of `boolean` (primitive)?

- A primitive `boolean` defaults to `false` when Jackson doesn't find the field in the JSON. That would silently disable scanning for clients that don't send the field.
- A boxed `Boolean` defaults to `null` when the field is missing, which lets us distinguish "not sent" from "explicitly set to false."
- The `@Builder.Default` annotation ensures that when code uses the builder pattern (e.g., `ScanRequest.builder().projectPath(p).build()`), the fields default to `true`.

### Update the SSE streaming path

In `ScanController.java` (line 180), the streaming endpoint constructs a `ScanRequest` directly:

```java
scanService.scanProjectWithProgress(
    new ScanRequest(projectPath),
    emitter,
    objectMapper
);
```

This uses the `@AllArgsConstructor` which now expects three arguments. Change it to use the builder:

```java
scanService.scanProjectWithProgress(
    ScanRequest.builder().projectPath(projectPath).build(),
    emitter,
    objectMapper
);
```

This way the SSE path gets the `@Builder.Default` values of `true` for both flags.

---

## Step 7: Use the Flags in the Service Layer

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/ScanService.java`

In the `scanProject` method, after the `projectScanner.scan()` call (around line 63), add filtering logic before the graph is populated.

### Before (current code):

```java
ProjectScanner.ScanResult scanResult = projectScanner.scan(projectPath);

// ... logging ...

graphPopulator.populateGraph(
    projectPath.toString(),
    extractProjectName(projectPath),
    scanResult
);
```

### After (with filtering):

```java
ProjectScanner.ScanResult scanResult = projectScanner.scan(projectPath);

// Resolve flags — treat null as true (backward compatible)
boolean includeConstants = request.getScanConstants() != Boolean.FALSE;
boolean includeParameters = request.getScanParameters() != Boolean.FALSE;

log.info("Scan complete. Found {} constants, {} parameters, {} param usages, {} constant usages",
    scanResult.constants().size(),
    scanResult.parameters().size(),
    scanResult.parameterUsages().size(),
    scanResult.constantUsages().size());

log.info("Scan scope: constants={}, parameters={}", includeConstants, includeParameters);

// Filter results based on user's checkbox selections
ProjectScanner.ScanResult filtered = new ProjectScanner.ScanResult(
    includeConstants ? scanResult.constants() : List.of(),
    includeParameters ? scanResult.parameters() : List.of(),
    includeParameters ? scanResult.parameterUsages() : List.of(),
    includeConstants ? scanResult.constantUsages() : List.of(),
    scanResult.javaFileFqns(),
    scanResult.javaFilesScanned(),
    scanResult.propertyFilesScanned(),
    scanResult.fileTypeStats()
);

graphPopulator.populateGraph(
    projectPath.toString(),
    extractProjectName(projectPath),
    filtered
);
```

Add the `List` import at the top of the file if it isn't already there:

```java
import java.util.List;
```

### Why filter after scanning rather than skipping the scan?

The scanner runs in two passes: property files first (to discover parameter names), then Java files (to find constants and parameter usages). Constant usages also depend on the first pass knowing what constants exist. Skipping either pass would break the other's detection logic. It is simpler and safer to scan everything and then discard what the user didn't ask for before persisting to the graph.

### Apply the same logic to `scanProjectWithProgress`

The SSE streaming method also calls `projectScanner.scan()` and `graphPopulator.populateGraph()`. Apply the same filtering pattern there so both code paths behave consistently.

---

## Summary of Changes

| # | File | What to change |
|---|------|----------------|
| 1 | `const-catalog-frontend/src/types/index.ts` | Add `scanConstants?` and `scanParameters?` to `ScanRequest` |
| 2 | `const-catalog-frontend/src/pages/ScanPage.tsx` | Add two `useState` booleans |
| 3 | `const-catalog-frontend/src/pages/ScanPage.tsx` | Pass new state into `scanMutation.mutate()` |
| 4 | `const-catalog-frontend/src/pages/ScanPage.tsx` | Add two checkbox `<input>` elements after the "Watch progress" checkbox |
| 5 | `const-catalog-frontend/src/services/api.ts` | No changes needed |
| 6 | `const-catalog-backend/.../dto/ScanRequest.java` | Add two `Boolean` fields with `@Builder.Default = true` |
| 7 | `const-catalog-backend/.../controller/ScanController.java` | Update `new ScanRequest(projectPath)` to use builder |
| 8 | `const-catalog-backend/.../service/ScanService.java` | Filter `ScanResult` based on the flags before populating the graph |

---

## Testing

1. **Both checked (default):** Should behave exactly as before — full scan.
2. **Only "Scan for Constants" checked:** The response should show `parametersFound: 0` and `parameterUsagesFound: 0`. The graph should contain only constant nodes and their relationships.
3. **Only "Scan for Parameters" checked:** The response should show `constantsFound: 0`. The graph should contain only parameter nodes and their usage relationships.
4. **Neither checked:** Edge case. The scan will still walk the filesystem and report file counts, but nothing will be persisted to the graph. Consider whether you want to show a validation warning in the UI for this case.
5. **API call without the fields (backward compatibility):** Send `{"projectPath": "/some/path"}` directly via curl or Swagger. Both flags should default to `true` and produce a full scan.
