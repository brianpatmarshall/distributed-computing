# Constants Catalog - Detailed Design Document

## 1. Design Philosophy

### 1.1 Core Principles

**Separation of Concerns.** The core module has zero Spring dependencies. Parsing, scanning, exporting, and transforming are pure Java operations that can run standalone (CLI) or be orchestrated by Spring (backend).

**Records Over Classes.** Java 21 records are used for all immutable data carriers (Constant, Parameter, ParameterUsage, ConstantTarget, TransformationEntry, TransformationResult) providing compact, correct value semantics.

**Functional Style.** Stream pipelines, Optional chaining, Predicate fields, and factory methods replace imperative if/else chains.

**Lombok for Ceremony Reduction.** Backend DTOs and entities use @Data, @Builder, @RequiredArgsConstructor to eliminate boilerplate while keeping the domain model explicit.

**Graph-First Data Model.** Neo4j stores the relationships between projects, files, constants, and parameters as first-class graph edges, enabling powerful Cypher queries that would be expensive joins in a relational model.

**Cache-Aside with Pub/Sub Invalidation.** Two-tier caching (Caffeine L1, ValKey L2) with Pub/Sub invalidation gives sub-millisecond reads and cross-instance consistency.

**AST-Based Transformation.** JavaParser provides type-safe AST manipulation rather than fragile regex-based find-and-replace.

### 1.2 Naming Conventions

| Pattern              | Convention                     | Example                              |
|:---------------------|:-------------------------------|:-------------------------------------|
| Records (core)       | Immutable data carriers        | Constant, Parameter, ConstantTarget  |
| Entities (backend)   | Neo4j node/relationship POJOs  | ProjectNode, FileNode, ConstantNode  |
| DTOs (backend)       | Request/Response payloads      | ScanRequest, ScanResponse            |
| Services             | Business orchestration         | ScanService, QueryService            |
| Controllers          | REST endpoint handlers         | ScanController, QueryController      |
| Repositories         | Spring Data Neo4j interfaces   | ProjectRepository, FileRepository    |

---

## 2. Core Module (const-catalog-core)

### 2.1 Model Records

#### Constant

**File:** model/Constant.java\
**Purpose:** Represents a private static final field discovered in a Java source file.

| Field      | Type   | Description              |
|:-----------|:-------|:-------------------------|
| name       | String | Field name (e.g. DB_HOST)|
| type       | String | Java type (e.g. String)  |
| value      | String | Literal value            |
| fileName   | String | Source file path          |
| className  | String | Enclosing class name     |
| lineNumber | int    | Line number in source    |

**Methods:**

| Method      | Returns | Description                              |
|:------------|:--------|:-----------------------------------------|
| toCsvLine   | String  | CSV serialization with quote escaping    |
| csvHeader   | String  | Static. Returns the CSV header line      |

#### Parameter

**File:** model/Parameter.java\
**Purpose:** Represents a key-value pair from a property, YAML, or env file.

| Field          | Type   | Description                    |
|:---------------|:-------|:-------------------------------|
| name           | String | Property key                   |
| value          | String | Property value                 |
| definitionFile | String | File where defined             |
| lineNumber     | int    | Line number (-1 for YAML)      |

**Methods:**

| Method      | Returns | Description                              |
|:------------|:--------|:-----------------------------------------|
| toCsvLine   | String  | CSV serialization                        |
| csvHeader   | String  | Static. Returns the CSV header line      |

#### ParameterUsage

**File:** model/ParameterUsage.java\
**Purpose:** Records where a parameter is referenced in Java source code.

| Field         | Type   | Description                  |
|:--------------|:-------|:-----------------------------|
| parameterName | String | Referenced parameter name    |
| usedInFile    | String | Java file using it           |
| usedInClass   | String | Class using it               |
| lineNumber    | int    | Line number of usage         |
| context       | String | Surrounding code context     |

**Methods:**

| Method      | Returns | Description                              |
|:------------|:--------|:-----------------------------------------|
| toCsvLine   | String  | CSV serialization with context escaping  |
| csvHeader   | String  | Static. Returns the CSV header line      |

#### ConstantTarget

**File:** model/ConstantTarget.java\
**Purpose:** Represents a constant selected for transformation into a @Value property lookup.

| Field         | Type   | Description                      |
|:--------------|:-------|:---------------------------------|
| constantName  | String | Original name (e.g. DB_HOST)     |
| propertyKey   | String | Derived key (e.g. db.host)       |
| originalValue | String | Hardcoded value being replaced   |
| originalType  | String | Java type (String, int, etc.)    |
| className     | String | Enclosing class                  |
| lineNumber    | int    | Line number in source            |

**Static Methods:**

| Method              | Returns | Description                                     |
|:--------------------|:--------|:------------------------------------------------|
| derivePropertyKey   | String  | Converts DB_HOST to db.host                     |
| deriveCamelCaseName | String  | Converts DB_HOST to dbHost                      |

#### TransformationEntry

**File:** model/TransformationEntry.java\
**Purpose:** Records the outcome of transforming a single constant.

| Field         | Type   | Description                           |
|:--------------|:-------|:--------------------------------------|
| filePath      | String | Modified source file                  |
| className     | String | Class containing the constant         |
| constantName  | String | Original constant name                |
| propertyKey   | String | Derived property key                  |
| originalValue | String | Value that was hardcoded              |
| originalType  | String | Java type                             |
| lineNumber    | int    | Where the constant was found          |
| status        | Status | TRANSFORMED, SKIPPED, or FAILED      |
| message       | String | Human-readable description            |

**Enum Status:** TRANSFORMED, SKIPPED, FAILED

**Factory Methods:**

| Method      | Description                          |
|:------------|:-------------------------------------|
| transformed | Creates entry with TRANSFORMED status|
| skipped     | Creates entry with SKIPPED status    |
| failed      | Creates entry with FAILED status     |

#### TransformationResult

**File:** model/TransformationResult.java\
**Purpose:** Aggregated result of a batch transformation over multiple files.

| Field         | Type                      | Description              |
|:--------------|:--------------------------|:-------------------------|
| projectPath   | String                    | Project root path        |
| transformedAt | LocalDateTime             | Timestamp                |
| entries       | List of TransformationEntry | All individual outcomes |

**Derived Methods (functional stream-based):**

| Method             | Returns                    | Description                    |
|:-------------------|:---------------------------|:-------------------------------|
| totalTransformed   | long                       | Count of TRANSFORMED entries   |
| totalSkipped       | long                       | Count of SKIPPED entries       |
| totalFailed        | long                       | Count of FAILED entries        |
| groupedByStatus    | Map of Status to List      | Entries grouped by status      |
| transformedEntries | List of TransformationEntry| Filtered TRANSFORMED entries   |
| failedEntries      | List of TransformationEntry| Filtered FAILED entries        |

---

### 2.2 Parsers

#### JavaFileParser

**File:** parser/JavaFileParser.java\
**Purpose:** Extracts constants and detects parameter usages from Java source files using JavaParser AST.

**Fields:**

| Field                    | Type        | Description                                       |
|:-------------------------|:------------|:--------------------------------------------------|
| javaParser               | JavaParser  | JavaParser instance                               |
| PROPERTY_GETTER_METHODS  | Set(String) | Property accessor methods recognized by the parser|
| VALUE_ANNOTATION_PATTERN | Pattern     | Regex to extract param names from @Value          |

The recognized property getter methods are: getProperty, get, getString, getInt, getInteger, getLong, getBoolean, getDouble, getFloat, getValue, getConfig, getenv, getOrDefault, getPropertyValue.

**Public Methods:**

| Method              | Parameters                    | Returns              | Description                                 |
|:--------------------|:------------------------------|:---------------------|:--------------------------------------------|
| parseConstants      | Path filePath                 | List of Constant     | Walks AST to find private static final fields|
| parseParameterUsages| Path filePath, Set knownParams| List of ParameterUsage| Finds @Value annotations and getter calls  |

**Design Notes:**

- Uses JavaParser VoidVisitorAdapter pattern with an anonymous inner class
- Tracks class context via a currentClass string updated on ClassOrInterfaceDeclaration visits
- Tolerates parse failures gracefully (logs warning, returns partial results)

#### PropertyFileParser

**File:** parser/PropertyFileParser.java\
**Purpose:** Parses multiple configuration file formats to extract parameters.

**Supported Formats:**

| Extension    | Parser Method         | Library                         |
|:-------------|:----------------------|:--------------------------------|
| .properties  | parsePropertiesFile   | Manual (handles line continuation)|
| .yml, .yaml  | parseYamlFile         | SnakeYAML                       |
| .xml         | parseXmlConfigFile    | Manual regex                    |
| .env         | parseEnvFile          | Manual                          |

**Key Private Methods:**

| Method                | Description                                                  |
|:----------------------|:-------------------------------------------------------------|
| parsePropertiesFile   | Handles # and ! comments, = and : separators, line continuation|
| parseYamlFile         | Full SnakeYAML parsing with recursive flattening             |
| flattenYamlMap        | Recursively flattens nested YAML into dot-notation keys      |
| flattenYamlCollection | Handles YAML arrays into indexed keys                        |
| parseXmlConfigFile    | Extracts property name/value and entry key/value patterns    |
| parseEnvFile          | Parses KEY=VALUE pairs, strips surrounding quotes            |

---

### 2.3 Scanner

#### ProjectScanner

**File:** scanner/ProjectScanner.java\
**Purpose:** Walks a project directory tree, delegates to parsers, and aggregates results.

**Excluded Directories:** target, build, out, .git, .idea, .gradle, node_modules, .mvn, bin, .settings

**Property Extensions:** .properties, .yml, .yaml, .env

**Inner Record ScanResult:**

| Field                | Type                   | Description                |
|:---------------------|:-----------------------|:---------------------------|
| constants            | List of Constant       | All discovered constants   |
| parameters           | List of Parameter      | All discovered parameters  |
| parameterUsages      | List of ParameterUsage | All parameter references   |
| javaFilesScanned     | int                    | Number of Java files parsed|
| propertyFilesScanned | int                    | Number of config files parsed|

**Algorithm:**

1. Walk directory tree with Files.walkFileTree and SimpleFileVisitor
2. Skip excluded directories in preVisitDirectory
3. Collect .java files and property files
4. **Phase 1:** Parse all property files to build the set of known parameter names
5. **Phase 2:** Parse all Java files for constants and parameter usages (using known parameters)
6. Return aggregated ScanResult

---

### 2.4 Exporter

#### CsvExporter

**File:** export/CsvExporter.java\
**Purpose:** Exports scan results to Neo4j-compatible CSV files and generates a Cypher import script.

**Generated Files:**

| File                     | Content        | Neo4j Role                          |
|:-------------------------|:---------------|:------------------------------------|
| constants.csv            | Constant nodes | ID, name, type, value, className    |
| parameters.csv           | Parameter nodes| ID, name, value                     |
| files.csv                | File nodes     | ID, path, fileName                  |
| constant_in_file.csv     | DEFINED_IN     | START_ID, END_ID, lineNumber        |
| parameter_defined_in.csv | DEFINED_IN     | START_ID, END_ID                    |
| parameter_used_in.csv    | USED_IN        | START_ID, END_ID, lineNumber, context|
| import-neo4j.cypher      | Import script  | LOAD CSV commands                   |

**ID Generation:**

| Entity    | Format                                  |
|:----------|:----------------------------------------|
| Constants | const_className_name (sanitized)        |
| Parameters| param_name (sanitized)                  |
| Files     | file_path (sanitized)                   |

---

### 2.5 Transformer

#### JavaCodeTransformer

**File:** transformer/JavaCodeTransformer.java\
**Purpose:** Replaces hardcoded static final constants with Spring @Value property lookups using JavaParser AST manipulation.

**Constant Sets:**

| Set                    | Values                                                                |
|:-----------------------|:----------------------------------------------------------------------|
| SPRING_BEAN_ANNOTATIONS| Component, Service, Repository, Controller, RestController, Configuration, Bean|
| NON_INJECTABLE_TYPES   | Logger, Pattern, long, double, float, boolean, byte, short, char      |
| CONFIG_PATTERNS        | HOST, PORT, URL, URI, PATH, KEY, SECRET, PASSWORD, TIMEOUT, ENDPOINT, DATABASE, CONNECTION, SERVER, CLIENT|

Line number tolerance is +/- 3 lines to handle drift since last scan.

**Public API:**

| Method               | Parameters                           | Returns                  | Description                          |
|:---------------------|:-------------------------------------|:-------------------------|:-------------------------------------|
| transformFile        | Path sourceFile, List targets        | List of TransformationEntry| Transforms a single file in place  |
| transformProject     | String projectPath, Map targetsByFile| TransformationResult     | Batch transforms across files        |
| dryRun               | Path sourceFile, List targets        | List of TransformationEntry| Reports changes without modifying  |
| looksLikeConfiguration| String constantName                 | boolean                  | Static. Checks if name matches config patterns|

**Transformation Steps (per constant):**

1. **Find field:** Match by constant name + line number (within tolerance)
2. **Check skip reasons:** Non-injectable type? Already annotated? Complex initializer?
3. **Remove modifiers:** Strip static and final
4. **Rename:** DB_HOST becomes dbHost
5. **Remove initializer:** Drop = "localhost"
6. **Add annotation:** Insert @Value("${db.host}")
7. **Post-processing:** Add @Component if class has no Spring bean annotation, add required imports

**Skip Logic:**

| Condition                          | Reason                       |
|:-----------------------------------|:-----------------------------|
| Type in NON_INJECTABLE_TYPES       | Non-injectable type          |
| Field already has @Value           | Already has @Value annotation|
| Complex initializer (new, List.of, etc.)| Complex initializer     |

**Before/After Example:**

```java
// Before
private static final String DB_HOST = "localhost";

// After
@Value("${db.host}")
private String dbHost;
```

---

## 3. Backend Module (const-catalog-backend)

### 3.1 Configuration

#### Neo4jConfig

**File:** config/Neo4jConfig.java\
**Annotations:** @Configuration, @Slf4j

Creates the Neo4j Driver bean from the configured URI, with optional authentication from username and password properties.

#### WebConfig

**File:** config/WebConfig.java\
**Annotations:** @Configuration\
**Implements:** WebMvcConfigurer

Configures CORS for development: allows origins localhost:3000, localhost:3001, localhost:5173.

#### OpenApiConfig

**File:** config/OpenApiConfig.java\
**Annotations:** @Configuration

Configures Swagger/OpenAPI 3 documentation with title "Constants Catalog API", version from build, and server URL from server.port.

#### ValKeyConfig

**File:** config/ValKeyConfig.java\
**Annotations:** @Configuration, @Slf4j

**Beans Created:**

| Bean                  | Type                           | Description                              |
|:----------------------|:-------------------------------|:-----------------------------------------|
| clientResources       | ClientResources                | Lettuce thread pool and event loop       |
| redisUri              | RedisURI                       | Connection URI with host/port/password   |
| redisClient           | RedisClient                    | Main Lettuce client                      |
| redisConnection       | StatefulRedisConnection        | Primary sync connection (@Primary)       |
| redisPubSubConnection | StatefulRedisPubSubConnection  | Dedicated Pub/Sub connection             |
| caffeineBuilder       | Caffeine                       | L1 cache (max-size, expire-after-write, stats)|

**Constants:** CONFIG_CHANGE_CHANNEL = "config:changes", CONFIG_KEY_PREFIX = "config:"

---

### 3.2 Custom Annotations

#### @SiteConfig

**File:** annotation/SiteConfig.java\
**Purpose:** Class-level annotation (like @Slf4j) that injects a SiteConfigurationService field.

```java
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface SiteConfig {
    String value() default "config";
}
```

#### SiteConfigBeanPostProcessor

**File:** annotation/SiteConfigBeanPostProcessor.java\
**Implements:** BeanPostProcessor, PriorityOrdered, ApplicationContextAware

Uses reflection in postProcessBeforeInitialization to inject SiteConfigurationService into any bean annotated with @SiteConfig. Searches the class hierarchy for the annotation and uses field injection by name.

#### SiteConfigurationServiceProvider

**File:** annotation/SiteConfigurationServiceProvider.java

Static singleton providing SiteConfigurationService.get() access for non-Spring contexts. Initialized via @PostConstruct. Thread-safe via volatile.

---

### 3.3 Entities (Neo4j Nodes)

#### ProjectNode

**File:** entity/ProjectNode.java\
**Annotations:** @Node("Project"), @Data, @Builder

| Field           | Type            | Annotations                        | Description              |
|:----------------|:----------------|:-----------------------------------|:-------------------------|
| id              | String          | @Id, @GeneratedValue               | UUID primary key         |
| name            | String          |                                    | Project display name     |
| rootPath        | String          |                                    | Absolute path to root    |
| scannedAt       | LocalDateTime   |                                    | When last scanned        |
| totalFiles      | int             |                                    | File count               |
| totalConstants  | int             |                                    | Constant count           |
| totalParameters | int             |                                    | Parameter count          |
| files           | Set of FileNode | @Relationship("CONTAINS", OUTGOING)| Contained files          |

#### FileNode

**File:** entity/FileNode.java\
**Annotations:** @Node("File"), @Data, @Builder

| Field      | Type                | Relationship                    | Description              |
|:-----------|:--------------------|:--------------------------------|:-------------------------|
| id         | String              |                                 | UUID                     |
| path       | String              |                                 | Full file path           |
| fileName   | String              |                                 | File name only           |
| constants  | Set of ConstantNode | DEFINED_IN, INCOMING            | Constants in this file   |
| parameters | Set of ParameterNode| DEFINED_IN, INCOMING            | Parameters in this file  |

#### ConstantNode

**File:** entity/ConstantNode.java\
**Annotations:** @Node("Constant"), @Data, @Builder

| Field      | Type     | Description                     |
|:-----------|:---------|:--------------------------------|
| id         | String   | UUID                            |
| name       | String   | Constant name                   |
| type       | String   | Java type                       |
| value      | String   | Literal value                   |
| className  | String   | Enclosing class                 |
| lineNumber | int      | Source line                     |
| file       | FileNode | DEFINED_IN, OUTGOING            |

#### ParameterNode

**File:** entity/ParameterNode.java\
**Annotations:** @Node("Parameter"), @Data, @Builder

| Field          | Type                       | Description                     |
|:---------------|:---------------------------|:--------------------------------|
| id             | String                     | UUID                            |
| name           | String                     | Parameter key                   |
| value          | String                     | Parameter value                 |
| definitionFile | String                     | File where defined              |
| lineNumber     | int                        | Line number                     |
| file           | FileNode                   | DEFINED_IN, OUTGOING            |
| usages         | List of UsageRelationship  | USED_IN, OUTGOING               |

#### UsageRelationship

**File:** entity/UsageRelationship.java\
**Annotations:** @RelationshipProperties, @Data, @Builder

| Field      | Type     | Description                            |
|:-----------|:---------|:---------------------------------------|
| id         | Long     | Auto-generated                         |
| file       | FileNode | @TargetNode - File where param is used |
| className  | String   | Class using the parameter              |
| lineNumber | int      | Line of usage                          |
| context    | String   | Surrounding code context               |

---

### 3.4 Repositories

#### ProjectRepository

**Extends:** Neo4jRepository of ProjectNode, String

| Method                  | Description                                   |
|:------------------------|:----------------------------------------------|
| findByRootPath          | Find project by its root path                 |
| findByName              | Find project by name                          |
| findAllWithFiles        | @Query - MATCH with OPTIONAL MATCH on files   |
| findByRootPathWithStats | @Query - Project with count aggregations      |
| getDatabaseStats        | @Query - Aggregate counts across all node types|

Inner Interface DatabaseStats provides: getProjectCount, getTotalFiles, getTotalConstants, getTotalParameters.

#### FileRepository

**Extends:** Neo4jRepository of FileNode, String

| Method        | Description                    |
|:--------------|:-------------------------------|
| findByPath    | Find file by path              |
| findByProject | @Query - Files in a project    |

#### ConstantRepository

**Extends:** Neo4jRepository of ConstantNode, String

| Method                      | Description                                        |
|:----------------------------|:---------------------------------------------------|
| findByName                  | Find constant by name                              |
| findByClassName             | Find constants in a class                          |
| findByType                  | Find constants of a type                           |
| findByNameContaining        | Search by partial name                             |
| findConfigurationCandidates | @Query - Constants matching HOST/PORT/URL patterns |
| findDuplicateValues         | @Query - Constants sharing the same value          |
| findConnectionStrings       | @Query - Constants with URL/connection values      |

#### ParameterRepository

**Extends:** Neo4jRepository of ParameterNode, String

| Method                  | Description                                         |
|:------------------------|:----------------------------------------------------|
| findByName              | Find parameter by name                              |
| findByNameContaining    | Search by partial name                              |
| findByDefinitionFile    | @Query - Parameters in a file                       |
| findUnusedParameters    | @Query - Parameters with no USED_IN edges           |
| findCrossFileParameters | @Query - Parameters used in multiple files          |
| findMostUsedParameters  | @Query - Top 10 by usage count                      |
| findSensitiveParameters | @Query - Names matching password/secret/key/token   |
| findParametersByPrefix  | @Query - Grouped by dot-prefix                      |
| findAllWithUsageDetails | @Query - Full details with usage locations           |

---

### 3.5 Services

#### ScanService

**File:** service/ScanService.java\
**Dependencies:** GraphPopulatorService

| Method       | Description                                                                     |
|:-------------|:--------------------------------------------------------------------------------|
| scanProject  | Validates path, creates ProjectScanner, scans, delegates to GraphPopulatorService|

Validation checks that the path exists and is a directory. Extracts project name from directory name.

#### GraphPopulatorService

**File:** service/GraphPopulatorService.java\
**Dependencies:** All 4 repositories\
**Annotations:** Methods are @Transactional

**Population Algorithm (6 phases):**

1. Create or update ProjectNode
2. Collect all unique file paths from scan result
3. Create FileNode for each unique path, link to project via CONTAINS
4. Create ConstantNode for each constant, link to file via DEFINED_IN
5. Create ParameterNode for each parameter, link to file via DEFINED_IN
6. Create UsageRelationship for each parameter usage, link via USED_IN

#### QueryService

**File:** service/QueryService.java\
**Dependencies:** Neo4j Driver

| Method                | Description                               |
|:----------------------|:------------------------------------------|
| getPreCannedQueries   | Returns list of 10 built-in queries       |
| getPreCannedQueryById | Finds a query by ID                       |
| executePreCannedQuery | Looks up and executes a pre-canned query  |
| executeQuery          | Validates read-only, executes ad-hoc Cypher|

**Security:** isReadOnlyQuery rejects queries containing CREATE, DELETE, SET, REMOVE, MERGE, DROP, DETACH.

#### SiteConfigurationService

**File:** service/SiteConfigurationService.java\
**Dependencies:** StatefulRedisConnection, StatefulRedisPubSubConnection, Caffeine

**Cache-Aside Pattern:**

1. Check Caffeine L1 cache
2. If miss, fetch from ValKey L2
3. Store in L1 cache
4. Return value

**Lookup Methods:**

| Method         | Returns         | Description                                |
|:---------------|:----------------|:-------------------------------------------|
| lookup(key)    | String          | Basic cache-aside lookup                   |
| lookup(key, default) | String    | With default value                         |
| lookup(key, supplier)| String    | With lazy default                          |
| lookupInt      | int             | Type-safe integer with default             |
| lookupLong     | long            | Type-safe long with default                |
| lookupBoolean  | boolean         | Recognizes true/false, yes/no, 1/0, on/off |
| lookupDouble   | double          | Type-safe double with default              |
| lookup(key, fn, default)| T       | Generic transform                          |
| lookupBatch    | Map             | Batch lookup multiple keys                 |
| lookupByPrefix | Map             | Lookup by key prefix                       |

**Write Methods:**

| Method     | Description                                  |
|:-----------|:---------------------------------------------|
| store      | SET in ValKey, publish change notification    |
| storeBatch | MSET + publish for each key                  |
| delete     | DEL in ValKey, publish change notification    |

**Cache Management Methods:**

| Method          | Description                                             |
|:----------------|:--------------------------------------------------------|
| invalidateLocal | Evict single key from Caffeine                          |
| invalidateAll   | Clear entire Caffeine cache                             |
| getCacheStats   | Returns hit count, miss count, hit rate, eviction count |

NULL_SENTINEL prevents cache pollution from repeated misses on non-existent keys.

#### ConfigurationExportService

**File:** service/ConfigurationExportService.java\
**Dependencies:** ConstantRepository, ParameterRepository, StatefulRedisConnection, Neo4jClient, SiteConfigurationService

**Export Strategies:**

| Strategy             | Behavior                                                |
|:---------------------|:--------------------------------------------------------|
| CONSTANTS_AS_CONFIG  | Only constants matching config patterns                 |
| PARAMETERS_AS_CONFIG | All parameters from property/YAML files                 |
| MERGED               | Both, with parameters overriding constants on collision |
| FULL                 | Everything with full qualified paths                    |

**Methods:**

| Method        | Description                                    |
|:--------------|:-----------------------------------------------|
| export        | Exports all projects' config to ValKey          |
| exportProject | Exports single project's config                |
| clearExported | Deletes all config:* keys from ValKey          |
| getStats      | Returns counts of total/constant/parameter keys|

**Key Derivation:** DB_HOST becomes config:db.host (lowercase, underscore to dot, prefixed).

#### ConfigurationChangeListener

**File:** service/ConfigurationChangeListener.java\
**Dependencies:** StatefulRedisPubSubConnection, SiteConfigurationService, ApplicationEventPublisher

| Method                       | Lifecycle    | Description                                  |
|:-----------------------------|:-------------|:---------------------------------------------|
| subscribe                    | @PostConstruct| Subscribes to config:changes Pub/Sub channel|
| unsubscribe                  | @PreDestroy  | Graceful cleanup                             |
| handleConfigurationChange    | (private)    | Invalidates L1 cache, publishes Spring event |
| getStats                     |              | Returns messages received, invalidations, connected status|
| isConnected                  |              | Checks Pub/Sub connection status             |

Inner class ConfigurationChangedEvent extends ApplicationEvent, carrying the changed key for application-level reaction to config changes.

#### CodeTransformationService

**File:** service/CodeTransformationService.java\
**Dependencies:** Neo4jClient, JavaCodeTransformer

| Method    | Description                                                              |
|:----------|:-------------------------------------------------------------------------|
| transform | Orchestrates: query Neo4j, group by file, transform or dry-run, respond |

**Cypher Query:**

```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)
      <-[:DEFINED_IN]-(c:Constant)
WHERE c.type IN ['String', 'java.lang.String', 'int', 'long', 'Integer', 'Long']
  AND c.name =~ '(?i).*(HOST|PORT|URL|URI|PATH|KEY|SECRET|PASSWORD|
      TIMEOUT|ENDPOINT|DATABASE|CONNECTION|SERVER|CLIENT).*'
RETURN c.name, c.type, c.value, c.className, c.lineNumber, f.path
ORDER BY f.path, c.lineNumber
```

Inner record ConstantWithFile holds the join of constant data with file location, with a toTarget() factory method.

---

### 3.6 Controllers

#### ScanController

**Path:** POST /api/scan\
**Tag:** Scan

| Endpoint  | Method | Description                          |
|:----------|:-------|:-------------------------------------|
| /api/scan | POST   | Accepts ScanRequest, returns ScanResponse|

#### QueryController

**Path:** /api/query\
**Tag:** Query

| Endpoint                     | Method | Description                     |
|:-----------------------------|:-------|:--------------------------------|
| /api/query/precanned         | GET    | List all pre-canned queries     |
| /api/query/precanned/{queryId}| GET   | Execute a pre-canned query by ID|
| /api/query/execute           | POST   | Execute ad-hoc Cypher query     |

#### StatsController

**Path:** /api/stats\
**Tag:** Statistics

| Endpoint              | Method | Description                           |
|:----------------------|:-------|:--------------------------------------|
| /api/stats            | GET    | Aggregate database statistics         |
| /api/stats/constants  | GET    | List constants (optional filter)      |
| /api/stats/parameters | GET    | List parameters (optional filter)     |
| /api/stats/health     | GET    | Health check with database status     |

#### FileController

**Path:** /api/files\
**Tag:** Files

| Endpoint           | Method | Description                |
|:-------------------|:-------|:---------------------------|
| /api/files/content | GET    | Read file contents by path |

Security: Validates path starts with allowed prefixes: /src, /esrc, /csrc, /projects.

#### TransformController

**Path:** POST /api/transform\
**Tag:** Transform

| Endpoint       | Method | Description                         |
|:---------------|:-------|:------------------------------------|
| /api/transform | POST   | Transform constants to @Value lookups|

Accepts TransformRequest (projectPath, dryRun), returns TransformResponse with per-entry details.

#### ConfigurationController

**Path:** /api/config\
**Tag:** Configuration

**Export Operations:**

| Endpoint                   | Method | Description                    |
|:---------------------------|:-------|:-------------------------------|
| /api/config/export         | POST   | Export config to ValKey         |
| /api/config/export/project | POST   | Export project-specific config  |
| /api/config/export         | DELETE | Clear all exported config       |

**Lookup Operations:**

| Endpoint                          | Method | Description              |
|:----------------------------------|:-------|:-------------------------|
| /api/config/lookup/{key}          | GET    | Lookup single value      |
| /api/config/lookup/batch          | GET    | Batch lookup by key list |
| /api/config/lookup/prefix/{prefix}| GET    | Lookup by key prefix     |

**Store Operations:**

| Endpoint                | Method | Description        |
|:------------------------|:-------|:-------------------|
| /api/config/store       | POST   | Store single value |
| /api/config/store/batch | POST   | Batch store        |
| /api/config/{key}       | DELETE | Delete a value     |

**Cache and Statistics:**

| Endpoint                      | Method | Description              |
|:------------------------------|:-------|:-------------------------|
| /api/config/cache/invalidate  | POST   | Invalidate L1 cache      |
| /api/config/stats             | GET    | Service statistics        |
| /api/config/stats/cache       | GET    | Cache hit/miss stats     |
| /api/config/health            | GET    | Pub/Sub health           |

Inner records (Java 21): ExportRequest, ProjectExportRequest, StoreRequest, InvalidationRequest, LookupResult, StoreResult, BatchStoreResult, DeleteResult, ClearResult, InvalidationResult, ServiceStats, HealthStatus.

---

### 3.7 DTOs

#### ScanRequest

| Field       | Type    | Validation |
|:------------|:--------|:-----------|
| projectPath | String  | @NotBlank  |

#### ScanResponse

| Field                | Type          |
|:---------------------|:--------------|
| success              | boolean       |
| message              | String        |
| projectPath          | String        |
| projectName          | String        |
| scannedAt            | LocalDateTime |
| javaFilesScanned     | int           |
| propertyFilesScanned | int           |
| constantsFound       | int           |
| parametersFound      | int           |
| parameterUsagesFound | int           |

#### QueryRequest

| Field  | Type   | Validation |
|:-------|:-------|:-----------|
| cypher | String | @NotBlank  |

#### QueryResponse

| Field    | Type              |
|:---------|:------------------|
| success  | boolean           |
| error    | String            |
| columns  | List of String    |
| rows     | List of Map       |
| rowCount | int               |

#### PreCannedQuery

| Field       | Type   |
|:------------|:-------|
| id          | String |
| name        | String |
| description | String |
| category    | String |
| cypher      | String |

#### StatsResponse

| Field            | Type              |
|:-----------------|:------------------|
| projectCount     | long              |
| fileCount        | long              |
| constantCount    | long              |
| parameterCount   | long              |
| constantsByType  | List of Map       |
| parametersByPrefix| List of Map      |
| topFiles         | List of Map       |

#### FileContentResponse

| Field     | Type   |
|:----------|:-------|
| path      | String |
| fileName  | String |
| content   | String |
| lineCount | int    |

#### TransformRequest

| Field       | Type    | Validation |
|:------------|:--------|:-----------|
| projectPath | String  | @NotBlank  |
| dryRun      | boolean | default false|

#### TransformResponse

| Field            | Type              |
|:-----------------|:------------------|
| success          | boolean           |
| message          | String            |
| projectPath      | String            |
| transformedAt    | LocalDateTime     |
| dryRun           | boolean           |
| totalTransformed | long              |
| totalSkipped     | long              |
| totalFailed      | long              |
| entries          | List of EntryDto  |

#### TransformResponse.EntryDto

| Field         | Type   |
|:--------------|:-------|
| filePath      | String |
| className     | String |
| constantName  | String |
| propertyKey   | String |
| originalValue | String |
| originalType  | String |
| lineNumber    | int    |
| status        | String |
| message       | String |

Static factory method from(TransformationEntry) converts core records to DTO.

---

## 4. CLI Module (const-catalog-cli)

#### Main

**File:** cli/Main.java\
**Purpose:** Standalone command-line tool for offline project scanning and CSV export.

**Usage:** java -jar const-catalog-cli.jar project-path [output-dir]

**Algorithm:**

1. Validate arguments (minimum 1 required)
2. Resolve project path as absolute
3. Default output to project-path/neo4j-export
4. Validate project path is a directory
5. Create ProjectScanner, call scan(projectRoot)
6. Print summary (files scanned, constants/parameters found)
7. Create CsvExporter, call exportForNeo4j(result, outputDir)
8. Print generated file list and Neo4j import instructions

No Spring dependency - uses core module directly.

---

## 5. Frontend Module (const-catalog-frontend)

### 5.1 Application Structure

| File                          | Component | Purpose                                       |
|:------------------------------|:----------|:----------------------------------------------|
| main.tsx                      | Root      | QueryClient setup (staleTime: 30s, retry: 1) |
| App.tsx                       | Router    | BrowserRouter with 3 routes                   |
| components/Layout.tsx         | Shell     | Header + Sidebar + Outlet + CommandLine       |
| components/Header.tsx         | HUD       | Health polling (30s), database/system status  |
| components/Sidebar.tsx        | Nav       | Dashboard, Scan, Query links                  |
| components/CommandLine.tsx    | Footer    | Terminal-style input with history              |
| components/ResultsTable.tsx   | Grid      | Dynamic columns, clickable file links          |
| components/FileViewerModal.tsx| Modal     | Source viewer with line numbers, Escape to close|
| pages/Dashboard.tsx           | Page      | 4 stat cards, constants by type, top files     |
| pages/ScanPage.tsx            | Page      | Project path form, progress steps, results     |
| pages/QueryPage.tsx           | Page      | Pre-canned query panel, Cypher editor, results |
| services/api.ts               | Client    | Axios with baseURL /api, 7 API functions       |
| types/index.ts                | Types     | TypeScript interfaces mirroring backend DTOs   |

### 5.2 API Client Functions

| Function              | Method | Endpoint                    |
|:----------------------|:-------|:----------------------------|
| scanProject           | POST   | /api/scan                   |
| getPreCannedQueries   | GET    | /api/query/precanned        |
| executePreCannedQuery | GET    | /api/query/precanned/{id}   |
| executeQuery          | POST   | /api/query/execute          |
| getStats              | GET    | /api/stats                  |
| healthCheck           | GET    | /api/stats/health           |
| getFileContent        | GET    | /api/files/content          |

### 5.3 State Management

- **Server State:** TanStack React Query with automatic background refresh
- **Local State:** React useState for form inputs and UI state
- **Mutations:** useMutation for scan and query operations
- **No global state store:** Each page manages its own state

### 5.4 Theme

"Space Command" dark theme via Tailwind CSS custom colors:

| Color Group    | Values                                               |
|:---------------|:-----------------------------------------------------|
| Space          | space-black, space-dark, space-darker, space-medium, space-light|
| Neon           | neon-cyan, neon-blue, neon-green, neon-purple        |
| Terminal       | terminal-text, terminal-dim                          |

---

## 6. Design Patterns Summary

| Pattern          | Where Used                  | Description                                     |
|:-----------------|:----------------------------|:------------------------------------------------|
| Visitor          | JavaFileParser              | VoidVisitorAdapter for AST traversal            |
| Cache-Aside      | SiteConfigurationService    | Check L1, fallback L2, populate L1              |
| Pub/Sub          | ConfigurationChangeListener | Redis Pub/Sub for cross-instance invalidation   |
| Repository       | All Repository interfaces   | Spring Data Neo4j for graph persistence         |
| Builder          | All DTOs, entities          | Lombok @Builder for immutable construction      |
| Factory Method   | TransformationEntry         | transformed, skipped, failed static factories   |
| Strategy         | ConfigurationExportService  | ExportStrategy enum selects export behavior     |
| Adapter          | ConfigurationChangeListener | RedisPubSubAdapter wraps Pub/Sub callbacks      |
| Template Method  | ProjectScanner              | SimpleFileVisitor callbacks for directory walking|
| Null Object      | SiteConfigurationService    | NULL_SENTINEL prevents repeated cache misses    |
| BeanPostProcessor| SiteConfigBeanPostProcessor | Custom annotation-driven injection              |

---

## 7. Test Coverage

### Core Module Tests

| Test Class              | Tests | Focus                                                      |
|:------------------------|:------|:-----------------------------------------------------------|
| JavaFileParserTest      | ~15   | Constant extraction, parameter usage detection, edge cases |
| JavaCodeTransformerTest | 17    | Transformation, skip logic, annotations, dry run, batch    |

### Test Patterns

- **@TempDir:** JUnit 5 temporary directory for file-based tests
- **Text Blocks:** Java 21 triple-quote strings for inline source code in tests
- **Assertion Helpers:** assertContains and assertNotContains for readable output validation
- **Factory Methods:** Tests use record constructors directly for test data

---

## 8. Configuration Reference

### application.yml

| Property                               | Default            | Description                |
|:---------------------------------------|:-------------------|:---------------------------|
| server.port                            | 8080               | Backend server port        |
| neo4j.uri                              | bolt://neo4j:7687  | Neo4j Bolt URI             |
| neo4j.username                         | neo4j              | Neo4j username             |
| neo4j.password                         | constcatalog       | Neo4j password             |
| valkey.host                            | valkey             | ValKey hostname            |
| valkey.port                            | 6379               | ValKey port                |
| valkey.password                        | (empty)            | ValKey password            |
| valkey.database                        | 0                  | ValKey database index      |
| valkey.timeout                         | 5000               | Connection timeout (ms)    |
| cache.caffeine.max-size                | 10000              | L1 cache max entries       |
| cache.caffeine.expire-after-write-minutes | 60              | L1 cache TTL (minutes)     |
