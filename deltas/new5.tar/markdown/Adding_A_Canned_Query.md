# Adding a Canned Query

A step-by-step recipe for adding a new pre-canned Cypher query to the Constants Catalog. This guide is generic — it works for any Neo4j query you want to make available in the Query Console.

---

## Table of Contents

1. [Overview: What Is a Canned Query?](#1-overview-what-is-a-canned-query)
2. [Prerequisites](#2-prerequisites)
3. [Step 1: Write and Test Your Cypher Query](#3-step-1-write-and-test-your-cypher-query)
4. [Step 2: Add the Query to QueryService.java](#4-step-2-add-the-query-to-queryservicejava)
5. [Step 3: Verify the API Returns It](#5-step-3-verify-the-api-returns-it)
6. [Step 4: Test in the Frontend](#6-step-4-test-in-the-frontend)
7. [That's It — No Frontend Changes Needed](#7-thats-it--no-frontend-changes-needed)
8. [Reference: PreCannedQuery Fields](#8-reference-precannedquery-fields)
9. [Reference: Query Categories](#9-reference-query-categories)
10. [Reference: Column Naming Conventions](#10-reference-column-naming-conventions)
11. [Example: Adding "Unused Constants" Query](#11-example-adding-unused-constants-query)

---

## 1. Overview: What Is a Canned Query?

A canned query is a pre-built Cypher query that appears in the "Pre-built Queries" panel on the Query Console page. Users select it, click "Run", and see the results in a table. They don't need to know Cypher.

The query is defined **entirely in the backend** — no frontend code changes are needed. The frontend automatically discovers new queries via the API and renders them.

### How It Works

```mermaid
sequenceDiagram
    participant FE as QueryPage.tsx
    participant API as QueryController
    participant SVC as QueryService
    participant Neo as Neo4j

    Note over FE: Page loads
    FE->>API: GET /api/query/precanned
    API->>SVC: getPreCannedQueries()
    SVC-->>API: List of PreCannedQuery
    API-->>FE: JSON array
    FE->>FE: Group by category,<br/>render as buttons

    Note over FE: User clicks a query
    FE->>API: GET /api/query/precanned/{id}
    API->>SVC: executePreCannedQuery(id)
    SVC->>SVC: Find query by ID
    SVC->>Neo: Execute Cypher
    Neo-->>SVC: Records
    SVC-->>API: QueryResponse
    API-->>FE: JSON with columns + rows
    FE->>FE: Render results table
```

### Where Queries Live

```mermaid
flowchart LR
    subgraph "Backend (one file)"
        QS["QueryService.java<br/>PRE_CANNED_QUERIES list"]
    end
    subgraph "API (automatic)"
        CTRL["QueryController<br/>/api/query/precanned"]
    end
    subgraph "Frontend (automatic)"
        QP["QueryPage.tsx<br/>Auto-discovers via API"]
    end

    QS -->|"serves"| CTRL
    CTRL -->|"fetched by"| QP

    style QS fill:#44aa44,color:#fff
    style CTRL fill:#666,color:#fff
    style QP fill:#666,color:#fff
```

The green box is the **only file you change**. Everything else is automatic.

---

## 2. Prerequisites

Before adding a query, make sure:

1. **You've scanned at least one project** — The Neo4j database needs data. Run a scan from the Scan page first.
2. **You can access the Neo4j Browser** — Navigate to `http://localhost:7474` to test your Cypher query interactively.
3. **You know the graph schema:**

```mermaid
graph LR
    P[("Project")] -->|CONTAINS| F[("File")]
    C[("Constant")] -->|DEFINED_IN| F
    C -.->|USED_IN| F2[("File")]
    Param[("Parameter")] -->|DEFINED_IN| F
    Param -.->|USED_IN| F3[("File")]

    style P fill:#4488ff,color:#fff
    style F fill:#44aa44,color:#fff
    style F2 fill:#44aa44,color:#fff
    style F3 fill:#44aa44,color:#fff
    style C fill:#ff8844,color:#fff
    style Param fill:#aa44ff,color:#fff
```

### Node Properties

| Node | Key Properties |
|---|---|
| **Project** | `name`, `rootPath`, `scannedAt`, `totalFiles`, `totalConstants`, `totalParameters` |
| **File** | `path`, `fileName`, `fileType` |
| **Constant** | `name`, `type`, `value`, `className`, `lineNumber`, `accessModifier`, `isEnum` |
| **Parameter** | `name`, `value`, `lineNumber` |

### Relationships

| Relationship | From | To | Meaning |
|---|---|---|---|
| `CONTAINS` | Project | File | File belongs to project |
| `DEFINED_IN` | Constant/Parameter | File | Where it's declared |
| `USED_IN` | Constant/Parameter | File | Where it's referenced |

---

## 3. Step 1: Write and Test Your Cypher Query

Open the Neo4j Browser at `http://localhost:7474` and write your query. Test it until the results look right.

```mermaid
flowchart LR
    A["Write Cypher"] --> B["Run in<br/>Neo4j Browser"]
    B --> C{Results OK?}
    C -->|No| A
    C -->|Yes| D["Copy query<br/>to Step 2"]

    style D fill:#44aa44,color:#fff
```

**Tips:**
- Always use column aliases (`RETURN c.name AS name`) — the frontend renders these as table headers
- Include `filePath` if you want the user to be able to click through to the file viewer
- Use `ORDER BY` for predictable result ordering
- Limit results if the query could return thousands of rows: `LIMIT 100`

**Test your query works:**

```cypher
-- Paste your query in the Neo4j Browser and run it
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
WHERE NOT (c)-[:USED_IN]->()
  AND c.accessModifier = 'public'
  AND NOT coalesce(c.isEnum, false) = true
RETURN c.name AS name, c.type AS type, c.value AS value,
       c.className AS className, f.fileName AS file,
       c.lineNumber AS line, f.path AS filePath
ORDER BY f.fileName, c.lineNumber
```

**Verify:**
- Results appear as expected
- Column names are clear
- No errors or warnings (except deprecated `id()` warnings, which are harmless)

---

## 4. Step 2: Add the Query to QueryService.java

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/QueryService.java`

Find the `PRE_CANNED_QUERIES` list (around line 42) and add a new entry. Add it in a logical position — queries are displayed in the order they appear in this list, grouped by category.

### Template

```java
PreCannedQuery.builder()
    .id("your-query-id")           // URL-friendly, unique, lowercase with hyphens
    .name("Your Query Name")       // Human-readable, shown in the UI button
    .description("What this query finds and why it's useful")
    .category("CATEGORY")          // See Reference: Query Categories below
    .cypher("""
        YOUR CYPHER QUERY HERE
        """)
    .build(),
```

### Field Rules

```mermaid
flowchart TD
    subgraph "PreCannedQuery"
        ID["id: 'unused-constants'<br/>━━━━━━━━━━━━━━━━━━<br/>Unique, lowercase, hyphens<br/>Used in API URL"]
        NAME["name: 'Unused Constants'<br/>━━━━━━━━━━━━━━━━━━<br/>Short (2-4 words)<br/>Shown as button label"]
        DESC["description: '...'<br/>━━━━━━━━━━━━━━━━━━<br/>One sentence<br/>Shown as tooltip"]
        CAT["category: 'ANALYSIS'<br/>━━━━━━━━━━━━━━━━━━<br/>Groups queries in UI<br/>See category reference"]
        CYP["cypher: 'MATCH ...'<br/>━━━━━━━━━━━━━━━━━━<br/>Read-only Cypher<br/>Use column aliases"]
    end

    ID --> URL["/api/query/precanned/{id}"]
    NAME --> BTN["Button label in UI"]
    CAT --> GRP["Category group heading"]
    CYP --> NEO["Executed against Neo4j"]

    style ID fill:#336,color:#fff
    style NAME fill:#336,color:#fff
    style DESC fill:#336,color:#fff
    style CAT fill:#336,color:#fff
    style CYP fill:#336,color:#fff
```

| Field | Requirements |
|---|---|
| `id` | Unique across all queries. Lowercase, hyphens. Used in the API URL: `/api/query/precanned/{id}` |
| `name` | Short (2-4 words). Shown as the button label. |
| `description` | One sentence. Shown as tooltip/subtitle. Explain what the query finds, not how it works. |
| `category` | One of: `EXPLORATION`, `ANALYSIS`, `SECURITY`, `ORGANIZATION`. Determines which group the query appears in. |
| `cypher` | Valid Cypher. Use text blocks (`"""..."""`) for readability. Always include column aliases. |

### Important

- Add a trailing comma after `.build()` since it's part of a `List.of(...)` call
- The query must be **read-only** — `MATCH` and `RETURN` only. No `CREATE`, `MERGE`, `DELETE`, or `SET`.
- Use `f.path AS filePath` if you want the file viewer integration to work

---

## 5. Step 3: Verify the API Returns It

Rebuild and restart the backend:

```bash
docker compose --env-file=.env.mint up -d --build backend
```

Or if running locally:

```bash
mvn compile -pl const-catalog-backend -am
# restart the Spring Boot app
```

Test with curl:

```bash
# List all queries — your new one should appear
curl -s http://localhost:9090/api/query/precanned | jq '.[].id'

# Execute your query
curl -s http://localhost:9090/api/query/precanned/your-query-id | jq '.rows[:3]'
```

```mermaid
flowchart LR
    A["Rebuild backend"] --> B["curl /precanned"]
    B --> C{ID in list?}
    C -->|No| D["Check QueryService.java<br/>— typo? missing comma?"]
    C -->|Yes| E["curl /precanned/{id}"]
    E --> F{Rows returned?}
    F -->|No| G["Check Cypher syntax<br/>in Neo4j Browser"]
    F -->|Yes| H["Step 4: Test in UI ✓"]

    style D fill:#ff4444,color:#fff
    style G fill:#ff4444,color:#fff
    style H fill:#44aa44,color:#fff
```

---

## 6. Step 4: Test in the Frontend

Open the Query Console page in the browser (`http://localhost:3001/query` or `http://localhost:3000/query` for dev).

1. Your new query should appear in the "Pre-built Queries" panel on the left, grouped under its category
2. Click it — the Cypher should populate in the query editor
3. Click "Run" — results should appear in the table
4. If you included `filePath`, clicking the file icon should open the file viewer

No frontend code changes are needed. The frontend fetches the query list from the API on page load, groups them by category, and renders them as buttons. New queries appear automatically.

```mermaid
flowchart TD
    subgraph "Query Console Page"
        subgraph "Left Panel: Pre-built Queries"
            direction TB
            E["📊 EXPLORATION"]
            E1["  All Constants"]
            E2["  All Parameters"]
            E3["  File Summary"]

            A["🔍 ANALYSIS"]
            A1["  Config Candidates"]
            A2["  Unused Parameters"]
            A3["  ✨ Your New Query"]
            A4["  Duplicate Values"]

            S["🔒 SECURITY"]
            S1["  Sensitive Params"]
            S2["  Connection Strings"]
        end

        subgraph "Right Panel: Results"
            R["Results Table<br/>━━━━━━━━━━━━━━<br/>| name | type | value | file |<br/>| HOST | String | ... | Config.java |<br/>| PORT | int | ... | Server.java |"]
        end
    end

    A3 -->|"click → run"| R

    style A3 fill:#44aa44,color:#fff
```

---

## 7. That's It — No Frontend Changes Needed

```mermaid
flowchart LR
    subgraph "What You Change"
        A["QueryService.java<br/>Add one entry"]
    end
    subgraph "What Happens Automatically"
        B["API serves it"]
        C["Frontend discovers it"]
        D["UI renders the button"]
        E["Results table works"]
        F["File viewer links work"]
    end

    A --> B --> C --> D --> E --> F

    style A fill:#44aa44,color:#fff
    style B fill:#666,color:#fff
    style C fill:#666,color:#fff
    style D fill:#666,color:#fff
    style E fill:#666,color:#fff
    style F fill:#666,color:#fff
```

To summarize, adding a canned query requires changing **one file**:

```
const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/QueryService.java
```

Add one `PreCannedQuery.builder()...build()` entry to the `PRE_CANNED_QUERIES` list. That's it.

---

## 8. Reference: PreCannedQuery Fields

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/dto/PreCannedQuery.java`

```java
public class PreCannedQuery {
    private String id;          // Unique identifier, used in API URL
    private String name;        // Display name in the UI
    private String description; // Tooltip text explaining what the query does
    private String category;    // Grouping: EXPLORATION, ANALYSIS, SECURITY, ORGANIZATION
    private String cypher;      // The actual Cypher query
}
```

### Data Flow Through the System

```mermaid
graph TD
    subgraph "Definition (QueryService.java)"
        Q["PreCannedQuery<br/>id, name, description,<br/>category, cypher"]
    end

    subgraph "API Layer"
        LIST["GET /api/query/precanned<br/>Returns: id, name, description, category<br/>(cypher omitted for list)"]
        EXEC["GET /api/query/precanned/{id}<br/>Executes cypher, returns QueryResponse<br/>columns + rows"]
    end

    subgraph "Frontend"
        PANEL["Pre-built Queries panel<br/>Uses: name, description, category"]
        TABLE["Results table<br/>Uses: QueryResponse columns/rows"]
    end

    Q --> LIST
    Q --> EXEC
    LIST --> PANEL
    EXEC --> TABLE
```

---

## 9. Reference: Query Categories

```mermaid
graph LR
    subgraph Categories
        EX["EXPLORATION<br/>━━━━━━━━━━━━<br/>What's in the codebase?<br/>General-purpose discovery"]
        AN["ANALYSIS<br/>━━━━━━━━━━━━<br/>What needs attention?<br/>Issues & opportunities"]
        SE["SECURITY<br/>━━━━━━━━━━━━<br/>What poses risk?<br/>Passwords, secrets, tokens"]
        OR["ORGANIZATION<br/>━━━━━━━━━━━━<br/>How is config structured?<br/>Prefixes, grouping, files"]
    end

    style EX fill:#4488ff,color:#fff
    style AN fill:#ff8844,color:#fff
    style SE fill:#ff4444,color:#fff
    style OR fill:#44aa44,color:#fff
```

| Category | Purpose | Use when |
|---|---|---|
| `EXPLORATION` | "What's in the codebase?" | General-purpose discovery queries |
| `ANALYSIS` | "What needs attention?" | Queries that identify issues or opportunities |
| `SECURITY` | "What poses risk?" | Queries about sensitive values |
| `ORGANIZATION` | "How is config structured?" | Queries about code structure and grouping |

If your query doesn't fit any category, use `EXPLORATION` as the default.

To add a new category: just use a new string (e.g., `"METRICS"`). The frontend groups dynamically — no code change needed. The category name is used as-is for the group heading.

---

## 10. Reference: Column Naming Conventions

The frontend renders columns directly from the `RETURN` clause aliases. Use consistent naming:

| Column alias | Meaning | Frontend behavior |
|---|---|---|
| `name` | Constant or parameter name | Displayed as primary identifier |
| `type` | Java type (String, int, etc.) | Displayed in mono font |
| `value` | The constant's value | Displayed, may be truncated |
| `className` | The Java class containing it | Displayed |
| `file` or `fileName` | Short file name | Displayed |
| `filePath` | Full file path | **Enables the file viewer link** |
| `line` or `lineNumber` | Line number in source | Displayed as number |
| `count` or `*Count` | Numeric count | Displayed as number |

### The `filePath` Convention

```mermaid
flowchart LR
    A["Query RETURN includes<br/>f.path AS filePath"] --> B["Results table shows<br/>clickable file icon 📄"]
    B --> C["Click opens<br/>File Viewer modal"]

    D["Query does NOT<br/>return filePath"] --> E["No file icon<br/>in results"]

    style A fill:#44aa44,color:#fff
    style D fill:#ff8844,color:#fff
```

If your query returns a column named `filePath`, the results table shows a clickable icon that opens the file viewer modal. Without it, no file link appears. **Always include `filePath` when your query returns file-specific data.**

---

## 11. Example: Adding "Unused Constants" Query

Here's a complete worked example.

### Step 1: Write the Cypher

Test in Neo4j Browser at `http://localhost:7474`:

```cypher
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
WHERE NOT (c)-[:USED_IN]->()
  AND c.accessModifier = 'public'
  AND NOT coalesce(c.isEnum, false) = true
RETURN c.name AS name, c.type AS type, c.value AS value,
       c.className AS className, f.fileName AS file,
       c.lineNumber AS line, f.path AS filePath
ORDER BY f.fileName, c.lineNumber
```

### What This Query Does

```mermaid
graph LR
    C[("Constant<br/>accessModifier = 'public'<br/>isEnum = false")] -->|DEFINED_IN| F[("File")]
    C -. "NO USED_IN<br/>(zero references)" .-> X[("Any File")]

    style C fill:#ff6666,color:#fff
    style X fill:#999,stroke-dasharray: 5 5
```

Finds `public static final` constants that exist in the graph but have no `USED_IN` relationships — meaning no scanned Java file references them.

### Step 2: Add to QueryService.java

Open `QueryService.java`, find the `PRE_CANNED_QUERIES` list, and add after an appropriate existing query (e.g., after `unused-parameters`):

```java
        PreCannedQuery.builder()
            .id("unused-constants")
            .name("Unused Constants")
            .description("Public constants declared but never referenced in any scanned file")
            .category("ANALYSIS")
            .cypher("""
                MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
                WHERE NOT (c)-[:USED_IN]->()
                  AND c.accessModifier = 'public'
                  AND NOT coalesce(c.isEnum, false) = true
                RETURN c.name AS name, c.type AS type, c.value AS value,
                       c.className AS className, f.fileName AS file,
                       c.lineNumber AS line, f.path AS filePath
                ORDER BY f.fileName, c.lineNumber
                """)
            .build(),
```

### Step 3: Rebuild and Test

```bash
# Rebuild backend
docker compose --env-file=.env.mint up -d --build backend

# Verify via API
curl -s http://localhost:9090/api/query/precanned | jq '.[].id'
# Should include "unused-constants"

curl -s http://localhost:9090/api/query/precanned/unused-constants | jq '.rowCount'
# Should return a number
```

### Step 4: Check the UI

Open `http://localhost:3001/query`. Under the "Analysis" group, you should see "Unused Constants" with the description as a subtitle. Click it, run it, see the results.

### The Complete Process

```mermaid
flowchart TD
    A["1. Write Cypher<br/>Test in Neo4j Browser"] --> B["2. Add to QueryService.java<br/>One PreCannedQuery entry"]
    B --> C["3. Rebuild backend<br/>docker compose up --build"]
    C --> D["4. Verify with curl<br/>GET /api/query/precanned"]
    D --> E["5. Open Query Console<br/>Click your query, see results"]

    style A fill:#4488ff,color:#fff
    style B fill:#44aa44,color:#fff
    style C fill:#ff8844,color:#fff
    style D fill:#336,color:#fff
    style E fill:#44aa44,color:#fff
```

**Done.** One file changed, zero frontend code, zero configuration.
