# Developer Guide: Adding Transformations to the Constants Catalog

This guide explains how the constant-to-lookup transformation is triggered end-to-end (React UI through Spring Boot to JavaParser AST manipulation), and provides step-by-step instructions for:

1. Adding a new transformation type (e.g., a new way to replace constants)
2. Writing code to eliminate unused constants from source files

---

## 1. End-to-End Transformation Flow

The transformation starts in the browser and flows through four layers before Java source files are modified.

### 1.1 High-Level Sequence

```mermaid
sequenceDiagram
    actor Developer
    participant React as TransformPage.tsx<br/>(React)
    participant Axios as api.ts<br/>(Axios Client)
    participant Nginx as nginx / Vite proxy
    participant Controller as TransformController<br/>(Spring MVC)
    participant Service as CodeTransformationService<br/>(Spring Service)
    participant Neo4j as Neo4j<br/>(Graph Database)
    participant Transformer as ConfigLookupTransformer<br/>(JavaParser AST)
    participant FS as File System<br/>(Source + Backups)

    Developer->>React: Enter project path, select scope, click Transform
    React->>Axios: transformProject({ projectPath, dryRun, candidateScope })
    Axios->>Nginx: POST /api/transform (JSON body)
    Nginx->>Controller: Forward to Spring Boot :8080

    Controller->>Service: transform(TransformRequest)

    Note over Service,Neo4j: Phase 1: Candidate Selection
    Service->>Neo4j: Cypher: MATCH config-candidate constants
    Neo4j-->>Service: List<ConstantWithFile>
    Service->>Neo4j: Cypher: MATCH parameter usages
    Neo4j-->>Service: List<ParameterWithFile>
    Service->>Service: Group all ConstantTargets by file path

    Note over Service,FS: Phase 2: AST Transformation
    loop For each Java file with targets
        Service->>Transformer: transformFile(path, targets, backupsDir)
        Transformer->>FS: Read source file
        Transformer->>Transformer: Parse to AST (JavaParser)
        Transformer->>Transformer: ModifierVisitor replaces NameExpr / FieldAccessExpr / MethodCallExpr
        Transformer->>Transformer: Add @Autowired SiteConfigurationService config field
        Transformer->>Transformer: Add required imports
        Transformer->>FS: Write .java.orig backup
        Transformer->>FS: Write transformed .java
        Transformer-->>Service: List<TransformationEntry>
    end

    Note over Service,Controller: Phase 3: Response
    Service-->>Controller: TransformResponse
    Controller-->>Nginx: 200 OK (JSON)
    Nginx-->>Axios: Response
    Axios-->>React: TransformResponse
    React-->>Developer: Display results table with Transformed/Skipped/Failed
```

### 1.2 Layer-by-Layer Breakdown

#### Layer 1: React Frontend (`TransformPage.tsx`)

The user interacts with the Transform page at route `/transform`.

**Key state variables:**
| State | Type | Purpose |
|-------|------|---------|
| `projectPath` | `string` | Container-relative path to the scanned project |
| `dryRun` | `boolean` | Preview mode (default: `true`) |
| `candidateScope` | `CandidateScope` | `ALL`, `CONSTANTS_ONLY`, or `PARAMETERS_ONLY` |
| `result` | `TransformResponse` | Transformation outcome |
| `comparison` | `FileComparisonResponse` | Before/after diff for a single file |

When the user clicks "Transform" or "Dry Run":

```typescript
// TransformPage.tsx
transformMutation.mutate({
  projectPath: projectPath.trim(),
  dryRun,
  candidateScope,
})
```

This calls `transformProject()` in `api.ts`:

```typescript
// api.ts
export async function transformProject(request: TransformRequest): Promise<TransformResponse> {
  const response = await api.post<TransformResponse>('/transform', request)
  return response.data
}
```

#### Layer 2: Spring Boot Controller (`TransformController.java`)

The `POST /api/transform` endpoint receives the request and delegates:

```java
// TransformController.java
@PostMapping
public ResponseEntity<TransformResponse> transformProject(
        @Valid @RequestBody TransformRequest request) {
    TransformResponse response = transformationService.transform(request);
    return ResponseEntity.ok(response);  // Always 200, success flag in body
}
```

**Important:** The controller always returns HTTP 200. The `success` boolean inside the JSON body indicates whether the transformation worked. This prevents Axios from discarding the detailed error response body (Axios throws on non-2xx responses and the response body may not be accessible).

#### Layer 3: Orchestration Service (`CodeTransformationService.java`)

This is where the real work is coordinated:

```mermaid
sequenceDiagram
    participant CTS as CodeTransformationService
    participant Neo4j as Neo4j
    participant CLT as ConfigLookupTransformer

    Note over CTS: Phase 1: Query Neo4j for candidates

    CTS->>Neo4j: findConfigurationCandidates(projectPath)
    Note right of Neo4j: MATCH constants with names<br/>matching HOST|PORT|URL|...<br/>JOIN with File nodes
    Neo4j-->>CTS: List<ConstantWithFile>

    CTS->>CTS: Deduplicate by constant name
    CTS->>Neo4j: findProjectJavaFiles(projectPath)
    Neo4j-->>CTS: List<String> (all .java file paths)
    CTS->>CTS: Assign constant targets to ALL Java files

    CTS->>Neo4j: findParameterCandidates(projectPath)
    Note right of Neo4j: MATCH parameters with<br/>USED_IN relationships<br/>to usage files
    Neo4j-->>CTS: List<ParameterWithFile>

    CTS->>CTS: Group all targets into Map<Path, List<ConstantTarget>>

    Note over CTS: Phase 2: Transform each file

    alt dryRun == true
        loop Each file
            CTS->>CLT: dryRun(path, targets)
            CLT-->>CTS: List<TransformationEntry>
        end
    else dryRun == false
        CTS->>CLT: transformProject(projectPath, targetsByFile)
        CLT-->>CTS: TransformationResult
    end

    Note over CTS: Phase 3: Build response + write log
    CTS->>CTS: Map entries to EntryDto, build TransformResponse
```

**Key detail:** Constants are assigned to *all* Java files in the project, not just the file where they are defined. This is because `SSH_PORT` might be defined in `NetworkConfig.java` but used in `SshService.java`, `SftpClient.java`, and others.

#### Layer 4: AST Transformer (`ConfigLookupTransformer.java`)

The transformer uses JavaParser's `ModifierVisitor` pattern to walk the AST and replace nodes:

```mermaid
sequenceDiagram
    participant CLT as ConfigLookupTransformer
    participant JP as JavaParser
    participant AST as CompilationUnit (AST)
    participant FS as File System

    CLT->>FS: Read source file bytes
    CLT->>JP: parse(sourceFile)
    JP-->>CLT: CompilationUnit

    CLT->>CLT: Split targets: constantTargets vs paramTargets

    CLT->>AST: cu.accept(new ModifierVisitor)

    Note over AST: For each NameExpr (e.g., SSH_PORT)
    AST->>CLT: visit(NameExpr n)
    CLT->>CLT: Is n.name in constantTargets?
    CLT->>CLT: Is this a usage (not a declaration)?
    CLT-->>AST: Return config.lookupInt("ssh.port", 22)

    Note over AST: For each FieldAccessExpr (e.g., Config.SSH_PORT)
    AST->>CLT: visit(FieldAccessExpr n)
    CLT->>CLT: Is n.name in constantTargets?
    CLT-->>AST: Return config.lookupInt("ssh.port", 22)

    Note over AST: For each MethodCallExpr (e.g., getProperty("db.host"))
    AST->>CLT: visit(MethodCallExpr n)
    CLT->>CLT: Is method name in PROPERTY_GETTER_METHODS?
    CLT->>CLT: Does a string arg match a paramTarget?
    CLT-->>AST: Return config.lookup("db.host")

    CLT->>AST: addConfigFieldIfMissing(cu)
    Note right of AST: Adds: @Autowired<br/>private SiteConfigurationService config;
    CLT->>AST: addRequiredImports(cu)
    Note right of AST: Adds import for Autowired<br/>and SiteConfigurationService

    CLT->>FS: Copy original to .java.orig
    CLT->>FS: Write cu.toString() to output path
```

---

## 2. How to Add a New Transformation Type

Suppose you want to add a new transformation -- for example, replacing `System.getenv("VAR_NAME")` calls with `config.lookup("var.name")`.

### 2.1 Checklist

| Step | Layer | File | What to do |
|------|-------|------|------------|
| 1 | Core Model | `ConstantTarget.java` | Add a new `SourceKind` if needed (e.g., `ENV_VAR`) |
| 2 | Core Transformer | `ConfigLookupTransformer.java` | Add AST visitor logic for the new pattern |
| 3 | Backend Service | `CodeTransformationService.java` | Add a Neo4j query to find candidates + convert to `ConstantTarget` |
| 4 | Backend DTO | `TransformRequest.java` | Add new `CandidateScope` enum value if needed |
| 5 | Frontend | `TransformPage.tsx` | Add UI for the new scope option |
| 6 | Tests | `ConfigLookupTransformerTest.java` | Add test cases for the new pattern |

### 2.2 Step-by-Step Example: Adding `System.getenv()` Replacement

#### Step 1: Extend `ConstantTarget.SourceKind`

```java
// const-catalog-core/src/main/java/com/boeing/constcatalog/model/ConstantTarget.java
public enum SourceKind {
    CONSTANT,
    PARAMETER,
    ENV_VAR       // <-- new
}
```

#### Step 2: Add Visitor Logic in `ConfigLookupTransformer`

The transformer already has a `visit(MethodCallExpr)` handler. Add detection for `System.getenv()`:

```java
// ConfigLookupTransformer.java — inside the ModifierVisitor

@Override
public Visitable visit(MethodCallExpr n, Void arg) {
    super.visit(n, arg);  // recurse first

    String methodName = n.getNameAsString();

    // Existing parameter getter handling ...
    if (PROPERTY_GETTER_METHODS.contains(methodName)) {
        // ... existing code ...
    }

    // NEW: Handle System.getenv("VAR_NAME")
    if ("getenv".equals(methodName)
            && n.getScope().map(s -> s.toString().equals("System")).orElse(false)) {
        for (Expression argExpr : n.getArguments()) {
            if (argExpr instanceof StringLiteralExpr strLit) {
                String envVarName = strLit.getValue();
                ConstantTarget target = envVarTargets.get(envVarName);
                if (target != null) {
                    replacedEnvVars.add(envVarName);
                    return createConfigLookupCall(target);
                }
            }
        }
    }

    return n;
}
```

#### Step 3: Add Neo4j Query in `CodeTransformationService`

Create a new method to find `System.getenv()` usages from the graph:

```java
// CodeTransformationService.java

private List<EnvVarWithFile> findEnvVarCandidates(String projectPath) {
    return neo4jClient.query("""
        MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(param:Parameter)
              -[usage:USED_IN]->(usageFile:File)
        WHERE usage.context CONTAINS 'System.getenv'
        RETURN param.name AS envVarName,
               param.value AS envVarValue,
               usage.className AS className,
               usage.lineNumber AS lineNumber,
               usageFile.path AS filePath
        """)
        .bind(projectPath).to("path")
        .fetchAs(EnvVarWithFile.class)
        .mappedBy((typeSystem, record) -> new EnvVarWithFile(
            record.get("envVarName").asString(),
            record.get("envVarValue").asString(""),
            record.get("className").asString(),
            record.get("lineNumber").asInt(),
            record.get("filePath").asString()
        ))
        .all().stream().toList();
}
```

Then call this in the `transform()` method and merge results into `targetsByFile`.

#### Step 4: Extend the DTO

```java
// TransformRequest.java
public enum CandidateScope {
    CONSTANTS_ONLY,
    PARAMETERS_ONLY,
    ENV_VARS_ONLY,   // <-- new
    ALL
}
```

#### Step 5: Update the Frontend

Add the new radio option in `TransformPage.tsx`:

```tsx
// TransformPage.tsx — in the scope selector
{([
  ['ALL', 'All'],
  ['CONSTANTS_ONLY', 'Constants Only'],
  ['PARAMETERS_ONLY', 'Parameters Only'],
  ['ENV_VARS_ONLY', 'Env Vars Only'],  // <-- new
] as const).map(([value, label]) => (
  // ... existing radio button JSX
))}
```

Update the `CandidateScope` type:

```typescript
type CandidateScope = 'ALL' | 'CONSTANTS_ONLY' | 'PARAMETERS_ONLY' | 'ENV_VARS_ONLY'
```

#### Step 6: Add Tests

```java
// ConfigLookupTransformerTest.java

@Test
void shouldReplaceSystemGetenvWithConfigLookup(@TempDir Path tempDir) throws Exception {
    String source = """
        package com.example;

        public class EnvReader {
            public void readEnv() {
                String home = System.getenv("HOME_DIR");
            }
        }
        """;

    Path sourceFile = tempDir.resolve("EnvReader.java");
    Files.writeString(sourceFile, source);

    ConstantTarget target = new ConstantTarget(
        "HOME_DIR", "home.dir", "/home/user", "String",
        "EnvReader", 5, ConstantTarget.SourceKind.ENV_VAR
    );

    List<TransformationEntry> results =
        transformer.transformFile(sourceFile, List.of(target), tempDir.resolve("backups"));

    // Assert replacement happened
    String transformed = Files.readString(tempDir.resolve("backups")
        .resolve(tempDir.relativize(sourceFile)));
    assertThat(transformed).contains("config.lookup(\"home.dir\")");
}
```

### 2.3 End-to-End Data Flow for Adding a New Transformation

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant FE as TransformPage.tsx
    participant DTO as TransformRequest.java
    participant SVC as CodeTransformationService.java
    participant Neo4j as Neo4j Graph
    participant TX as ConfigLookupTransformer.java
    participant Model as ConstantTarget.java

    Note over Dev: 1. Add SourceKind.ENV_VAR to model
    Dev->>Model: Add enum value

    Note over Dev: 2. Add AST visitor in transformer
    Dev->>TX: Handle System.getenv() in visit(MethodCallExpr)

    Note over Dev: 3. Add Neo4j query in service
    Dev->>SVC: findEnvVarCandidates() method

    Note over Dev: 4. Wire scope in DTO
    Dev->>DTO: Add ENV_VARS_ONLY to CandidateScope

    Note over Dev: 5. Add scope option in frontend
    Dev->>FE: Add radio button for ENV_VARS_ONLY

    Note over Dev,FE: The new flow at runtime
    FE->>DTO: { candidateScope: "ENV_VARS_ONLY" }
    DTO->>SVC: transform(request)
    SVC->>Neo4j: findEnvVarCandidates(projectPath)
    Neo4j-->>SVC: List<EnvVarWithFile>
    SVC->>TX: transformFile(path, targets, backupsDir)
    TX->>TX: ModifierVisitor replaces System.getenv("X")
    TX-->>SVC: TransformationEntry(status=TRANSFORMED)
    SVC-->>FE: TransformResponse
```

---

## 3. How to Write Code to Eliminate Unused Constants

An "unused constant" is a `public static final` field that has no `USED_IN` relationships in the Neo4j graph -- it is defined but never referenced anywhere else in the scanned project.

### 3.1 Architecture Overview

```mermaid
sequenceDiagram
    actor Developer
    participant React as UnusedConstantsPage.tsx
    participant Axios as api.ts
    participant Controller as CleanupController
    participant Service as ConstantCleanupService
    participant Neo4j as Neo4j
    participant Remover as UnusedConstantRemover<br/>(JavaParser AST)
    participant FS as File System

    Developer->>React: Click "Find Unused Constants"
    React->>Axios: POST /api/cleanup/unused

    Axios->>Controller: POST /api/cleanup/unused { projectPath, dryRun }
    Controller->>Service: removeUnused(request)

    Service->>Neo4j: Find constants with zero USED_IN relationships
    Neo4j-->>Service: List<UnusedConstantWithFile>

    Service->>Service: Group by file path

    loop For each file with unused constants
        Service->>Remover: removeFromFile(path, unusedConstants, backupsDir)
        Remover->>FS: Read source
        Remover->>Remover: Parse AST, find FieldDeclaration by name
        Remover->>Remover: Remove FieldDeclaration from AST
        Remover->>FS: Write backup + modified source
        Remover-->>Service: List<RemovalEntry>
    end

    Service-->>Controller: CleanupResponse
    Controller-->>React: JSON response
    React-->>Developer: Show removed/skipped/failed table
```

### 3.2 Implementation Steps

#### Step 1: Create the Neo4j Query to Find Unused Constants

Add a query method to `ConstantRepository` or write a raw Cypher query in a new service:

```java
// ConstantCleanupService.java (new file in backend/service/)

@Service
@Slf4j
public class ConstantCleanupService {

    private final Neo4jClient neo4jClient;
    private final UnusedConstantRemover remover;

    public ConstantCleanupService(Neo4jClient neo4jClient) {
        this.neo4jClient = neo4jClient;
        this.remover = new UnusedConstantRemover();
    }

    /**
     * Finds constants that are defined but never referenced anywhere
     * in the scanned project.
     */
    private List<UnusedConstantWithFile> findUnusedConstants(String projectPath) {
        return neo4jClient.query("""
            MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)
                  <-[:DEFINED_IN]-(c:Constant)
            WHERE NOT exists {
                MATCH (c)-[:USED_IN]->(:File)
            }
            AND NOT c.isEnum = true
            RETURN c.name AS constantName,
                   c.type AS constantType,
                   c.value AS constantValue,
                   c.className AS className,
                   c.lineNumber AS lineNumber,
                   f.path AS filePath
            ORDER BY f.path, c.lineNumber DESC
            """)
            .bind(projectPath).to("path")
            .fetchAs(UnusedConstantWithFile.class)
            .mappedBy((typeSystem, record) -> new UnusedConstantWithFile(
                record.get("constantName").asString(),
                record.get("constantType").asString(),
                record.get("constantValue").asString(""),
                record.get("className").asString(),
                record.get("lineNumber").asInt(),
                record.get("filePath").asString()
            ))
            .all().stream().toList();
    }

    record UnusedConstantWithFile(
        String constantName, String constantType, String constantValue,
        String className, int lineNumber, String filePath
    ) {}
}
```

**Important:** The query orders by `lineNumber DESC` so that when we remove fields from a file, we work from bottom to top. This prevents line number drift from invalidating subsequent removals in the same file.

#### Step 2: Create the AST Remover (`UnusedConstantRemover.java`)

This goes in the `const-catalog-core` module (no Spring dependency):

```java
// const-catalog-core/src/main/java/com/boeing/constcatalog/transformer/UnusedConstantRemover.java

package com.boeing.constcatalog.transformer;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;

public class UnusedConstantRemover {

    private final JavaParser javaParser;

    /** Names of constants that should never be removed even if unused. */
    private static final Set<String> PROTECTED_NAMES = Set.of(
        "serialVersionUID", "VERSION", "LOG", "LOGGER"
    );

    public UnusedConstantRemover() {
        ParserConfiguration config = new ParserConfiguration()
            .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_21);
        this.javaParser = new JavaParser(config);
    }

    public record RemovalTarget(String constantName, String className, int lineNumber) {}

    public record RemovalEntry(
        String filePath, String constantName, String className,
        int lineNumber, RemovalStatus status, String message
    ) {}

    public enum RemovalStatus { REMOVED, SKIPPED, FAILED }

    /**
     * Removes unused constant declarations from a single file.
     */
    public List<RemovalEntry> removeFromFile(
            Path sourceFile, List<RemovalTarget> targets, Path backupsDir) {

        String filePath = sourceFile.toString();
        List<RemovalEntry> results = new ArrayList<>();

        try {
            ParseResult<CompilationUnit> parseResult = javaParser.parse(sourceFile);
            if (!parseResult.isSuccessful() || parseResult.getResult().isEmpty()) {
                return targets.stream()
                    .map(t -> new RemovalEntry(filePath, t.constantName(), t.className(),
                        t.lineNumber(), RemovalStatus.FAILED, "File could not be parsed"))
                    .toList();
            }

            CompilationUnit cu = parseResult.getResult().get();
            boolean anyRemoved = false;

            // Process targets in reverse line-number order (bottom-up)
            List<RemovalTarget> sorted = targets.stream()
                .sorted(Comparator.comparingInt(RemovalTarget::lineNumber).reversed())
                .toList();

            for (RemovalTarget target : sorted) {
                if (PROTECTED_NAMES.contains(target.constantName())) {
                    results.add(new RemovalEntry(filePath, target.constantName(),
                        target.className(), target.lineNumber(),
                        RemovalStatus.SKIPPED, "Protected constant name"));
                    continue;
                }

                // Find the FieldDeclaration containing this constant
                Optional<FieldDeclaration> field = cu.findAll(FieldDeclaration.class).stream()
                    .filter(f -> f.isStatic() && f.isFinal())
                    .filter(f -> f.getVariables().stream()
                        .anyMatch(v -> v.getNameAsString().equals(target.constantName())))
                    .filter(f -> f.getBegin()
                        .map(pos -> Math.abs(pos.line - target.lineNumber()) <= 3)
                        .orElse(false))
                    .findFirst();

                if (field.isPresent()) {
                    FieldDeclaration fd = field.get();

                    if (fd.getVariables().size() == 1) {
                        // Single variable in declaration -- remove the entire field
                        fd.remove();
                    } else {
                        // Multiple variables in one declaration -- remove only this variable
                        fd.getVariables().stream()
                            .filter(v -> v.getNameAsString().equals(target.constantName()))
                            .findFirst()
                            .ifPresent(VariableDeclarator::remove);
                    }

                    anyRemoved = true;
                    results.add(new RemovalEntry(filePath, target.constantName(),
                        target.className(), target.lineNumber(),
                        RemovalStatus.REMOVED, "Removed unused constant declaration"));
                } else {
                    results.add(new RemovalEntry(filePath, target.constantName(),
                        target.className(), target.lineNumber(),
                        RemovalStatus.SKIPPED,
                        "Field declaration not found (may have been modified since scan)"));
                }
            }

            if (anyRemoved) {
                // Write backup and modified file
                Path absSource = sourceFile.toAbsolutePath();
                Path relPath = absSource.getRoot().relativize(absSource);
                Path outputPath = backupsDir.resolve(relPath);
                Files.createDirectories(outputPath.getParent());
                Files.copy(sourceFile, Path.of(outputPath + ".orig"),
                    StandardCopyOption.REPLACE_EXISTING);
                Files.writeString(outputPath, cu.toString());
            }

            return results;

        } catch (IOException e) {
            return targets.stream()
                .map(t -> new RemovalEntry(filePath, t.constantName(), t.className(),
                    t.lineNumber(), RemovalStatus.FAILED, "IO error: " + e.getMessage()))
                .toList();
        }
    }
}
```

#### Step 3: Create the Controller

```java
// const-catalog-backend/.../controller/CleanupController.java

@RestController
@RequestMapping("/api/cleanup")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Cleanup", description = "Remove unused constants from source files")
public class CleanupController {

    private final ConstantCleanupService cleanupService;

    @PostMapping("/unused")
    public ResponseEntity<CleanupResponse> removeUnused(
            @Valid @RequestBody CleanupRequest request) {
        log.info("Cleanup request for: {} (dryRun={})",
            request.getProjectPath(), request.isDryRun());
        return ResponseEntity.ok(cleanupService.removeUnused(request));
    }
}
```

#### Step 4: Create DTOs

```java
// CleanupRequest.java
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CleanupRequest {
    @NotBlank private String projectPath;
    @Builder.Default private boolean dryRun = true;
}

// CleanupResponse.java
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CleanupResponse {
    private boolean success;
    private String message;
    private String projectPath;
    private boolean dryRun;
    private long totalRemoved;
    private long totalSkipped;
    private long totalFailed;
    private List<EntryDto> entries;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class EntryDto {
        private String filePath;
        private String constantName;
        private String className;
        private int lineNumber;
        private String status;
        private String message;
    }
}
```

#### Step 5: Add Frontend API Function

```typescript
// api.ts
export async function removeUnusedConstants(request: CleanupRequest): Promise<CleanupResponse> {
  const response = await api.post<CleanupResponse>('/cleanup/unused', request)
  return response.data
}
```

#### Step 6: Add Frontend Page (or Tab)

Add a new route in `App.tsx` or integrate into the existing Transform page as a second action.

### 3.3 AST Removal Sequence

```mermaid
sequenceDiagram
    participant UCR as UnusedConstantRemover
    participant JP as JavaParser
    participant AST as CompilationUnit
    participant FS as File System

    UCR->>FS: Read source file
    UCR->>JP: parse(sourceFile)
    JP-->>UCR: CompilationUnit

    UCR->>UCR: Sort targets by lineNumber DESC (bottom-up)

    loop For each unused constant (bottom to top)
        UCR->>UCR: Is constant name in PROTECTED_NAMES?
        alt Protected
            UCR->>UCR: Skip (serialVersionUID, LOG, etc.)
        else Not protected
            UCR->>AST: findAll(FieldDeclaration.class)
            UCR->>AST: Filter: isStatic && isFinal && name matches && line ~= target
            alt Field found, single variable
                UCR->>AST: fd.remove() — remove entire field declaration
            else Field found, multiple variables
                UCR->>AST: variableDeclarator.remove() — remove just this variable
            else Field not found
                UCR->>UCR: Skip (modified since scan)
            end
        end
    end

    alt Any removals made
        UCR->>FS: Copy original → .java.orig
        UCR->>FS: Write cu.toString() → output path
    end
```

### 3.4 Why Bottom-Up Removal Matters

When removing AST nodes, the tree is modified in place. If you remove a field on line 10, every node below it shifts up. By processing from the highest line number to the lowest, earlier (lower) line numbers remain valid throughout the operation.

```
Before removal:
  Line 5:  public static final String HOST = "localhost";   ← remove second
  Line 10: public static final int PORT = 8080;             ← remove first
  Line 15: public void connect() { ... }

After removing line 10 first:
  Line 5:  public static final String HOST = "localhost";   ← still at line 5
  Line 14: public void connect() { ... }                    ← shifted up, but we don't care
```

### 3.5 Safety Considerations

| Concern | Mitigation |
|---------|------------|
| Removing constants still in use | The Neo4j graph must be up-to-date; always re-scan before cleanup |
| `serialVersionUID` detected as unused | Protected by the `PROTECTED_NAMES` set |
| Constants used via reflection | Cannot be detected by static analysis; consider a `@KeepConstant` annotation convention |
| Multi-variable declarations | Only the specific variable is removed, not the entire `FieldDeclaration` |
| Line number drift since last scan | 3-line tolerance window, same as `ConfigLookupTransformer` |
| Original file corruption | Backup written before any modification |
| Dry-run support | Parse and identify candidates without writing anything |

---

## 4. Key Files Reference

| Layer | File | Purpose |
|-------|------|---------|
| **Frontend** | `const-catalog-frontend/src/pages/TransformPage.tsx` | UI for transformation |
| **Frontend** | `const-catalog-frontend/src/services/api.ts` | Axios HTTP client |
| **Frontend** | `const-catalog-frontend/src/types/index.ts` | TypeScript interfaces |
| **Controller** | `const-catalog-backend/.../controller/TransformController.java` | REST endpoint |
| **DTO** | `const-catalog-backend/.../dto/TransformRequest.java` | Request payload |
| **DTO** | `const-catalog-backend/.../dto/TransformResponse.java` | Response payload |
| **Service** | `const-catalog-backend/.../service/CodeTransformationService.java` | Orchestration |
| **Transformer** | `const-catalog-core/.../transformer/ConfigLookupTransformer.java` | AST surgery |
| **Model** | `const-catalog-core/.../model/ConstantTarget.java` | Unit of work for transformation |
| **Model** | `const-catalog-core/.../model/TransformationEntry.java` | Per-constant outcome |
| **Model** | `const-catalog-core/.../model/TransformationResult.java` | Aggregated result |

---

## 5. Testing Strategy

### Unit Tests for Transformers

All transformer tests follow the same pattern:

1. Write a Java source string using a text block
2. Write it to a `@TempDir` file
3. Create `ConstantTarget` objects describing what to transform
4. Call `transformFile()` or `dryRun()`
5. Read the output and assert on content

```java
@Test
void shouldReplaceConstantUsageWithLookup(@TempDir Path tempDir) throws Exception {
    String source = """
        package com.example;
        public class MyService {
            public void doWork() {
                String host = AppConfig.DB_HOST;
            }
        }
        """;

    Path file = tempDir.resolve("MyService.java");
    Files.writeString(file, source);

    ConstantTarget target = new ConstantTarget(
        "DB_HOST", "db.host", "localhost", "String", "AppConfig", 4);

    Path backups = tempDir.resolve("backups");
    List<TransformationEntry> results = transformer.transformFile(file, List.of(target), backups);

    assertThat(results).hasSize(1);
    assertThat(results.get(0).status()).isEqualTo(TransformationEntry.Status.TRANSFORMED);

    String output = Files.readString(backups.resolve(/* relative path */));
    assertThat(output).contains("config.lookup(\"db.host\")");
    assertThat(output).contains("@Autowired");
    assertThat(output).contains("SiteConfigurationService config");
}
```

### Integration Tests

For the controller layer, use `@SpringBootTest` with `@AutoConfigureMockMvc` and a test Neo4j configuration (see `Neo4jTestConfiguration.java` in the test sources).

---

## 6. Summary: The Pattern for Any New Transformation

Every transformation in this system follows the same architectural pattern:

```
1. React page collects user input
       ↓ POST /api/...
2. Spring Controller validates + delegates
       ↓
3. Service queries Neo4j for candidates
       ↓ List<ConstantTarget> grouped by file
4. Transformer parses AST, visits nodes, replaces/removes
       ↓ writes backup + modified source
5. Results bubble back as TransformationEntry → EntryDto → JSON → React table
```

To add any new transformation, you implement each layer of this stack. The core module (`const-catalog-core`) handles AST parsing and manipulation with no Spring dependency. The backend module wires it into the REST API and Neo4j. The frontend renders the results.
