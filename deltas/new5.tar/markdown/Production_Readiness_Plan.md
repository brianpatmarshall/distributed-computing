# Production Readiness Plan

This document outlines the remaining work to bring the Constants Catalog from its current prototype state to a production-ready product. It covers security, deployment, observability, data adapters, testing strategy, and team work assignments.

---

## Current State Summary

| Area | Status | Score |
|------|--------|-------|
| Core functionality (scan, graph, transform) | Complete | 9/10 |
| API documentation (OpenAPI/Swagger) | Complete | 9/10 |
| Module structure | Clean | 9/10 |
| Database/caching layer | Solid | 8/10 |
| Test coverage | Good unit + integration | 7/10 |
| Authentication/authorization | Not implemented | 0/10 |
| Global error handling | Not implemented | 2/10 |
| Observability (metrics, tracing) | Minimal (health only) | 3/10 |
| CI/CD pipeline | Not implemented | 0/10 |
| Secrets management | Plain env vars | 2/10 |

**Overall: ~5.5/10 -- functional prototype, not production-ready.**

---

## 1. Authentication and Authorization

### 1.1 Approach: OAuth 2.0 / OIDC with JWT

The backend is a stateless REST API. The recommended approach is **OAuth 2.0 Resource Server** with JWT bearer tokens, integrating with Boeing's SSO identity provider.

**Architecture:**

```
Browser --> Frontend (React) --> Identity Provider (SSO)
                                       |
                                  access_token (JWT)
                                       |
                                       v
              Frontend --> Backend (validates JWT, extracts roles)
```

### 1.2 Implementation Steps

**Backend (Spring Security):**

1. Add `spring-boot-starter-oauth2-resource-server` dependency
2. Configure JWT issuer and JWKS endpoint in `application.yml`:
   ```yaml
   spring:
     security:
       oauth2:
         resourceserver:
           jwt:
             issuer-uri: https://sso.boeing.com/realms/constcatalog
   ```
3. Create `SecurityConfig.java`:
   - Permit `/api/stats/health` and `/swagger-ui/**` unauthenticated
   - Require authentication for all other endpoints
   - Map JWT claims to Spring authorities for RBAC
4. Define roles:
   | Role | Permissions |
   |------|-------------|
   | `VIEWER` | Read scan results, query graph, view stats |
   | `OPERATOR` | All viewer permissions + trigger scans and transforms |
   | `ADMIN` | All operator permissions + manage configuration, export to ValKey |

**Frontend (React):**

5. Integrate an OIDC client library (e.g., `oidc-client-ts` or `@azure/msal-browser`)
6. Store access token in memory (not localStorage)
7. Attach `Authorization: Bearer <token>` header to all API calls via Axios interceptor
8. Redirect to login on 401 responses

**Infrastructure:**

9. Enable Neo4j authentication (`NEO4J_AUTH=neo4j/password`) -- currently disabled
10. Set a password on ValKey (`requirepass` in valkey-server command)
11. Store all credentials in a secrets manager (HashiCorp Vault or Kubernetes Secrets)

### 1.3 Estimate

| Task | Hours |
|------|-------|
| Spring Security + JWT resource server config | 8 |
| Role-based endpoint authorization | 6 |
| Frontend OIDC integration + token management | 12 |
| Secure Neo4j and ValKey credentials | 4 |
| Secrets manager integration | 8 |
| Testing (auth flows, role enforcement) | 12 |
| **Total** | **50** |

---

## 2. Deployment

### 2.1 Current State

- Docker Compose with multi-stage builds (backend + frontend)
- Non-root container user (`appuser`)
- Health checks on all services
- No CI/CD, no Kubernetes manifests

### 2.2 CI/CD Pipeline (GitHub Actions)

**Pipeline stages:**

```
push/PR --> lint + compile --> unit tests --> integration tests --> build images --> push to registry --> deploy
```

**Workflows to create:**

| Workflow | Trigger | Steps |
|----------|---------|-------|
| `ci.yml` | Push to any branch, PR to main | Compile, unit tests, integration tests (Testcontainers), JaCoCo coverage report |
| `build.yml` | Merge to main | Build Docker images, tag with git SHA, push to container registry |
| `deploy-staging.yml` | Manual or auto after build | Deploy to staging environment, run smoke tests |
| `deploy-prod.yml` | Manual approval | Blue-green deploy to production |

### 2.3 Kubernetes Manifests

Create Helm chart `charts/const-catalog/` with:

| Resource | Purpose |
|----------|---------|
| `Deployment` (backend) | 2+ replicas, resource limits, readiness/liveness probes |
| `Deployment` (frontend) | 2+ replicas, nginx serving static assets |
| `StatefulSet` (Neo4j) | Persistent storage, causal clustering for HA |
| `Deployment` (ValKey) | Sentinel or cluster mode for HA |
| `Service` | ClusterIP for internal, LoadBalancer/Ingress for external |
| `ConfigMap` | Non-sensitive configuration |
| `Secret` | Database passwords, JWT signing keys |
| `Ingress` | TLS termination, path-based routing |
| `HorizontalPodAutoscaler` | Scale backend on CPU/memory |
| `NetworkPolicy` | Restrict pod-to-pod communication |

### 2.4 Production Docker Hardening

- Remove debug port (`5005`) from backend Dockerfile
- Pin image digests instead of tags
- Add container image scanning (Trivy in CI)
- Set read-only root filesystem where possible
- Drop all Linux capabilities

### 2.5 Estimate

| Task | Hours |
|------|-------|
| GitHub Actions CI workflow (compile + test + coverage) | 8 |
| GitHub Actions build + push workflow | 6 |
| Helm chart (all manifests) | 16 |
| Staging deploy workflow + smoke tests | 8 |
| Production deploy workflow with approval gates | 6 |
| Docker hardening (remove debug, pin digests, scan) | 4 |
| **Total** | **48** |

---

## 3. Finishing Touches

### 3.1 Global Error Handling

Create a `@RestControllerAdvice` that returns consistent error responses:

```java
{
  "timestamp": "2026-02-16T10:30:00Z",
  "status": 500,
  "error": "Internal Server Error",
  "message": "Failed to connect to Neo4j",
  "path": "/api/scan",
  "traceId": "abc123"
}
```

Handle: `MethodArgumentNotValidException`, `NoSuchFileException`, `Neo4jException`, `RedisConnectionException`, and a catch-all for unhandled exceptions. Never expose stack traces in production.

| Task | Hours |
|------|-------|
| `GlobalExceptionHandler` + `ErrorResponse` DTO | 6 |
| Custom exception classes (NotFound, Validation, Service) | 4 |
| Tests | 4 |
| **Total** | **14** |

### 3.2 Observability and Metrics

**Metrics (Micrometer + Prometheus):**

1. Add `micrometer-registry-prometheus` dependency
2. Expose `/actuator/prometheus` endpoint
3. Add custom metrics:
   | Metric | Type | Description |
   |--------|------|-------------|
   | `scan.duration.seconds` | Timer | Time to scan a project |
   | `scan.files.total` | Counter | Files scanned |
   | `scan.constants.found` | Counter | Constants discovered |
   | `transform.entries.total` | Counter | Entries by status (transformed/skipped/failed) |
   | `transform.duration.seconds` | Timer | Transform execution time |
   | `cache.caffeine.hit.ratio` | Gauge | Local cache effectiveness |
   | `neo4j.query.duration.seconds` | Timer | Graph query latency |

**Distributed Tracing:**

4. Add `micrometer-tracing-bridge-otel` + `opentelemetry-exporter-otlp`
5. Propagate trace IDs through request headers
6. Include trace ID in error responses and log output

**Structured Logging:**

7. Switch logback format to JSON for log aggregation:
   ```xml
   <encoder class="net.logstash.logback.encoder.LogstashEncoder"/>
   ```

**Dashboards:**

8. Create Grafana dashboards:
   - JVM metrics (heap, GC, threads)
   - HTTP request rate, latency (p50/p95/p99), error rate
   - Neo4j query performance
   - Cache hit rates
   - Transform success/failure rates

| Task | Hours |
|------|-------|
| Prometheus metrics + custom meters | 8 |
| Distributed tracing (OpenTelemetry) | 8 |
| Structured JSON logging | 3 |
| Grafana dashboards (4 boards) | 8 |
| Alerting rules (latency, error rate, disk) | 4 |
| **Total** | **31** |

### 3.3 Reliability

| Task | Hours |
|------|-------|
| Circuit breakers for Neo4j and ValKey (Resilience4j) | 8 |
| Graceful shutdown configuration | 2 |
| Dependency health indicators (Neo4j, ValKey liveness) | 4 |
| API rate limiting (Bucket4j or Spring Gateway) | 6 |
| **Total** | **20** |

### 3.4 Finishing Touches Summary

| Category | Hours |
|----------|-------|
| Global error handling | 14 |
| Observability and metrics | 31 |
| Reliability | 20 |
| **Total** | **65** |

---

## 4. MongoDB Adapter / Plugin Architecture

### 4.1 Goal

Allow the system to pull scanned data (constants, parameters, usages) from external sources like MongoDB, in addition to the current flow of scanning source files directly.

### 4.2 Adapter Architecture

Introduce a plugin interface that decouples data ingestion from the scanning implementation:

```
                 ┌──────────────────┐
                 │  DataSourceAdapter│  (interface)
                 │  ─────────────── │
                 │  ingest(project) │──> ScanResult
                 └────────┬─────────┘
                          │
          ┌───────────────┼───────────────┐
          │               │               │
   ┌──────┴──────┐ ┌──────┴──────┐ ┌──────┴──────┐
   │ FileSystem  │ │  MongoDB    │ │   REST API  │
   │ Adapter     │ │  Adapter    │ │   Adapter   │
   │ (current)   │ │  (new)      │ │  (future)   │
   └─────────────┘ └─────────────┘ └─────────────┘
```

### 4.3 Interface Design

```java
public interface DataSourceAdapter {

    /** Unique identifier for this adapter (e.g., "filesystem", "mongodb"). */
    String type();

    /** Whether this adapter can handle the given connection/path. */
    boolean supports(String source);

    /** Pull data from the external source and return a ScanResult. */
    ProjectScanner.ScanResult ingest(String source, Map<String, String> options);
}
```

The existing `ProjectScanner` becomes the `FileSystemAdapter`. New adapters implement the same interface.

### 4.4 MongoDB Adapter Implementation

**Purpose:** Connect to a MongoDB instance where another team has already cataloged constants/parameters (e.g., from a different scanner or manual entry), and import that data into our Neo4j graph.

**Dependencies:**
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-mongodb</artifactId>
</dependency>
```

**Expected MongoDB schema:**

```json
// constants collection
{
  "_id": "ObjectId",
  "name": "DB_HOST",
  "type": "String",
  "value": "localhost",
  "filePath": "/src/com/example/Config.java",
  "className": "Config",
  "lineNumber": 15,
  "projectPath": "/src/myproject"
}

// parameters collection
{
  "_id": "ObjectId",
  "name": "server.port",
  "value": "8080",
  "filePath": "/src/main/resources/application.properties",
  "lineNumber": 3
}

// parameter_usages collection
{
  "_id": "ObjectId",
  "parameterName": "server.port",
  "filePath": "/src/com/example/WebServer.java",
  "className": "WebServer",
  "lineNumber": 42,
  "context": "getProperty(\"server.port\")"
}
```

**Implementation steps:**

1. Create `const-catalog-mongodb` Maven module (or add to `const-catalog-core`)
2. Implement `MongoDataSourceAdapter`:
   - Connect to MongoDB using Spring Data Mongo
   - Query `constants`, `parameters`, and `parameter_usages` collections
   - Map documents to `Constant`, `Parameter`, `ParameterUsage` model objects
   - Return a `ScanResult`
3. Add adapter registry to `ScanService`:
   ```java
   @Autowired List<DataSourceAdapter> adapters;
   ```
   Spring auto-discovers all implementations via component scanning.
4. Extend `ScanRequest` DTO with `sourceType` field:
   ```json
   {
     "projectPath": "mongodb://host:27017/mydb",
     "sourceType": "mongodb",
     "options": { "database": "mydb", "project": "myproject" }
   }
   ```
5. Update `ScanController` to route to the appropriate adapter based on `sourceType`
6. Add frontend dropdown to select data source type

### 4.5 Future Adapters

The same interface supports additional sources:

| Adapter | Source | Use Case |
|---------|--------|----------|
| `RestApiAdapter` | External REST API | Pull from another team's catalog service |
| `CsvAdapter` | CSV files | Bulk import from spreadsheets |
| `JdbcAdapter` | SQL database | Pull from existing relational stores |
| `GitAdapter` | Git repository | Clone + scan without local checkout |

### 4.6 Estimate

| Task | Hours |
|------|-------|
| Define `DataSourceAdapter` interface + adapter registry | 6 |
| Refactor `ProjectScanner` into `FileSystemAdapter` | 8 |
| Update `ScanService` and `ScanController` to use adapter routing | 6 |
| `MongoDataSourceAdapter` implementation | 16 |
| MongoDB connection configuration + health check | 4 |
| Frontend: data source type selector on Scan page | 6 |
| Integration tests (Testcontainers with MongoDB) | 10 |
| Documentation | 4 |
| **Total** | **60** |

---

## 5. Testing Strategy

### 5.1 Current Test Coverage

The project has **43+ test classes** with **320+ test methods** covering:

- **Unit tests:** Model records, parsers, transformers, exporters
- **Integration tests:** Neo4j repositories, graph population, Spring Boot controllers (using Testcontainers)
- **Diagnostic tests:** Failure mode analysis for the transformer

**Gaps:**
- No code coverage reporting (JaCoCo not configured)
- No frontend tests
- No end-to-end tests
- No performance/load tests
- No security tests
- No contract tests for the API

### 5.2 Test Pyramid

```
                 ┌───────┐
                 │  E2E  │  ~10 tests     (Playwright)
                ─┤       ├─
               ┌─┴───────┴─┐
               │ Integration│  ~80 tests   (Testcontainers, SpringBootTest)
              ─┤            ├─
             ┌─┴────────────┴─┐
             │   Unit Tests    │  ~250 tests  (JUnit 5, Mockito)
             └─────────────────┘
```

**Coverage target:** 80% line coverage across all modules, enforced in CI.

### 5.3 Test Categories and Assignments

#### A. Unit Tests (Target: 250+ tests, ~80% line coverage)

Focused, fast tests for individual classes with mocked dependencies.

| Area | What to Test | Existing | To Add | Assigned To |
|------|-------------|----------|--------|-------------|
| Model records | Equality, factory methods, derived fields | ~15 | 5 (TransformationEntry.backupFilePath) | Junior 1 |
| JavaFileParser | Constant extraction edge cases | ~30 | 10 (enums, generics, annotations) | Junior 1 |
| PropertyFileParser | All 5 formats, malformed files | ~15 | 10 (edge cases, encoding) | Junior 1 |
| ConfigLookupTransformer | Substitution logic, type mapping | ~43 | 10 (shadowed vars, nested classes) | Junior 2 |
| CsvExporter | Export format, special characters | ~10 | 5 (large datasets, unicode) | Junior 2 |
| SiteConfigurationService | Cache hits/misses, pub/sub, TTL | ~12 | 8 (concurrent access, eviction) | Junior 2 |
| Controllers (mocked service) | Request validation, response mapping | ~8 | 15 (all endpoints, error paths) | Junior 2 |
| Global error handler | Exception-to-response mapping | 0 | 10 (each exception type) | Junior 1 |
| MongoDataSourceAdapter | Document mapping, missing fields | 0 | 12 (happy path, malformed docs) | Junior 1 |

#### B. Integration Tests (Target: 80+ tests)

Tests that exercise real infrastructure via Testcontainers.

| Area | What to Test | Existing | To Add | Assigned To |
|------|-------------|----------|--------|-------------|
| Neo4j repositories | CRUD, custom queries, relationships | ~30 | 5 (new query methods) | Senior 2 |
| Graph population | End-to-end scan-to-graph flow | ~15 | 5 (re-scan, large projects) | Senior 2 |
| ValKey cache | Set/get, pub/sub invalidation, expiry | ~5 | 10 (connection failure, reconnect) | Senior 2 |
| Transform pipeline | Real file I/O, backups dir, compare endpoint | ~5 | 10 (read-only source, large files) | Senior 2 |
| MongoDB adapter | Real MongoDB via Testcontainers | 0 | 12 (ingest, missing collections, auth) | Senior 2 |
| Auth flows | JWT validation, role enforcement, 401/403 | 0 | 15 (valid/expired/missing token, each role) | Senior 1 (Lead) |

#### C. End-to-End Tests (Target: 10-15 tests)

Full browser-to-database tests using Playwright against a Docker Compose stack.

| Scenario | Description | Assigned To |
|----------|-------------|-------------|
| Scan project | Enter path, trigger scan, verify results table | Junior 2 |
| Query graph | Run pre-canned query, verify results | Junior 2 |
| Dry-run transform | Run dry-run, verify entry statuses, click View | Junior 2 |
| Real transform | Run transform, verify backups created, view diff | Junior 2 |
| Export to ValKey | Trigger export, verify keys in ValKey | Junior 2 |
| Auth: login flow | Redirect to SSO, receive token, access app | Senior 1 (Lead) |
| Auth: unauthorized | Attempt action without role, verify 403 | Senior 1 (Lead) |
| Error handling | Trigger known error, verify user-friendly message | Junior 2 |

#### D. Performance Tests (Target: 5 scenarios)

Load tests using Gatling or k6 to establish baselines and find bottlenecks.

| Scenario | Target | Assigned To |
|----------|--------|-------------|
| Scan large project (10k+ files) | Complete in < 5 minutes | Senior 2 |
| Concurrent graph queries (50 users) | p95 < 500ms | Senior 2 |
| Transform 500 files | Complete in < 2 minutes | Senior 2 |
| Cache lookup under load (1000 rps) | p99 < 10ms | Senior 2 |
| MongoDB ingest (100k documents) | Complete in < 1 minute | Senior 2 |

#### E. Security Tests

| Test | Description | Assigned To |
|------|-------------|-------------|
| Unauthenticated access | All protected endpoints return 401 | Senior 1 (Lead) |
| Role escalation | VIEWER cannot trigger scan or transform | Senior 1 (Lead) |
| JWT expiry | Expired token returns 401, not 500 | Senior 1 (Lead) |
| Injection | Cypher injection via query endpoint, path traversal via file endpoints | Senior 1 (Lead) |
| CORS | Only allowed origins accepted | Senior 1 (Lead) |

### 5.4 Test Infrastructure

| Component | Purpose | Setup By |
|-----------|---------|----------|
| JaCoCo Maven plugin | Line + branch coverage, fail build below 80% | Senior 1 (Lead) |
| Testcontainers (Neo4j, ValKey, MongoDB) | Real databases in tests | Already configured |
| Playwright | Browser-based E2E tests | Junior 2 |
| Gatling or k6 | Performance/load testing | Senior 2 |
| GitHub Actions test job | Run all tests on every PR, publish coverage | Senior 1 (Lead) |
| SonarQube or Codacy | Static analysis, code quality gates | Senior 1 (Lead) |

### 5.5 Test Execution in CI

```
PR opened / push
  │
  ├─ Stage 1: Compile + Lint                         (~1 min)
  │
  ├─ Stage 2: Unit Tests + JaCoCo                    (~2 min)
  │    └─ Fail if coverage < 80%
  │
  ├─ Stage 3: Integration Tests (Testcontainers)     (~5 min)
  │
  ├─ Stage 4: E2E Tests (Playwright + Docker Compose) (~5 min, main branch only)
  │
  └─ Stage 5: Performance Tests                       (nightly schedule only)
```

---

## 6. Team Work Assignments

### Team Structure

| Role | Person | Availability | Focus Area |
|------|--------|-------------|------------|
| **Senior 1 (Lead)** | TBD | 30 hrs/week | Architecture, security, CI/CD, code review |
| **Senior 2** | TBD | 20 hrs/week | Infrastructure, databases, performance, adapters |
| **Junior 1** | TBD | 20 hrs/week | Backend features, unit tests, error handling |
| **Junior 2** | TBD | 20 hrs/week | Frontend, E2E tests, transformer tests |

### Phase 1: Foundation (Weeks 1-2)

Focus: Error handling, test infrastructure, CI pipeline.

| Task | Assignee | Hours | Depends On |
|------|----------|-------|------------|
| Global exception handler + ErrorResponse DTO | Junior 1 | 10 | -- |
| JaCoCo plugin + coverage enforcement | Senior 1 | 4 | -- |
| GitHub Actions CI workflow (compile + test) | Senior 1 | 8 | -- |
| Unit tests for error handler | Junior 1 | 4 | Error handler |
| Fill unit test gaps (parsers, models) | Junior 1 | 10 | -- |
| Fill unit test gaps (transformer, controllers) | Junior 2 | 10 | -- |
| Playwright setup + first 3 E2E tests | Junior 2 | 12 | -- |
| SonarQube / static analysis integration | Senior 1 | 4 | CI workflow |
| Neo4j + ValKey integration test hardening | Senior 2 | 8 | -- |
| **Phase 1 Total** | | **70** | |

### Phase 2: Security (Weeks 3-4)

Focus: Authentication, authorization, secrets management.

| Task | Assignee | Hours | Depends On |
|------|----------|-------|------------|
| Spring Security + OAuth2 Resource Server config | Senior 1 | 8 | -- |
| Role-based endpoint authorization | Senior 1 | 6 | Security config |
| Frontend OIDC integration + Axios interceptor | Junior 2 | 12 | Security config |
| Secure Neo4j + ValKey credentials | Senior 2 | 4 | -- |
| Secrets manager integration (Vault or K8s) | Senior 2 | 8 | -- |
| Auth unit + integration tests (JWT, roles) | Senior 1 | 12 | Security config |
| Auth E2E tests (login, 401, 403) | Junior 2 | 6 | Frontend OIDC |
| Security tests (injection, CORS, escalation) | Senior 1 | 8 | Security config |
| **Phase 2 Total** | | **64** | |

### Phase 3: Observability + Reliability (Weeks 5-6)

Focus: Metrics, tracing, dashboards, resilience patterns.

| Task | Assignee | Hours | Depends On |
|------|----------|-------|------------|
| Micrometer + Prometheus metrics | Senior 2 | 8 | -- |
| Custom application metrics (scan, transform, cache) | Junior 1 | 8 | Prometheus |
| OpenTelemetry distributed tracing | Senior 2 | 8 | -- |
| Structured JSON logging (logstash-logback) | Junior 1 | 3 | -- |
| Grafana dashboards (4 boards) | Senior 2 | 8 | Prometheus |
| Alerting rules (latency, errors, disk) | Senior 1 | 4 | Grafana |
| Circuit breakers (Resilience4j for Neo4j, ValKey) | Senior 2 | 8 | -- |
| Graceful shutdown + dependency health checks | Junior 1 | 6 | -- |
| API rate limiting | Junior 1 | 6 | -- |
| Tests for resilience (connection failures, timeouts) | Senior 2 | 6 | Circuit breakers |
| **Phase 3 Total** | | **65** | |

### Phase 4: MongoDB Adapter (Weeks 7-8)

Focus: Plugin architecture, MongoDB integration.

| Task | Assignee | Hours | Depends On |
|------|----------|-------|------------|
| `DataSourceAdapter` interface design | Senior 1 | 4 | -- |
| Refactor `ProjectScanner` into `FileSystemAdapter` | Senior 1 | 8 | Interface design |
| Adapter registry + routing in ScanService | Senior 1 | 6 | Refactor |
| `MongoDataSourceAdapter` implementation | Junior 1 | 16 | Interface design |
| MongoDB connection config + health check | Senior 2 | 4 | -- |
| Frontend: data source selector on Scan page | Junior 2 | 6 | Routing |
| MongoDB integration tests (Testcontainers) | Junior 1 | 10 | Adapter impl |
| Unit tests for adapter + document mapping | Junior 1 | 6 | Adapter impl |
| **Phase 4 Total** | | **60** | |

### Phase 5: Deployment + Polish (Weeks 9-10)

Focus: Kubernetes, production hardening, performance validation.

| Task | Assignee | Hours | Depends On |
|------|----------|-------|------------|
| Helm chart (all K8s manifests) | Senior 2 | 16 | -- |
| GitHub Actions build + push workflow | Senior 1 | 6 | -- |
| Staging deploy workflow + smoke tests | Senior 1 | 8 | Helm chart |
| Production deploy workflow with approval gates | Senior 1 | 6 | Staging |
| Docker hardening (remove debug, pin digests, Trivy) | Senior 2 | 4 | -- |
| Performance test suite (Gatling/k6, 5 scenarios) | Senior 2 | 12 | -- |
| Operations runbook | Senior 1 | 6 | All phases |
| Final E2E test suite (remaining scenarios) | Junior 2 | 8 | All phases |
| Remaining test gap coverage to reach 80% | Junior 1 + Junior 2 | 10 | -- |
| **Phase 5 Total** | | **76** | |

---

## 7. Total Effort Summary

| Phase | Focus | Hours | Duration |
|-------|-------|-------|----------|
| Phase 1 | Foundation (errors, CI, test infra) | 70 | Weeks 1-2 |
| Phase 2 | Security (auth, secrets) | 64 | Weeks 3-4 |
| Phase 3 | Observability + Reliability | 65 | Weeks 5-6 |
| Phase 4 | MongoDB Adapter | 60 | Weeks 7-8 |
| Phase 5 | Deployment + Polish | 76 | Weeks 9-10 |
| **Total** | | **335 hours** | **10 weeks** |

### Hours by Team Member

| Person | Phase 1 | Phase 2 | Phase 3 | Phase 4 | Phase 5 | Total |
|--------|---------|---------|---------|---------|---------|-------|
| Senior 1 (Lead) | 16 | 34 | 4 | 18 | 26 | **98** |
| Senior 2 | 8 | 12 | 38 | 4 | 32 | **94** |
| Junior 1 | 24 | 0 | 23 | 32 | 5 | **84** |
| Junior 2 | 22 | 18 | 0 | 6 | 13 | **59** |
| **Weekly** | **70** | **64** | **65** | **60** | **76** | **335** |

### Key Milestones

| Milestone | Week | Gate Criteria |
|-----------|------|---------------|
| CI pipeline green with 80% coverage | 2 | All PRs must pass, coverage enforced |
| Auth-protected staging environment | 4 | No unauthenticated access possible |
| Observable (metrics + dashboards live) | 6 | Grafana boards showing real data |
| MongoDB adapter working in staging | 8 | Ingest from MongoDB, verify in Neo4j |
| Production deploy with runbook signed off | 10 | All tests green, runbook reviewed |
