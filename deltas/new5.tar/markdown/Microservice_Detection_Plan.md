# Microservice Detection Plan

When a Java project is scanned, we want to identify which classes are microservices and what type they are. This information is stored on the `FileNode` in Neo4j as two new attributes:

- `isMicroService` (boolean) — true if the class is a microservice
- `microServiceType` (String) — e.g., `"REST_CONTROLLER"`, `"FEIGN_CLIENT"`, `"SPRING_BOOT"`

---

## Table of Contents

1. [Detection Rules](#1-detection-rules)
2. [Data Flow](#2-data-flow)
3. [Changes by Layer](#3-changes-by-layer)
4. [Implementation Sequence](#4-implementation-sequence)
5. [Design Decisions](#5-design-decisions)
6. [Pre-canned Queries](#6-pre-canned-queries)
7. [Test Plan](#7-test-plan)
8. [Open Questions](#8-open-questions)

---

## 1. Detection Rules

Each microservice type is identified by specific annotations found in the class AST. Some annotations are on the class itself, others are on methods within the class.

| Type | Annotation(s) | Level | Package |
|---|---|---|---|
| `SPRING_BOOT` | `@SpringBootApplication` | Class | `org.springframework.boot.autoconfigure` |
| `REST_CONTROLLER` | `@RestController` | Class | `org.springframework.web.bind.annotation` |
| `REST_CONTROLLER` | `@Path` | Class | `jakarta.ws.rs` (JAX-RS) |
| `FEIGN_CLIENT` | `@FeignClient` | Class (interface) | `org.springframework.cloud.openfeign` |
| `GRPC_SERVICE` | `@GrpcService` | Class | `net.devh.boot.grpc.server.service` |
| `GRPC_SERVICE` | extends `*ImplBase` | Superclass pattern | gRPC generated code |
| `KAFKA_LISTENER` | `@KafkaListener` | Method | `org.springframework.kafka.annotation` |
| `EUREKA_CLIENT` | `@EnableEurekaClient` | Class | `org.springframework.cloud.netflix.eureka` |
| `EUREKA_CLIENT` | `@EnableDiscoveryClient` | Class | `org.springframework.cloud.client.discovery` |
| `SCHEDULED_SERVICE` | `@Scheduled` | Method | `org.springframework.scheduling.annotation` |

### Priority Order

If a class has multiple microservice annotations, the highest-priority type wins:

```
SPRING_BOOT > REST_CONTROLLER > FEIGN_CLIENT > GRPC_SERVICE > KAFKA_LISTENER > SCHEDULED_SERVICE > EUREKA_CLIENT
```

For example, a `@SpringBootApplication` class that also has `@EnableEurekaClient` is classified as `SPRING_BOOT`.

---

## 2. Data Flow

```
JavaFileParser.detectMicroService(path)
        |
        v
MicroServiceDetector.detect(compilationUnit)
        |
        v
MicroServiceInfo(isMicroService=true, type="REST_CONTROLLER")
        |
        v
ProjectScanner.ScanResult.microServiceInfos  (Map<filePath, MicroServiceInfo>)
        |
        v
GraphPopulatorService.setMicroServiceInfo()
        |
        v
FileNode { isMicroService=true, microServiceType="REST_CONTROLLER" }  (Neo4j)
```

This mirrors the existing flow for `javaFileFqns` — the parser extracts data, the scanner collects it into `ScanResult`, and the graph populator writes it to Neo4j.

---

## 3. Changes by Layer

### Layer 1: Core Domain Model (new file)

**New file:** `const-catalog-core/src/main/java/com/boeing/constcatalog/model/MicroServiceInfo.java`

A simple record following the same pattern as `Constant`, `Parameter`, etc.:

```java
public record MicroServiceInfo(
    boolean isMicroService,
    String microServiceType
) {
    public static MicroServiceInfo none() {
        return new MicroServiceInfo(false, null);
    }

    public static MicroServiceInfo of(String type) {
        return new MicroServiceInfo(true, type);
    }
}
```

### Layer 2: Core Parser — Detector (new file)

**New file:** `const-catalog-core/src/main/java/com/boeing/constcatalog/parser/MicroServiceDetector.java`

A dedicated class that takes a JavaParser `CompilationUnit` and checks for microservice annotations:

- Visits all `ClassOrInterfaceDeclaration` nodes for class-level annotations
- Visits all `MethodDeclaration` nodes for method-level annotations (`@KafkaListener`, `@Scheduled`)
- Checks superclass names for the gRPC `*ImplBase` pattern
- Uses a map of annotation simple names to microservice types:

```java
Map.of(
    "SpringBootApplication", "SPRING_BOOT",
    "RestController",        "REST_CONTROLLER",
    "Path",                  "REST_CONTROLLER",
    "FeignClient",           "FEIGN_CLIENT",
    "GrpcService",           "GRPC_SERVICE",
    "KafkaListener",         "KAFKA_LISTENER",
    "EnableEurekaClient",    "EUREKA_CLIENT",
    "EnableDiscoveryClient", "EUREKA_CLIENT",
    "Scheduled",             "SCHEDULED_SERVICE"
)
```

- Returns the highest-priority match, or `MicroServiceInfo.none()`

### Layer 3: Core Parser — JavaFileParser (modify)

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/parser/JavaFileParser.java`

Add one new public method:

```java
public MicroServiceInfo detectMicroService(Path filePath) {
    // Parse the file, get CompilationUnit
    // Delegate to MicroServiceDetector.detect(cu)
}
```

This follows the same pattern as `extractFqn(Path)`.

**Note:** This re-parses the file (the same file is also parsed by `parseConstants`). This matches the existing pattern — `extractFqn()` also re-parses. A single-parse refactor could be done later but is out of scope here.

### Layer 4: Core Scanner — ProjectScanner (modify)

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/scanner/ProjectScanner.java`

Add a new field to the `ScanResult` record:

```java
public record ScanResult(
    List<Constant> constants,
    List<Parameter> parameters,
    List<ParameterUsage> parameterUsages,
    List<ConstantUsage> constantUsages,
    Map<String, String> javaFileFqns,
    Map<String, MicroServiceInfo> microServiceInfos,  // NEW
    int javaFilesScanned,
    int propertyFilesScanned,
    FileTypeStats fileTypeStats
) {}
```

In the Java file parsing loop, after calling `extractFqn()`, also call `detectMicroService()`:

```java
MicroServiceInfo msInfo = javaParser.detectMicroService(javaFile);
microServiceInfos.put(javaFile.toString(), msInfo);
```

Update the `ScanResult` constructor call to include the new map.

### Layer 5: Backend Entity — FileNode (modify)

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/entity/FileNode.java`

Add two fields:

```java
private boolean isMicroService;
private String microServiceType;
```

Lombok `@Data` and `@Builder` auto-generate getters, setters, and builder methods. No Neo4j migration needed — new properties are added to nodes on next save. Existing nodes will have `false`/`null`.

### Layer 6: Backend Service — GraphPopulatorService (modify)

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/GraphPopulatorService.java`

Add a new step after `setJavaFileFqns` (currently Step 8). This follows the exact same pattern:

```java
private void setMicroServiceInfo(ProjectScanner.ScanResult result, Map<String, FileNode> fileCache) {
    for (Map.Entry<String, MicroServiceInfo> entry : result.microServiceInfos().entrySet()) {
        FileNode file = fileCache.get(entry.getKey());
        if (file != null && entry.getValue().isMicroService()) {
            file.setMicroService(true);
            file.setMicroServiceType(entry.getValue().microServiceType());
            fileRepository.save(file);
        }
    }
    log.debug("Set microservice info on {} file nodes",
        result.microServiceInfos().entrySet().stream()
            .filter(e -> e.getValue().isMicroService()).count());
}
```

### Layer 7: Backend — Stats and Queries (modify)

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/repository/FileRepository.java`

Add a query method:

```java
List<FileNode> findByIsMicroServiceTrue();
```

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/QueryService.java`

Add pre-canned queries (see [Section 6](#6-pre-canned-queries)).

### Layer 8: Frontend — Dashboard (modify)

**File:** `const-catalog-frontend/src/types/index.ts`

Add to stats types:

```typescript
microServicesByType?: { type: string; count: number }[]
```

**File:** `const-catalog-frontend/src/pages/Dashboard.tsx`

Add a "Microservices by Type" card following the same pattern as existing stat cards.

---

## 4. Implementation Sequence

```
Step 1: MicroServiceInfo record (core model)         — no dependencies
Step 2: MicroServiceDetector class (core parser)      — depends on 1
Step 3: detectMicroService() in JavaFileParser         — depends on 2
Step 4: Update ScanResult + ProjectScanner loop        — depends on 3
        ---- core module complete, run: mvn install -pl const-catalog-core -DskipTests ----
Step 5: Add fields to FileNode entity                  — no dependency on core
Step 6: Add setMicroServiceInfo() in GraphPopulator    — depends on 4 + 5
Step 7: Add repository queries + pre-canned queries    — depends on 5
Step 8: Update frontend Dashboard                      — depends on 7
Step 9: Tests at each layer                            — parallel with implementation
```

After Step 4, run `mvn install -pl const-catalog-core -DskipTests` so the backend picks up the new `ScanResult` field.

---

## 5. Design Decisions

| Decision | Rationale | Alternative |
|---|---|---|
| Single `microServiceType` per class | Simpler model, covers 90% of cases | `List<String>` or comma-separated for multi-type classes |
| Priority ordering for multi-match | Deterministic, predictable | Return all types and let the UI decide |
| Separate `MicroServiceDetector` class | Keeps `JavaFileParser` focused; easy to test in isolation | Add detection logic directly to `JavaFileParser` |
| Re-parse the file (don't refactor to single parse) | Matches existing `extractFqn()` pattern; avoids large refactor | Parse once, return composite result (future optimization) |
| Detect by annotation simple name only | Simple, works with or without imports resolved | Use fully qualified annotation names for precision |
| Store on `FileNode` not a new entity | File = class in most Java conventions; no new Neo4j schema | New `MicroServiceNode` entity with relationships |

---

## 6. Pre-canned Queries

### All Microservices

```cypher
MATCH (f:File)
WHERE f.isMicroService = true
RETURN f.fileName AS file, f.microServiceType AS type, f.fqn AS fqn, f.path AS filePath
ORDER BY f.microServiceType, f.fileName
```

### Constants in Microservices

```cypher
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
WHERE f.isMicroService = true
RETURN c.name AS name, c.type AS type, c.value AS value,
       f.fileName AS file, f.microServiceType AS serviceType
ORDER BY f.microServiceType, f.fileName, c.name
```

### Microservice Type Summary

```cypher
MATCH (f:File)
WHERE f.isMicroService = true
RETURN f.microServiceType AS type, count(f) AS count
ORDER BY count DESC
```

---

## 7. Test Plan

### MicroServiceDetectorTest (new, core)

| Test | Input | Expected |
|---|---|---|
| Spring Boot app | `@SpringBootApplication class App {}` | `SPRING_BOOT` |
| REST controller | `@RestController class Api {}` | `REST_CONTROLLER` |
| Feign client | `@FeignClient(name="x") interface Svc {}` | `FEIGN_CLIENT` |
| Kafka listener on method | Class with `@KafkaListener` method | `KAFKA_LISTENER` |
| Scheduled method | Class with `@Scheduled` method | `SCHEDULED_SERVICE` |
| gRPC via superclass | `class Svc extends GreeterGrpc.GreeterImplBase {}` | `GRPC_SERVICE` |
| No annotations | Plain class | `isMicroService=false`, type=`null` |
| Multiple annotations | `@SpringBootApplication @EnableEurekaClient` | `SPRING_BOOT` (higher priority) |
| JAX-RS path | `@Path("/api") class Resource {}` | `REST_CONTROLLER` |

### ProjectScannerTest (modify, core)

- Scan a temp directory containing a `@RestController` class. Verify `ScanResult.microServiceInfos()` contains the file with type `REST_CONTROLLER`.

### GraphPopulatorServiceTest (modify, backend)

- Populate graph with a `ScanResult` that has microservice info. Verify `FileNode.isMicroService` and `FileNode.microServiceType` are set correctly in Neo4j.

---

## 8. Open Questions

1. **Multi-type classes:** A class with both `@RestController` and `@Scheduled` methods is currently classified as `REST_CONTROLLER` only (higher priority). Should we support multiple types? If so, should it be a `List<String>` or comma-separated string?

2. **Inner classes:** If an outer class has `@SpringBootApplication` and an inner class has `@RestController`, should both be detected? The current plan detects per-file, not per-class. Inner classes in the same file would be collapsed to the highest-priority match.

3. **Additional types:** Should we detect any of these in the first iteration?
   - `@EnableBinding` (Spring Cloud Stream, deprecated but common)
   - `@Controller` with `@QueryMapping` (GraphQL)
   - `@WebService` (JAX-WS / SOAP)
   - `@MessageDriven` (JMS / EJB)

4. **Scan checkbox:** Should microservice detection be optional (a checkbox on the scan page) or always-on? It adds one extra AST parse per Java file, which adds scan time.

5. **Naming:** The attribute is on `FileNode`, but "isMicroService" is really about the class, not the file. In Java, one file typically has one public class, but not always. Is this acceptable, or should we create a separate `ClassNode` entity?
