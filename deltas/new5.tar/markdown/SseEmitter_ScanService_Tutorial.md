# SseEmitter and ScanService Tutorial

A detailed guide to how Server-Sent Events (SSE) work in this project, from the Spring Boot backend through nginx to the React frontend. This tutorial explains not just how, but why each piece exists.

---

## Table of Contents

1. [What Is SSE?](#1-what-is-sse)
2. [SSE vs. WebSocket vs. Polling](#2-sse-vs-websocket-vs-polling)
3. [The SSE Protocol](#3-the-sse-protocol)
4. [Architecture Overview](#4-architecture-overview)
5. [Backend: SseEmitter](#5-backend-sseemitter)
6. [Backend: ScanController — The Endpoint](#6-backend-scancontroller--the-endpoint)
7. [Backend: ScanService — The Async Worker](#7-backend-scanservice--the-async-worker)
8. [Backend: @EnableAsync — Why It's Required](#8-backend-enableasync--why-its-required)
9. [Core: ProjectScanner and ScanProgressListener](#9-core-projectscanner-and-scanprogresslistener)
10. [The Event Payload: ScanProgressEvent](#10-the-event-payload-scanprogressevent)
11. [Nginx: Proxy Configuration for SSE](#11-nginx-proxy-configuration-for-sse)
12. [Frontend: EventSource and useScanProgress](#12-frontend-eventsource-and-usescanprogress)
13. [Frontend: ScanPage Integration](#13-frontend-scanpage-integration)
14. [Complete Request Lifecycle](#14-complete-request-lifecycle)
15. [Error Handling at Each Layer](#15-error-handling-at-each-layer)
16. [Lessons Learned: Four Bugs That Broke SSE](#16-lessons-learned-four-bugs-that-broke-sse)

---

## 1. What Is SSE?

Server-Sent Events (SSE) is a standard HTTP-based protocol for **one-way streaming** from server to client. The server sends a stream of text events over a single, long-lived HTTP connection. The client receives them as they arrive — no polling, no WebSocket handshake.

SSE is built into every modern browser via the `EventSource` API. It uses plain HTTP, works through firewalls and proxies, and automatically reconnects if the connection drops.

In this project, SSE streams real-time scan progress from the Spring Boot backend to the React frontend. As the scanner processes each file, it sends an event with the file name, progress count, and running totals. The frontend renders these as a live progress bar and scrolling file list.

---

## 2. SSE vs. WebSocket vs. Polling

| Feature | SSE | WebSocket | Polling |
|---|---|---|---|
| Direction | Server → Client only | Bidirectional | Client → Server (repeated) |
| Protocol | HTTP/1.1 | Upgrade from HTTP to WS | HTTP |
| Reconnection | Automatic (built into EventSource) | Manual | N/A |
| Proxy compatibility | Excellent (plain HTTP) | Moderate (requires upgrade support) | Excellent |
| Binary data | No (text only) | Yes | Yes |
| Complexity | Low | Medium | Low (but wasteful) |

**Why SSE for scan progress?** The data flow is strictly one-directional — the server reports progress, the client displays it. The client never needs to send messages back during the scan. SSE is the simplest technology for this pattern. WebSocket would add unnecessary bidirectional complexity, and polling would miss events between intervals.

---

## 3. The SSE Protocol

SSE uses a simple text-based format over HTTP. The server responds with `Content-Type: text/event-stream` and sends events as plain text blocks separated by double newlines:

```
event: progress
data: {"fileIndex":1,"totalFiles":50,"fileName":"Config.java"}

event: progress
data: {"fileIndex":2,"totalFiles":50,"fileName":"Service.java"}

event: complete
data: {"fileIndex":50,"totalFiles":50,"constantsFound":127}
```

Each event has:
- `event:` — An optional event name (the client can listen for specific names)
- `data:` — The payload (can be any text; we use JSON)
- A blank line — Separates events

The browser's `EventSource` API parses this format and fires JavaScript events that your code can handle.

---

## 4. Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        Browser                              │
│                                                             │
│  ScanPage.tsx                                               │
│    └── useScanProgress hook                                 │
│          └── EventSource("GET /api/scan/stream?path=...")   │
│                │                                            │
│                │  receives: event: progress                 │
│                │            data: {fileIndex, totalFiles...} │
│                │                                            │
│                └── Updates React state → re-renders UI      │
└──────────────────────────┬──────────────────────────────────┘
                           │ HTTP (text/event-stream)
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                    nginx (Docker)                            │
│                                                             │
│  location /api/scan/stream {                                │
│      proxy_buffering off;   ← critical for SSE              │
│      proxy_pass http://backend:8080/api/scan/stream;        │
│  }                                                          │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│              Spring Boot Backend (port 8080)                 │
│                                                             │
│  ScanController.streamScan()                                │
│    ├── Creates SseEmitter (10-min timeout)                  │
│    ├── Calls scanService.scanProjectWithProgress() [@Async] │
│    └── Returns SseEmitter immediately to Spring MVC         │
│                                                             │
│  ScanService.scanProjectWithProgress() [async thread]       │
│    ├── Creates ScanProgressListener (lambda)                │
│    ├── Calls projectScanner.scan(path, listener)            │
│    │     └── For each file: listener.onProgress(...)        │
│    │           └── emitter.send(event)  ──────────────► SSE │
│    ├── Sends "complete" event                               │
│    └── emitter.complete()                                   │
│                                                             │
│  ProjectScanner.scan()                                      │
│    ├── Phase 1: Walk file tree, collect all files            │
│    │   (totalFiles is known after this phase)               │
│    └── Phase 2: Parse each file, call listener per file     │
└─────────────────────────────────────────────────────────────┘
```

---

## 5. Backend: SseEmitter

`SseEmitter` is Spring MVC's built-in class for Server-Sent Events. It's a specialized `ResponseBodyEmitter` that formats output as SSE events.

### What It Does

An `SseEmitter` represents an open HTTP connection to a client. You create it, return it from a controller method, and then call `.send()` from any thread to push events to the client. When you're done, call `.complete()` to close the connection.

```java
SseEmitter emitter = new SseEmitter(600_000L); // 10 minute timeout

// Send a named event with JSON data
emitter.send(SseEmitter.event()
    .name("progress")                              // event: progress
    .data("{\"fileIndex\":1,\"totalFiles\":50}"));  // data: {...}

// When done
emitter.complete();
```

### Key Methods

| Method | Purpose |
|---|---|
| `new SseEmitter(timeout)` | Creates an emitter with a maximum lifetime in milliseconds. After this timeout, the connection closes automatically. |
| `.send(SseEmitter.event().name("x").data("y"))` | Sends a named event with a data payload. The data is formatted as `event: x\ndata: y\n\n` in the HTTP response. |
| `.send(data)` | Sends an unnamed event (client receives it on the default `message` handler). |
| `.complete()` | Closes the connection normally. The client's `EventSource` will attempt to reconnect unless you handle the `complete` event. |
| `.completeWithError(ex)` | Closes the connection with an error. The client's `EventSource.onerror` fires. |

### Why a Timeout?

The `600_000L` (10 minutes) timeout prevents abandoned connections from consuming server resources. If a client disconnects without closing (browser crash, network drop), the server doesn't know until it tries to write. The timeout ensures cleanup happens within a bounded time.

This timeout matches the nginx `proxy_read_timeout 600s` — if nginx has a shorter timeout, it would close the connection before the emitter does, causing a confusing error on the client.

### Thread Safety

`SseEmitter.send()` is thread-safe. In this project, the controller creates the emitter on the request thread, but `.send()` is called from the `@Async` thread running the scan. Spring MVC holds the HTTP connection open and routes the emitter's output to it regardless of which thread calls `.send()`.

---

## 6. Backend: ScanController — The Endpoint

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/controller/ScanController.java` (lines 168–187)

```java
@GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public SseEmitter streamScan(@RequestParam("projectPath") String projectPath) {
    SseEmitter emitter = new SseEmitter(600_000L); // 10 minute timeout

    log.info("SSE scan stream requested for: {}", projectPath);

    scanService.scanProjectWithProgress(
        new ScanRequest(projectPath),
        emitter,
        objectMapper
    );

    return emitter;
}
```

### Line-by-Line Explanation

**`@GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)`**

This maps `GET /api/scan/stream` and tells Spring MVC the response content type is `text/event-stream`. This is important because:
- The browser's `EventSource` checks the content type and rejects non-SSE responses
- Spring MVC knows to keep the connection open instead of closing it after the response body is written

**`@RequestParam("projectPath") String projectPath`**

The explicit `("projectPath")` is required because the Docker build doesn't use the `-parameters` javac flag. Without it, the compiled class has `arg0` instead of `projectPath`, and Spring can't match the URL parameter `?projectPath=...` to the method argument. This was one of the four bugs we discovered.

**`SseEmitter emitter = new SseEmitter(600_000L)`**

Creates the emitter with a 10-minute timeout. The emitter is returned to Spring MVC, which holds the HTTP response open and writes to it whenever `emitter.send()` is called.

**`scanService.scanProjectWithProgress(request, emitter, objectMapper)`**

This call returns **immediately** because the method is annotated with `@Async`. Spring intercepts the call, submits the method to a thread pool, and returns a proxy result. The actual scan runs on a background thread.

**`return emitter`**

Returns the emitter to Spring MVC. At this point:
1. The HTTP response headers are sent to the client (`200 OK`, `Content-Type: text/event-stream`)
2. The connection stays open
3. The async scan thread starts calling `emitter.send()` to push events

### Why the Controller Doesn't Do the Scan Itself

If `scanProjectWithProgress` were synchronous, the controller would block on the scan. The emitter would be returned to Spring MVC only **after** the scan completes — but by then, all events have been sent to an emitter that wasn't connected to the client yet. The client would receive nothing.

The `@Async` annotation solves this by running the scan on a separate thread, allowing the controller to return the emitter immediately.

---

## 7. Backend: ScanService — The Async Worker

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/ScanService.java` (lines 119–190)

The `scanProjectWithProgress` method runs on a Spring-managed async thread. It has three phases:

### Phase 1: Create the Progress Listener

```java
ProjectScanner.ScanProgressListener listener = (fileName, filePath, fileIndex, totalFiles,
                                                 constantsFound, parametersFound) -> {
    try {
        ScanProgressEvent event = ScanProgressEvent.builder()
            .eventType(ScanProgressEvent.EventType.FILE_PARSING)
            .fileName(fileName)
            .filePath(filePath)
            .fileIndex(fileIndex)
            .totalFiles(totalFiles)
            .constantsFound(constantsFound)
            .parametersFound(parametersFound)
            .timestamp(LocalDateTime.now())
            .build();

        emitter.send(SseEmitter.event()
            .name("progress")
            .data(objectMapper.writeValueAsString(event)));
    } catch (Exception e) {
        log.debug("Failed to send SSE event: {}", e.getMessage());
    }
};
```

This lambda is the bridge between the scanner (which knows about files) and the emitter (which knows about HTTP). Each time the scanner processes a file, it calls this listener. The listener:

1. Builds a `ScanProgressEvent` DTO with file info and running counters
2. Serializes it to JSON using Jackson's `ObjectMapper`
3. Sends it through the emitter as a named `"progress"` event
4. Catches exceptions silently — if the client disconnected, `emitter.send()` throws, but we don't want to abort the scan

**Why use `ObjectMapper` instead of letting Spring serialize?** The `emitter.send()` with `.data()` accepts a string. We need to control the JSON format explicitly. If we passed the `ScanProgressEvent` object directly, Spring would serialize it, but we'd have less control over error handling and format.

### Phase 2: Run the Scan

```java
ProjectScanner.ScanResult scanResult = projectScanner.scan(projectPath, listener);

graphPopulator.populateGraph(
    projectPath.toString(),
    extractProjectName(projectPath),
    scanResult
);
```

The scanner walks the file tree, parses each file, and calls the listener after each file. Then the graph populator writes the results to Neo4j. During this entire process, SSE events are streaming to the client.

### Phase 3: Send Completion Event

```java
ScanProgressEvent completeEvent = ScanProgressEvent.builder()
    .eventType(ScanProgressEvent.EventType.SCAN_COMPLETE)
    .constantsFound(scanResult.constants().size())
    .parametersFound(scanResult.parameters().size())
    .totalFiles(scanResult.javaFilesScanned() + scanResult.propertyFilesScanned())
    .fileIndex(scanResult.javaFilesScanned() + scanResult.propertyFilesScanned())
    .timestamp(LocalDateTime.now())
    .build();

emitter.send(SseEmitter.event()
    .name("complete")
    .data(objectMapper.writeValueAsString(completeEvent)));
emitter.complete();
```

After the scan and graph population finish, a final `"complete"` event is sent with the totals. Then `emitter.complete()` closes the HTTP connection cleanly. The frontend uses this event to stop the progress display and show the results.

### Error Handling

```java
catch (Exception e) {
    log.error("SSE scan failed for project: {}", projectPath, e);
    try {
        ScanProgressEvent errorEvent = ScanProgressEvent.builder()
            .eventType(ScanProgressEvent.EventType.ERROR)
            .timestamp(LocalDateTime.now())
            .build();
        emitter.send(SseEmitter.event()
            .name("error")
            .data(objectMapper.writeValueAsString(errorEvent)));
    } catch (Exception ex) {
        log.debug("Failed to send error event: {}", ex.getMessage());
    }
    emitter.completeWithError(e);
}
```

If anything fails (invalid path, parse error, Neo4j down), an `"error"` event is sent to the client and the emitter is closed with an error. The nested try-catch handles the case where even sending the error event fails (client already disconnected).

---

## 8. Backend: @EnableAsync — Why It's Required

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/ConstCatalogApplication.java`

```java
@SpringBootApplication
@EnableAsync
public class ConstCatalogApplication { ... }
```

Spring's `@Async` annotation does nothing by itself. It's a marker that tells Spring's AOP framework: "intercept calls to this method and run them on a thread pool." But the AOP processing is only activated when `@EnableAsync` is present on a `@Configuration` class.

Without `@EnableAsync`:
```
Controller thread: scanProjectWithProgress() runs SYNCHRONOUSLY
  → All events sent to emitter
  → Method returns
  → Controller returns emitter
  → Client connects but emitter is already complete
  → No events received
```

With `@EnableAsync`:
```
Controller thread: scanProjectWithProgress() → Spring submits to thread pool → returns immediately
  → Controller returns emitter → client connects
Async thread: scan runs → emitter.send() → events stream to client
```

### How @Async Works Under the Hood

1. At startup, `@EnableAsync` tells Spring to create a `AsyncAnnotationBeanPostProcessor`
2. This post-processor wraps any bean with `@Async` methods in a proxy
3. When the proxy intercepts an `@Async` call, it:
   - Creates a `Runnable` wrapping the method invocation
   - Submits it to a `TaskExecutor` (defaults to `SimpleAsyncTaskExecutor`)
   - Returns immediately (for `void` methods) or returns a `Future`/`CompletableFuture`
4. The actual method runs on the executor's thread

### Important Constraint

`@Async` only works for **external calls** — calls from other beans through the Spring proxy. If `ScanService` called its own `@Async` method internally, the proxy wouldn't intercept it and the method would run synchronously. In this project, `ScanController` (a different bean) calls `ScanService.scanProjectWithProgress()`, so the proxy intercepts correctly.

---

## 9. Core: ProjectScanner and ScanProgressListener

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/scanner/ProjectScanner.java`

```java
@FunctionalInterface
public interface ScanProgressListener {
    void onProgress(String fileName, String filePath, int fileIndex, int totalFiles,
                    int constantsFound, int parametersFound);
}
```

This is a callback interface in the core module (no Spring dependency). The scanner calls it for each file it processes:

```java
public ScanResult scan(Path projectRoot, ScanProgressListener listener) throws IOException {
    // Phase 1: Walk the file tree, collect all files
    List<Path> javaFiles = new ArrayList<>();
    List<Path> propertyFiles = new ArrayList<>();
    Files.walkFileTree(projectRoot, ...);  // populates both lists

    int totalFiles = javaFiles.size() + propertyFiles.size();
    int fileIndex = 0;

    // Phase 2: Parse property files
    for (Path propertyFile : propertyFiles) {
        fileIndex++;
        if (listener != null) {
            listener.onProgress(fileName, filePath, fileIndex, totalFiles,
                constants.size(), parameters.size());
        }
        // parse...
    }

    // Phase 3: Parse Java files
    for (Path javaFile : javaFiles) {
        fileIndex++;
        if (listener != null) {
            listener.onProgress(fileName, filePath, fileIndex, totalFiles,
                constants.size(), parameters.size());
        }
        // parse...
    }
}
```

**Why the two-phase design matters for progress reporting:**

Phase 1 walks the entire file tree **before** parsing begins. This means `totalFiles` is known from the start. Without this, the progress bar couldn't show a percentage — you'd only know "file 5 of ???". The file tree walk is fast (milliseconds for most projects), so the user doesn't notice the delay before the first progress event.

**Why `listener` is nullable:** The `scan(Path)` overload (no listener) passes `null`. This keeps the scanning logic in one place — the listener check is just `if (listener != null)`. The non-SSE scan endpoint (`POST /api/scan`) uses this overload.

---

## 10. The Event Payload: ScanProgressEvent

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/dto/ScanProgressEvent.java`

```java
public class ScanProgressEvent {

    public enum EventType {
        FILE_DISCOVERED,
        FILE_PARSING,
        FILE_PARSED,
        SCAN_COMPLETE,
        ERROR
    }

    private EventType eventType;
    private String fileName;
    private String filePath;
    private int fileIndex;      // 1-based: "file 7 of 50"
    private int totalFiles;     // known upfront from file tree walk
    private int constantsFound; // running total
    private int parametersFound; // running total
    private LocalDateTime timestamp;
}
```

This DTO is serialized to JSON and sent as the `data:` field of each SSE event. The frontend parses it and uses:

- `fileIndex` / `totalFiles` → progress bar percentage: `Math.round((fileIndex / totalFiles) * 100)`
- `fileName` → scrolling file list
- `constantsFound` / `parametersFound` → running counters displayed below the progress bar
- `eventType` → the frontend doesn't currently use this (it relies on SSE event names: `"progress"`, `"complete"`, `"error"`), but it's available for future use

---

## 11. Nginx: Proxy Configuration for SSE

**File:** `const-catalog-frontend/nginx.conf` (lines 25–43)

When the frontend runs inside Docker, nginx proxies API requests to the backend. SSE requires specific configuration:

```nginx
location /api/scan/stream {
    proxy_pass http://backend:8080/api/scan/stream;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header Connection '';

    proxy_buffering off;
    proxy_cache off;
    gzip off;
    proxy_read_timeout 600s;
}
```

### Why Each Directive Matters for SSE

**`proxy_buffering off`** — This is the critical directive. By default, nginx collects the backend's response into an internal buffer (4–8KB) and only forwards it to the client when the buffer fills or the connection closes. Each SSE event is ~200 bytes — they'd sit in the buffer invisibly. With buffering off, nginx forwards each chunk immediately as it arrives from the backend.

**`proxy_cache off`** — Prevents nginx from caching the SSE response. Each SSE connection is unique and real-time.

**`gzip off`** — Gzip compression collects data into blocks before compressing. This re-introduces buffering at the encoding layer, defeating `proxy_buffering off`. The events are small text payloads; compression would save negligible bytes.

**`proxy_set_header Connection ''`** — Keeps the connection open using HTTP/1.1's default keep-alive. An earlier version had `Connection 'upgrade'` (WebSocket header), which caused the backend to reject the connection because SSE is not WebSocket.

**`proxy_read_timeout 600s`** — Matches the `SseEmitter` timeout (10 minutes). If no data arrives from the backend within this time, nginx closes the connection. Without this, nginx's default 60-second timeout would kill long scans.

### Why a Separate Location Block

The SSE endpoint has its own `location /api/scan/stream` block, separate from the general `location /api/` block. Nginx uses longest-prefix matching — a request to `/api/scan/stream?projectPath=...` matches both, but nginx picks the longer prefix. This lets us disable buffering for SSE without affecting normal REST API requests, which benefit from buffering.

### Not Needed for `npm run dev`

When running the frontend via `npm run dev`, Vite's built-in dev server handles proxying. Vite doesn't buffer SSE responses — it passes events through natively. The nginx config only applies inside the Docker container.

---

## 12. Frontend: EventSource and useScanProgress

**File:** `const-catalog-frontend/src/hooks/useScanProgress.ts`

### The EventSource API

`EventSource` is a browser-native API for receiving SSE streams. Usage:

```javascript
const eventSource = new EventSource('/api/scan/stream?projectPath=/src/myproject');

eventSource.onopen = () => { /* connected */ };

eventSource.addEventListener('progress', (event) => {
    const data = JSON.parse(event.data);
    // data.fileIndex, data.totalFiles, data.fileName, etc.
});

eventSource.addEventListener('complete', (event) => {
    const data = JSON.parse(event.data);
    eventSource.close();
});

eventSource.onerror = () => {
    eventSource.close();
};
```

`EventSource` automatically:
- Sets `Accept: text/event-stream` header
- Parses the SSE format (`event:`, `data:`, blank line separators)
- Fires named event listeners based on the `event:` field
- Reconnects automatically if the connection drops (unless you call `.close()`)

### The useScanProgress Hook

The hook wraps `EventSource` in React state management:

```typescript
export function useScanProgress(): UseScanProgressReturn {
    const [events, setEvents] = useState<ScanProgressEvent[]>([])
    const [isConnected, setIsConnected] = useState(false)
    const [isComplete, setIsComplete] = useState(false)
    const [currentEvent, setCurrentEvent] = useState<ScanProgressEvent | null>(null)
    const eventSourceRef = useRef<EventSource | null>(null)
```

**State breakdown:**

| State | Purpose |
|---|---|
| `events` | Array of all received events (used for the scrolling file list) |
| `isConnected` | `true` while the `EventSource` connection is open |
| `isComplete` | `true` after the `"complete"` event is received |
| `currentEvent` | The most recent event (used for progress bar and counters) |
| `eventSourceRef` | A React ref holding the `EventSource` instance (not state — doesn't trigger re-renders) |

**Why `useRef` for the EventSource?** The `EventSource` instance doesn't need to trigger re-renders when it changes. It's a mutable object that the `startStreaming` and `stopStreaming` callbacks need to access. `useRef` provides a stable reference across renders without causing unnecessary re-renders.

**`startStreaming(projectPath)`:**
1. Closes any existing connection
2. Resets all state
3. Creates a new `EventSource`
4. Registers three event listeners:
   - `'progress'` → updates `currentEvent` and appends to `events`
   - `'complete'` → updates state, sets `isComplete = true`, closes connection
   - `'error'` → closes connection

**`stopStreaming()`:**
1. Calls `eventSource.close()` to terminate the connection
2. Sets `isConnected = false`

**The rolling window:**
```typescript
const latestFiles = events
    .filter((e) => e.fileName)
    .slice(-25)
    .map((e) => e.fileName)
```

Only the last 25 file names are kept for the scrolling display. This is computed from `events` on every render — it's derived state, not stored separately.

---

## 13. Frontend: ScanPage Integration

**File:** `const-catalog-frontend/src/pages/ScanPage.tsx`

The ScanPage uses the hook and decides between SSE and POST based on the checkbox:

```typescript
const { isConnected, isComplete, latestFiles, currentEvent, startStreaming } =
    useScanProgress()

const handleScan = (e: React.FormEvent) => {
    e.preventDefault()
    if (!projectPath.trim()) return
    setScanResult(null)

    if (watchProgress) {
        // SSE-only: the /api/scan/stream endpoint runs its own scan
        startStreaming(projectPath.trim())
    } else {
        // POST-only: traditional request-response
        scanMutation.mutate({ projectPath: projectPath.trim() })
    }
}
```

**Why mutually exclusive?** The SSE endpoint (`GET /api/scan/stream`) and the POST endpoint (`POST /api/scan`) each run their own independent scan. Running both concurrently causes `ConcurrentModificationException` in the scanner's shared data structures. The frontend ensures only one scan mechanism fires per user action.

**Building the result from SSE completion:**

```typescript
useEffect(() => {
    if (isComplete && currentEvent) {
        setScanResult({
            success: true,
            message: 'Scan completed successfully',
            constantsFound: currentEvent.constantsFound,
            parametersFound: currentEvent.parametersFound,
            javaFilesScanned: currentEvent.totalFiles,
        })
        queryClient.invalidateQueries({ queryKey: ['stats'] })
    }
}, [isComplete, currentEvent, queryClient])
```

When the SSE scan finishes, the `'complete'` event provides enough data to build a basic `ScanResponse` for the results panel. The Dashboard stats cache is also invalidated so it reflects the new scan data.

---

## 14. Complete Request Lifecycle

Here's every step from button click to progress bar update:

```
1. User clicks "Scan Project" with "Watch scan progress" checked

2. ScanPage.handleScan() calls startStreaming(projectPath)

3. useScanProgress creates EventSource:
   new EventSource("/api/scan/stream?projectPath=/src/myproject")

4. Browser sends:
   GET /api/scan/stream?projectPath=/src/myproject HTTP/1.1
   Accept: text/event-stream

5. nginx matches location /api/scan/stream
   → proxy_pass to backend:8080 with proxy_buffering off

6. Spring MVC routes to ScanController.streamScan()
   → Creates SseEmitter(600_000L)
   → Calls scanService.scanProjectWithProgress() — @Async, returns immediately
   → Returns emitter to Spring MVC

7. Spring MVC sends response headers:
   HTTP/1.1 200 OK
   Content-Type: text/event-stream
   (connection stays open)

8. EventSource.onopen fires → isConnected = true

9. Async thread starts in ScanService:
   → Validates path
   → Creates ScanProgressListener lambda
   → Calls projectScanner.scan(path, listener)

10. ProjectScanner Phase 1: walks file tree
    → Collects 50 Java files, 10 property files
    → totalFiles = 60

11. ProjectScanner Phase 2: parses property files
    → For each file:
       a. listener.onProgress("app.properties", "/src/.../app.properties", 1, 60, 0, 5)
       b. Lambda builds ScanProgressEvent, serializes to JSON
       c. emitter.send(event().name("progress").data(json))
       d. Spring MVC writes to HTTP response:
          event: progress
          data: {"eventType":"FILE_PARSING","fileName":"app.properties","fileIndex":1,"totalFiles":60,...}

       e. nginx forwards immediately (no buffering)
       f. Browser receives the chunk
       g. EventSource parses the SSE format
       h. 'progress' event listener fires
       i. setCurrentEvent(data) → React re-renders
       j. Progress bar: Math.round(1/60 * 100) = 2%

12. ProjectScanner Phase 3: parses Java files
    → Same as Phase 2, for each of 50 Java files
    → Progress bar advances: 17%, 18%, 20%, ...

13. Scan finishes:
    → graphPopulator.populateGraph() writes to Neo4j
    → ScanService sends "complete" event
    → emitter.complete()

14. Browser receives "complete" event:
    → 'complete' listener: setIsComplete(true), stopStreaming()
    → EventSource.close()
    → useEffect fires: builds ScanResponse, invalidates stats cache
    → Results panel appears with "Scan Completed Successfully"
```

---

## 15. Error Handling at Each Layer

### Backend: Listener Exception
The lambda wraps `emitter.send()` in try-catch. If the client disconnected mid-scan, the send fails but the scan continues. This is intentional — the scan and graph population are still valuable even if nobody's watching.

### Backend: Scan Exception
If the scan itself fails (bad path, parse crash), the catch block sends an `"error"` event and calls `emitter.completeWithError(e)`. The nested try-catch handles the case where even sending the error event fails.

### Nginx: Timeout
If no events arrive within `proxy_read_timeout 600s`, nginx closes the connection. The frontend's `EventSource.onerror` fires and calls `stopStreaming()`.

### Frontend: Parse Error
The `'progress'` listener wraps `JSON.parse` in try-catch. Malformed events are silently ignored rather than crashing the UI.

### Frontend: Connection Error
Both `eventSource.addEventListener('error', ...)` and `eventSource.onerror` call `stopStreaming()`. The duplicate handlers exist because some browsers fire the error on one or the other.

### SseEmitter: Timeout
If the scan takes longer than 10 minutes, the `SseEmitter` times out. Spring MVC closes the connection. The frontend sees a connection error and calls `stopStreaming()`.

---

## 16. Lessons Learned: Four Bugs That Broke SSE

During development, SSE didn't work. Four layered issues were discovered, each masking the next:

| # | Bug | Symptom | Fix |
|---|---|---|---|
| 1 | Missing `@EnableAsync` | `scanProjectWithProgress` ran synchronously — all events sent before client connected | Added `@EnableAsync` to `ConstCatalogApplication` |
| 2 | Missing `@RequestParam("projectPath")` | Docker build didn't preserve parameter names — endpoint returned 500 | Added explicit name to annotation |
| 3 | Nginx buffering | Events accumulated in nginx's buffer, never forwarded | Added `proxy_buffering off` in dedicated SSE location block |
| 4 | Double scan (POST + SSE) | Two concurrent scans caused `ConcurrentModificationException` — POST killed SSE stream | Made POST and SSE mutually exclusive in frontend |

Each fix was discovered by working from the outside in: browser Network tab → curl through nginx → curl direct to backend → backend logs → code review. The full investigation is documented in `Fix_Watch_Scan_Progress.md`.
