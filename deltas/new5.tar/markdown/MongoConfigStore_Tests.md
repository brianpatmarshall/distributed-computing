# MongoConfigStore Unit Tests

A catalog of all 58 tests in `MongoConfigStoreTest.java`, organized by category. Each test uses a real MongoDB 7 instance via Testcontainers — no mocks.

---

## Table of Contents

1. [Connection Tests](#1-connection-tests)
2. [Basic Get/Set Tests](#2-basic-getset-tests)
3. [Create: Storing Key-Value Pairs](#3-create-storing-key-value-pairs)
4. [Read: Retrieving Values](#4-read-retrieving-values)
5. [Update: Overwriting Existing Values](#5-update-overwriting-existing-values)
6. [Delete: Removing Values](#6-delete-removing-values)
7. [Batch Operations](#7-batch-operations)
8. [Prefix Queries](#8-prefix-queries)
9. [Pub/Sub](#9-pubsub)
10. [CRUD Lifecycle](#10-crud-lifecycle)
11. [Document Structure Verification](#11-document-structure-verification)
12. [Stress and Edge Cases](#12-stress-and-edge-cases)

---

## 1. Connection Tests

| Test | Intent |
|---|---|
| `testMongoContainerIsRunning` | Verifies the Testcontainers MongoDB container started successfully. If this fails, all other tests will fail — it's a quick diagnostic. |
| `testCanConnectToMongo` | Runs a `ping` command against the database to verify the Java driver can communicate with MongoDB. Tests the connection string and authentication. |
| `testStoreNameIsMongoDB` | Verifies `storeName()` returns `"MongoDB"` — used in log messages and diagnostics to identify which backend is active. |

---

## 2. Basic Get/Set Tests

| Test | Intent |
|---|---|
| `testSetAndGet` | The most fundamental test: store `"localhost"` under key `"db.host"`, retrieve it, verify it matches. Proves the basic write-then-read path works. |
| `testGetMissingKeyReturnsNull` | Verifies that reading a key that was never stored returns `null` rather than throwing or returning an empty string. This is the contract that `SiteConfigurationService` depends on for its null-sentinel caching. |
| `testSetOverwritesExistingValue` | Stores a value, stores a different value under the same key, verifies the second value wins. Tests the upsert behavior (`replaceOne` with `upsert: true`). |
| `testSetEmptyValue` | Stores an empty string `""` and verifies it's retrievable as `""` (not `null`). Empty strings are valid configuration values (e.g., an empty password for local dev). |
| `testSetValueWithSpecialCharacters` | Stores a JDBC URL containing `://`, `?`, `=`, and `&`. Verifies these characters aren't mangled by MongoDB's BSON encoding or the Java driver. |
| `testSetValueWithUnicode` | Stores Japanese text (`こんにちは世界`). Verifies UTF-8 encoding is preserved through the full write-read cycle. |
| `testKeyWithDots` | Stores a deeply dotted key `"app.server.http.port"`. Dots are special in MongoDB's query language (field path separator), but since we use `_id` matching, they should work fine as key names. |

---

## 3. Create: Storing Key-Value Pairs

| Test | Intent |
|---|---|
| `testCreateSingleKeyValue` | Stores one key and verifies the collection has exactly 1 document. Checks that `set()` creates a document, not just returns silently. |
| `testCreateMultipleDistinctKeys` | Stores 5 different keys and verifies all 5 are independently retrievable. Tests that keys don't collide or overwrite each other. |
| `testCreateWithNullValueThrowsOrStoresNull` | Stores a `null` value. MongoDB allows null fields. Verifies `get()` returns `null` — the caller can't distinguish "key exists with null value" from "key doesn't exist", which matches the `ConfigStore` contract. |
| `testCreateWithVeryLongKey` | Stores a key that's ~280 characters long (repeated dotted segments). Tests that MongoDB doesn't truncate or reject long `_id` values. MongoDB's `_id` limit is ~1000 bytes for indexed fields. |
| `testCreateWithMultilineValue` | Stores a value with `\n` newlines and `\t` tabs. Verifies whitespace characters survive the BSON round-trip. Important for configuration values that contain formatted text. |
| `testCreateWithJsonValue` | Stores a raw JSON string as the value. Verifies it's stored as a plain string, not parsed as a nested BSON document. The value field is always a string in our schema. |
| `testCreateWithEqualsAndColonsInValue` | Stores a MySQL JDBC URL with `=` and `:` characters. These are common in Java property values and must be preserved exactly. |
| `testCreateWithEmptyKey` | Stores a value under the empty string key `""`. Edge case — MongoDB allows empty `_id`. Verifies the store doesn't reject or mishandle it. |
| `testCreatePreservesWhitespace` | Stores a value with leading and trailing spaces. Verifies the store doesn't trim whitespace — the value must be byte-for-byte identical on retrieval. |
| `testCreateWithPathLikeKey` | Stores a key that looks like a file path (`/opt/app/config/db.host`). Verifies slashes don't interfere with MongoDB operations. |

---

## 4. Read: Retrieving Values

| Test | Intent |
|---|---|
| `testReadNonexistentKeyReturnsNull` | Stores one key, reads a different key. Verifies that the presence of other data doesn't cause false matches. |
| `testReadAfterMultipleWrites` | Writes to the same key 3 times, reads after each write. Verifies that `get()` always returns the latest value, not a cached or stale one. |
| `testReadDoesNotModifyStore` | Reads the same key 3 times, then verifies the document count is still 1 and the value is unchanged. Proves `get()` is a pure read with no side effects. |
| `testReadDistinguishesSimilarKeys` | Stores `app.timeout`, `app.timeoutMs`, and `app.timeout.read` — keys that share a common prefix. Verifies exact-match retrieval doesn't accidentally return a partial match. |
| `testReadFromEmptyStore` | Reads from a freshly cleared store. Verifies no exception is thrown and `null` is returned. |

---

## 5. Update: Overwriting Existing Values

| Test | Intent |
|---|---|
| `testUpdateValueInPlace` | Stores a value, overwrites it, verifies the new value. Also checks the document count is still 1 — proving `replaceOne` with upsert updates in place rather than creating a duplicate. |
| `testUpdateToEmptyValue` | Updates a non-empty value to `""`. Verifies the empty string is stored correctly and the old value is gone. |
| `testUpdateToLongerValue` | Updates `"short"` to a much longer string. Verifies MongoDB handles the document size increase without issues. |
| `testUpdateToShorterValue` | Updates a long string to `"short"`. Verifies the old data is fully replaced, not partially overwritten. |
| `testUpdateDoesNotAffectOtherKeys` | Stores 3 keys, updates 1, verifies the other 2 are unchanged. Proves updates are isolated to the targeted key. |
| `testUpdateManyTimesInSuccession` | Updates the same key 100 times in a loop. Verifies the final value is correct and only 1 document exists. Stress-tests the upsert path. |
| `testUpdateViaBatchOverwritesSingle` | Creates a key with `set()`, then overwrites it via `setBatch()`. Verifies batch operations correctly update existing keys, not just insert new ones. |
| `testBatchUpdateMixedNewAndExisting` | Batch writes 3 keys: 2 already exist (update), 1 is new (create). Verifies the batch correctly handles mixed create/update in a single call. |

---

## 6. Delete: Removing Values

| Test | Intent |
|---|---|
| `testDeleteExistingKey` | Stores a key, deletes it, verifies `get()` returns `null`. The basic delete path. |
| `testDeleteMissingKeyReturnsFalse` | Deletes a key that was never stored. Verifies `delete()` returns `false` (not an exception). This is important — callers use the return value to know if anything happened. |
| `testDeleteDoesNotAffectOtherKeys` | Stores 2 keys, deletes 1, verifies the other survives. Proves delete is targeted. |
| `testDeleteReducesCount` | Stores 3 keys, deletes 1, verifies the document count dropped from 3 to 2. Tests at the database level, not just via `get()`. |
| `testDeleteThenRecreate` | Stores a key, deletes it, stores the same key with a different value. Verifies delete doesn't leave behind phantom data that interferes with recreation. |
| `testDeleteAllKeys` | Stores 3 keys, deletes all 3 individually, verifies the collection is empty. Tests that repeated deletes drain the store completely. |
| `testDeleteSameKeyTwice` | Deletes the same key twice. First returns `true`, second returns `false`. Verifies idempotency — double-delete doesn't throw or return a misleading result. |
| `testDeleteFromEmptyStore` | Deletes from an empty collection. Verifies no exception and returns `false`. |
| `testDeleteWithSimilarKeyNames` | Stores `app.timeout` and `app.timeoutMs`, deletes `app.timeout`. Verifies `app.timeoutMs` is not affected. Tests that delete uses exact `_id` matching, not prefix matching. |

---

## 7. Batch Operations

| Test | Intent |
|---|---|
| `testSetBatch` | Stores 3 keys in one `setBatch()` call. Verifies all 3 are individually retrievable. Tests the basic batch-write path. |
| `testSetBatchOverwritesExisting` | Stores a key, then runs a batch that includes that key with a new value. Verifies the batch upsert overwrites correctly. |
| `testSetBatchEmptyMap` | Calls `setBatch()` with an empty map. Verifies it doesn't throw — it's a valid no-op. |

---

## 8. Prefix Queries

| Test | Intent |
|---|---|
| `testKeysByPrefix` | Stores 4 keys (3 starting with `db.`, 1 with `app.`). Queries `keysByPrefix("db.")`. Verifies only the 3 matching keys are returned. |
| `testKeysByPrefixNoMatches` | Queries a prefix that matches nothing. Verifies an empty list is returned, not null or an exception. |
| `testGetByPrefix` | Stores 4 keys (3 `mail.`, 1 `db.`). Queries `getByPrefix("mail.")`. Verifies the returned map has 3 entries with correct values, and excludes the `db.` key. |
| `testGetByPrefixNoMatches` | Queries a prefix with no matches. Verifies an empty map is returned. |
| `testPrefixWithRegexSpecialCharacters` | Stores `db.host` and `dbahost`. Queries `keysByPrefix("db.")`. The dot is a regex wildcard — without escaping, `dbahost` would match `db.host` pattern. Verifies only `db.host` is returned, proving the dot is escaped in the regex. |

---

## 9. Pub/Sub

| Test | Intent |
|---|---|
| `testPublishChangeDoesNotThrow` | Calls `publishChange()` which is a no-op for MongoDB standalone. Verifies it doesn't throw an exception. MongoDB Change Streams (needed for real pub/sub) require a replica set. |

---

## 10. CRUD Lifecycle

| Test | Intent |
|---|---|
| `testFullCrudLifecycle` | Walks through the complete lifecycle of a single key: Create → Read → Update → Read → Delete → Verify gone. Tests that all four operations work in sequence on the same key. |
| `testCrudWithBatchOperations` | Creates 3 keys via batch, reads all via prefix, updates one via `set()`, deletes one, verifies final state. Tests that individual and batch operations interoperate correctly. |
| `testSimulateConfigurationScenario` | Simulates a realistic workflow: batch-export 5 constants (like `ConfigurationExportService` would), lookup by prefix (like querying all `AppConfig` values), update one value, delete an obsolete key. This is the closest test to how the store is actually used in production. |

---

## 11. Document Structure Verification

| Test | Intent |
|---|---|
| `testDocumentStructure` | Bypasses the `ConfigStore` interface and queries MongoDB directly. Verifies the document has the expected shape: `{ _id: "db.host", key: "db.host", value: "localhost" }`. This ensures the schema is correct for any future direct MongoDB queries or migrations. |

---

## 12. Stress and Edge Cases

| Test | Intent |
|---|---|
| `testLargeValue` | Stores a 100,000-character string. Verifies MongoDB handles values well beyond typical configuration sizes. MongoDB's document size limit is 16MB — this is well within bounds. |
| `testManyKeys` | Stores 500 keys in a loop, reads the first and last, queries all by prefix. Tests that the store handles moderate scale without performance or correctness issues. |
