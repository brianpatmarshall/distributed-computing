# Detailed Substitution Strategy

This document describes the detailed mechanics of how `ConfigLookupTransformer` decides what to replace, how it rewrites the AST, and how output files are managed. It complements the [Transformation Process](TransformationProcess.md) overview with implementation-level specifics.

---

## 1. Target Classification

Every candidate for substitution is represented as a `ConstantTarget` record with a `SourceKind` discriminator:

| Field | Purpose | Example (Constant) | Example (Parameter) |
|-------|---------|---------------------|---------------------|
| `constantName` | Identifier to match in AST | `DB_HOST` | `database.host` |
| `propertyKey` | Key for `config.lookup*()` call | `db.host` | `database.host` |
| `originalValue` | Hardcoded value (used as default) | `"localhost"` | `""` |
| `originalType` | Java type of the constant | `String` | `String` |
| `className` | Class containing the usage | `AppConfig` | `DbService` |
| `lineNumber` | Line where constant/usage was found | `15` | `42` |
| `sourceKind` | Discriminator | `CONSTANT` | `PARAMETER` |

### Property Key Derivation

For constants, the property key is derived from `SCREAMING_SNAKE_CASE` by lowering and replacing underscores with dots:

```
DB_HOST         -> db.host
API_BASE_URL    -> api.base.url
MAX_RETRIES     -> max.retries
```

For parameters, the property key is the parameter name as-is (already in dotted notation from the property file).

---

## 2. AST Matching Rules

The transformer parses each Java file into an AST using JavaParser (configured for Java 21) and visits it with a `ModifierVisitor`. The visitor handles three node types, each mapped to a specific target kind.

### 2.1 Constant Targets: NameExpr

A `NameExpr` is an unqualified reference to a name in the source code.

```java
String host = DB_HOST;  // DB_HOST is a NameExpr
```

**Match criteria:**
1. The `NameExpr.nameAsString` equals a constant target's `constantName`
2. The node is **not** a declaration (i.e., not the left-hand side of `String DB_HOST = ...`)

**Declaration guard:** The `isDeclaration()` check examines whether the `NameExpr`'s parent is a `VariableDeclarator` with the same name. This prevents the transformer from rewriting the constant definition itself:

```java
// This is a declaration -- NOT replaced:
public static final String DB_HOST = "localhost";

// This is a usage -- replaced:
String host = DB_HOST;
```

### 2.2 Constant Targets: FieldAccessExpr

A `FieldAccessExpr` is a qualified reference like `ClassName.FIELD`.

```java
String host = AppConfig.DB_HOST;  // DB_HOST is a FieldAccessExpr
```

**Match criteria:**
1. The `FieldAccessExpr.nameAsString` equals a constant target's `constantName`

No declaration guard is needed because `FieldAccessExpr` nodes only appear at usage sites (cross-class references), never at the declaration site.

### 2.3 Parameter Targets: MethodCallExpr

A `MethodCallExpr` represents a method invocation, including the scope, name, and arguments.

```java
String host = props.getProperty("database.host");
//            ^---- scope        ^---- StringLiteralExpr argument
```

**Match criteria (all must hold):**
1. The method name is in the recognized property getter set
2. At least one argument is a `StringLiteralExpr`
3. That string literal's value equals a parameter target's `constantName`

**Recognized getter methods:**

| Method Name | Category |
|-------------|----------|
| `getProperty`, `get`, `getString` | Standard string accessors |
| `getInt`, `getInteger` | Integer accessors |
| `getLong` | Long accessor |
| `getBoolean` | Boolean accessor |
| `getDouble`, `getFloat` | Floating-point accessors |
| `getValue`, `getConfig` | Generic accessors |
| `getenv` | Environment variable access |
| `getOrDefault`, `getPropertyValue` | Extended accessors |

The entire `MethodCallExpr` (including its scope like `props.`) is replaced, not just the method name.

---

## 3. Replacement Expression Construction

When a match is found, the transformer constructs a new `MethodCallExpr` to replace the original node.

### 3.1 Constant Replacement

The replacement call is built on `config` (a `NameExpr` referencing the injected `SiteConfigurationService` field):

```java
config.<lookupMethod>("<propertyKey>", <defaultValue>)
```

**Lookup method selection** is based on `originalType`:

| `originalType` | Method | Has Default Arg | Example |
|----------------|--------|-----------------|---------|
| `String` | `lookup` | No | `config.lookup("db.host")` |
| `int` / `Integer` | `lookupInt` | Yes | `config.lookupInt("ssh.port", 22)` |
| `long` / `Long` | `lookupLong` | Yes | `config.lookupLong("timeout.ms", 30000L)` |
| `boolean` / `Boolean` | `lookupBoolean` | Yes | `config.lookupBoolean("ssl.enabled", false)` |
| `double` / `Double` | `lookupDouble` | Yes | `config.lookupDouble("rate", 0.15)` |
| anything else | `lookup` | No | `config.lookup("custom.key")` |

**Default value parsing:** The `originalValue` string is parsed into the appropriate literal expression type:
- `int` values: `IntegerLiteralExpr` (non-digit characters stripped)
- `long` values: `LongLiteralExpr` (suffixed with `L`)
- `boolean` values: `BooleanLiteralExpr`
- `double` values: `DoubleLiteralExpr`
- Fallback: `StringLiteralExpr` if parsing fails

### 3.2 Parameter Replacement

For parameter targets, the lookup method is inferred from the **original getter method name**, not from type metadata (since property files have no type information):

| Original Getter | Replacement |
|-----------------|-------------|
| `getInt`, `getInteger` | `config.lookupInt()` |
| `getLong` | `config.lookupLong()` |
| `getBoolean` | `config.lookupBoolean()` |
| `getDouble`, `getFloat` | `config.lookupDouble()` |
| all others | `config.lookup()` |

Parameter replacements do **not** include a default value argument, since the original getter call typically did not have one.

---

## 4. Post-Replacement Injection

After the visitor completes, if at least one substitution was made (`anyTransformed == true`), the transformer injects supporting code:

### 4.1 Config Field

Added to the first top-level `ClassOrInterfaceDeclaration` (skipping inner classes):

```java
@Autowired
private SiteConfigurationService config;
```

The field is only added if no field named `config` already exists on the class.

### 4.2 Import Statements

Two imports are added (if not already present):

```java
import org.springframework.beans.factory.annotation.Autowired;
import com.boeing.constcatalog.backend.service.SiteConfigurationService;
```

---

## 5. Output File Strategy

Scanned projects are Docker-mounted as **read-only** (`:ro`), so the transformer cannot write back to the source files. Instead, all output is written to a writable `backups/` directory at the application root, preserving the original directory structure.

### 5.1 Path Computation

Given a source file path, the transformer strips the filesystem root and resolves under the backups directory:

```
Source:      /src/java/dubbo/dubbo-remoting/.../Constants.java
             ▲ root    ▲ relative path
             │         │
             stripped   preserved
             │
             ▼
Backup:      /app/backups/src/java/dubbo/dubbo-remoting/.../Constants.java.orig
Transformed: /app/backups/src/java/dubbo/dubbo-remoting/.../Constants.java
```

In code:
```java
Path absSource  = sourceFile.toAbsolutePath();
Path relPath    = absSource.getRoot().relativize(absSource);
Path outputPath = backupsDir.resolve(relPath);
Path backupOrig = Path.of(outputPath + ".orig");
```

### 5.2 What Gets Written

For every file processed by `transformFile()` (regardless of whether substitutions succeed):

| File | Contents | Always Created |
|------|----------|----------------|
| `<path>.orig` | Byte-for-byte copy of the original source | Yes |
| `<path>` | JavaParser-serialized AST with substitutions applied | Only if `anyTransformed` |

### 5.3 Dry-Run Mode

Dry-run (`dryRun=true`) uses a completely separate code path (`dryRun()`) that only reads and scans the AST. **No files are written** -- no backups, no transformed output. The results table shows what *would* be transformed.

### 5.4 Docker Volume Mount

The `backups/` directory is mounted as a writable bind-mount in `docker-compose.yml`:

```yaml
volumes:
  - ./backups:/app/backups
```

This makes the output accessible on the host at `./backups/` relative to the project root.

---

## 6. Comparison Viewer

The `/api/transform/compare` endpoint serves before/after content for the frontend's diff viewer.

**Resolution order:**

1. Look for the transformed file in `backups/` -- if found, read it and the `.orig` sibling
2. If no transformed file exists (dry-run or file had no substitutions), fall back to reading the original source file directly
3. If neither exists, return a 400 error

This allows the "View" button to work for both dry-run (shows the original) and real transforms (shows the diff).

---

## 7. Entry Status Classification

Each target processed by `transformFile()` produces a `TransformationEntry` with one of three statuses:

### TRANSFORMED

The target's usage was found in the AST and successfully replaced.

```
[TRANSFORMED] DB_HOST in DataService.java -- Replaced with config.lookup("db.host")
```

The entry includes `backupFilePath` pointing to the `.orig` file in the backups directory.

### SKIPPED

The file parsed successfully, but no matching usage was found. Common reasons:

- The constant is **declared** in this file but not **used** (only the declaration site exists)
- The constant name appears only in comments or string literals (not AST nodes)
- A parameter target's key doesn't match any `StringLiteralExpr` in recognized getter calls
- The getter method name isn't in the recognized set

```
[SKIPPED] DB_HOST in Constants.java -- No usages of constant 'DB_HOST' found in file
```

### FAILED

An error prevented processing. The two main causes:

| Cause | Example |
|-------|---------|
| **Parse failure** | File contains invalid Java syntax, JavaParser returns unsuccessful result |
| **IO error** | File doesn't exist, permission denied, disk full |

```
[FAILED] DB_HOST in Broken.java -- File could not be parsed
[FAILED] DB_HOST in Missing.java -- IO error: /src/.../Missing.java (No such file)
```

### Fan-Out Amplification

A single file failure produces one FAILED entry **per target** in that file. If a file has 50 targets and fails to parse, that's 50 FAILED entries from one root cause. The transform log groups failures by file to identify these amplification sources.

---

## 8. Target Deduplication

When multiple targets share the same `constantName`, the transformer uses `Collectors.toMap()` with merge function `(a, b) -> a`, keeping only the first target. This means:

- If two `ConstantTarget` records both have `constantName = "DB_HOST"`, only the first is used
- Constant targets and parameter targets are deduplicated independently (they go into separate maps)

---

## 9. Visitor Traversal Order

The `ModifierVisitor` traverses the AST depth-first. Key ordering details:

- **NameExpr and FieldAccessExpr** are visited as they are encountered in the tree
- **MethodCallExpr** explicitly calls `super.visit(n, arg)` first to recurse into child nodes before checking for parameter matches. This ensures nested calls are processed inside-out
- Replacement returns a new `MethodCallExpr` node, which the visitor substitutes into the parent

Since constant targets and parameter targets are in separate maps, there is no conflict if a name appears in both (the constant map is checked for `NameExpr`/`FieldAccessExpr`, the parameter map for `MethodCallExpr`).

---

## 10. Limitations and Edge Cases

| Scenario | Behavior |
|----------|----------|
| Constant used in annotation attribute (`@Cacheable(CACHE_KEY)`) | Replaced (annotations contain `NameExpr` nodes) |
| Constant used in `switch` case label | Replaced if it's a `NameExpr` |
| Constant used as array index | Replaced |
| Constant redefined in inner scope (local variable shadows it) | May incorrectly replace the local variable reference |
| Multi-file constant: defined in A, used in B | Works -- the target points to file B where the usage is |
| Record class syntax (`public record ...`) | Supported (JavaParser configured for Java 21) |
| Sealed class syntax | Supported |
| Text blocks | Supported |
| Pattern matching `instanceof` | Supported |
| File with only `package` declaration (no class) | Parses successfully, all targets SKIPPED |
| Empty file | Parses successfully, all targets SKIPPED |
| File with syntax errors | FAILED (parse failure) |
