# Docker Tutorial

A comprehensive guide to Docker, Docker Compose, and container management. Written for developers working with the Constants Catalog project, but applicable to any Docker-based development workflow.

---

## Table of Contents

1. [What Is Docker?](#1-what-is-docker)
2. [Core Concepts](#2-core-concepts)
3. [Docker Images](#3-docker-images)
4. [Docker Containers](#4-docker-containers)
5. [Docker Networks](#5-docker-networks)
6. [Docker Volumes](#6-docker-volumes)
7. [Dockerfile Deep Dive](#7-dockerfile-deep-dive)
8. [Docker Compose](#8-docker-compose)
9. [Docker System and Maintenance](#9-docker-system-and-maintenance)
10. [Docker Exec and Debugging](#10-docker-exec-and-debugging)
11. [Docker Logs](#11-docker-logs)
12. [Docker Build](#12-docker-build)
13. [Docker Hub and Registries](#13-docker-hub-and-registries)
14. [Quick Reference](#14-quick-reference)

---

## 1. What Is Docker?

Docker packages applications and their dependencies into isolated, portable units called **containers**. A container has everything the application needs to run: code, runtime, libraries, and system tools. It runs the same way on your laptop, your colleague's machine, and a production server.

### Why Docker?

**Without Docker:**
```
Developer A: "It works on my machine"
Developer B: "Not on mine — I have Java 17, you have 21"
Server admin: "Production has a different version of everything"
```

**With Docker:**
```
Everyone runs the same container image.
Same Java version, same libraries, same configuration.
If it works in the container, it works everywhere.
```

### Docker vs. Virtual Machines

| | Docker Container | Virtual Machine |
|---|---|---|
| Startup time | Seconds | Minutes |
| Size | MBs | GBs |
| Isolation | Process-level (shared kernel) | Full OS (own kernel) |
| Performance | Near-native | Hypervisor overhead |
| Resource usage | Lightweight | Heavy |

Containers share the host OS kernel. They isolate the filesystem, network, and process tree, but not the kernel itself. This makes them fast and lightweight.

---

## 2. Core Concepts

### Image

A read-only template for creating containers. Think of it as a class in OOP — you can create many instances (containers) from one image. Images are built from Dockerfiles and stored in registries.

### Container

A running instance of an image. It has its own filesystem, network interface, and process tree. When the main process exits, the container stops. Containers are ephemeral by default — data written inside a container is lost when it's removed (unless you use volumes).

### Dockerfile

A text file with instructions for building an image. Each instruction creates a layer. Layers are cached, so rebuilding only re-executes instructions whose inputs changed.

### Volume

Persistent storage that survives container restarts and removal. Used for database data, file uploads, backups — anything you don't want to lose.

### Network

A virtual network that connects containers. Containers on the same network can reach each other by service name. Containers on different networks are isolated.

### Registry

A server that stores and distributes images. Docker Hub is the default public registry. You can also run private registries.

### Relationship Diagram

```
┌─────────────┐     builds      ┌─────────────┐
│  Dockerfile │ ───────────────▶ │    Image    │
└─────────────┘                  └──────┬──────┘
                                        │ creates
                                        ▼
                                 ┌─────────────┐
                                 │  Container  │
                                 │  ┌───────┐  │
                                 │  │Process│  │
                                 │  └───────┘  │
                                 └──┬───────┬──┘
                                    │       │
                            ┌───────▼─┐  ┌──▼──────┐
                            │ Volume  │  │ Network │
                            └─────────┘  └─────────┘
```

---

## 3. Docker Images

An image is a stack of read-only filesystem layers. Each Dockerfile instruction adds a layer. When you run a container, Docker adds a thin writable layer on top.

### `docker image` Subcommands

#### `docker image ls` (alias: `docker images`)

List images on your machine.

```bash
$ docker image ls
REPOSITORY               TAG       IMAGE ID       SIZE
eclipse-temurin          21-jre    a1b2c3d4e5f6   280MB
mongo                    7         f6e5d4c3b2a1   750MB
neo4j                    5.15      1a2b3c4d5e6f   590MB
constants-backend        latest    9f8e7d6c5b4a   420MB
```

| Column | Meaning |
|---|---|
| REPOSITORY | Image name (may include registry prefix) |
| TAG | Version label (`latest`, `21-jre`, `7`, etc.) |
| IMAGE ID | Unique hash (first 12 chars of SHA256) |
| SIZE | Total disk space (shared layers aren't double-counted) |

**Useful flags:**
```bash
docker image ls -a              # Include intermediate layers
docker image ls --filter dangling=true   # Images with no tag (cleanup candidates)
docker image ls --format "{{.Repository}}:{{.Tag}} {{.Size}}"  # Custom format
```

#### `docker image pull`

Download an image from a registry.

```bash
docker image pull mongo:7           # Pull specific tag
docker image pull eclipse-temurin:21-jre
```

Docker Compose does this automatically when you run `docker compose up`.

#### `docker image build` (alias: `docker build`)

Build an image from a Dockerfile. See [Section 12: Docker Build](#12-docker-build) for details.

```bash
docker image build -t myapp:1.0 .    # Build from current directory
```

#### `docker image rm` (alias: `docker rmi`)

Remove one or more images.

```bash
docker image rm mongo:7              # Remove by name:tag
docker image rm a1b2c3d4e5f6         # Remove by ID
docker image rm $(docker image ls -q --filter dangling=true)  # Remove all dangling
```

An image can't be removed if a container (even stopped) is using it.

#### `docker image inspect`

Show detailed JSON metadata about an image.

```bash
docker image inspect eclipse-temurin:21-jre
docker image inspect --format '{{.Config.Env}}' eclipse-temurin:21-jre  # Just env vars
docker image inspect --format '{{.Architecture}}' mongo:7  # Architecture (amd64, arm64)
```

#### `docker image history`

Show the layers that make up an image and which Dockerfile instruction created each.

```bash
$ docker image history constants-backend:latest
IMAGE          CREATED        CREATED BY                                      SIZE
9f8e7d6c5b4a   2 hours ago   ENTRYPOINT ["/app/entrypoint.sh"]               0B
<missing>      2 hours ago   HEALTHCHECK ...                                 0B
<missing>      2 hours ago   EXPOSE 8080                                     0B
<missing>      2 hours ago   COPY const-catalog-backend/entrypoint.sh ...    256B
<missing>      2 hours ago   RUN mkdir -p /home/appuser && ...               1.2kB
<missing>      2 hours ago   RUN mkdir -p /app/backups ...                   0B
<missing>      2 hours ago   COPY --from=builder /app/.../target/*.jar ...   50MB
<missing>      2 hours ago   RUN apt-get update && apt-get install git ...   95MB
```

#### `docker image prune`

Remove unused images.

```bash
docker image prune          # Remove dangling images (untagged)
docker image prune -a       # Remove ALL images not used by a container
docker image prune --filter "until=24h"  # Remove images older than 24 hours
```

#### `docker image tag`

Create a new tag (alias) for an image.

```bash
docker image tag constants-backend:latest myregistry.com/constants-backend:v2.1
```

This doesn't copy the image — it adds a second name pointing to the same layers.

#### `docker image save` / `docker image load`

Export/import images as tar files. Useful for air-gapped machines.

```bash
docker image save constants-backend:latest > backend.tar    # Export
docker image load < backend.tar                              # Import on another machine
```

---

## 4. Docker Containers

A container is a running (or stopped) instance of an image. Each container has its own filesystem, network stack, and process tree.

### `docker container` Subcommands

#### `docker container run` (alias: `docker run`)

Create and start a container.

```bash
# Basic: run and attach to terminal
docker container run mongo:7

# Detached (background) with name and port mapping
docker container run -d --name my-mongo -p 27017:27017 mongo:7

# Interactive with shell
docker container run -it eclipse-temurin:21-jre /bin/bash

# With environment variables
docker container run -d -e NEO4J_AUTH=none neo4j:5.15

# With volume mount
docker container run -d -v ./data:/data/db mongo:7

# Remove container when it exits
docker container run --rm mongo:7 mongosh --eval "db.stats()"
```

**Key flags:**

| Flag | Meaning |
|---|---|
| `-d` | Detached (background) |
| `-it` | Interactive + TTY (terminal access) |
| `--name X` | Give the container a name |
| `-p 8080:80` | Map host port 8080 to container port 80 |
| `-e KEY=VALUE` | Set environment variable |
| `-v /host:/container` | Bind mount a directory |
| `--rm` | Auto-remove container when it exits |
| `--network X` | Connect to a specific network |
| `--restart unless-stopped` | Auto-restart on crash/reboot |

#### `docker container ls` (alias: `docker ps`)

List running containers.

```bash
docker container ls                 # Running containers
docker container ls -a              # All containers (including stopped)
docker container ls -q              # Only container IDs
docker container ls --filter name=backend   # Filter by name
docker container ls --format "{{.Names}}\t{{.Status}}"  # Custom format
```

#### `docker container stop`

Send SIGTERM to the main process, wait 10 seconds, then SIGKILL if still running.

```bash
docker container stop const-catalog-backend
docker container stop -t 30 const-catalog-backend   # Wait 30 seconds before SIGKILL
docker container stop $(docker container ls -q)      # Stop ALL running containers
```

#### `docker container start`

Start a stopped container (reuses the existing filesystem and configuration).

```bash
docker container start const-catalog-backend
```

#### `docker container restart`

Stop then start a container.

```bash
docker container restart const-catalog-backend
```

#### `docker container rm`

Remove a stopped container. Use `-f` to force-remove a running container.

```bash
docker container rm const-catalog-backend
docker container rm -f const-catalog-backend    # Force (stops first)
docker container rm $(docker container ls -aq)  # Remove ALL containers
```

#### `docker container inspect`

Show detailed JSON metadata about a container.

```bash
docker container inspect const-catalog-backend

# Useful format queries:
docker container inspect --format '{{.State.Status}}' const-catalog-backend
docker container inspect --format '{{.NetworkSettings.IPAddress}}' const-catalog-backend
docker container inspect --format '{{.Created}}' const-catalog-backend
docker container inspect --format '{{.State.Status}} {{.State.Health.Status}}' const-catalog-backend
```

#### `docker container exec` (alias: `docker exec`)

Run a command inside a running container. See [Section 10](#10-docker-exec-and-debugging).

```bash
docker container exec -it const-catalog-backend /bin/bash
docker container exec const-catalog-backend whoami
```

#### `docker container logs` (alias: `docker logs`)

See [Section 11](#11-docker-logs).

#### `docker container cp`

Copy files between host and container.

```bash
docker container cp const-catalog-backend:/app/app.jar ./local-copy.jar  # Container → host
docker container cp ./config.yml const-catalog-backend:/app/config.yml   # Host → container
```

#### `docker container stats`

Live resource usage (CPU, memory, network, disk I/O).

```bash
docker container stats                           # All containers
docker container stats const-catalog-backend     # Specific container
```

#### `docker container top`

Show processes running inside a container (like `ps` on the host but scoped to the container).

```bash
docker container top const-catalog-backend
```

#### `docker container port`

Show port mappings for a container.

```bash
$ docker container port const-catalog-backend
8080/tcp -> 0.0.0.0:9090
5005/tcp -> 0.0.0.0:5005
```

#### `docker container rename`

```bash
docker container rename old-name new-name
```

#### `docker container prune`

Remove all stopped containers.

```bash
docker container prune
docker container prune --filter "until=24h"   # Only containers stopped more than 24h ago
```

#### `docker container diff`

Show files changed in a container's writable layer (vs. the image).

```bash
$ docker container diff const-catalog-backend
C /app
A /app/backups
A /app/logs
C /tmp
```

`A` = added, `C` = changed, `D` = deleted.

---

## 5. Docker Networks

Networks control how containers communicate. By default, Docker creates a `bridge` network. Docker Compose creates a project-specific network.

### `docker network` Subcommands

#### `docker network ls`

List all networks.

```bash
$ docker network ls
NETWORK ID     NAME                        DRIVER    SCOPE
a1b2c3d4e5f6   bridge                      bridge    local
f6e5d4c3b2a1   host                        host      local
1a2b3c4d5e6f   none                        null      local
9f8e7d6c5b4a   constants_const-catalog-network  bridge    local
```

**Built-in networks:**

| Network | Purpose |
|---|---|
| `bridge` | Default network for standalone containers. Containers can reach each other by IP but not by name. |
| `host` | Container shares the host's network stack. No port mapping needed, but no isolation. |
| `none` | No networking. Container is completely isolated. |

#### `docker network create`

Create a custom network.

```bash
docker network create my-network
docker network create --driver bridge --subnet 172.20.0.0/16 my-custom-net
```

**Why create custom networks?**

1. **DNS resolution** — Containers on a custom bridge network can reach each other by name (e.g., `mongo:27017`). The default bridge network only supports IP addresses.
2. **Isolation** — Containers on different networks can't communicate. Your `const-catalog-network` isolates the catalog services from other containers on the host.
3. **Scoping** — Docker Compose creates one network per project. Services in different Compose files are isolated by default.

#### `docker network inspect`

Show details about a network, including which containers are connected.

```bash
$ docker network inspect constants_const-catalog-network
[{
    "Name": "constants_const-catalog-network",
    "Driver": "bridge",
    "Containers": {
        "abc123": { "Name": "const-catalog-backend", "IPv4Address": "172.18.0.4/16" },
        "def456": { "Name": "const-catalog-neo4j",   "IPv4Address": "172.18.0.2/16" },
        "ghi789": { "Name": "const-catalog-valkey",   "IPv4Address": "172.18.0.3/16" }
    }
}]
```

#### `docker network connect` / `docker network disconnect`

Add or remove a container from a network.

```bash
docker network connect my-network const-catalog-backend     # Add
docker network disconnect my-network const-catalog-backend  # Remove
```

A container can be on multiple networks simultaneously. Useful for connecting a debug container to an existing service network.

#### `docker network rm`

Remove a network (must have no connected containers).

```bash
docker network rm my-network
```

#### `docker network prune`

Remove all networks not used by any container.

```bash
docker network prune
```

### How Container DNS Works

On a custom bridge network, Docker runs an embedded DNS server at `127.0.0.11`. When `const-catalog-backend` connects to `neo4j:7687`, Docker's DNS resolves `neo4j` to the container's IP on that network (e.g., `172.18.0.2`).

```
backend container:
  neo4j:7687
    → DNS query to 127.0.0.11
    → resolves to 172.18.0.2
    → TCP connection to 172.18.0.2:7687
    → reaches the neo4j container
```

This is why `docker-compose.yml` uses `bolt://neo4j:7687` and `http://backend:8080` — service names are DNS names within the Docker network.

### Port Mapping vs. Container Networking

| Scenario | Access method |
|---|---|
| Container → Container (same network) | Use service name + container port: `neo4j:7687` |
| Host → Container | Use `localhost` + mapped port: `localhost:9090` |
| Container → Host | Use `host.docker.internal` (Docker Desktop) or host IP |

Port mapping (`-p 9090:8080`) only affects host access. Containers on the same network always use the container's internal port.

---

## 6. Docker Volumes

Volumes provide persistent storage that survives container restarts, removal, and rebuilds.

### `docker volume` Subcommands

#### `docker volume ls`

```bash
$ docker volume ls
DRIVER    VOLUME NAME
local     constants_neo4j_data
local     constants_neo4j_logs
local     constants_valkey_data
local     constants_mongo_data
```

#### `docker volume create`

```bash
docker volume create my-data
```

#### `docker volume inspect`

```bash
$ docker volume inspect constants_neo4j_data
[{
    "Name": "constants_neo4j_data",
    "Mountpoint": "/var/lib/docker/volumes/constants_neo4j_data/_data",
    "Driver": "local"
}]
```

The `Mountpoint` is where the data lives on the host filesystem.

#### `docker volume rm`

```bash
docker volume rm constants_neo4j_data
```

Can't remove a volume that's in use by a container.

#### `docker volume prune`

Remove all volumes not used by any container.

```bash
docker volume prune       # With confirmation prompt
docker volume prune -f    # Force (no prompt)
```

**Warning:** This permanently deletes data. Database contents, configuration — gone.

### Types of Mounts

| Type | Syntax | Data lives | Use case |
|---|---|---|---|
| Named volume | `my-volume:/data` | Docker-managed directory | Database data, persistent state |
| Bind mount | `./local:/container` | Your host directory | Source code, config files |
| tmpfs | `--tmpfs /tmp` | RAM only | Temporary data, secrets |

In `docker-compose.yml`:

```yaml
volumes:
  - neo4j_data:/data                 # Named volume
  - ./backups:/app/backups           # Bind mount
  - ${HOST_SRC_PATH:-/src}:/src      # Bind mount with env var
```

### Bind Mount Permissions

When you bind-mount a host directory, the container sees the host's file ownership. If the host directory is owned by `root` but the container runs as `appuser`, writes will fail. This is why our `entrypoint.sh` runs `chown` before dropping to `appuser`.

---

## 7. Dockerfile Deep Dive

A Dockerfile is a recipe for building an image. Each instruction creates a cached layer.

### Common Instructions

| Instruction | Purpose | Example |
|---|---|---|
| `FROM` | Base image | `FROM eclipse-temurin:21-jre` |
| `WORKDIR` | Set working directory | `WORKDIR /app` |
| `COPY` | Copy files from host | `COPY target/*.jar app.jar` |
| `ADD` | Like COPY but can extract tars and fetch URLs | `ADD config.tar.gz /etc/` |
| `RUN` | Execute command during build | `RUN apt-get install -y git` |
| `ENV` | Set environment variable | `ENV JAVA_HOME=/opt/java` |
| `EXPOSE` | Document which ports the container listens on | `EXPOSE 8080` |
| `USER` | Switch to a different user | `USER appuser` |
| `ENTRYPOINT` | The command that always runs | `ENTRYPOINT ["java", "-jar", "app.jar"]` |
| `CMD` | Default arguments (overridable) | `CMD ["--server.port=8080"]` |
| `HEALTHCHECK` | Define how to check container health | `HEALTHCHECK CMD curl -f http://localhost:8080/health` |
| `ARG` | Build-time variable | `ARG VERSION=1.0` |
| `LABEL` | Metadata | `LABEL maintainer="team@example.com"` |

### Multi-Stage Builds

Use multiple `FROM` instructions to separate build tools from the runtime image:

```dockerfile
# Stage 1: Build (has Maven, JDK — large)
FROM maven:3.9-eclipse-temurin-21 AS builder
WORKDIR /app
COPY pom.xml .
RUN mvn dependency:go-offline -B
COPY src ./src
RUN mvn package -DskipTests -B

# Stage 2: Runtime (has only JRE — small)
FROM eclipse-temurin:21-jre
COPY --from=builder /app/target/*.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]
```

The final image only contains the JRE and the JAR. Maven, the JDK, source code, and all build artifacts are discarded. This reduces the image from ~800MB to ~300MB.

### Layer Caching

Docker caches each layer. If an instruction's inputs haven't changed, the cached layer is reused:

```dockerfile
COPY pom.xml .                    # Layer 1: changes rarely
RUN mvn dependency:go-offline     # Layer 2: only reruns if pom.xml changed
COPY src ./src                    # Layer 3: changes often
RUN mvn package                   # Layer 4: reruns whenever source changes
```

**Order matters:** Put instructions that change infrequently at the top.

### BuildKit Cache Mounts

```dockerfile
RUN --mount=type=cache,target=/root/.m2 \
    mvn package -B
```

This mounts a persistent cache directory that survives between builds. Maven's `.m2` repository is preserved, so dependencies aren't re-downloaded every time. The cache is NOT included in the image — it only exists during the `RUN` instruction.

### ENTRYPOINT vs. CMD

```dockerfile
ENTRYPOINT ["java", "-jar", "app.jar"]  # Always runs
CMD ["--server.port=8080"]               # Default args, overridable
```

Combined: `java -jar app.jar --server.port=8080`

Override CMD: `docker run myapp --server.port=9090` → `java -jar app.jar --server.port=9090`

Override ENTRYPOINT: `docker run --entrypoint /bin/bash myapp` → `/bin/bash`

### Shell Form vs. Exec Form

```dockerfile
# Exec form (preferred) — runs directly, gets signals properly
ENTRYPOINT ["java", "-jar", "app.jar"]

# Shell form — runs via /bin/sh -c, PID 1 is shell not your app
ENTRYPOINT java -jar app.jar
```

Always use exec form (`["..."]`) for ENTRYPOINT and CMD. Shell form wraps your command in `/bin/sh -c`, which means the shell is PID 1 and your application doesn't receive signals (SIGTERM for graceful shutdown).

---

## 8. Docker Compose

Docker Compose manages multi-container applications with a single YAML file.

### Why Docker Compose?

Without Compose, starting the Constants Catalog requires:

```bash
docker network create const-catalog-network
docker run -d --name neo4j --network const-catalog-network -p 7474:7474 -p 7687:7687 -e NEO4J_AUTH=none neo4j:5.15
docker run -d --name valkey --network const-catalog-network -p 6379:6379 valkey/valkey:8-alpine
docker run -d --name backend --network const-catalog-network -p 9090:8080 -e NEO4J_URI=bolt://neo4j:7687 constants-backend
docker run -d --name frontend --network const-catalog-network -p 3001:80 constants-frontend
```

With Compose:

```bash
docker compose up -d
```

### `docker compose` Subcommands

#### `docker compose up`

Create and start all services.

```bash
docker compose up                    # Foreground (see all logs)
docker compose up -d                 # Detached (background)
docker compose up --build            # Rebuild images before starting
docker compose up -d --build backend # Rebuild and restart one service
docker compose up --profile mongodb  # Include optional profile
docker compose --env-file .env.mint up -d  # Use specific env file
```

**What `up` does:**
1. Reads `docker-compose.yml`
2. Creates the network if it doesn't exist
3. Creates named volumes if they don't exist
4. Pulls images that aren't built locally
5. Builds images that have a `build:` directive
6. Creates and starts containers in dependency order
7. Waits for health checks if `depends_on: condition: service_healthy`

#### `docker compose down`

Stop and remove containers, networks. Optionally remove volumes.

```bash
docker compose down                  # Stop containers, remove network
docker compose down -v               # Also remove named volumes (DATA LOSS)
docker compose down --rmi all        # Also remove images
docker compose down backend          # Stop just one service
```

#### `docker compose ps`

List containers managed by this Compose project.

```bash
$ docker compose ps
NAME                      STATUS          PORTS
const-catalog-backend     Up (healthy)    0.0.0.0:9090->8080/tcp, 0.0.0.0:5005->5005/tcp
const-catalog-frontend    Up              0.0.0.0:3001->80/tcp
const-catalog-neo4j       Up (healthy)    0.0.0.0:7474->7474/tcp, 0.0.0.0:7687->7687/tcp
const-catalog-valkey      Up (healthy)    0.0.0.0:6379->6379/tcp
```

#### `docker compose logs`

View logs from one or all services.

```bash
docker compose logs                  # All services
docker compose logs backend          # One service
docker compose logs -f backend       # Follow (tail -f)
docker compose logs --tail 50        # Last 50 lines
docker compose logs --since 5m       # Last 5 minutes
```

#### `docker compose build`

Build images without starting containers.

```bash
docker compose build                 # All services with build: directive
docker compose build backend         # One service
docker compose build --no-cache      # Ignore layer cache
```

#### `docker compose exec`

Run a command in a running service container.

```bash
docker compose exec backend /bin/bash
docker compose exec neo4j cypher-shell
docker compose exec valkey valkey-cli PING
```

#### `docker compose run`

Create a new container and run a one-off command. Unlike `exec`, this creates a new container (doesn't run in the existing one).

```bash
docker compose run --rm valkey-cli                    # Interactive CLI
docker compose run --rm backend java -version         # Check Java version
```

#### `docker compose pull`

Pull the latest images for all services.

```bash
docker compose pull
docker compose pull neo4j valkey     # Specific services
```

#### `docker compose restart`

Restart containers without recreating them.

```bash
docker compose restart               # All services
docker compose restart backend       # One service
```

#### `docker compose stop` / `docker compose start`

```bash
docker compose stop backend          # Stop without removing
docker compose start backend         # Start a stopped service
```

#### `docker compose config`

Validate and display the resolved Compose file (with env vars expanded).

```bash
docker compose config                # Show resolved YAML
docker compose --env-file .env.mint config  # With specific env file
```

#### `docker compose top`

Show running processes in all containers.

```bash
docker compose top
```

### Compose File Structure

```yaml
services:
  backend:
    build:                           # How to build the image
      context: .
      dockerfile: const-catalog-backend/Dockerfile
    container_name: const-catalog-backend
    ports:
      - "9090:8080"                  # host:container
      - "5005:5005"
    environment:                     # Environment variables
      - NEO4J_URI=bolt://neo4j:7687
      - VALKEY_HOST=valkey
    depends_on:                      # Startup order
      neo4j:
        condition: service_healthy
      valkey:
        condition: service_healthy
    volumes:
      - ./backups:/app/backups       # Bind mount
      - ${HOST_SRC_PATH:-/src}:/src  # Env var with default
    networks:
      - const-catalog-network

  neo4j:
    image: neo4j:5.15-community     # Pre-built image (no build:)
    ports:
      - "7474:7474"
      - "7687:7687"
    volumes:
      - neo4j_data:/data             # Named volume
    healthcheck:
      test: ["CMD", "wget", "--spider", "http://localhost:7474"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 30s
    networks:
      - const-catalog-network

  mongo:
    image: mongo:7
    profiles:                        # Only starts with --profile mongodb
      - mongodb
    ports:
      - "27017:27017"
    volumes:
      - mongo_data:/data/db

networks:
  const-catalog-network:
    driver: bridge

volumes:
  neo4j_data:
  mongo_data:
```

### Profiles

Profiles let you define optional services that only start when requested:

```yaml
services:
  mongo:
    image: mongo:7
    profiles:
      - mongodb
```

```bash
docker compose up -d                       # mongo does NOT start
docker compose --profile mongodb up -d     # mongo starts
```

### depends_on and Health Checks

```yaml
backend:
  depends_on:
    neo4j:
      condition: service_healthy    # Wait for neo4j to pass health check
    valkey:
      condition: service_healthy
```

Without `condition: service_healthy`, Docker only waits for the container to start — not for the service inside to be ready. A database container starts in seconds but may take 30+ seconds to accept connections.

### Environment Variables

Three ways to set them:

```yaml
# 1. Inline
environment:
  - NEO4J_URI=bolt://neo4j:7687

# 2. From .env file (automatic — Docker Compose reads .env by default)
# .env file: NEO4J_URI=bolt://neo4j:7687

# 3. From specific env file
# Command: docker compose --env-file .env.mint up -d
```

Variable substitution in the Compose file:

```yaml
volumes:
  - ${HOST_SRC_PATH:-/src}:/src    # Use HOST_SRC_PATH, default to /src
```

---

## 9. Docker System and Maintenance

#### `docker system df`

Show disk usage by images, containers, volumes, and build cache.

```bash
$ docker system df
TYPE            TOTAL     ACTIVE    SIZE      RECLAIMABLE
Images          15        5         4.2GB     2.1GB (50%)
Containers      5         5         120MB     0B (0%)
Local Volumes   4         4         850MB     0B (0%)
Build Cache     25        0         1.5GB     1.5GB (100%)
```

#### `docker system prune`

One-command cleanup.

```bash
docker system prune          # Remove stopped containers, unused networks, dangling images
docker system prune -a       # Also remove ALL unused images (not just dangling)
docker system prune --volumes  # Also remove unused volumes (DATA LOSS)
```

#### `docker system info` (alias: `docker info`)

Show Docker engine configuration, storage driver, OS, kernel version, etc.

```bash
docker system info
```

---

## 10. Docker Exec and Debugging

`docker exec` runs a command inside a running container.

```bash
# Interactive shell
docker exec -it const-catalog-backend /bin/bash
docker exec -it const-catalog-backend /bin/sh    # If bash isn't available

# Run a single command
docker exec const-catalog-backend whoami
docker exec const-catalog-backend cat /etc/os-release
docker exec const-catalog-backend ls -la /app/

# Check Java version
docker exec const-catalog-backend java -version 2>&1

# Query Neo4j
docker exec const-catalog-neo4j cypher-shell "MATCH (n) RETURN count(n)"

# Ping ValKey
docker exec const-catalog-valkey valkey-cli PING

# MongoDB shell
docker exec -it const-catalog-mongo mongosh
```

**Flags:**

| Flag | Purpose |
|---|---|
| `-it` | Interactive terminal (for shells) |
| `-u root` | Run as root (override USER directive) |
| `-e KEY=VALUE` | Set environment variable for this command |
| `-w /path` | Set working directory |

**Debug a permission issue:**

```bash
docker exec const-catalog-backend stat -c '%U:%G %a' /app/backups
docker exec -u root const-catalog-backend chown appuser:appgroup /app/backups
```

---

## 11. Docker Logs

`docker logs` shows stdout/stderr from a container's main process.

```bash
docker logs const-catalog-backend              # All logs
docker logs const-catalog-backend --tail 20    # Last 20 lines
docker logs const-catalog-backend -f           # Follow (live tail)
docker logs const-catalog-backend --since 5m   # Last 5 minutes
docker logs const-catalog-backend --until 2h   # Up to 2 hours ago
docker logs const-catalog-backend -t           # Include timestamps
```

**Searching logs:**

```bash
docker logs const-catalog-backend 2>&1 | grep "ERROR"
docker logs const-catalog-backend 2>&1 | grep -i "scan"
docker logs const-catalog-backend 2>&1 | tail -100
```

Note: `2>&1` redirects stderr to stdout because some applications log to stderr.

---

## 12. Docker Build

#### `docker build` (alias: `docker image build`)

```bash
# Basic build
docker build -t myapp:1.0 .

# Specify Dockerfile
docker build -t myapp:1.0 -f path/to/Dockerfile .

# Build with build arguments
docker build --build-arg VERSION=2.1 -t myapp:2.1 .

# No cache (rebuild from scratch)
docker build --no-cache -t myapp:1.0 .

# Multi-platform build
docker buildx build --platform linux/amd64,linux/arm64 -t myapp:1.0 .
```

**Build context:** The `.` at the end is the build context — the directory Docker sends to the daemon. `COPY` instructions are relative to this directory. Use `.dockerignore` to exclude files (like `node_modules`, `.git`, `target`).

### `.dockerignore`

```
.git
node_modules
target
*.log
.env
backups
```

This prevents Docker from sending unnecessary files to the build daemon, speeding up the build.

---

## 13. Docker Hub and Registries

#### `docker login` / `docker logout`

```bash
docker login                          # Docker Hub
docker login myregistry.example.com   # Private registry
docker logout
```

#### `docker push`

Upload an image to a registry.

```bash
docker tag myapp:1.0 username/myapp:1.0
docker push username/myapp:1.0
```

#### `docker search`

Search Docker Hub from the command line.

```bash
docker search mongo
docker search --filter is-official=true neo4j
```

---

## 14. Quick Reference

### Most-Used Commands

| Task | Command |
|---|---|
| Start all services | `docker compose up -d` |
| Start with rebuild | `docker compose up -d --build` |
| Stop all services | `docker compose down` |
| View logs | `docker compose logs -f backend` |
| Shell into container | `docker exec -it const-catalog-backend /bin/bash` |
| Check status | `docker compose ps` |
| Rebuild one service | `docker compose up -d --build backend` |
| View resource usage | `docker stats` |
| Clean up everything | `docker system prune -a` |

### When Do I Need `--build`?

| Changed | Need `--build`? |
|---|---|
| Dockerfile | Yes |
| Source code (Java, TypeScript) | Yes |
| pom.xml / package.json | Yes |
| entrypoint.sh, nginx.conf | Yes |
| docker-compose.yml | No |
| .env files | No |
| application.yml (in src/) | Yes (compiled into JAR) |

### Port Mapping Cheat Sheet (This Project)

| Service | Container Port | Host Port | Access |
|---|---|---|---|
| Backend | 8080 | 9090 | `localhost:9090` |
| Backend Debug | 5005 | 5005 | `localhost:5005` |
| Frontend (Docker) | 80 | 3001 | `localhost:3001` |
| Frontend (dev) | 3000 | 3000 | `localhost:3000` |
| Neo4j Browser | 7474 | 7474 | `localhost:7474` |
| Neo4j Bolt | 7687 | 7687 | `localhost:7687` |
| ValKey | 6379 | 6379 | `localhost:6379` |
| MongoDB | 27017 | 27017 | `localhost:27017` |

### Docker Compose with Env File

```bash
docker compose --env-file .env.mint up -d
docker compose --env-file .env.mint --profile mongodb up -d
docker compose --env-file .env.mint up -d --build backend
docker compose --env-file .env.mint down
docker compose --env-file .env.mint logs -f backend
```

### Cleanup Commands

```bash
docker container prune       # Remove stopped containers
docker image prune -a        # Remove unused images
docker volume prune          # Remove unused volumes (DATA LOSS)
docker network prune         # Remove unused networks
docker system prune -a       # All of the above
docker builder prune         # Remove build cache
```
