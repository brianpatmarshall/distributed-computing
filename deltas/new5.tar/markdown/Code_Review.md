# Constants Catalog — Code Review

> **Project:** Constants Catalog (const-catalog)
> **Language / Runtime:** Java 21, React 18 / TypeScript
> **Frameworks:** Spring Boot 3.4.1, JavaParser 3.28, Neo4j 5.x, ValKey 8.x
> **Review Date:** March 2026

---

## Executive Summary

The Constants Catalog is a multi-module Java application that discovers hardcoded constants and configuration parameters in Java projects, stores them in a Neo4j graph database, and provides tools to query, visualize, export, and transform them into externalized configuration lookups. It comprises four Maven modules (core, backend, CLI) plus a React/TypeScript frontend, orchestrated via Docker Compose.

```mermaid
graph TB
    subgraph "User Interfaces"
        FE["React Frontend<br/>(Port 3001 / nginx)"]
        CLI["CLI Tool<br/>(Fat JAR)"]
    end

    subgraph "Backend (Spring Boot — Port 8080)"
        API["REST Controllers"]
        SVC["Service Layer"]
        REPO["Neo4j Repositories"]
        CACHE["Two-Tier Cache<br/>Caffeine L1 + ValKey L2"]
    end

    subgraph "Core Library (Pure Java)"
        PARSER["JavaFileParser<br/>PropertyFileParser"]
        SCANNER["ProjectScanner"]
        XFORM["ConfigLookupTransformer<br/>JavaCodeTransformer"]
        EXPORT["CsvExporter"]
    end

    subgraph "Data Stores"
        NEO["Neo4j 5.x<br/>(Graph DB)"]
        VK["ValKey 8.x<br/>(Redis-compatible)"]
    end

    subgraph "Source Projects"
        SRC["/src, /esrc, /csrc<br/>Bind-mounted repos"]
    end

    FE -->|"HTTP / SSE"| API
    CLI --> SCANNER
    CLI --> EXPORT
    API --> SVC
    SVC --> REPO
    SVC --> CACHE
    SVC --> SCANNER
    SVC --> XFORM
    REPO --> NEO
    CACHE --> VK
    SCANNER --> PARSER
    SCANNER --> SRC
    XFORM --> PARSER
    EXPORT -.->|"CSV files"| NEO
```

### Key Flows

| Flow | Description |
|------|-------------|
| **Scan** | Parse Java and property files, populate Neo4j graph with Project, File, Constant, and Parameter nodes plus DEFINED_IN / USED_IN / CONTAINS relationships |
| **Query** | Execute pre-canned or ad-hoc Cypher queries against the graph |
| **Transform** | Replace hardcoded constants and parameter getters with `config.lookupType()` calls using JavaParser AST rewriting |
| **Export** | Export scanned configuration values to ValKey with two-tier cache-aside (Caffeine L1 + ValKey L2) and pub/sub invalidation |

---

## Module Dependency Map

The project is built as a Maven multi-module reactor. The frontend is outside the Maven build (npm/Vite).

```mermaid
graph LR
    PARENT["const-catalog-parent<br/>(Root POM)"]

    CORE["const-catalog-core<br/>Pure Java library<br/>No Spring"]
    BACKEND["const-catalog-backend<br/>Spring Boot 3.4.1"]
    CLIM["const-catalog-cli<br/>Fat JAR (Shade)"]
    FRONT["const-catalog-frontend<br/>React 18 + Vite<br/>(npm, not Maven)"]

    PARENT --> CORE
    PARENT --> BACKEND
    PARENT --> CLIM

    BACKEND -->|"compile"| CORE
    CLIM -->|"compile"| CORE
    FRONT -->|"HTTP at runtime"| BACKEND

    style CORE fill:#2d4a22,stroke:#4a7a33,color:#fff
    style BACKEND fill:#1a3a5c,stroke:#2a5a8c,color:#fff
    style CLIM fill:#4a3a22,stroke:#7a5a33,color:#fff
    style FRONT fill:#3a1a4c,stroke:#5a2a7c,color:#fff
```

| Module | Packaging | Key Dependencies |
|--------|-----------|-----------------|
| **const-catalog-core** | jar | JavaParser 3.28, SnakeYAML 2.2, Jackson 2.17, Lombok |
| **const-catalog-backend** | jar (Spring Boot repackage) | Core module, Spring Boot 3.4.1, Spring Data Neo4j, Lettuce 6.3, Caffeine 3.1, SpringDoc OpenAPI 2.3 |
| **const-catalog-cli** | fat jar (Shade) | Core module, Logback |
| **const-catalog-frontend** | static assets (Vite build) | React 18, React Router 6, TanStack Query 5, Axios, Tailwind CSS 3.4, Lucide React |

---

## Chapter 1 — const-catalog-core

> Pure Java library with zero Spring dependencies. Contains all parsing, scanning, transformation, and CSV export logic. Reused by both the backend and CLI modules.

### 1.1 Domain Model

All domain objects are **Java records** — immutable, with auto-generated `equals` / `hashCode` / `toString`.

```mermaid
classDiagram
    class Constant {
        <<record>>
        +String name
        +String type
        +String value
        +String fileName
        +String className
        +int lineNumber
        +String accessModifier
        +boolean isEnum
        +String enumClassName
        +toCsvLine() String
        +csvHeader()$ String
    }

    class Parameter {
        <<record>>
        +String name
        +String value
        +String definitionFile
        +int lineNumber
        +toCsvLine() String
        +csvHeader()$ String
    }

    class ConstantUsage {
        <<record>>
        +String constantName
        +String definingClassName
        +String usedInFile
        +String usedInClass
        +int lineNumber
        +String context
    }

    class ParameterUsage {
        <<record>>
        +String parameterName
        +String usedInFile
        +String usedInClass
        +int lineNumber
        +String context
    }

    class ConstantTarget {
        <<record>>
        +String constantName
        +String propertyKey
        +String originalValue
        +String originalType
        +String className
        +int lineNumber
        +SourceKind sourceKind
        +derivePropertyKey() String
        +deriveCamelCaseName() String
    }

    class SourceKind {
        <<enumeration>>
        CONSTANT
        PARAMETER
    }

    class TransformationEntry {
        <<record>>
        +String filePath
        +String className
        +String constantName
        +String propertyKey
        +String originalValue
        +String originalType
        +int lineNumber
        +Status status
        +String message
        +SourceKind sourceKind
        +String backupFilePath
        +transformed()$ TransformationEntry
        +skipped()$ TransformationEntry
        +failed()$ TransformationEntry
    }

    class Status {
        <<enumeration>>
        TRANSFORMED
        SKIPPED
        FAILED
    }

    class TransformationResult {
        <<record>>
        +String projectPath
        +LocalDateTime transformedAt
        +List~TransformationEntry~ entries
        +totalTransformed() int
        +totalSkipped() int
        +totalFailed() int
        +groupedByStatus() Map
    }

    ConstantTarget --> SourceKind
    TransformationEntry --> Status
    TransformationEntry --> SourceKind
    TransformationResult --> TransformationEntry
```

**Design notes:**

- `Constant` catalogs **all** `static final` fields regardless of access modifier (public, protected, private, package-private). This enables tracking of internal constants for refactoring.
- `ConstantTarget` is the unit of work for transformations — it carries `derivePropertyKey()` to convert `SCREAMING_SNAKE_CASE` to `dot.notation` (e.g. `DB_HOST` → `db.host`).
- `TransformationEntry` uses static factory methods (`transformed()`, `skipped()`, `failed()`) instead of constructors, making call sites self-documenting.

### 1.2 JavaFileParser

The AST extraction engine, built on JavaParser 3.28 using the **Visitor pattern**.

**Parser configuration:** `LanguageLevel.JAVA_21` with `DoNotConsiderAnnotationsAsNodeStartForCodeAttribution`.

**Key AST node types used:**

| AST Node | Purpose |
|----------|---------|
| `CompilationUnit` | Root of parsed file |
| `ClassOrInterfaceDeclaration` | Class/interface traversal with nesting tracking |
| `EnumDeclaration` | Enum type detection |
| `FieldDeclaration` | `static final` field discovery |
| `VariableDeclarator` | Individual variable bindings (handles `int A = 1, B = 2;`) |
| `Modifier` | STATIC / FINAL / access modifier checks |
| `ImportDeclaration` | Static import tracking (specific and wildcard) |
| `FieldAccessExpr` | Qualified constant access (`AppConfig.DB_HOST`) |
| `NameExpr` | Unqualified name references via static imports |
| `MethodCallExpr` | Property getter calls (`getProperty`, `getString`, etc.) |
| `AnnotationExpr` | `@Value("${...}")` annotation detection |

**Three extraction methods:**

| Method | Pattern | Extracts |
|--------|---------|----------|
| `parseConstants(Path)` | `VoidVisitorAdapter` | All `static final` fields: name, type, value, line, class, modifier |
| `parseParameterUsages(Path, Set<String>)` | `VoidVisitorAdapter` | `@Value` annotations + property getter calls matching known parameter names |
| `parseConstantUsages(Path, Map<String, Set<String>>)` | `VoidVisitorAdapter` | Cross-class constant references via `FieldAccessExpr` and static-imported `NameExpr` |

**Static import resolution** — The parser maintains two collections:
1. Specific imports: `import static com.example.Config.DB_HOST;` → resolves `DB_HOST` to `Config`
2. Wildcard imports: `import static com.example.Config.*;` → resolves any matching name to `Config`

### 1.3 PropertyFileParser

Dispatcher-pattern parser supporting five configuration file formats:

| Format | Method | Library / Approach |
|--------|--------|--------------------|
| `.properties` | `parsePropertiesFile()` | Line-by-line with continuation (`\`) support |
| `.yml` / `.yaml` | `parseYamlFile()` | SnakeYAML — recursive flattening to dot-notation |
| `.json` | `parseJsonFile()` | Jackson `ObjectMapper.readTree()` — recursive flattening |
| `.xml` | `parseXmlConfigFile()` | Regex-based `<property>`, `<entry>`, `<param>` extraction |
| `.env` | `parseEnvFile()` | Shell-style `KEY=VALUE`, strips surrounding quotes |

**YAML flattening example:**
```yaml
database:
  host: localhost    # → database.host=localhost
  port: 5432         # → database.port=5432
```

### 1.4 ProjectScanner — Orchestrator

Coordinates the full scan workflow using `Files.walkFileTree()`.

```mermaid
sequenceDiagram
    participant Client
    participant Scanner as ProjectScanner
    participant FV as FileVisitor
    participant PFP as PropertyFileParser
    participant JFP as JavaFileParser

    Client->>Scanner: scan(projectPath)
    Scanner->>FV: walkFileTree(projectPath)
    FV-->>Scanner: javaFiles[], propertyFiles[]
    Note over FV: Skips: target, build, .git,<br/>node_modules, .idea, etc.

    loop Each property file
        Scanner->>PFP: parseParameters(file)
        PFP-->>Scanner: List~Parameter~
    end
    Note over Scanner: Build knownParameterNames set

    loop Each Java file
        Scanner->>JFP: parseConstants(file)
        JFP-->>Scanner: List~Constant~
        Scanner->>JFP: parseParameterUsages(file, knownParams)
        JFP-->>Scanner: List~ParameterUsage~
        Scanner->>JFP: extractFqn(file)
        JFP-->>Scanner: fullyQualifiedName
    end

    Note over Scanner: Build constantsByName map

    loop Each Java file
        Scanner->>JFP: parseConstantUsages(file, constantsByName)
        JFP-->>Scanner: List~ConstantUsage~
    end

    Scanner-->>Client: ScanResult
```

**Excluded directories:** `target`, `build`, `out`, `.git`, `.idea`, `.gradle`, `node_modules`, `.mvn`, `bin`, `.settings`

**ScanResult** aggregates: constants, parameters, parameterUsages, constantUsages, javaFileFqns map, file counts, and `FileTypeStats` breakdown.

**Progress listener:** Optional `ScanProgressListener` functional interface enables real-time SSE progress events in the backend.

### 1.5 Transformers

Two complementary transformation engines, each targeting a different aspect of constant externalization:

#### ConfigLookupTransformer — Usage Replacement

Replaces **usages** of constants and parameter getters with typed `config.lookupType()` calls using the **ModifierVisitor** pattern (a visitor that can modify the AST in-place).

**Type-aware lookup method selection:**

| Java Type | Lookup Method | Default Value |
|-----------|--------------|---------------|
| `String` | `config.lookup(key)` | — |
| `int` / `Integer` | `config.lookupInt(key, default)` | original value |
| `long` / `Long` | `config.lookupLong(key, default)` | original value |
| `boolean` / `Boolean` | `config.lookupBoolean(key, default)` | original value |
| `double` / `Double` | `config.lookupDouble(key, default)` | original value |

**Transformation example:**
```java
// Before
String host = AppConfig.DB_HOST;
int port = DB_PORT;  // via static import
String url = props.getProperty("jdbc.url");

// After
String host = config.lookup("db.host");
int port = config.lookupInt("db.port", 5432);
String url = config.lookup("jdbc.url");
```

**Auto-injection:** When any transformations occur in a file, the transformer automatically adds:
```java
@Autowired
private SiteConfigurationService config;
```
Plus the required imports for `Autowired` and `SiteConfigurationService`.

**Safety features:**
- `isDeclaration()` check prevents replacing variable declarations themselves
- Backup files written as `.orig` in a backups directory preserving source tree structure
- Dry-run mode scans for usages without modifying files

#### JavaCodeTransformer — Definition Replacement

Replaces constant **definitions** with Spring `@Value` annotations.

**Example:**
```java
// Before
private static final String DB_HOST = "localhost";

// After
@Value("${db.host}")
private String dbHost;
```

**Skip conditions** (fields that cannot be converted to `@Value`):
- Non-injectable types: `Logger`, `Pattern`, numeric primitives (`byte`, `short`, `char`, `float`)
- Already annotated with `@Value`
- Complex initializers containing `new `, `Arrays.`, `List.of()`, `Map.of()`, `Pattern.`

**Field location tolerance:** ±3 lines from the recorded line number, accounting for file edits since the last scan.

### 1.6 CsvExporter

Exports `ScanResult` to seven CSV files formatted for Neo4j `LOAD CSV` import, plus a Cypher import script.

**Generated files:**

| File | Type | ID Format |
|------|------|-----------|
| `constants.csv` | Node (:Constant) | `const_<class>_<name>` |
| `parameters.csv` | Node (:Parameter) | `param_<name>` |
| `files.csv` | Node (:File) | `file_<path>` |
| `constant_in_file.csv` | Rel (DEFINED_IN) | constant → file |
| `constant_used_in.csv` | Rel (USED_IN) | constant → file |
| `parameter_defined_in.csv` | Rel (DEFINED_IN) | parameter → file |
| `parameter_used_in.csv` | Rel (USED_IN) | parameter → file |
| `import-neo4j.cypher` | Script | — |

CSV escaping handles quotes (doubled), commas, and newlines. IDs are sanitized to alphanumeric + underscore.

---

## Chapter 2 — const-catalog-backend

> Spring Boot 3.4.1 REST API with Neo4j graph persistence, ValKey distributed caching, and real-time SSE progress streaming.

### 2.1 Neo4j Entity Model — Annotations Deep Dive

Spring Data Neo4j 7.x provides a rich set of annotations for mapping Java objects to the Neo4j graph. This section explains each annotation as used in the codebase.

#### @Node

Marks a class as a Neo4j node entity. The `value` parameter specifies the node label in the graph.

```java
@Node("Project")
public class ProjectNode { ... }

@Node("File")
public class FileNode { ... }

@Node("Constant")
public class ConstantNode { ... }

@Node("Parameter")
public class ParameterNode { ... }
```

A single Java class maps to one node label. All instances of `ProjectNode` become `:Project` nodes in Neo4j.

#### @Id

Marks a field as the unique identifier for the node. Spring Data Neo4j uses this field to determine equality and for MERGE operations.

```java
@Id
private String id;
```

Unlike JPA, Spring Data Neo4j does **not** map `@Id` to Neo4j's internal node ID by default — it creates a property on the node.

#### @GeneratedValue

Specifies the strategy for generating ID values. The project uses `UUIDStringGenerator`:

```java
@Id @GeneratedValue(UUIDStringGenerator.class)
private String id;
```

`UUIDStringGenerator` produces UUID strings (e.g. `"a1b2c3d4-..."`). This is preferred over Neo4j internal IDs because:
- Internal IDs can be recycled after node deletion
- UUIDs are stable across database restarts and exports
- UUIDs can be used in URLs and external references

#### @Relationship

Defines a relationship between two node entities. Parameters:

| Parameter | Description |
|-----------|-------------|
| `type` | Relationship type label in Neo4j (e.g. `"CONTAINS"`, `"DEFINED_IN"`, `"USED_IN"`) |
| `direction` | `OUTGOING` (default), `INCOMING`, or `UNDIRECTED` |

**Usage in ProjectNode:**
```java
@Relationship(type = "CONTAINS", direction = Relationship.Direction.OUTGOING)
private Set<FileNode> files = new HashSet<>();
```
Creates: `(:Project)-[:CONTAINS]->(:File)`

**Usage in ConstantNode:**
```java
@Relationship(type = "DEFINED_IN", direction = Relationship.Direction.OUTGOING)
private FileNode definedIn;

@Relationship(type = "USED_IN", direction = Relationship.Direction.OUTGOING)
private Set<UsageRelationship> usages = new HashSet<>();
```
Creates: `(:Constant)-[:DEFINED_IN]->(:File)` and `(:Constant)-[:USED_IN]->(:File)`

When the field type is a **collection** (`Set<>`, `List<>`), Spring Data Neo4j creates one relationship per element. When it is a **single object**, exactly one relationship is created.

When the field type is a `@RelationshipProperties` class (like `UsageRelationship`), the relationship carries properties (rich relationship).

#### @RelationshipProperties

Marks a class as a **rich relationship** — a relationship that carries its own properties beyond just connecting two nodes.

```java
@RelationshipProperties
public class UsageRelationship {
    @RelationshipId
    private Long id;

    @TargetNode
    private FileNode file;

    private String className;
    private int lineNumber;
    private String context;
}
```

In Neo4j, this becomes:
```
(:Constant)-[:USED_IN {className: "...", lineNumber: 42, context: "..."}]->(:File)
```

Without `@RelationshipProperties`, relationships are bare edges with no properties.

#### @RelationshipId

Used **only** inside `@RelationshipProperties` classes. Identifies the internal Neo4j relationship ID (a `Long`). This is different from `@Id` on nodes — relationship IDs are managed by Neo4j, not generated by the application.

```java
@RelationshipId
private Long id;
```

This field is required by Spring Data Neo4j for relationship entity management but is never set by application code.

#### @TargetNode

Used **only** inside `@RelationshipProperties` classes. Identifies the **target node** of the relationship (the node at the other end).

```java
@TargetNode
private FileNode file;
```

The **source node** is implicit — it's the entity whose field references the `@RelationshipProperties` class. For example, when `ConstantNode.usages` contains a `UsageRelationship` with `@TargetNode FileNode file`, the relationship is: `ConstantNode → USED_IN → FileNode`.

#### Entity Graph Model

```mermaid
graph LR
    P["(:Project)<br/>id, name, rootPath,<br/>scannedAt, totalFiles,<br/>totalConstants, totalParameters"]
    F["(:File)<br/>id, path, fileName,<br/>fileType, fqn"]
    C["(:Constant)<br/>id, name, type, value,<br/>className, lineNumber,<br/>accessModifier, isEnum,<br/>enumClassName"]
    PM["(:Parameter)<br/>id, name, value,<br/>lineNumber"]

    P -->|"CONTAINS"| F
    C -->|"DEFINED_IN"| F
    C -->|"USED_IN<br/>{className, lineNumber, context}"| F
    PM -->|"DEFINED_IN"| F
    PM -->|"USED_IN<br/>{className, lineNumber, context}"| F
```

### 2.2 Repository Layer

All repositories extend `Neo4jRepository<T, ID>` and provide custom Cypher queries via `@Query`.

#### ProjectRepository

```java
public interface ProjectRepository extends Neo4jRepository<ProjectNode, String> {
    Optional<ProjectNode> findByRootPath(String rootPath);
    Optional<ProjectNode> findByName(String name);

    @Query("MATCH (p:Project) OPTIONAL MATCH (p)-[:CONTAINS]->(f:File) RETURN p, collect(f)")
    List<ProjectNode> findAllWithFiles();

    @Query("MATCH (p:Project {rootPath: $rootPath}) ...")
    Optional<ProjectNode> findByRootPathWithStats(String rootPath);

    @Query("MATCH (p:Project) RETURN count(p) as projectCount, ...")
    DatabaseStats getDatabaseStats();
}
```

**Projection interface:** `DatabaseStats` with getter methods — Spring Data Neo4j maps Cypher result columns to interface methods by name.

#### ConstantRepository — Notable Queries

| Method | Cypher Pattern | Purpose |
|--------|----------------|---------|
| `findConfigurationCandidates()` | `WHERE c.name =~ '(?i).*(HOST\|PORT\|URL\|...).*'` | Regex match for config-like names |
| `findDuplicateValues()` | `GROUP BY c.value HAVING count > 1` | Detect duplicated magic values |
| `findConnectionStrings()` | `WHERE c.value =~ '.*(http\|jdbc\|mongodb).*'` | Find hardcoded connection URLs |
| `findUnusedConstants()` | `WHERE NOT (c)-[:USED_IN]->()` | Constants with no cross-file usage |
| `findCrossFileConstants()` | `WITH c, count(DISTINCT f) as fileCount WHERE fileCount > 1` | Constants used across multiple files |
| `findFilesWithMostConstants()` | `ORDER BY constantCount DESC LIMIT 10` | Top 10 files by constant count |

#### ParameterRepository — Notable Queries

| Method | Cypher Pattern | Purpose |
|--------|----------------|---------|
| `findSensitiveParameters()` | `WHERE p.name =~ '(?i).*(password\|secret\|key\|token).*'` | Security audit |
| `findParametersByPrefix()` | `split(p.name, '.')[0] as prefix` | Group by namespace |
| `findMostUsedParameters()` | `ORDER BY usageCount DESC LIMIT 10` | Hot parameters |

### 2.3 Service Layer

#### ScanService

Bridges HTTP requests to the core `ProjectScanner` and `GraphPopulatorService`.

```mermaid
sequenceDiagram
    participant Client
    participant SC as ScanController
    participant SS as ScanService
    participant PS as ProjectScanner
    participant GPS as GraphPopulatorService
    participant Neo as Neo4j

    Client->>SC: POST /api/scan
    SC->>SS: scanProject(request)
    SS->>SS: validateProjectPath()
    SS->>PS: scan(projectPath)
    PS-->>SS: ScanResult
    SS->>GPS: populateGraph(name, path, result)
    GPS->>Neo: MERGE ProjectNode
    GPS->>Neo: CREATE FileNodes
    GPS->>Neo: CREATE ConstantNodes + DEFINED_IN
    GPS->>Neo: CREATE ParameterNodes + DEFINED_IN
    GPS->>Neo: CREATE USED_IN relationships
    GPS-->>SS: void
    SS-->>SC: ScanResponse
    SC-->>Client: 200 OK
```

**SSE streaming variant** — `GET /api/scan/stream?projectPath=...` uses `SseEmitter` with the core module's `ScanProgressListener` to push `ScanProgressEvent` objects in real time.

#### GraphPopulatorService

Eight-phase graph population:

1. Create or update `ProjectNode` (MERGE on rootPath)
2. Collect all unique file paths from constants, parameters, and usages
3. Create `FileNode` objects and build path-to-node cache
4. Create `ConstantNode` objects with `DEFINED_IN` → `FileNode`
5. Create `ParameterNode` objects with `DEFINED_IN` → `FileNode`
6. Create `USED_IN` relationships for parameter usages
7. Create `USED_IN` relationships for constant usages
8. Set fully-qualified names on Java `FileNode` entries

Re-scanning a project calls `clearProject()` first to remove stale data.

#### QueryService

Provides 10 pre-canned Cypher queries organized by category:

| ID | Category | Description |
|----|----------|-------------|
| `all-constants` | Constants | All constants with file locations |
| `config-candidates` | Constants | Constants matching HOST/PORT/URL patterns |
| `duplicate-values` | Constants | Constants sharing the same value |
| `connection-strings` | Constants | Hardcoded connection URLs |
| `all-parameters` | Parameters | All parameters |
| `unused-parameters` | Parameters | Parameters with no USED_IN edges |
| `cross-file-params` | Parameters | Parameters used across multiple files |
| `sensitive-params` | Parameters | Password/secret/key/token patterns |
| `param-by-prefix` | Parameters | Grouped by namespace prefix |
| `file-summary` | Files | Per-file statistics |

**Read-only enforcement** — `isReadOnlyQuery()` blocks keywords: `CREATE`, `DELETE`, `SET`, `REMOVE`, `MERGE`, `DROP`, `DETACH`.

#### CodeTransformationService

Orchestrates the full transformation pipeline.

```mermaid
sequenceDiagram
    participant Client
    participant TC as TransformController
    participant CTS as CodeTransformationService
    participant Neo as Neo4j
    participant CLT as ConfigLookupTransformer
    participant GS as GitService
    participant FS as FileSystem

    Client->>TC: POST /api/transform
    TC->>CTS: transform(request)

    CTS->>Neo: findConfigurationCandidates(projectPath)
    Neo-->>CTS: List~ConstantWithFile~
    CTS->>Neo: findParameterCandidates(projectPath)
    Neo-->>CTS: List~ParameterWithFile~

    Note over CTS: Group targets by source file

    CTS->>CLT: transformProject(projectPath, targetsByFile)

    loop Each Java file with targets
        CLT->>FS: Read source file
        CLT->>CLT: ModifierVisitor AST rewrite
        CLT->>FS: Write transformed file + .orig backup
    end

    CLT-->>CTS: TransformationResult

    alt createBranch == true && !dryRun
        CTS->>GS: isGitRepo(projectPath)?
        alt Not a git repo
            CTS->>GS: initRepoWithInitialCommit()
        end
        CTS->>GS: getCurrentBranch()
        CTS->>GS: createAndCheckoutBranch(branch-transformed)
        CTS->>FS: Copy transformed files from backups/
        CTS->>GS: addAndCommit("Transformed constants")
        CTS->>GS: checkoutBranch(originalBranch)
    end

    CTS-->>TC: TransformResponse
    TC-->>Client: 200 OK
```

#### SiteConfigurationService — Two-Tier Cache

Implements the **cache-aside** pattern with Caffeine (L1 local) and ValKey (L2 distributed).

```mermaid
sequenceDiagram
    participant Caller
    participant SCS as SiteConfigurationService
    participant L1 as Caffeine (L1)
    participant L2 as ValKey (L2)
    participant PS as Pub/Sub

    Caller->>SCS: lookup("db.host")
    SCS->>L1: get("db.host")
    alt L1 hit
        L1-->>SCS: "localhost"
        SCS-->>Caller: "localhost"
    else L1 miss
        SCS->>L2: GET config:db.host
        alt L2 hit
            L2-->>SCS: "localhost"
            SCS->>L1: put("db.host", "localhost")
            SCS-->>Caller: "localhost"
        else L2 miss
            SCS-->>Caller: null (or default)
        end
    end

    Note over Caller: Store flow
    Caller->>SCS: store("db.host", "remotehost")
    SCS->>L2: SET config:db.host "remotehost"
    SCS->>PS: PUBLISH config:changes "db.host"
    SCS->>L1: put("db.host", "remotehost")
```

**Typed lookup methods:** `lookup`, `lookupInt`, `lookupLong`, `lookupBoolean`, `lookupDouble`, plus a generic `lookup(key, Function<String,T>, T default)`.

**Null caching:** Uses a sentinel value (`"\0__NULL__\0"`) to cache negative lookups, preventing repeated L2 misses.

**Pub/sub invalidation:** On `store()`, publishes the key to `config:changes` channel. `ConfigurationChangeListener` (on other instances) receives the message and calls `invalidateLocal(key)`.

#### GitService

Executes git CLI commands via `ProcessBuilder` with a 30-second timeout.

| Method | Git Command | Purpose |
|--------|-------------|---------|
| `isGitRepo(path)` | `git rev-parse --git-dir` | Check if directory is in a git repo |
| `getCurrentBranch(path)` | `git rev-parse --abbrev-ref HEAD` | Get current branch name |
| `createAndCheckoutBranch(path, name)` | `git checkout -b <name>` | Create and switch to new branch |
| `checkoutBranch(path, name)` | `git checkout <name>` | Switch to existing branch |
| `addAndCommit(path, msg)` | `git add -A && git commit -m` | Stage all and commit |
| `initRepoWithInitialCommit(path)` | `git init && git add -A && git commit` | Initialize new repo with baseline |

Uses `ProcessBuilder.redirectErrorStream(true)` for combined stdout/stderr capture. Throws `GitException` on non-zero exit codes.

### 2.4 SiteConfig Annotation System

A custom annotation + `BeanPostProcessor` that auto-injects `SiteConfigurationService` into annotated beans — similar to Lombok's `@Slf4j` pattern.

**Annotation:**
```java
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface SiteConfig {
    String value() default "config";
}
```

**Usage:**
```java
@Service
@SiteConfig
public class EmailService {
    private SiteConfigurationService config;  // Auto-injected

    public void sendEmail(String to) {
        String host = config.lookup("smtp.host", "localhost");
    }
}
```

**SiteConfigBeanPostProcessor** implements `BeanPostProcessor` with `PriorityOrdered`:
1. In `postProcessBeforeInitialization()`, checks if the bean's class has `@SiteConfig`
2. Finds the field matching the annotation's `value` (default `"config"`)
3. Uses `ReflectionUtils.makeAccessible()` + `ReflectionUtils.setField()` to inject the service
4. Handles CGLIB proxies by checking the superclass for the annotation

**SiteConfigurationServiceProvider** offers a static accessor for optional use before the Spring context is fully initialized. Uses `volatile` + double-checked locking.

### 2.5 Controller API Surface

#### ScanController (`/api/scan`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/scan` | Synchronous project scan |
| `GET` | `/api/scan/stream?projectPath=` | SSE stream with real-time progress |

#### QueryController (`/api/query`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/query/precanned` | List all 10 pre-canned queries |
| `GET` | `/api/query/precanned/{id}` | Execute a pre-canned query by ID |
| `POST` | `/api/query/execute` | Execute ad-hoc Cypher (read-only) |

#### TransformController (`/api/transform`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/transform` | Transform constants (dry-run or actual, optional branch creation) |
| `GET` | `/api/transform/compare?path=` | Side-by-side diff (original vs. transformed) |

#### ConfigurationController (`/api/config`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `//export` | Export config to ValKey |
| `POST` | `/export/project` | Export project-specific config |
| `DELETE` | `/export` | Clear exported config |
| `GET` | `/lookup/{key}` | Lookup single key |
| `GET` | `/lookup/batch?keys=` | Batch lookup |
| `GET` | `/lookup/prefix/{prefix}` | Prefix wildcard lookup |
| `POST` | `/store` | Store single key-value |
| `POST` | `/store/batch` | Batch store |
| `DELETE` | `/{key}` | Delete single key |
| `POST` | `/cache/invalidate` | Invalidate cache entries |
| `GET` | `/stats` | Service statistics |
| `GET` | `/stats/cache` | Cache hit/miss statistics |
| `GET` | `/health` | Health check |

#### StatsController (`/api/stats`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/stats` | Dashboard statistics |
| `GET` | `/api/stats/constants` | Constants with optional type/class filter |
| `GET` | `/api/stats/parameters` | Parameters with optional name filter |
| `GET` | `/api/stats/health` | Health check (database + project count) |

#### FileController (`/api/files`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/files/content?path=` | Read source file content (allowed prefixes: `/src`, `/esrc`, `/csrc`, `/projects`) |

### 2.6 Configuration

**Neo4jConfig** — `@EnableNeo4jRepositories`, `@EnableTransactionManagement`. Supports both authenticated and `NEO4J_AUTH=none` modes.

**ValKeyConfig** — Lettuce-based with separate connections for read/write and pub/sub. Configures Caffeine builder with max-size and TTL from application properties. Constants: `CONFIG_CHANGE_CHANNEL = "config:changes"`, `CONFIG_KEY_PREFIX = "config:"`.

**WebConfig** — CORS for `localhost:3000`, `3001`, `5173` (Vite dev server, nginx, preview).

**OpenApiConfig** — SpringDoc with Swagger UI at `/swagger-ui.html`, tags for all controller groups.

---

## Chapter 3 — const-catalog-cli

> Standalone batch tool for offline scanning and CSV export. No Spring, no database connections.

### 3.1 Architecture

The CLI is deliberately minimal (~136 lines in `Main.java`). It depends only on `const-catalog-core` and Logback, producing a fat JAR via the Maven Shade plugin.

```mermaid
graph TB
    USER["java -jar const-catalog-cli.jar<br/>&lt;project-path&gt; [output-dir]"]
    MAIN["Main.java"]
    SCAN["ProjectScanner<br/>(from core)"]
    EXP["CsvExporter<br/>(from core)"]
    FS["File System"]

    USER --> MAIN
    MAIN --> SCAN
    MAIN --> EXP
    SCAN --> FS
    EXP --> FS

    FS -.->|"7 CSV files +<br/>import script"| NEO["Neo4j<br/>(manual import)"]
```

### 3.2 Command-Line Usage

```
Usage: java -jar const-catalog-cli.jar <project-path> [output-dir]

Arguments:
  project-path  Path to the Java project to scan
  output-dir    Output directory for CSV files (default: <project-path>/neo4j-export)
```

- Positional arguments only — no flags (`--help`, `--verbose`, etc.)
- Validates that `project-path` exists and is a directory
- Prints an ASCII banner, scan summary, and Neo4j import instructions

### 3.3 Workflow

1. Validate arguments and project path
2. Initialize `ProjectScanner` (from core)
3. Scan project → `ScanResult`
4. Display summary: Java files, property files, constants, parameters, usages
5. Initialize `CsvExporter` (from core)
6. Export to `output-dir`: 7 CSV files + `import-neo4j.cypher`
7. Print success message with Neo4j import instructions

### 3.4 Build

The Maven Shade plugin creates a single executable JAR with all dependencies relocated:

```xml
<plugin>
    <artifactId>maven-shade-plugin</artifactId>
    <configuration>
        <transformers>
            <transformer implementation="...ManifestResourceTransformer">
                <mainClass>com.boeing.constcatalog.cli.Main</mainClass>
            </transformer>
        </transformers>
    </configuration>
</plugin>
```

**Minimal dependency footprint:** core + Logback + transitive (JavaParser, SnakeYAML, Jackson). No Spring, no Neo4j driver, no ValKey client.

---

## Chapter 4 — const-catalog-frontend

> React 18 + TypeScript single-page application with the "Space Command" dark theme. Built with Vite, styled with Tailwind CSS.

### 4.1 Component Tree

```mermaid
graph TB
    APP["App.tsx<br/>BrowserRouter"]
    LAYOUT["Layout.tsx<br/>Main wrapper"]
    HEADER["Header.tsx<br/>HUD status bar"]
    SIDEBAR["Sidebar.tsx<br/>Navigation"]
    OUTLET["Router Outlet"]
    CMD["CommandLine.tsx<br/>Terminal footer"]
    CMDRES["CommandLineResults.tsx<br/>Slide-up panel"]

    APP --> LAYOUT
    LAYOUT --> HEADER
    LAYOUT --> SIDEBAR
    LAYOUT --> OUTLET
    LAYOUT --> CMD
    CMD --> CMDRES

    DASH["Dashboard.tsx"]
    SCANP["ScanPage.tsx"]
    QUERYP["QueryPage.tsx"]
    XFORMP["TransformPage.tsx"]

    OUTLET --> DASH
    OUTLET --> SCANP
    OUTLET --> QUERYP
    OUTLET --> XFORMP

    RT["ResultsTable.tsx"]
    FVM["FileViewerModal.tsx"]
    DV["DiffViewer.tsx"]

    QUERYP --> RT
    QUERYP --> FVM
    XFORMP --> DV
    CMDRES --> RT
    DASH --> RT
```

### 4.2 Routing

| Path | Component | Description |
|------|-----------|-------------|
| `/` | `Dashboard` | System overview with stat cards and quick insights |
| `/scan` | `ScanPage` | Project scanning with real-time SSE progress |
| `/query` | `QueryPage` | Pre-canned and ad-hoc Cypher query execution |
| `/transform` | `TransformPage` | Code transformation with diff viewer |

### 4.3 Page Components

**Dashboard** — Four stat cards (Projects, Files, Constants, Parameters), constants-by-type distribution, top files list, and quick insight cards linking to pre-canned queries. Data fetched via TanStack Query (`useQuery` with `getStats()`).

**ScanPage** — Project path input, "watch progress" checkbox, real-time progress bar with scrolling file list (last 25 files). Uses the `useScanProgress()` SSE hook. Displays post-scan statistics broken down by file type.

**QueryPage** — Two-panel layout: left panel lists pre-canned queries by category, right panel has a Cypher textarea editor with results table below. Supports URL parameter `?q=queryId` for deep linking. Read-only queries enforced. Integrates `FileViewerModal` for source file inspection.

**TransformPage** — Form with project path, candidate scope radio buttons (`ALL`, `CONSTANTS_ONLY`, `PARAMETERS_ONLY`), dry-run checkbox (mutually exclusive with branch creation), and create-branch checkbox. Results table with status filters (Transformed/Skipped/Failed) and per-entry diff viewing via `DiffViewer`.

### 4.4 Shared Components

| Component | Purpose |
|-----------|---------|
| `Layout` | Wraps all pages with Header, Sidebar, main content area, and CommandLine footer |
| `Header` | HUD-style bar with Neo4j connection status, system status indicator, project count. Health polling every 30s |
| `Sidebar` | Four navigation items with active/hover styling and version footer |
| `CommandLine` | Terminal-style Cypher input with command history (Up/Down arrows), Escape to close results |
| `CommandLineResults` | Slide-up panel above footer displaying query results in `ResultsTable` |
| `ResultsTable` | Generic data grid for query results with dynamic columns, clickable file names, and row count |
| `DiffViewer` | Side-by-side modal with synchronized scrolling, line numbers, and red/green diff highlighting |
| `FileViewerModal` | Full-screen source file viewer with line numbers, async loading, and cancellation support |

### 4.5 State Management & Data Fetching

- **Server state:** TanStack Query (React Query 5) for all API calls. Provides caching, loading/error states, and refetch intervals.
- **Local state:** React `useState` / `useRef` hooks. No global state library.
- **Real-time updates:** Custom `useScanProgress()` hook wrapping the `EventSource` API for SSE consumption. Maintains a rolling window of the last 25 file names.
- **Mutations:** `useMutation` for scan, query execution, and transformation triggers.

### 4.6 API Integration

Axios client with base URL `/api` (proxied through Vite dev server or nginx in production).

| Function | Method | Endpoint |
|----------|--------|----------|
| `scanProject()` | POST | `/scan` |
| `getPreCannedQueries()` | GET | `/query/precanned` |
| `executePreCannedQuery(id)` | GET | `/query/precanned/{id}` |
| `executeQuery(cypher)` | POST | `/query/execute` |
| `getStats()` | GET | `/stats` |
| `healthCheck()` | GET | `/stats/health` |
| `getFileContent(path)` | GET | `/files/content?path=` |
| `transformProject(req)` | POST | `/transform` |
| `getFileComparison(path)` | GET | `/transform/compare?path=` |

### 4.7 Space Command Theme

A consistent retro-terminal / sci-fi dark theme:

| Token | Value | Usage |
|-------|-------|-------|
| `space-black` | `#0a0a0f` | Page background |
| `space-darker` | `#0d0d14` | Card backgrounds |
| `space-dark` | `#12121a` | Sidebar, header |
| `neon-cyan` | `#00ffff` | Primary accent, borders, active states |
| `neon-green` | `#00ff9f` | Success states |
| `neon-red` | `#ff3333` | Error states |
| `terminal-text` | `#e0e0e0` | Body text |
| `terminal-dim` | `#666666` | Secondary text |

**Font:** JetBrains Mono (loaded from Google Fonts).

**Effects:** Glowing borders (`box-shadow` with cyan layers), pulse animations for status dots, slide-up animation for results panel.

---

## Chapter 5 — Infrastructure

### 5.1 Docker Compose

Five services on a shared `const-catalog-network` bridge:

```mermaid
graph TB
    subgraph "Docker Compose Stack"
        VK["valkey:8-alpine<br/>Port 6379<br/>256MB max memory"]
        NEO["neo4j:5.15-community<br/>Ports 7474, 7687<br/>APOC plugin"]
        BE["backend<br/>(Dockerfile build)<br/>Port 9090→8080<br/>Debug 5005"]
        FE["frontend<br/>(Dockerfile build)<br/>Port 3001→80<br/>nginx"]
        VKCLI["valkey-cli<br/>(optional profile)"]
    end

    subgraph "Host Volumes"
        SRC["HOST_SRC_PATH → /src"]
        ESRC["HOST_ESRC_PATH → /esrc"]
        CSRC["HOST_CSRC_PATH → /csrc"]
        BK["./backups → /app/backups"]
        NDATA["neo4j-data"]
        VKDATA["valkey-data"]
    end

    FE -->|"proxy /api/"| BE
    BE --> NEO
    BE --> VK
    BE --> SRC
    BE --> ESRC
    BE --> CSRC
    BE --> BK
    NEO --> NDATA
    VK --> VKDATA
```

**Key configuration:**

| Service | Image | Ports | Health Check |
|---------|-------|-------|-------------|
| valkey | valkey/valkey:8-alpine | 6379 | `valkey-cli ping` |
| neo4j | neo4j:5.15-community | 7474 (HTTP), 7687 (Bolt) | `wget --spider localhost:7474` |
| backend | Multi-stage Dockerfile | 9090→8080, 5005 (debug) | `wget --spider localhost:8080/api/stats/health` |
| frontend | Multi-stage Dockerfile | 3001→80 | `wget --spider localhost:80` |

**Source directories** are bind-mounted **read-only** into the backend container. The `backups/` volume is writable for transformation output.

### 5.2 Backend Dockerfile

Multi-stage build:
1. **Builder stage** (`maven:3.9-eclipse-temurin-21`): Copies POMs first for dependency caching, then builds backend module
2. **Runtime stage** (`eclipse-temurin:21-jre`): Installs `git` (required for branch creation feature), creates non-root `appuser`, configures `git safe.directory` for mounted repos

### 5.3 Frontend Dockerfile

Multi-stage build:
1. **Builder stage** (`node:20-alpine`): `npm ci` + `npm run build`
2. **Runtime stage** (`nginx:alpine`): Custom `nginx.conf` with API proxy, gzip compression, SPA fallback, and static asset caching (1 year + immutable)

### 5.4 Nginx Configuration

- API proxy: `/api/` → `http://backend:8080/api/` with 6000s timeouts (for long-running scans)
- SPA routing: Non-file routes fall back to `index.html`
- Gzip enabled for text, CSS, JSON, JavaScript, XML
- Static assets: `Cache-Control: max-age=31536000, immutable`

### 5.5 Environment Files

| File | Platform | HOST_SRC_PATH |
|------|----------|---------------|
| `.env.wsl` | WSL2 accessing Windows drives | `/mnt/c/Users/brian/src` |
| `.env.mint` | Linux Mint | `/home/bmarshall/src` |
| `.env.example` | Template | Examples for Windows, WSL2, Linux, macOS |

### 5.6 Restart Script

`scripts/RestartContainersFresh` — PowerShell script that detects the platform (`$IsLinux`), selects the appropriate `.env` file, and runs `docker compose down` followed by `docker compose up -d --build`.

---

## Chapter 6 — Code Quality & Recommendations

### 6.1 Design Patterns Employed

| Pattern | Where | Notes |
|---------|-------|-------|
| **Visitor** | `JavaFileParser` (`VoidVisitorAdapter`), `ConfigLookupTransformer` (`ModifierVisitor`) | Core of the AST processing pipeline |
| **Strategy / Dispatch** | `PropertyFileParser` format routing, `ConfigurationExportService` export strategies | Clean extension point for new formats |
| **Factory Method** | `TransformationEntry.transformed/skipped/failed()`, `FileNode.fromPath()`, `ConstantNode.fromConstant()` | Self-documenting construction |
| **Cache-Aside** | `SiteConfigurationService` (Caffeine L1 + ValKey L2) | With pub/sub invalidation across instances |
| **Observer / Pub-Sub** | `ConfigurationChangeListener` subscribing to ValKey channel | Cross-instance cache consistency |
| **Bean Post-Processor** | `SiteConfigBeanPostProcessor` for `@SiteConfig` injection | Mirrors `@Slf4j` pattern for config access |
| **Template Method** | `GraphPopulatorService` eight-phase population | Fixed algorithm with per-phase methods |
| **Repository** | Spring Data Neo4j repositories with `@Query` | Clean separation of data access |

### 6.2 Strengths

1. **Clean module boundaries** — Core has zero Spring dependencies, making it reusable in the CLI and testable without a container. The backend is a thin orchestration layer over core services.

2. **Immutable domain model** — Java records throughout the core module eliminate setter bugs and make concurrent access safe by default.

3. **Type-safe transformations** — The `chooseLookupMethod()` dispatch ensures that `int` constants get `lookupInt()`, `boolean` gets `lookupBoolean()`, etc., with appropriate defaults.

4. **Comprehensive test coverage** — Nested `@Nested` test classes with `@DisplayName` cover edge cases: numeric literal formats (hex, octal, binary, underscore separators), multiple variables per declaration, static import variants.

5. **Two-tier caching with pub/sub** — The Caffeine + ValKey architecture with null-sentinel caching and pub/sub invalidation is production-grade.

6. **Real-time progress** — SSE streaming from the backend with the custom `useScanProgress()` hook provides a responsive scanning experience.

7. **Security awareness** — File controller enforces allowed path prefixes (`/src`, `/esrc`, `/csrc`, `/projects`). Query controller blocks write operations.

8. **Backup strategy** — Transformations write `.orig` backups preserving the source tree structure, enabling rollback.

### 6.3 Areas for Improvement

1. **Long methods** — `GraphPopulatorService.populateGraph()` and `ConfigLookupTransformer.transformFile()` are large orchestration methods. Consider extracting named phases into smaller methods with clear contracts.

2. **Error propagation** — Some services catch and log exceptions without re-throwing (e.g. parse failures in `JavaFileParser`). Consider accumulating errors into the result object so the caller can report partial failures.

3. **CLI feature parity** — The CLI lacks `--help`, `--verbose`, `--exclude` flags. Adding a lightweight argument parser (e.g. picocli) would improve usability.

4. **XML parsing robustness** — `PropertyFileParser.parseXmlConfigFile()` uses regex-based line parsing rather than a proper XML parser. This may miss multi-line attributes or CDATA sections.

5. **Timeout handling for large projects** — `Files.walkFileTree()` in `ProjectScanner` has no timeout or file-count limit. Extremely large monorepos could cause long scan times.

6. **Frontend test coverage** — No unit or integration tests exist for the React components. Consider adding Vitest + React Testing Library for critical paths (scan form, query execution, transformation display).

7. **Git service error handling** — `GitService` uses a fixed 30-second timeout for all operations. Large `git add` operations on initial commits could exceed this. Consider making the timeout configurable.

8. **Hardcoded container paths** — The backend Dockerfile configures `git safe.directory` for specific mount points. If mount paths change, these must be updated manually.

### 6.4 Architectural Recommendations

1. **Consider pagination** for query results — Currently all Cypher results are returned in a single response. For large result sets, server-side pagination would reduce memory pressure.

2. **Add WebSocket support** for transformation progress — Like the SSE-based scan progress, long-running transformations would benefit from real-time feedback.

3. **Configuration validation** — The `SiteConfigurationService.store()` method accepts any key-value pair. Consider adding a schema or validation layer to prevent typos in configuration keys.

4. **Metrics and observability** — The application exposes basic health endpoints but no Prometheus metrics or distributed tracing. For production deployments, consider Spring Boot Actuator with Micrometer.
