# Frontend Maintainer's Diary: Constants Catalog

This is the companion document to the [Maintainer's Diary](./Maintainers_Diary.md). It covers everything you need to know about the frontend: how the technology stack fits together, how the "Space Command" visual theme is built from two configuration files, and how to set up a local development environment.

---

## Setup and Getting Started

### Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| **Node.js** | 18+ | JavaScript runtime for the dev server and build tooling. |
| **npm** | Bundled with Node | Package manager. |
| **VS Code** (recommended) | Latest | The best editor for Tailwind + React + TypeScript. |

### Recommended VS Code Extensions

- **Tailwind CSS IntelliSense** -- Autocomplete for every Tailwind utility class, including the custom ones defined in `tailwind.config.js`. Hover any class to see the generated CSS. This is the single most important extension for this project.
- **ES7+ React/Redux/React-Native Snippets** -- Shortcuts for component boilerplate (`rfce`, `rfc`, etc.).
- **ESLint** -- The project includes an ESLint configuration for TypeScript and React hooks.

### Installing Dependencies

```bash
cd const-catalog-frontend
npm install
```

### Starting the Dev Server

```bash
npm run dev
```

This starts Vite on port **3000** with a proxy that forwards `/api` requests to `http://localhost:8080` (the Spring Boot backend). You will need the backend and Neo4j running for the application to function -- either via Docker Compose or by running the Spring Boot app locally.

Open `http://localhost:3000` in your browser.

### Building for Production

```bash
npm run build
```

This runs TypeScript type checking (`tsc`) followed by Vite's production build. Output lands in `dist/`. The Docker build uses this same command inside a multi-stage Dockerfile: Node builds the assets, then nginx serves them.

### How It Runs in Docker

The `const-catalog-frontend/Dockerfile` uses a two-stage build:

1. **Build stage** (`node:20-alpine`): Installs dependencies, runs `npm run build`, produces static assets in `dist/`.
2. **Runtime stage** (`nginx:alpine`): Copies the built assets and a custom `nginx.conf` into the nginx image.

The nginx configuration does three things:
- Proxies `/api/` requests to `http://backend:8080/api/` (the Docker service name).
- Serves `index.html` for all other routes (SPA fallback via `try_files`).
- Caches static assets (JS, CSS, images, fonts) for one year with immutable headers.

Port mapping in `docker-compose.yml`: container port 80 is mapped to host port **3001**.

---

## Technology Stack

| Library | Version | Role |
|---------|---------|------|
| **React** | 18.2 | UI framework. |
| **TypeScript** | 5.3 | Type safety. |
| **Vite** | 5.0 | Dev server and bundler. Fast HMR. |
| **Tailwind CSS** | 3.4 | Utility-first CSS framework. All styling is done through class names. |
| **React Router** | 6.21 | Client-side routing (`/`, `/scan`, `/query`, `/transform`). |
| **React Query** (@tanstack/react-query) | 5.17 | Server state management. Handles fetching, caching, and refetching API data. |
| **Axios** | 1.6 | HTTP client for REST calls. |
| **Lucide React** | 0.303 | Icon library (fork of Feather Icons). |
| **clsx** | 2.0 | Conditional class name joining. |
| **PostCSS** | 8.4 | CSS processing pipeline (Tailwind uses it). |
| **Autoprefixer** | 10.4 | Adds vendor prefixes automatically. |

The PostCSS pipeline is configured in `postcss.config.js`:

```js
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

Tailwind processes your CSS first, then Autoprefixer handles browser compatibility.

---

## A Tailwind CSS Tutorial for This Project

If you are new to Tailwind, the core idea is simple: instead of writing CSS in separate files and inventing class names, you compose styling directly in the HTML (or JSX) using small utility classes. Each class does exactly one thing.

### The Basics

```jsx
<div className="bg-blue-500 text-white p-4 rounded">
  Hello
</div>
```

This creates a div with a blue background, white text, 1rem padding, and rounded corners. No CSS file needed.

### How Tailwind Works Under the Hood

1. You write utility classes in your JSX.
2. Tailwind scans all files listed in the `content` array of `tailwind.config.js`.
3. It generates a CSS file containing *only* the classes you actually used.
4. PostCSS processes the output, and Vite includes it in the bundle.

The `content` array in our config:

```js
content: [
  "./index.html",
  "./src/**/*.{js,ts,jsx,tsx}",
]
```

This means Tailwind scans `index.html` and every source file in `src/`.

### Reading Tailwind Classes

Tailwind class names follow a pattern: `{property}-{value}` or `{property}-{value}/{opacity}`.

| Class | CSS It Generates |
|-------|-----------------|
| `bg-red-500` | `background-color: #ef4444` |
| `text-white` | `color: #fff` |
| `p-4` | `padding: 1rem` |
| `px-6` | `padding-left: 1.5rem; padding-right: 1.5rem` |
| `py-3` | `padding-top: 0.75rem; padding-bottom: 0.75rem` |
| `m-2` | `margin: 0.5rem` |
| `mx-auto` | `margin-left: auto; margin-right: auto` |
| `rounded` | `border-radius: 0.25rem` |
| `rounded-full` | `border-radius: 9999px` |
| `w-4` | `width: 1rem` |
| `h-4` | `height: 1rem` |
| `w-64` | `width: 16rem` |
| `flex` | `display: flex` |
| `flex-1` | `flex: 1 1 0%` |
| `flex-col` | `flex-direction: column` |
| `items-center` | `align-items: center` |
| `justify-between` | `justify-content: space-between` |
| `gap-3` | `gap: 0.75rem` |
| `text-sm` | `font-size: 0.875rem` |
| `text-xs` | `font-size: 0.75rem` |
| `text-2xl` | `font-size: 1.5rem` |
| `font-bold` | `font-weight: 700` |
| `font-medium` | `font-weight: 500` |
| `tracking-wider` | `letter-spacing: 0.05em` |
| `border` | `border-width: 1px` |
| `border-b` | `border-bottom-width: 1px` |
| `border-r` | `border-right-width: 1px` |
| `overflow-auto` | `overflow: auto` |
| `min-h-screen` | `min-height: 100vh` |
| `transition-all` | `transition-property: all` |
| `duration-200` | `transition-duration: 200ms` |

### State Modifiers

Prefix a class with a state modifier to apply it conditionally:

| Modifier | When It Applies |
|----------|----------------|
| `hover:` | On mouse hover |
| `focus:` | When focused |
| `active:` | While being clicked |
| `disabled:` | When the element is disabled |

Example: `hover:bg-neon-cyan/30` means "apply `bg-neon-cyan/30` only on hover."

### Opacity Shorthand

The `/` syntax sets opacity on a color:

| Class | Meaning |
|-------|---------|
| `bg-neon-cyan/30` | `background-color: rgba(0, 255, 255, 0.3)` |
| `border-neon-cyan/50` | `border-color: rgba(0, 255, 255, 0.5)` |
| `text-neon-cyan/80` | `color: rgba(0, 255, 255, 0.8)` |

This opacity syntax is used extensively throughout the theme to create layered depth effects -- borders at 20-30% opacity, backgrounds at 10-20%, and text at 60-100%.

---

## The Two Key Files: `tailwind.config.js` and `index.css`

These two files define the entire visual language of the application. Understanding them is the key to maintaining or extending the UI.

### `tailwind.config.js` -- The Theme Definition

This file extends Tailwind's default theme with custom values specific to the Space Command aesthetic.

#### Custom Colors

Three color groups are defined:

**`space.*`** -- Background shades (darkest to lightest):

| Token | Hex | Usage |
|-------|-----|-------|
| `space-black` | `#0a0a0f` | Page background (the `body`) |
| `space-darker` | `#0d0d14` | Header, sidebar, input backgrounds |
| `space-dark` | `#12121a` | Secondary panels |
| `space-medium` | `#1a1a24` | Table headers, card backgrounds |
| `space-light` | `#252530` | Borders, hover states, subtle separators |

**`neon.*`** -- Accent colors (vivid, saturated):

| Token | Hex | Usage |
|-------|-----|-------|
| `neon-cyan` | `#00ffff` | Primary accent: active nav items, headings, borders, glows |
| `neon-green` | `#00ff9f` | Success states, online indicators |
| `neon-blue` | `#00aaff` | Secondary accents |
| `neon-purple` | `#aa00ff` | Decorative only |
| `neon-pink` | `#ff00aa` | Decorative only |
| `neon-orange` | `#ff6600` | Warning states, pending indicators |
| `neon-red` | `#ff3333` | Error states, danger buttons, offline indicators |

**`terminal.*`** -- Text hierarchy:

| Token | Hex | Usage |
|-------|-----|-------|
| `terminal-text` | `#e0e0e0` | Default body text |
| `terminal-dim` | `#888899` | Secondary text, labels, descriptions |
| `terminal-bright` | `#ffffff` | Emphasized text, hover states |

In JSX, you use these as `bg-space-dark`, `text-neon-cyan`, `border-terminal-dim`, and so on.

#### Custom Font

```js
fontFamily: {
  mono: ['JetBrains Mono', 'Fira Code', 'Monaco', 'Consolas', 'monospace'],
}
```

The entire application uses a monospace font stack, reinforcing the terminal aesthetic. Applied globally via `font-mono` on the `body` in `index.css`.

#### Custom Box Shadows (Neon Glows)

```js
boxShadow: {
  'neon-cyan': '0 0 10px rgba(0, 255, 255, 0.3), 0 0 20px rgba(0, 255, 255, 0.2)',
  'neon-green': '0 0 10px rgba(0, 255, 159, 0.3), 0 0 20px rgba(0, 255, 159, 0.2)',
  'neon-blue': '0 0 10px rgba(0, 170, 255, 0.3), 0 0 20px rgba(0, 170, 255, 0.2)',
}
```

Used as `shadow-neon-cyan` for hover glows on buttons and active elements. The dual-layer shadow (10px inner glow + 20px outer glow) creates a convincing neon tube effect.

#### Custom Animations

Three animations are defined:

| Animation | Class | Effect |
|-----------|-------|--------|
| `pulse-slow` | `animate-pulse-slow` | A 3-second opacity pulse. Used on the `online` status dot. |
| `glow` | `animate-glow` | Alternates between dim and bright neon glow. |
| `slide-up` | `animate-slide-up` | Expands `maxHeight` from 0 to 50vh with fade-in. Used for the CommandLine results panel. |

### `index.css` -- Global Styles and Component Classes

This file is processed by Tailwind's PostCSS pipeline. It starts with the three Tailwind directives:

```css
@tailwind base;       /* Reset and base HTML styling */
@tailwind components; /* Pre-built component classes (none by default) */
@tailwind utilities;  /* All the utility classes */
```

Everything after these directives defines custom global styles and reusable component classes using Tailwind's `@apply` directive.

#### Body Defaults

```css
body {
  @apply bg-space-black text-terminal-text font-mono;
  min-height: 100vh;
}
```

This is the foundation. Every page starts with the darkest background, light gray text, and the monospace font.

#### Scrollbar Styling

```css
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-track { @apply bg-space-darker; }
::-webkit-scrollbar-thumb { @apply bg-space-light rounded; }
::-webkit-scrollbar-thumb:hover { @apply bg-neon-cyan/30; }
```

Thin, dark scrollbars that glow cyan on hover. A subtle detail that keeps the theme consistent.

#### The `.neon-border` Class

```css
.neon-border {
  @apply border border-neon-cyan/30;
  box-shadow: inset 0 0 10px rgba(0, 255, 255, 0.1);
}
.neon-border:hover {
  @apply border-neon-cyan/50;
  box-shadow: inset 0 0 15px rgba(0, 255, 255, 0.15);
}
```

This is the workhorse class for panels and cards. It gives elements a faint cyan border with an inner glow that intensifies on hover.

#### Text Selection

```css
::selection {
  @apply bg-neon-cyan/30 text-terminal-bright;
}
```

Selected text gets a cyan highlight instead of the browser default blue.

#### Input and Textarea Defaults

```css
input, textarea {
  @apply bg-space-darker border border-space-light rounded px-3 py-2;
  @apply text-terminal-text placeholder-terminal-dim;
  @apply focus:outline-none focus:border-neon-cyan/50 focus:ring-1 focus:ring-neon-cyan/30;
}
```

All form inputs automatically adopt the dark theme with a cyan focus ring. No per-component styling needed.

#### Button Classes

Three button variants:

| Class | Appearance |
|-------|-----------|
| `.btn` | Base: padding, rounded, transition, disabled styles. |
| `.btn-primary` | Cyan tinted background, cyan text and border, neon glow on hover. |
| `.btn-secondary` | Neutral gray, subtle border, dim hover. |
| `.btn-danger` | Red tinted background, red text and border. |

#### Data Table Styles

```css
.data-table th  { @apply bg-space-medium text-neon-cyan ... border-b border-neon-cyan/30; }
.data-table td  { @apply px-3 py-2 border-b border-space-light; }
.data-table tr:hover td { @apply bg-space-light/50; }
```

Table headers get cyan text on a medium-dark background with a cyan bottom border. Rows highlight on hover.

#### Status Dots

```css
.status-dot         { @apply w-2 h-2 rounded-full; }
.status-dot.online  { @apply bg-neon-green shadow-neon-green animate-pulse-slow; }
.status-dot.offline { @apply bg-neon-red; }
.status-dot.pending { @apply bg-neon-orange animate-pulse; }
```

Small colored circles used in the Header for database and system status. The `online` dot pulses slowly with a green glow.

---

## Application Architecture

### Entry Point: `main.tsx`

```tsx
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000,
      retry: 1,
    },
  },
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>,
)
```

React Query is configured with a 30-second stale time (data is considered fresh for 30 seconds after fetching; subsequent renders use the cached value). Retries are limited to 1 to avoid hammering a potentially down backend.

### Routing: `App.tsx`

```tsx
<BrowserRouter>
  <Routes>
    <Route path="/" element={<Layout />}>
      <Route index element={<Dashboard />} />
      <Route path="scan" element={<ScanPage />} />
      <Route path="query" element={<QueryPage />} />
      <Route path="transform" element={<TransformPage />} />
    </Route>
  </Routes>
</BrowserRouter>
```

All four pages are nested inside `Layout`, which provides the header, sidebar, and command line footer. The `<Outlet />` inside Layout renders the active page.

### Layout Structure: `Layout.tsx`

```
+-----------------------------------------------+
| Header (bg-space-darker, border-b)            |
+----------+------------------------------------+
| Sidebar  | Main Content Area                  |
| (w-64,   | (flex-1, p-6, overflow-auto)       |
| border-r)|   <-- Outlet renders here -->      |
|          |                                    |
+----------+------------------------------------+
| CommandLine (footer)                          |
+-----------------------------------------------+
```

The layout uses flexbox: `min-h-screen flex flex-col` on the outer div, then `flex flex-1` for the sidebar+main row. The sidebar is fixed at `w-64` (16rem / 256px); the main content takes the rest.

### Component Summary

| Component | File | Purpose |
|-----------|------|---------|
| **Header** | `components/Header.tsx` | Title bar with Neo4j connection status and project count. Polls `GET /api/stats/health` every 30 seconds via React Query. |
| **Sidebar** | `components/Sidebar.tsx` | Navigation links (Dashboard, Scan, Query, Transform). Active link gets cyan background/border via `clsx` conditional classes. |
| **CommandLine** | `components/CommandLine.tsx` | Terminal-style input at the bottom. Accepts quick navigation commands and pre-canned query shortcuts. |
| **CommandLineResults** | `components/CommandLineResults.tsx` | Expandable results panel (uses `animate-slide-up`) that shows command output. |
| **ResultsTable** | `components/ResultsTable.tsx` | Generic sortable table for query results. Detects `filePath` columns and makes them clickable. |
| **FileViewerModal** | `components/FileViewerModal.tsx` | Modal overlay showing file contents with line numbers and syntax highlighting. |
| **DiffViewer** | `components/DiffViewer.tsx` | Side-by-side diff view for transformation results. Used on the Transform page. |

### Page Summary

| Page | File | API Calls |
|------|------|-----------|
| **Dashboard** | `pages/Dashboard.tsx` | `GET /api/stats` -- Fetches aggregate statistics on mount. |
| **ScanPage** | `pages/ScanPage.tsx` | `GET /api/scan/stream?projectPath=...` -- SSE connection for real-time progress. |
| **QueryPage** | `pages/QueryPage.tsx` | `GET /api/query/precanned`, `GET /api/query/precanned/{id}`, `POST /api/query/execute` |
| **TransformPage** | `pages/TransformPage.tsx` | `POST /api/transform`, `GET /api/transform/compare?path=...` |

---

## How to Extend the Theme

### Adding a New Color

Edit `tailwind.config.js` under `theme.extend.colors`:

```js
neon: {
  cyan: '#00ffff',
  green: '#00ff9f',
  // ... existing colors ...
  yellow: '#ffff00',  // <-- add it here
}
```

You can then use `text-neon-yellow`, `bg-neon-yellow/20`, `border-neon-yellow` anywhere in JSX.

### Adding a New Animation

Add the keyframes and animation name in `tailwind.config.js`:

```js
keyframes: {
  'fade-in': {
    '0%': { opacity: '0' },
    '100%': { opacity: '1' },
  }
},
animation: {
  'fade-in': 'fade-in 0.3s ease-out forwards',
}
```

Use as `className="animate-fade-in"`.

### Adding a New Reusable Class

Add it to `index.css` using `@apply`:

```css
.card {
  @apply bg-space-dark border border-space-light rounded-lg p-4;
  @apply hover:border-neon-cyan/30 transition-all duration-200;
}
```

Then use `className="card"` in any component. Keep the number of custom classes small -- prefer inline Tailwind utilities for one-off styling.

---

## Common Patterns in This Codebase

### Conditional Classes with `clsx`

The `clsx` library joins class names conditionally. You will see this pattern often:

```tsx
className={clsx(
  'flex items-center gap-3 px-4 py-3',          // always applied
  'border border-transparent',                    // always applied
  isActive
    ? 'bg-neon-cyan/10 border-neon-cyan/30 text-neon-cyan'  // when active
    : 'text-terminal-dim hover:bg-space-light'               // when inactive
)}
```

### React Query for Server State

API data is fetched with `useQuery`:

```tsx
const { data, isLoading, isError } = useQuery({
  queryKey: ['stats'],
  queryFn: fetchStats,
  refetchInterval: 30000,  // optional: poll every 30s
})
```

The `queryKey` is used for caching. Mutations (POST requests) use `useMutation`.

### SSE for Scan Progress

The Scan page uses a custom `useScanProgress` hook that opens an `EventSource` connection:

```tsx
const eventSource = new EventSource(`/api/scan/stream?projectPath=${path}`)
eventSource.addEventListener('progress', (e) => { /* update state */ })
eventSource.addEventListener('complete', (e) => { /* mark done */ })
eventSource.addEventListener('error', (e) => { /* handle error */ })
```

This gives the user real-time feedback during long-running scans.

### Lucide Icons

Icons are imported individually from `lucide-react`:

```tsx
import { Database, Activity, Cpu } from 'lucide-react'

<Database className="w-4 h-4 text-terminal-dim" />
```

Standard sizing: `w-4 h-4` (16px) for inline icons, `w-5 h-5` (20px) for nav items, `w-6 h-6` and larger for page-level icons.

---

## File Structure

```
const-catalog-frontend/
  Dockerfile           # Multi-stage build (Node -> nginx)
  nginx.conf           # Proxy /api to backend, SPA fallback
  package.json         # Dependencies and scripts
  postcss.config.js    # Tailwind + Autoprefixer pipeline
  tailwind.config.js   # Space Command theme definition
  vite.config.ts       # Dev server on port 3000, /api proxy
  index.html           # HTML shell, loads JetBrains Mono from Google Fonts
  src/
    main.tsx           # React Query provider, app mount
    App.tsx            # BrowserRouter with 4 routes
    index.css          # Tailwind directives + global styles
    types/
      index.ts         # TypeScript interfaces for all API responses
    services/
      api.ts           # Axios client with all API functions
    hooks/
      useScanProgress.ts  # SSE EventSource hook
    components/
      Layout.tsx       # Header + Sidebar + Outlet + CommandLine
      Header.tsx       # HUD top bar with health polling
      Sidebar.tsx      # Navigation links
      CommandLine.tsx   # Terminal-style footer input
      CommandLineResults.tsx  # Expandable command output
      ResultsTable.tsx # Sortable data table
      FileViewerModal.tsx    # File content modal
      DiffViewer.tsx   # Side-by-side diff for transforms
    pages/
      Dashboard.tsx    # Statistics overview
      ScanPage.tsx     # Project scanning with SSE progress
      QueryPage.tsx    # Pre-canned and ad-hoc Cypher queries
      TransformPage.tsx # Constant-to-config transformation
```
