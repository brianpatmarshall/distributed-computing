# Addendum: Remote Debugging IDE Setup

This addendum to the [Remote Debugging Guide](Remote_Debugging_Guide.md) provides detailed, step-by-step walkthroughs for setting up remote debugging in IntelliJ IDEA and Visual Studio Code. Where the parent guide gives concise configuration tables, this document explains every screen, every setting, and the reasoning behind each choice.

---

## Part 1: IntelliJ IDEA

### 1.1 Prerequisites

- IntelliJ IDEA (Community or Ultimate — remote debugging works in both)
- The project opened as a **Maven project** (File > Open > select the root `pom.xml` > Open as Project). This ensures all three modules (`const-catalog-core`, `const-catalog-backend`, `const-catalog-cli`) are resolved on the classpath and source navigation works across module boundaries.
- The backend JVM running with JDWP enabled (Docker, local, or remote — see [parent guide](Remote_Debugging_Guide.md))

### 1.2 Importing the Project

If you haven't opened the project yet:

1. **File > Open**
2. Navigate to the root directory (the one containing `pom.xml`, `docker-compose.yml`, and the three module directories)
3. Select the root `pom.xml`
4. When prompted, choose **Open as Project**
5. IntelliJ will detect the Maven structure and import all three modules

```mermaid
flowchart TD
    A["File > Open"] --> B["Select root pom.xml"]
    B --> C["Open as Project"]
    C --> D["Maven auto-import resolves<br/>core, backend, cli modules"]
    D --> E["All source roots indexed<br/>Breakpoints work across modules"]
```

> **Tip:** If IntelliJ does not prompt "Open as Project" and instead opens the POM as a text file, close it and use **File > Open** on the root *directory* instead. IntelliJ will detect the `pom.xml` inside and offer to import it as a Maven project.

Wait for the Maven import to finish (progress bar in the bottom status bar). Once complete, you should see all three modules in the Project tool window.

### 1.3 Creating the Remote Debug Configuration

1. Open **Run > Edit Configurations...** (or click the configuration dropdown in the toolbar and select **Edit Configurations...**)
2. Click the **+** button in the top-left corner of the dialog
3. Look for the remote debug template in the list that appears:

| IntelliJ Version          | Template Name          | Where to Find It                                                                 |
|---------------------------|------------------------|----------------------------------------------------------------------------------|
| **2022.3 and newer**      | `Remote JVM Debug`     | Listed alphabetically in the template list under "R"                              |
| **2021.x and older**      | `Remote`               | Listed alphabetically under "R"                                                   |
| **Any version (if you can't find it)** | —           | Type `remote` in the **search/filter field** at the top of the template list — it will narrow the list down immediately |

> **Note:** If you are using IntelliJ IDEA **Community Edition**, the remote debug template is included — it is not an Ultimate-only feature. If the template is missing entirely, go to **File > Settings > Plugins** and confirm the **Java** bundled plugin is enabled.

You will see a form with several fields. Fill them in as follows:

| Field                           | Value                        | Explanation                                                                                      |
|---------------------------------|------------------------------|--------------------------------------------------------------------------------------------------|
| **Name**                        | `Backend (Docker)`           | A descriptive label — appears in the Run/Debug dropdown. Use names that distinguish scenarios.    |
| **Debugger mode**               | `Attach to remote JVM`       | The JVM is the server; IntelliJ connects to it. This is the standard mode.                        |
| **Transport**                   | `Socket`                     | TCP socket — matches the `dt_socket` in the JDWP flag.                                            |
| **Host**                        | `localhost`                  | The machine where the JVM is running. Use `localhost` for Docker or local runs. For remote servers behind an SSH tunnel, this is still `localhost`. |
| **Port**                        | `5005`                       | Must match the port in the JDWP `address=*:5005` flag and the Docker port mapping.                |
| **Use module classpath**        | `const-catalog-backend`      | Tells IntelliJ which module's compiled classes to map against the running JVM's classes. This is what makes breakpoints resolve correctly. |
| **Command line arguments for remote JVM** | *(read-only display)*  | IntelliJ shows the JDWP flag you would need on the JVM. Useful for reference but already configured in our `docker-compose.yml`. |

> **Tip:** The "Use module classpath" dropdown matters. If you're debugging code in `const-catalog-core` (e.g., `JavaFileParser`), you might think you need to select `const-catalog-core` here. You don't — the backend module depends on core, so its classpath already includes core's classes. Select `const-catalog-backend`.

4. Click **Apply**, then **OK**.

### 1.4 Creating Multiple Configurations

You will likely want more than one debug configuration. Create separate entries for each scenario:

| Configuration Name          | Host        | Port | Module Classpath         | When to Use                                      |
|-----------------------------|-------------|------|--------------------------|--------------------------------------------------|
| `Backend (Docker)`          | `localhost` | 5005 | `const-catalog-backend`  | Normal development — Docker stack running         |
| `Backend (Local)`           | `localhost` | 5005 | `const-catalog-backend`  | Running `mvn spring-boot:run` with JDWP           |
| `Backend (Remote Dev VM)`   | `localhost` | 5005 | `const-catalog-backend`  | SSH tunnel forwarding from a remote server        |
| `CLI Debugger`              | `localhost` | 5005 | `const-catalog-cli`      | Debugging the CLI shaded JAR with `suspend=y`     |

The host and port are often the same — the **Name** and **module classpath** are what differ.

### 1.5 Attaching the Debugger

1. Start the target JVM (e.g., `docker compose up -d`)
2. Select your debug configuration from the dropdown in the toolbar
3. Click the **Debug** button (green bug icon), or press **Shift+F9**

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant IJ as IntelliJ IDEA
    participant JVM as Backend JVM<br/>(Docker)

    Dev->>JVM: docker compose up -d
    Note over JVM: JDWP listening on :5005
    Dev->>IJ: Select "Backend (Docker)"<br/>Click Debug
    IJ->>JVM: TCP connect to localhost:5005
    JVM-->>IJ: JDWP handshake
    Note over IJ: "Connected to the target VM,<br/>address: 'localhost:5005'"
    Dev->>IJ: Set breakpoint in ScanService.java
    IJ->>JVM: Install breakpoint
    Note over Dev: Trigger a scan via the UI or curl
    JVM-->>IJ: Thread suspended at breakpoint
    Note over IJ: Variables, call stack,<br/>watches all visible
```

The **Debug** tool window will open at the bottom of the screen with the message:

```
Connected to the target VM, address: 'localhost:5005', transport: 'socket'
```

### 1.6 Setting Breakpoints

Click in the **gutter** (the gray margin to the left of the line numbers) on any executable line. A red dot appears. Breakpoints work in any module whose source is on the classpath:

| Module                 | Example Classes                                          |
|------------------------|----------------------------------------------------------|
| `const-catalog-backend`| `ScanService`, `QueryController`, `GraphPopulatorService`, `GitService` |
| `const-catalog-core`   | `JavaFileParser`, `ConfigLookupTransformer`, `ProjectScanner`            |

**Conditional breakpoints:** Right-click a breakpoint dot and enter a condition expression. For example, on a line inside a loop in `GraphPopulatorService`:

```java
constantNode.getName().equals("MAX_RETRIES")
```

The debugger will only stop when that specific constant is being processed.

**Log breakpoints (non-suspending):** Right-click a breakpoint, uncheck **Suspend**, and check **Log > "Breakpoint hit" message** or **Evaluate and log**. This prints to the Debug console without pausing execution — useful for tracing control flow in a long scan without halting the process.

### 1.7 Using the Debug Tool Window

Once the debugger hits a breakpoint, the Debug tool window shows several panels:

| Panel          | What It Shows                                                                                    |
|----------------|--------------------------------------------------------------------------------------------------|
| **Frames**     | The call stack of the suspended thread. Click any frame to see local variables at that level.     |
| **Variables**  | All local variables and fields in scope at the current line. Expand objects to inspect their fields. |
| **Watches**    | Expressions you want to evaluate on every stop. Right-click > Add Watch, or type in the field.   |
| **Console**    | The raw JDWP connection output and any log-breakpoint messages.                                   |

**Key actions** (toolbar buttons or keyboard shortcuts):

| Action                | Shortcut (default) | What It Does                                                              |
|-----------------------|---------------------|---------------------------------------------------------------------------|
| **Step Over**         | F8                  | Execute the current line and stop at the next line in the same method.     |
| **Step Into**         | F7                  | Step into the method call on the current line.                             |
| **Step Out**          | Shift+F8            | Run until the current method returns, then stop in the caller.             |
| **Resume**            | F9                  | Continue execution until the next breakpoint (or program ends).            |
| **Evaluate Expression** | Alt+F8           | Opens a dialog where you can type any Java expression and evaluate it in the current context. |
| **Drop Frame**        | *(no default)*      | Re-enter the current method from the beginning. Useful for re-testing logic without restarting. Note: side effects (DB writes, file I/O) are not rolled back. |

### 1.8 Evaluate Expression

**Alt+F8** (or right-click > Evaluate Expression) is one of the most powerful debugging features. You can:

- Inspect any variable: `scanRequest.getProjectPath()`
- Call methods: `constantRepository.findByName("MAX_RETRIES")`
- Test transformations: `configLookupTransformer.buildLookupCall("MAX_RETRIES", "int")`
- Check Spring beans: `applicationContext.getBean(SiteConfigurationService.class)`

The expression is evaluated in the context of the current stack frame, with access to all local variables and `this`.

### 1.9 Hot Swap (Modifying Code While Debugging)

IntelliJ supports **HotSwap** — recompiling a class and replacing it in the running JVM without restarting:

1. Edit a method body while the debugger is attached
2. **Build > Build Project** (Ctrl+F9)
3. IntelliJ will ask: *"Reload changed classes?"* — click **Yes**

**Limitations:**
- You can change **method bodies** only. Adding/removing methods, fields, or classes requires a restart.
- HotSwap works best with the full JDK. Our Docker runtime image uses `eclipse-temurin:21-jre` (JRE only), which limits HotSwap. For full HotSwap support when running locally, ensure your `JAVA_HOME` points to a JDK, not a JRE.
- Consider [DCEVM](https://dcevm.github.io/) or [JRebel](https://www.jrebel.com/) for advanced hot-reload that supports structural changes.

### 1.10 Disconnecting

To disconnect the debugger **without stopping the JVM**:

- Click the **Disconnect** button (red square with a line through it) in the Debug tool window
- Or go to **Run > Stop** — IntelliJ will ask whether to disconnect or terminate. Choose **Disconnect**.

The backend continues running. You can re-attach at any time by clicking Debug again.

### 1.11 Troubleshooting

| Problem                                          | Cause                                                    | Fix                                                                                                  |
|--------------------------------------------------|----------------------------------------------------------|------------------------------------------------------------------------------------------------------|
| "Connection refused" on attach                   | JVM not running or JDWP not enabled                      | Verify `docker compose ps` shows the backend as running. Check logs for `Listening for transport dt_socket`. |
| Breakpoint shows as gray with an "X"             | Source/class mismatch                                    | Rebuild the project (`mvn clean install -DskipTests`), then re-import Maven (Ctrl+Shift+O).           |
| "Unable to open debugger port"                   | Port 5005 already in use                                 | Run `lsof -i :5005` (Linux/Mac) or `netstat -ano | findstr 5005` (Windows) to find the conflict.     |
| Variables show as "collecting data..." forever    | Thread is not actually suspended                         | Ensure you hit a real breakpoint. Check the Frames panel — if no frames, the thread is still running.  |
| Breakpoints in core module don't trigger          | Module classpath not set or source not on classpath      | Confirm "Use module classpath" is `const-catalog-backend` and that Maven import completed successfully. |

---

## Part 2: Visual Studio Code

### 2.1 Prerequisites

VS Code requires extensions for Java development and debugging. Install the following from the Extensions marketplace (Ctrl+Shift+X):

| Extension                         | Publisher   | Purpose                                    |
|-----------------------------------|-------------|--------------------------------------------|
| **Language Support for Java**     | Red Hat     | Syntax, navigation, Maven integration       |
| **Debugger for Java**             | Microsoft   | JDWP debug adapter for VS Code              |
| **Extension Pack for Java**       | Microsoft   | Convenient bundle that includes both above plus Test Runner, Maven, and Project Manager |

> **Recommended:** Install the **Extension Pack for Java** — it includes everything you need in a single install.

```mermaid
flowchart LR
    A["Extensions (Ctrl+Shift+X)"] --> B["Search: Extension Pack for Java"]
    B --> C["Install"]
    C --> D["Reload VS Code"]
    D --> E["Java support active<br/>Maven auto-detected"]
```

### 2.2 Opening the Project

1. **File > Open Folder...** (Ctrl+K Ctrl+O)
2. Select the root project directory (the one containing the root `pom.xml`)
3. VS Code's Java extension will detect the Maven structure and begin indexing

The first time you open the project, the Java Language Server will download dependencies and build the workspace. This can take a few minutes. Watch the status bar for progress.

Once complete, the **Java Projects** view in the Explorer sidebar will show all three modules:

```
JAVA PROJECTS
├── const-catalog-parent
│   ├── const-catalog-core
│   ├── const-catalog-backend
│   └── const-catalog-cli
```

### 2.3 Creating the Launch Configuration

VS Code stores debug configurations in `.vscode/launch.json`. You can create this file manually or through the UI.

**Option A: Through the UI**

1. Open the **Run and Debug** sidebar (Ctrl+Shift+D)
2. Click **create a launch.json file**
3. Select **Java** as the environment
4. VS Code generates a template. Replace it or add the remote attach configuration.

**Option B: Manual creation**

Create or edit `.vscode/launch.json` in the project root:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "java",
      "name": "Attach to Backend (Docker)",
      "request": "attach",
      "hostName": "localhost",
      "port": 5005,
      "projectName": "const-catalog-backend",
      "sourcePaths": [
        "const-catalog-backend/src/main/java",
        "const-catalog-core/src/main/java"
      ]
    },
    {
      "type": "java",
      "name": "Attach to Backend (Local)",
      "request": "attach",
      "hostName": "localhost",
      "port": 5005,
      "projectName": "const-catalog-backend"
    },
    {
      "type": "java",
      "name": "Attach to CLI",
      "request": "attach",
      "hostName": "localhost",
      "port": 5005,
      "projectName": "const-catalog-cli"
    }
  ]
}
```

**Field-by-field explanation:**

| Field           | Value                        | Explanation                                                                                          |
|-----------------|------------------------------|------------------------------------------------------------------------------------------------------|
| `type`          | `"java"`                     | Tells VS Code to use the Java debug adapter.                                                          |
| `name`          | `"Attach to Backend (Docker)"` | The label shown in the debug configuration dropdown.                                                |
| `request`       | `"attach"`                   | We're attaching to an already-running JVM, not launching one. This is the key setting for remote debug. |
| `hostName`      | `"localhost"`                | Where the JVM is listening. Use `localhost` for Docker, local runs, and SSH-tunneled remote servers.   |
| `port`          | `5005`                       | Must match the JDWP port configured on the JVM and exposed in Docker.                                 |
| `projectName`   | `"const-catalog-backend"`    | Maps to the Maven artifact ID. Tells the debug adapter which compiled classes to use for source resolution. |
| `sourcePaths`   | `[...]` *(optional)*         | Explicit source directories to search. Useful when you want breakpoints in `const-catalog-core` classes while attached to the backend. Usually auto-resolved, but listing them explicitly guarantees cross-module breakpoints work. |

### 2.4 Attaching the Debugger

1. Start the target JVM (e.g., `docker compose up -d`)
2. Open the **Run and Debug** sidebar (Ctrl+Shift+D)
3. Select **Attach to Backend (Docker)** from the dropdown at the top
4. Click the green **Start Debugging** play button, or press **F5**

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant VSC as VS Code
    participant JVM as Backend JVM<br/>(Docker)

    Dev->>JVM: docker compose up -d
    Note over JVM: JDWP listening on :5005
    Dev->>VSC: Ctrl+Shift+D<br/>Select config, press F5
    VSC->>JVM: TCP connect to localhost:5005
    JVM-->>VSC: JDWP handshake
    Note over VSC: Debug toolbar appears<br/>Status bar turns orange
    Dev->>VSC: Set breakpoint in QueryService.java
    VSC->>JVM: Install breakpoint
    Note over Dev: Execute a query via the UI
    JVM-->>VSC: Thread suspended at breakpoint
    Note over VSC: Variables, call stack,<br/>watch expressions visible
```

When connected, the **status bar** at the bottom of VS Code turns **orange** and the debug toolbar appears at the top of the editor.

### 2.5 Setting Breakpoints

Click in the **gutter** to the left of a line number. A red dot appears. Breakpoints work in any `.java` file that the Java Language Server has indexed:

- Backend classes: `ScanService.java`, `GraphPopulatorService.java`, `GitService.java`
- Core classes: `JavaFileParser.java`, `ConfigLookupTransformer.java`, `ProjectScanner.java`

**Conditional breakpoints:** Right-click a breakpoint > **Edit Breakpoint...** > enter an expression:

```java
constantNode.getName().equals("DATABASE_URL")
```

**Logpoints (non-suspending):** Right-click in the gutter > **Add Logpoint...**. Enter a message using `{}` for expressions:

```
Processing constant: {constantNode.getName()} in file: {fileNode.getPath()}
```

This logs to the Debug Console without pausing — ideal for tracing a full scan.

**Hit count breakpoints:** Right-click a breakpoint > **Edit Breakpoint...** > **Hit Count** > enter a number. The breakpoint will only trigger after being hit that many times. Useful inside loops.

### 2.6 The Debug Sidebar Panels

When the debugger pauses at a breakpoint, the Run and Debug sidebar shows:

| Panel           | What It Shows                                                                                    |
|-----------------|--------------------------------------------------------------------------------------------------|
| **Variables**   | Local variables, `this` fields, and method arguments at the current frame. Expand objects to drill into nested fields. |
| **Watch**       | Expressions you add manually. Click **+** to add a watch like `scanRequest.getProjectPath()`. Re-evaluated on every stop. |
| **Call Stack**  | The full call chain leading to the current line. Click any frame to jump to that point in the code and see its variables. |
| **Breakpoints** | A list of all breakpoints across all files. Toggle them on/off, remove, or edit conditions from here. |

### 2.7 The Debug Toolbar

The floating toolbar at the top of the editor provides the core stepping controls:

| Button          | Shortcut | What It Does                                                                |
|-----------------|----------|-----------------------------------------------------------------------------|
| **Continue**    | F5       | Resume execution until the next breakpoint.                                  |
| **Step Over**   | F10      | Execute the current line and move to the next line in the same method.       |
| **Step Into**   | F11      | Step into the method call on the current line.                               |
| **Step Out**    | Shift+F11| Run until the current method returns, then pause in the caller.              |
| **Restart**     | Ctrl+Shift+F5 | Disconnect and immediately re-attach (useful if you restart the JVM).  |
| **Stop**        | Shift+F5 | Disconnect from the JVM. The JVM continues running.                          |

### 2.8 Debug Console (Evaluate Expressions)

The **Debug Console** at the bottom of the screen (next to the Terminal tab) is VS Code's equivalent of IntelliJ's Evaluate Expression. When paused at a breakpoint:

1. Click into the Debug Console input field
2. Type any Java expression and press Enter

Examples:

```java
scanRequest.getProjectPath()
constantRepository.findByName("MAX_RETRIES")
this.getClass().getSimpleName()
java.lang.System.getProperty("java.version")
```

The result is printed inline. You can evaluate complex expressions, call methods, and inspect return values — all in the context of the current stack frame.

### 2.9 Multi-Module Source Navigation

When you set a breakpoint in `QueryController` (backend) and it calls into `JavaFileParser` (core), the debugger will **Step Into** the core code seamlessly — provided the Java Language Server has indexed both modules. If stepping into a core class opens a decompiled `.class` file instead of the `.java` source:

1. Check that the root `pom.xml` was loaded (Java Projects sidebar shows all three modules)
2. Add the core source path explicitly in your launch configuration:

```json
"sourcePaths": [
  "const-catalog-core/src/main/java",
  "const-catalog-backend/src/main/java"
]
```

3. Reload the window (Ctrl+Shift+P > **Developer: Reload Window**)

### 2.10 Useful VS Code Settings for Java Debugging

Open **Settings** (Ctrl+,) and search for these:

| Setting                                    | Recommended Value | Why                                                                      |
|--------------------------------------------|-------------------|--------------------------------------------------------------------------|
| `java.debug.settings.stepping.skipClasses` | Add `java.*`, `javax.*`, `sun.*` | Prevents Step Into from diving into JDK internals. Focus on your code.   |
| `java.debug.settings.hotCodeReplace`       | `auto`            | Automatically applies code changes when you save, if the JVM supports it. |
| `java.debug.settings.showHex`              | `false`           | Set to `true` if you're debugging binary data or byte arrays.             |
| `java.debug.settings.showQualifiedNames`   | `false`           | `true` shows fully-qualified class names in the Variables panel. Verbose but precise. |

To configure `skipClasses`, add this to your `.vscode/launch.json` configuration:

```json
{
  "type": "java",
  "name": "Attach to Backend (Docker)",
  "request": "attach",
  "hostName": "localhost",
  "port": 5005,
  "projectName": "const-catalog-backend",
  "stepping": {
    "skipClasses": [
      "$JDK",
      "org.springframework.*",
      "org.neo4j.driver.*"
    ]
  }
}
```

This keeps **Step Into** focused on your application code and skips framework internals.

### 2.11 Troubleshooting

| Problem                                             | Cause                                                    | Fix                                                                                                        |
|-----------------------------------------------------|----------------------------------------------------------|------------------------------------------------------------------------------------------------------------|
| F5 shows "Could not find a debug adapter"           | Java extensions not installed or not activated            | Install **Extension Pack for Java**. Reload VS Code.                                                        |
| "Connection refused" on attach                      | JVM not running or JDWP not enabled                      | `docker compose ps` to check. Look for `Listening for transport dt_socket` in `docker compose logs backend`. |
| Breakpoint is grayed out ("Unverified breakpoint")  | Source doesn't match compiled classes                    | Run `mvn clean install -DskipTests`, then Ctrl+Shift+P > **Java: Clean Language Server Workspace**.          |
| Step Into opens decompiled `.class` file            | Source path not resolved for that module                 | Add `sourcePaths` to your launch config (see Section 2.9).                                                   |
| Variables panel shows "not available"               | Frame is in a library or JDK class without debug info    | Step Out to return to your code. Or add `-g` flag to maven-compiler-plugin for full debug symbols.           |
| Debug Console says "evaluation failed"              | Expression uses a variable not in scope at current frame | Click the correct frame in the Call Stack panel first, then evaluate.                                        |
| Java Language Server takes too long to index         | Large project or slow disk                               | Wait for the progress bar to complete. Close other heavy projects. Check `java.jdt.ls.vmargs` memory settings. |

---

## Summary: IntelliJ vs VS Code at a Glance

| Capability                  | IntelliJ IDEA                          | VS Code                                          |
|-----------------------------|----------------------------------------|---------------------------------------------------|
| **Setup effort**            | Built-in, no extensions needed         | Requires Extension Pack for Java                   |
| **Configuration**           | Run/Debug Configurations dialog        | `.vscode/launch.json` file                         |
| **Attach shortcut**         | Shift+F9 (Debug)                       | F5 (Start Debugging)                               |
| **Evaluate expression**     | Alt+F8 dialog                          | Debug Console input                                |
| **Conditional breakpoints** | Right-click breakpoint dot             | Right-click breakpoint > Edit Breakpoint           |
| **Log breakpoints**         | "Evaluate and log" option              | Logpoints (right-click gutter)                     |
| **Step filter**             | Settings > Debugger > Stepping         | `stepping.skipClasses` in launch.json              |
| **Hot code replace**        | Build > Build Project (Ctrl+F9)        | Auto on save (if `hotCodeReplace: auto`)           |
| **Multi-module source**     | Automatic via Maven import             | May need explicit `sourcePaths`                    |
| **Disconnect**              | Disconnect button in Debug window      | Shift+F5 (Stop) — JVM keeps running               |

Both IDEs connect to the same JDWP port using the same protocol. The debugging experience — breakpoints, stepping, variable inspection, expression evaluation — is functionally identical. Choose whichever IDE you are most productive in.
