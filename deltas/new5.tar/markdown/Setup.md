# Constants Catalog - Setup Guide

## Philosophy: Why Not Just Now?

Before we dive into installation steps, consider this question that haunts every software project:

**"Why didn't we do this sooner?"**

Every team that scans their codebase for configuration debt asks this question. The constants have been there for years. The hardcoded URLs, the magic numbers, the passwords that should never have been committed—they've been accumulating interest like technical debt always does.

The answer is always the same: **because we thought we'd do it later.**

```mermaid
graph TB
    subgraph "The Procrastination Spiral"
        NOW[Now: 50 hardcoded values] -->|"We'll fix it later"| LATER1[3 months: 150 values]
        LATER1 -->|"After this sprint"| LATER2[6 months: 400 values]
        LATER2 -->|"When we have time"| LATER3[1 year: 1000+ values]
        LATER3 -->|"It's too big now"| NEVER[Never: Technical Bankruptcy]
    end

    subgraph "The Alternative"
        NOW2[Now: 50 hardcoded values] -->|"Why not just now?"| SCAN[Scan Today]
        SCAN --> VISIBLE[See the problem]
        VISIBLE --> FIX[Fix incrementally]
        FIX --> HABIT[Make it a habit]
    end

    style NEVER fill:#e74c3c,stroke:#333,color:#fff
    style NOW fill:#f39c12,stroke:#333,color:#000
    style HABIT fill:#27ae60,stroke:#333,color:#fff
```

This tool takes less time to set up than a coffee break. **Why not just now?**

---

## System Requirements

```mermaid
flowchart LR
    subgraph "Required"
        JAVA[Java 21+]
        MAVEN[Maven 3.8+]
        DOCKER[Docker & Compose]
    end

    subgraph "For Frontend Dev"
        NODE[Node.js 18+]
        NPM[npm/yarn]
    end

    subgraph "Provided by Docker"
        NEO4J[(Neo4J 5.x)]
    end

    JAVA --> BUILD[Build Project]
    MAVEN --> BUILD
    BUILD --> DOCKER
    DOCKER --> NEO4J

    style JAVA fill:#5382a1,stroke:#333,color:#fff
    style MAVEN fill:#c71a36,stroke:#333,color:#fff
    style DOCKER fill:#2496ed,stroke:#333,color:#fff
    style NEO4J fill:#008cc1,stroke:#333,color:#fff
```

### Verification Commands

```bash
# Check Java version (need 21+)
java -version

# Check Maven version (need 3.8+)
mvn -version

# Check Docker is running
docker info

# Check Node.js for frontend development
node --version
```

---

## Quick Start: 5 Minutes to First Scan

The fastest path from zero to insight.

```mermaid
flowchart LR
    subgraph "5 Minutes"
        A[1. Clone] --> B[2. Build]
        B --> C[3. Docker Up]
        C --> D[4. Scan]
        D --> E[5. Explore]
    end

    A -.- T1[30 sec]
    B -.- T2[2 min]
    C -.- T3[1 min]
    D -.- T4[30 sec]
    E -.- T5[forever]

    style E fill:#27ae60,stroke:#333,color:#fff
```

### Step 1: Clone & Navigate

```bash
cd const-catalog
```

### Step 2: Build All Modules

```bash
mvn clean install -DskipTests
```

This produces three artifacts:

| Artifact | Location | Purpose |
|----------|----------|---------|
| `const-catalog-core` | `const-catalog-core/target/*.jar` | Parsing engine |
| `const-catalog-backend` | `const-catalog-backend/target/*.jar` | REST API server |
| `const-catalog-cli` | `const-catalog-cli/target/*-shaded.jar` | Standalone CLI |

### Step 3: Start Infrastructure

```bash
docker-compose up -d
```

```mermaid
flowchart TB
    subgraph "Docker Compose Stack"
        subgraph "neo4j"
            NEO4J[(Neo4J)]
            NEO4J -.- P1[":7474 Browser"]
            NEO4J -.- P2[":7687 Bolt"]
        end

        subgraph "backend"
            BE[Spring Boot API]
            BE -.- P3[":8080 REST"]
        end

        subgraph "frontend"
            FE[React + nginx]
            FE -.- P4[":3000 Web UI"]
        end

        FE -->|/api/*| BE
        BE -->|bolt://| NEO4J
    end

    style NEO4J fill:#008cc1,stroke:#333,color:#fff
    style BE fill:#6db33f,stroke:#333,color:#fff
    style FE fill:#61dafb,stroke:#333,color:#000
```

### Step 4: Verify Health

```bash
# Check all containers are running
docker-compose ps

# Check backend health
curl http://localhost:8080/api/stats/health
```

Expected response:
```json
{"status":"healthy","database":"connected","projectCount":0}
```

### Step 5: Open the UI

Navigate to [http://localhost:3000](http://localhost:3000)

---

## Alternative: CLI-Only Setup

Don't need the full stack? Just want to scan and export CSV?

```mermaid
flowchart LR
    subgraph "Minimal Setup"
        BUILD[mvn install -pl const-catalog-core,const-catalog-cli] --> CLI[CLI JAR]
        CLI --> SCAN[Scan Project]
        SCAN --> CSV[CSV Files]
        CSV --> NEO4J[(Manual Import<br/>to Neo4J)]
    end

    style CLI fill:#9b59b6,stroke:#333,color:#fff
    style CSV fill:#f1c40f,stroke:#333,color:#000
```

```bash
# Build only core and CLI modules
mvn clean install -pl const-catalog-core,const-catalog-cli -DskipTests

# Run the CLI
java -jar const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT-shaded.jar /path/to/your/project
```

Output appears in `/path/to/your/project/neo4j-export/`:
- `constants.csv`
- `parameters.csv`
- `files.csv`
- `constant_in_file.csv`
- `parameter_defined_in.csv`
- `parameter_used_in.csv`
- `import-neo4j.cypher`

---

## Configuration Reference

### Docker Compose Environment Variables

```mermaid
flowchart TB
    subgraph "Environment Configuration"
        subgraph "Neo4J"
            N1[NEO4J_AUTH=neo4j/password]
            N2[NEO4J_PLUGINS=apoc]
        end

        subgraph "Backend"
            B1[SPRING_NEO4J_URI=bolt://neo4j:7687]
            B2[SPRING_NEO4J_AUTHENTICATION_USERNAME=neo4j]
            B3[SPRING_NEO4J_AUTHENTICATION_PASSWORD=password]
        end

        subgraph "Frontend"
            F1[VITE_API_URL=/api]
        end
    end
```

### Application Properties (Backend)

| Property | Default | Description |
|----------|---------|-------------|
| `spring.neo4j.uri` | `bolt://localhost:7687` | Neo4J connection URI |
| `spring.neo4j.authentication.username` | `neo4j` | Database username |
| `spring.neo4j.authentication.password` | `password` | Database password |
| `server.port` | `8080` | REST API port |

### Overriding Configuration

```bash
# Via environment variables
export SPRING_NEO4J_URI=bolt://custom-host:7687
java -jar const-catalog-backend/target/*.jar

# Via command line
java -jar const-catalog-backend/target/*.jar --spring.neo4j.uri=bolt://custom-host:7687
```

---

## Development Setup

For contributors and customizers.

```mermaid
flowchart TB
    subgraph "Development Environment"
        subgraph "Terminal 1: Database"
            DB[docker-compose up neo4j]
        end

        subgraph "Terminal 2: Backend"
            BE[cd const-catalog-backend<br/>mvn spring-boot:run]
        end

        subgraph "Terminal 3: Frontend"
            FE[cd const-catalog-frontend<br/>npm install<br/>npm run dev]
        end

        FE -->|:3000 → :8080| BE
        BE -->|:8080 → :7687| DB
    end

    BROWSER[Browser :3000] --> FE

    style DB fill:#008cc1,stroke:#333,color:#fff
    style BE fill:#6db33f,stroke:#333,color:#fff
    style FE fill:#61dafb,stroke:#333,color:#000
```

### Backend Development

```bash
# Start only Neo4J
docker-compose up -d neo4j

# Run backend with hot reload
cd const-catalog-backend
mvn spring-boot:run -Dspring-boot.run.jvmArguments="-Dspring.devtools.restart.enabled=true"
```

### Frontend Development

```bash
cd const-catalog-frontend
npm install
npm run dev
```

The Vite dev server proxies `/api/*` to `localhost:8080`.

### Running Tests

```bash
# All tests
mvn test

# Core module only (57 tests)
mvn test -pl const-catalog-core

# With coverage report
mvn test jacoco:report
```

---

## Troubleshooting

### Common Issues

```mermaid
flowchart TD
    subgraph "Problem → Solution"
        P1[Port 7687 in use] --> S1[Stop other Neo4J instances<br/>or change port in docker-compose.yml]

        P2[Backend can't connect to Neo4J] --> S2[Wait for Neo4J to fully start<br/>docker-compose logs neo4j]

        P3[CORS errors in browser] --> S3[Ensure frontend proxies /api<br/>Don't call backend directly]

        P4[Out of memory building] --> S4[export MAVEN_OPTS='-Xmx2g']

        P5[Java version mismatch] --> S5[Ensure JAVA_HOME points to Java 21+]
    end

    style S1 fill:#27ae60,stroke:#333,color:#fff
    style S2 fill:#27ae60,stroke:#333,color:#fff
    style S3 fill:#27ae60,stroke:#333,color:#fff
    style S4 fill:#27ae60,stroke:#333,color:#fff
    style S5 fill:#27ae60,stroke:#333,color:#fff
```

### Checking Logs

```bash
# All services
docker-compose logs -f

# Just backend
docker-compose logs -f backend

# Just Neo4J
docker-compose logs -f neo4j
```

### Resetting Everything

```bash
# Stop and remove containers, networks, volumes
docker-compose down -v

# Fresh start
docker-compose up -d
```

---

## Ports Summary

| Service | Port | Protocol | Purpose |
|---------|------|----------|---------|
| Frontend | 3000 | HTTP | Web UI |
| Backend | 8080 | HTTP | REST API |
| Neo4J Browser | 7474 | HTTP | Database admin UI |
| Neo4J Bolt | 7687 | Bolt | Database connection |

```mermaid
flowchart LR
    USER[User] -->|:3000| FE[Frontend]
    FE -->|:8080| BE[Backend]
    BE -->|:7687| NEO4J[(Neo4J)]
    ADMIN[Admin] -->|:7474| NEO4J

    style USER fill:#3498db,stroke:#333,color:#fff
    style ADMIN fill:#9b59b6,stroke:#333,color:#fff
```

---

## What's Next?

You've set up the tool. Now what?

```mermaid
flowchart LR
    SETUP[Setup Complete] --> SCAN[Scan a Project]
    SCAN --> EXPLORE[Explore Results]
    EXPLORE --> QUERY[Write Custom Queries]
    QUERY --> ACT[Take Action]

    ACT --> A1[Externalize configs]
    ACT --> A2[Remove dead params]
    ACT --> A3[Document sensitive values]

    style ACT fill:#27ae60,stroke:#333,color:#fff
```

See the [Tutorial](TUTORIAL.md) for a guided walkthrough of scanning, querying, and acting on results.

---

## Remember: Why Not Just Now?

You've read this far. The tool is ready. Your codebase is waiting.

Every day you delay, more constants accumulate. More developers hardcode "just this one thing." More configuration debt accrues interest.

The setup is done. The question isn't "should we catalog our constants?"

The question is: **why not just now?**

```bash
# Right now. This command. Your project.
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{"projectPath": "/path/to/your/project"}'
```
