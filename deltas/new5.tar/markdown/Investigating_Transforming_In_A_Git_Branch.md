# Investigating: "Create New Branch with Transformed Files Committed"

An investigation into whether the "Create new branch" checkbox on the Code Transformer page works in the Docker environment.

---

## Table of Contents

1. [What the Feature Does](#1-what-the-feature-does)
2. [Investigation Steps](#2-investigation-steps)
3. [Findings](#3-findings)
4. [Verdict](#4-verdict)
5. [Fixes Applied](#5-fixes-applied)

---

## 1. What the Feature Does

When the user checks "Create new branch with transformed files committed" and runs a live transform (dry run off), the backend:

1. Runs the transformation (or removal), writing modified files to `backups/`
2. Checks if the scanned project is a git repo (initializes one if not)
3. Gets the current branch name (e.g., `adding-constant-data`)
4. Creates a new branch named `<current-branch>-transformed`
5. Copies modified files from `backups/` back to the source directory
6. Commits all changes with `git add -A && git commit`
7. Switches back to the original branch

The frontend enforces mutual exclusion: checking "Create new branch" unchecks "Dry run", and vice versa. The request sends `createBranch: !dryRun && createBranch`.

---

## 2. Investigation Steps

### Test 1: Backend container working directory

```
$ docker exec const-catalog-backend pwd
/app
```

**Result:** The working directory is `/app`. This means `Path.of("backups").toAbsolutePath()` resolves to `/app/backups`.

### Test 2: Backups directory exists and is mounted

```
$ docker exec const-catalog-backend ls -la /app/backups/
total 8
drwxr-xr-x 2 root root 4096 Mar 11 11:58 .
drwxr-xr-x 1 root root 4096 Mar 23 01:42 ..
```

**Result:** The `backups/` directory exists. It's mounted from the host via `docker-compose.yml`: `./backups:/app/backups`.

### Test 3: Can the application write to the backups directory?

```
$ docker exec const-catalog-backend whoami
appuser

$ docker exec const-catalog-backend stat -c '%U:%G %a' /app/backups
root:root 755

$ docker exec const-catalog-backend touch /app/backups/test.txt
touch: cannot touch '/app/backups/test.txt': Permission denied
```

**Result: FAILURE.** The `backups/` directory is owned by `root:root` with permissions `755`. The application runs as `appuser` (a non-root user created in the Dockerfile for security). `appuser` is not in the `root` group, so it only has the "other" permission bits: read (4) and execute (1). No write permission.

This means the transformer cannot write backup files or modified files. Both `ConfigLookupTransformer.transformProject()` and `UnusedConstantRemover.removeFromProject()` will fail with an `IOException` when trying to create files in `/app/backups/`.

### Test 4: Can the application create git branches in the source directory?

```
$ docker exec const-catalog-backend stat -c '%U:%G %a' /src/java/soheili/constants
ubuntu:ubuntu 777

$ docker exec const-catalog-backend git -C /src/java/soheili/constants rev-parse --is-inside-work-tree
true

$ docker exec const-catalog-backend git -C /src/java/soheili/constants rev-parse --abbrev-ref HEAD
adding-constant-data

$ docker exec const-catalog-backend git -C /src/java/soheili/constants checkout -b test-branch-creation
Switched to a new branch 'test-branch-creation'

$ docker exec const-catalog-backend git -C /src/java/soheili/constants checkout adding-constant-data
Switched to branch 'adding-constant-data'

$ docker exec const-catalog-backend git -C /src/java/soheili/constants branch -d test-branch-creation
Deleted branch test-branch-creation
```

**Result: SUCCESS.** The source directory at `/src/java/soheili/constants` has permissions `777` (world-writable), so `appuser` can run git commands. The `safe.directory` git config is set to `*` in the Dockerfile, so git doesn't complain about ownership mismatch.

### Test 5: Git identity configuration

The `GitService.initRepoWithInitialCommit()` method sets a local `user.email` and `user.name` for repos that aren't yet initialized. But for existing repos (which is the common case), `addAndCommit()` calls `git commit` without ensuring an identity exists.

```
$ docker exec const-catalog-backend git -C /src/java/soheili/constants config user.email
```

No output — no local or global git identity is configured for `appuser` inside the container. The `git commit` would fail with:

```
Author identity unknown
*** Please tell me who you are.
```

This would only be an issue for existing repos. The `initRepoWithInitialCommit()` path sets a local identity, so newly initialized repos are fine.

### Test 6: Frontend mutual exclusion

The frontend correctly enforces that "Create new branch" and "Dry run" cannot both be true:

- Checking "Dry run" unchecks "Create branch" (`if (e.target.checked) setCreateBranch(false)`)
- Checking "Create branch" unchecks "Dry run" (`if (e.target.checked) setDryRun(false)`)
- The checkbox is disabled when dry run is on (`disabled={dryRun}`)
- The request enforces it again: `createBranch: !dryRun && createBranch`

**Result: CORRECT.** The UI properly prevents the impossible combination.

### Test 7: Code path review — `createBranchWithTransformedFiles()`

The method copies files from `backups/<relative-path>` back to the original source path. It uses:

```java
Path absSource = Paths.get(filePath).toAbsolutePath();
Path relPath = absSource.getRoot().relativize(absSource);
Path backupPath = backupsDir.resolve(relPath);
```

For a file at `/src/java/soheili/constants/SomeClass.java`:
- `absSource` = `/src/java/soheili/constants/SomeClass.java`
- `relPath` = `src/java/soheili/constants/SomeClass.java` (root `/` stripped)
- `backupPath` = `/app/backups/src/java/soheili/constants/SomeClass.java`

This path logic is correct — the same relativization is used in both the write step (transformer) and the read step (branch creation), so the files will be found.

---

## 3. Findings

### Issue 1: Backups directory not writable (BLOCKING)

**Severity:** The feature will not work at all.

The `/app/backups` directory is owned by `root:root` with `755` permissions. The application runs as `appuser`. Any transform (live or dry) that writes to backups will fail with a permission error.

**Root cause:** The `docker-compose.yml` mounts `./backups:/app/backups`. When Docker creates the host directory, it's owned by root. The Dockerfile switches to `appuser` but doesn't change the backups directory ownership.

**Fix:** In the Dockerfile, ensure `appuser` owns the backups directory. Add before the `USER appuser` line:

```dockerfile
RUN mkdir -p /app/backups && chown appuser:appgroup /app/backups
```

Or, on the host, change the backups directory permissions:

```bash
chmod 777 backups/
```

### Issue 2: Missing git identity for existing repos (BLOCKING for commit step)

**Severity:** Branch creation and checkout work, but the `git commit` will fail.

`GitService.addAndCommit()` runs `git commit -m "..."` without ensuring a user identity exists. In the container, `appuser` has no global `~/.gitconfig`. For newly initialized repos, `initRepoWithInitialCommit()` sets a local identity, but for existing repos, no identity is set.

**Fix:** Set a git identity in `addAndCommit()` before committing, or set it globally in the Dockerfile:

```dockerfile
RUN mkdir -p /home/appuser && \
    git config --system --add safe.directory '*' && \
    git config --system user.email "const-catalog@tool.local" && \
    git config --system user.name "Const Catalog"
```

### Issue 3: `git add -A` stages everything (LOW RISK)

`GitService.addAndCommit()` runs `git add -A`, which stages all changes in the repo — not just the transformed files. If the working tree has other uncommitted changes (which it does, as seen from the extensive `git checkout` output showing modified files), those changes would be included in the commit.

This could be a problem for this project specifically since the branch `adding-constant-data` has many uncommitted changes. A transform commit would accidentally include all of them.

**Fix:** The `addAndCommit()` method should stage only the specific files that were transformed, not everything. The `createBranchWithTransformedFiles()` method already has the list of transformed file paths in the `transformedFiles` set — it could pass these to a more targeted `addFiles()` method.

---

## 4. Verdict

**The "Create new branch" feature does not currently work in the Docker environment** due to two blocking issues:

1. **The backups directory is not writable by `appuser`** — the transform fails before it even gets to the git branch step
2. **No git identity is configured for `appuser`** — even if the backups issue were fixed, `git commit` would fail

Additionally, `git add -A` staging all changes (not just transformed files) is a correctness issue that could lead to unintended commits.

The feature's code logic (path handling, branch creation, rollback on failure, frontend mutual exclusion) is otherwise correct.

---

## 5. Fixes Applied

All three issues have been fixed. This section documents each change with before/after code and the reasoning.

### Fix 1: Backups Directory Ownership

**File:** `const-catalog-backend/Dockerfile`

**Before (lines 45–47):**
```dockerfile
# Trust all mounted git repos (ownership differs from appuser)
RUN mkdir -p /home/appuser && \
    git config --system --add safe.directory '*'
```

**After (lines 45–52):**
```dockerfile
# Create writable backups directory owned by appuser
RUN mkdir -p /app/backups && chown appuser:appgroup /app/backups

# Trust all mounted git repos (ownership differs from appuser) and
# set a system-wide git identity so commits work without ~/.gitconfig
RUN mkdir -p /home/appuser && \
    git config --system --add safe.directory '*' && \
    git config --system user.email "const-catalog@tool.local" && \
    git config --system user.name "Const Catalog"
```

**Why `mkdir -p /app/backups && chown appuser:appgroup /app/backups`:**

The backups directory is created *inside the Docker image* and owned by `appuser:appgroup` before the `USER appuser` directive switches the runtime user. This ensures the application can write to `/app/backups` regardless of how the host volume is mounted.

When `docker-compose.yml` mounts `./backups:/app/backups`, Docker creates the host `./backups` directory as root if it doesn't exist. The mount overlays the container's `/app/backups`, so the container sees the host directory's permissions. However, the `chown` in the Dockerfile ensures that if the volume is *not* mounted (e.g., running the image standalone), the directory is still writable.

For the Docker Compose case, the host `./backups` directory also needs to be writable. Since the host directory is created by Docker as root, you may still need to run `chmod 777 backups/` on the host the first time. After that, the application can write freely.

**Why `git config --system user.email` and `git config --system user.name`:**

The `--system` flag writes to `/etc/gitconfig`, which applies to all users on the system. This is the right level for a Docker container because:

- `--global` writes to `~/.gitconfig` — but `appuser`'s home directory may not have the right permissions, and the global config would need to be set *after* the `USER appuser` directive
- `--local` only applies to one specific repo — useless here since we don't know which repos will be scanned
- `--system` applies everywhere, is set once during image build, and works for any repo `appuser` interacts with

The identity `const-catalog@tool.local` / `Const Catalog` clearly identifies automated commits from this tool. It's not a real email address, which prevents accidental notifications.

### Fix 2: Targeted File Staging

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/GitService.java`

**Added method (after `addAndCommit`):**
```java
/**
 * Stages only the specified files and commits with the given message.
 * This avoids accidentally staging unrelated changes in the working tree.
 *
 * @param projectDir the git repository root
 * @param files      absolute paths to files that should be staged
 * @param message    commit message
 */
public void addFilesAndCommit(Path projectDir, java.util.Collection<String> files, String message) throws GitException {
    for (String file : files) {
        runGit(projectDir, "add", file);
    }
    runGit(projectDir, "commit", "-m", message);
    log.info("Committed {} files: {}", files.size(), message);
}
```

**Why a new method instead of modifying `addAndCommit()`:**

The existing `addAndCommit()` is still correct for the `initRepoWithInitialCommit()` flow, which intentionally stages everything (it's creating a baseline commit of the entire project). Changing its behavior would break that use case. A new method with a clear name (`addFilesAndCommit`) makes the intent explicit at the call site.

**Why `git add <file>` per file instead of `git add -- file1 file2 ...`:**

Git has a command-line argument length limit inherited from the OS (`ARG_MAX`, typically 128KB–2MB). For projects with hundreds of transformed files, a single `git add` with all paths could exceed this limit. Adding files one at a time is slightly slower but safe for any number of files. The performance difference is negligible — each `git add` is a fast index-only operation.

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/CodeTransformationService.java`

**Before (line 357):**
```java
gitService.addAndCommit(projectDir, "Transform constants to config lookups");
```

**After (line 357):**
```java
gitService.addFilesAndCommit(projectDir, transformedFiles, "Transform constants to config lookups");
```

**Why this is the right call site:**

The `createBranchWithTransformedFiles()` method already builds `transformedFiles` — a `Set<String>` of absolute paths to files that were successfully transformed. This set is used to copy files from `backups/` back to the source. Passing the same set to `addFilesAndCommit()` ensures git stages exactly the files that were modified and nothing else.

**What this prevents:**

The `adding-constant-data` branch has over 100 uncommitted modifications (visible in the `git status` output). Without targeted staging, `git add -A` would include all of these in the transform commit — mixing unrelated work with the transformation. This would make the branch diff useless for reviewing what the transformer changed.

With targeted staging, only the files the transformer actually modified are committed. The commit diff shows exactly the transformation results.

### Fix 3: Scanner Excludes Same-Class Constant Usages (Causes False "Unused" Reports)

**Discovery:** After running "Remove Unused" on a scanned project, the transformed file `Singer.java` had its `FIND_SINGER_BY_ID` and `FIND_ALL_WITH_ALBUM` constants removed. However, these constants were **used in the same class** inside `@NamedQuery` annotations:

```java
// Original Singer.java — constants defined on lines 29-30
public static final String FIND_SINGER_BY_ID = "Singer.findById";
public static final String FIND_ALL_WITH_ALBUM = "Singer.findAllWithAlbum";

// Used on lines 17 and 22 in the same class
@NamedQuery(name=Singer.FIND_SINGER_BY_ID, query="...")
@NamedQuery(name=Singer.FIND_ALL_WITH_ALBUM, query="...")
```

The transformed file removed the constants but left the `@NamedQuery` annotations referencing them — the file would not compile.

**Investigation:** Traced the issue through the code:

1. The `findUnusedConstants()` Neo4j query checks for constants with no `USED_IN` relationships
2. `USED_IN` relationships are created by `GraphPopulatorService.createConstantUsageRelationships()` from the `ConstantUsage` records produced by the scanner
3. `ConstantUsage` records are produced by `JavaFileParser.parseConstantUsages()`

Inside `parseConstantUsages()`, the `FieldAccessExpr` visitor (handles expressions like `Singer.FIND_SINGER_BY_ID`) had this filter:

```java
if (definingClasses != null && definingClasses.contains(scopeName)
        && !scopeName.equals(currentClass)) {  // ← skips same-class references
```

The check `!scopeName.equals(currentClass)` **intentionally excluded same-class references**. When `Singer` uses `Singer.FIND_SINGER_BY_ID` inside `@NamedQuery`, the scope is `Singer` and the current class is `Singer` — so the usage was skipped. No `USED_IN` relationship was created in Neo4j, and `findUnusedConstants` reported the constant as unused.

The same exclusion existed in the `NameExpr` visitor for bare-name references (e.g., `FIND_SINGER_BY_ID` without the `Singer.` prefix).

**Why the original exclusion was wrong:** The filter was likely intended to avoid counting the constant's *declaration* as a usage of itself. But this concern is unfounded — JavaParser models declarations as `FieldDeclaration`/`VariableDeclarator` nodes, which are visited by different visitor methods. A `FieldAccessExpr` like `Singer.FIND_SINGER_BY_ID` inside an annotation or method body is genuinely a *usage*, not a declaration. The visitor types are distinct, so there's no double-counting risk.

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/parser/JavaFileParser.java`

**Change 3a: FieldAccessExpr visitor — remove self-class exclusion**

**Before (lines 292–293):**
```java
if (definingClasses != null && definingClasses.contains(scopeName)
        && !scopeName.equals(currentClass)) {
```

**After (line 292):**
```java
if (definingClasses != null && definingClasses.contains(scopeName)) {
```

The `!scopeName.equals(currentClass)` check is removed. Now `Singer.FIND_SINGER_BY_ID` used inside the `Singer` class is recorded as a usage.

**Change 3b: NameExpr visitor — add same-class bare-name detection**

The `NameExpr` visitor was more complex because it handled two cases: explicit static imports and wildcard static imports. Both excluded same-class references. The fix restructures the logic to check for same-class bare-name references first:

**Before:**
```java
@Override
public void visit(NameExpr nameExpr, Void arg) {
    String name = nameExpr.getNameAsString();
    Set<String> definingClasses = constantsByName.get(name);
    if (definingClasses != null) {
        if (staticImportedConstants.contains(name)) {
            for (String definingClass : definingClasses) {
                if (!definingClass.equals(currentClass)) {  // ← excluded same-class
                    // record usage
                }
            }
        } else {
            for (String definingClass : definingClasses) {
                if (wildcardStaticImportedClasses.contains(definingClass)
                        && !definingClass.equals(currentClass)) {  // ← excluded same-class
                    // record usage
                }
            }
        }
    }
}
```

**After:**
```java
@Override
public void visit(NameExpr nameExpr, Void arg) {
    String name = nameExpr.getNameAsString();
    Set<String> definingClasses = constantsByName.get(name);
    if (definingClasses != null) {
        // Check if this bare name is a same-class constant reference
        boolean isSameClassRef = definingClasses.contains(currentClass);

        if (isSameClassRef) {
            // record usage with currentClass as both definer and user
        } else if (staticImportedConstants.contains(name)) {
            for (String definingClass : definingClasses) {
                // record usage (no self-exclusion)
            }
        } else {
            for (String definingClass : definingClasses) {
                if (wildcardStaticImportedClasses.contains(definingClass)) {
                    // record usage (no self-exclusion)
                }
            }
        }
    }
}
```

The key change: a bare `NameExpr` like `FIND_SINGER_BY_ID` inside the `Singer` class is now recognized as a same-class reference. Previously, it would only be recognized if it came through a static import from another class.

**Test results:** All 290 existing tests in `const-catalog-core` pass after this change. There are no existing tests for `parseConstantUsages()` that assert the self-exclusion behavior.

**Impact:** After this fix, re-scanning a project will create `USED_IN` relationships for same-class constant references. Constants like `Singer.FIND_SINGER_BY_ID` that are used within their own class will no longer be reported as unused. The `Singer.java` false positive is eliminated.

**Important:** Projects must be re-scanned after this fix for the new `USED_IN` relationships to be recorded in Neo4j. Existing scan data in the graph will still have the old behavior until the project is scanned again.

### Fix 4: Logger Fields With Non-Standard Names Not Protected

**Discovery:** The transformed file `TestProjectionPerformance.java` had its logger field removed:

```java
// Original — line 26
private static final Logger _logger = Logger.getLogger(TestProjectionPerformance.class);
```

But `_logger` is used on lines 50, 63, 76, and 89:

```java
_logger.warn("Query Traditional: total " + timeQuery + ...);
```

The transformed file would not compile — `_logger` no longer exists.

**Investigation:** The `UnusedConstantRemover` has a protected names list:

```java
private static final Set<String> PROTECTED_NAMES = Set.of(
    "serialVersionUID", "VERSION", "LOG", "LOGGER", "logger"
);
```

The field name `_logger` (with underscore prefix) doesn't match any entry. The protection is purely name-based and case-sensitive, so any non-standard logger name (`_logger`, `_log`, `myLogger`, `AUDIT_LOG`) would be missed.

This is actually two bugs compounding:
1. The same-class usage issue from Fix 3 — `_logger` is used in the same class it's defined in, so no `USED_IN` relationship exists in Neo4j
2. The protected names list doesn't cover `_logger` or other common variants

Even after Fix 3 (scanner records same-class usages), the protected names list should be a safety net for logger fields, since loggers are almost never truly "unused" — they're essential for operational visibility.

**Fix: Two-layer protection**

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/transformer/UnusedConstantRemover.java`

**Change 4a: Expand the protected names list**

**Before:**
```java
private static final Set<String> PROTECTED_NAMES = Set.of(
    "serialVersionUID", "VERSION", "LOG", "LOGGER", "logger"
);
```

**After:**
```java
private static final Set<String> PROTECTED_NAMES = Set.of(
    "serialVersionUID", "VERSION", "LOG", "LOGGER", "logger", "_logger", "log", "_log"
);

/** Type names that indicate a logger — fields of these types are never removed. */
private static final Set<String> LOGGER_TYPE_NAMES = Set.of(
    "Logger", "Log", "Slf4jLogger"
);
```

Added `_logger`, `log`, and `_log` to the name list. But more importantly, added a **type-based check** via `LOGGER_TYPE_NAMES`. This catches any `static final Logger` field regardless of what it's named — `_logger`, `auditLog`, `myLogger`, etc.

**Change 4b: Add type-based protection check**

**Before (in both `removeFromFile` and `dryRun`):**
```java
if (PROTECTED_NAMES.contains(name)) {
    results.add(TransformationEntry.skipped(target, filePath,
        "Protected name '%s' — not removed".formatted(name)));
```

**After:**
```java
if (PROTECTED_NAMES.contains(name) || isLoggerType(field)) {
    String reason = PROTECTED_NAMES.contains(name)
        ? "Protected name '%s' — not removed".formatted(name)
        : "Logger field '%s' (type %s) — not removed".formatted(name, field.getElementType().asString());
    results.add(TransformationEntry.skipped(target, filePath, reason));
```

**New helper method:**
```java
private boolean isLoggerType(FieldDeclaration field) {
    String typeName = field.getElementType().asString();
    return LOGGER_TYPE_NAMES.contains(typeName);
}
```

The check uses `field.getElementType().asString()` which returns the simple type name from the AST (e.g., `Logger`, not `org.apache.log4j.Logger`). This matches against simple names because Java imports resolve the fully-qualified name — the source code almost always uses the simple name.

**Why two layers of protection:**
- **Name-based** catches the common conventions regardless of type (what if someone has `private static final String LOG = "audit"` — not a logger, but still protected by convention)
- **Type-based** catches all logger fields regardless of naming (any `Logger _auditLog`, `Logger metricsLogger`, etc.)

Together they eliminate the class of false removals where a logger field is incorrectly reported as unused.

**Test results:** All 290 existing tests pass after this change.

### Fix 5: Non-Public Static Final Fields Should Never Be Removed or Transformed

**Discovery:** The `_logger` field in `TestProjectionPerformance.java` was `private static final`. Even without the logger protection issues, a `private static final` field should never be a candidate for removal or transformation into a `config.lookup()` call. These fields are internal implementation details of a class — they can't be referenced from other files, so:

- **Removal:** The graph's `USED_IN` relationships only track cross-file references. A `private` field has zero cross-file usages by definition — it would always appear "unused" in the graph even if it's heavily used within its own class.
- **Transformation:** Converting `private static final String DB_HOST = "localhost"` to `config.lookup("db.host")` makes no sense — the constant is private precisely because it's an internal implementation choice, not a configuration value meant to be externalized.

The same reasoning applies to `protected` and package-private (`static final` with no access modifier) fields. Only `public static final` fields are part of a class's public API and are meaningful candidates for either removal or transformation.

**Investigation:** Checked how visibility is tracked end-to-end:

1. **Parser** (`JavaFileParser.java:104`): Already extracts `accessModifier` from the field's modifiers and stores it in the `Constant` model — values are `"public"`, `"private"`, `"protected"`, or `"package-private"`.
2. **Neo4j** (`ConstantNode.java:46`): Already persists `accessModifier` as a property on `Constant` nodes.
3. **Neo4j queries** (`CodeTransformationService.java`): Did **not** filter by `accessModifier` — all `static final` constants were candidates regardless of visibility.
4. **Remover** (`UnusedConstantRemover.java`): Did **not** check visibility — matched any `static final` field.

The fix adds the filter at two levels: the Neo4j queries (primary) and the remover (safety net).

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/CodeTransformationService.java`

**Change 5a: Filter `findConfigurationCandidates()` to public only**

**Before (line 383):**
```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE (c.type IN ['String', 'java.lang.String', ...] OR c.isEnum = true)
  AND c.name =~ '(?i).*(HOST|PORT|URL|...).*'
```

**After:**
```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE c.accessModifier = 'public'
  AND (c.type IN ['String', 'java.lang.String', ...] OR c.isEnum = true)
  AND c.name =~ '(?i).*(HOST|PORT|URL|...).*'
```

This filters out `private static final String DB_HOST` from the transformation candidate list. Only `public static final` constants are considered for replacement with `config.lookup()` calls.

**Change 5b: Filter `findUnusedConstants()` to public only**

**Before (line 417):**
```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE NOT exists { MATCH (c)-[:USED_IN]->() }
  AND NOT coalesce(c.isEnum, false) = true
```

**After:**
```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE c.accessModifier = 'public'
  AND NOT exists { MATCH (c)-[:USED_IN]->() }
  AND NOT coalesce(c.isEnum, false) = true
```

This eliminates all `private`, `protected`, and package-private constants from the "unused" list. Since these fields can only be used within their own class (or package), and the graph doesn't reliably track intra-class usages, they would almost always be falsely reported as unused.

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/transformer/UnusedConstantRemover.java`

**Change 5c: Add `isPublic()` check in the remover as a safety net**

Added `if (!isPublic(field)) continue;` immediately after the `isStaticFinal` check in both `removeFromFile()` and `dryRun()`. This skips non-public fields even if they somehow make it past the Neo4j query filter (e.g., if the `accessModifier` property was null or missing in older graph data).

**Before (line 110):**
```java
for (FieldDeclaration field : compilationUnit.findAll(FieldDeclaration.class)) {
    if (!isStaticFinal(field)) continue;

    for (VariableDeclarator var : field.getVariables()) {
```

**After:**
```java
for (FieldDeclaration field : compilationUnit.findAll(FieldDeclaration.class)) {
    if (!isStaticFinal(field)) continue;
    if (!isPublic(field)) continue;

    for (VariableDeclarator var : field.getVariables()) {
```

**New helper method:**
```java
private boolean isPublic(FieldDeclaration field) {
    return field.getModifiers().stream()
        .anyMatch(m -> m.getKeyword() == Modifier.Keyword.PUBLIC);
}
```

Non-public fields targeted by the Neo4j query will be reported as "Declaration not found" (since the AST walk skips them). This is the correct behavior — the remover refuses to touch them.

**Impact on existing tests:**

The logger and serialVersionUID protection tests previously used `private static final` fields. After this fix, those fields are skipped by the `isPublic` check before reaching the protected-name check. The tests were updated to use `public static final` so they specifically verify the name/type protection layer:

- `testProtectsSerialVersionUID` — changed to `public static final long serialVersionUID`
- `testProtectsLoggerField` — changed to `public static final Logger LOG`
- `testProtectsUnderscoreLoggerByName` — changed to `public static final Logger _logger`
- `testProtectsLoggerByType` — changed to `public static final Logger auditLog`
- `testProtectsLoggerByTypeInDryRun` — changed to `public static final Logger metricsLogger`

These are unusual in real code (loggers are typically private), but the tests exist to verify the name/type protection layer independently of the visibility filter. The visibility filter is tested by its own dedicated tests (see below).

**New tests for visibility filtering:**

| Test | What it verifies |
|---|---|
| `testSkipsPrivateStaticFinalFields` | `private static final String INTERNAL_KEY` is skipped; `public static final String PUBLIC_KEY` is removed |
| `testSkipsProtectedStaticFinalFields` | `protected static final String BASE_URL` is skipped; `public static final String UNUSED` is removed |
| `testSkipsPackagePrivateStaticFinalFields` | `static final int INTERNAL_TIMEOUT` (no access modifier) is skipped; `public static final String UNUSED` is removed |
| `testDryRunSkipsPrivateFields` | Dry run also skips `private static final` — reports "Would remove" only for `public` field |

**Test results:** All 314 tests pass across the core module (35 in `UnusedConstantRemoverTest`).

### Fix 6: Dangling Reference Detection — Verify Transformed Files Would Compile

**Discovery:** Even with all the previous fixes (same-class usage tracking, logger protection, visibility filtering), there's still a risk that a constant reported as "unused" by Neo4j is actually referenced within the file. This can happen when:

- The scan data is stale (file modified since last scan)
- The scanner has blind spots (e.g., constants referenced in annotation attributes that weren't caught)
- A new usage pattern is introduced that the scanner doesn't recognize

The Singer.java and TestProjectionPerformance.java bugs were caught by earlier fixes, but the same class of error could recur with different code patterns. A defensive check in the remover itself provides a final safety net.

**Approach:** After removing constant declarations from the AST but before writing the file, scan the modified AST for references to the removed names. If any removed name still appears as a `NameExpr` (bare reference like `FIND_SINGER_BY_ID`) or `FieldAccessExpr` (qualified reference like `Singer.FIND_SINGER_BY_ID`), the removal would break compilation. The constant is marked FAILED instead of TRANSFORMED, and the file is not written with that removal.

This is not a full compilation check (it doesn't resolve types, imports, or cross-file dependencies), but it catches the most common cause of broken transforms: removing a constant that's used in the same file.

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/transformer/UnusedConstantRemover.java`

**Change 6a: New `findDanglingReferences()` method**

```java
private Set<String> findDanglingReferences(CompilationUnit cu, Set<String> removedNames) {
    Set<String> dangling = new LinkedHashSet<>();

    // Check bare name references: FIND_SINGER_BY_ID
    cu.findAll(NameExpr.class).forEach(nameExpr -> {
        if (removedNames.contains(nameExpr.getNameAsString())) {
            dangling.add(nameExpr.getNameAsString());
        }
    });

    // Check qualified references: Singer.FIND_SINGER_BY_ID
    cu.findAll(FieldAccessExpr.class).forEach(fieldAccess -> {
        if (removedNames.contains(fieldAccess.getNameAsString())) {
            dangling.add(fieldAccess.getNameAsString());
        }
    });

    return dangling;
}
```

After removing all candidate declarations from the AST, this method walks the modified AST looking for any `NameExpr` or `FieldAccessExpr` node whose name matches a removed constant. If found, that name is "dangling" — the declaration is gone but a reference remains.

**Change 6b: Post-removal validation in `removeFromFile()`**

After removing candidates but before writing the file, the removal loop now:
1. Collects all removed names into a `Set<String>`
2. Calls `findDanglingReferences()` on the modified AST
3. For each candidate: if the name is dangling, marks it FAILED with "Removal would break compilation — 'X' is still referenced in this file"
4. If some removals are safe and others aren't, re-parses the original file and removes only the safe ones via `rewriteWithSafeRemovalsOnly()`

**Change 6c: `rewriteWithSafeRemovalsOnly()` for mixed cases**

When a file has both safe and unsafe removals (e.g., `TRULY_UNUSED` can be removed but `FIND_BY_ID` cannot), the first pass already modified the AST with all removals. Rather than trying to undo specific removals on a modified AST, this method re-parses the original file from disk and applies only the safe removals cleanly.

```java
private void rewriteWithSafeRemovalsOnly(
        Path sourceFile, List<RemovalCandidate> allCandidates,
        Set<String> danglingRefs, Path outputPath, Path backupsDir) {
    // Re-parse original, remove only safe candidates, write output
}
```

**Change 6d: Dry-run also checks for dangling references**

The dry-run method now clones the AST, simulates the removals on the clone, and runs the same dangling reference check. Constants that would break compilation are reported as FAILED in the dry-run preview, giving the user advance warning before they uncheck "Dry run."

**New tests:**

| Test | What it verifies |
|---|---|
| `testRejectsRemovalWhenConstantUsedInAnnotation` | Constants referenced via `FIND_BY_ID` and `Singer.FIND_ALL` in method bodies are detected as dangling — marked FAILED while `UNUSED` is TRANSFORMED |
| `testDryRunDetectsDanglingReferences` | Dry run also detects dangling references and reports FAILED |
| `testQualifiedReferenceDetected` | `ClassName.CONSTANT_NAME` style references are caught by the `FieldAccessExpr` check |
| `testMixedSafeAndUnsafeRemovals` | File with one referenced and one truly unused constant — only the unused one is removed, the referenced one is FAILED, and the output file contains only the safe removal |
| `testTrulyUnusedConstantPassesDanglingCheck` | Two constants with zero references are both successfully removed |

**Test results:** All 319 tests pass across the core module (40 in `UnusedConstantRemoverTest`).

### Summary of All Changed Files

| File | Change | Issue Fixed |
|---|---|---|
| `const-catalog-backend/Dockerfile` | Entrypoint script for directory permissions; `gosu` for privilege drop; system-wide git identity | Issues 1 & 2 |
| `const-catalog-backend/entrypoint.sh` | New startup script that ensures `backups/` and `logs/` are writable before dropping to `appuser` | Issue 1 |
| `const-catalog-backend/.../GitService.java` | Added `addFilesAndCommit()` method for targeted staging | Issue 3 |
| `const-catalog-backend/.../CodeTransformationService.java` | Changed `addAndCommit()` call to `addFilesAndCommit(transformedFiles, ...)`; added `c.accessModifier = 'public'` to both Neo4j queries | Issues 3, 6 |
| `const-catalog-core/.../JavaFileParser.java` | Removed same-class exclusion from `FieldAccessExpr` and `NameExpr` visitors | Issue 4 (false unused reports — Singer.FIND_SINGER_BY_ID) |
| `const-catalog-core/.../UnusedConstantRemover.java` | Expanded protected names; type-based logger detection; `isPublic()` visibility filter; dangling reference detection with `findDanglingReferences()` and `rewriteWithSafeRemovalsOnly()` | Issues 5, 6, 7 |
| `const-catalog-core/.../UnusedConstantRemoverTest.java` | 40 tests total (11 original + 29 new); covers logger protection, visibility, line tolerance, dangling refs, edge cases | Tests for issues 4, 5, 6, 7 |

### All Issues Found

| # | Issue | Severity | Fix |
|---|---|---|---|
| 1 | Backups directory not writable by `appuser` | Blocking | Dockerfile entrypoint script with `gosu` |
| 2 | No git identity for `appuser` in container | Blocking | Dockerfile: `git config --system` |
| 3 | `git add -A` stages all changes, not just transformed files | Correctness | New `addFilesAndCommit()` method |
| 4 | Scanner excludes same-class constant usages → false "unused" reports | Correctness | Removed `!scopeName.equals(currentClass)` filter |
| 5 | Logger fields with non-standard names (`_logger`) not protected | Correctness | Expanded protected names + type-based detection |
| 6 | Non-public `static final` fields incorrectly targeted for removal/transformation | Correctness | Added `accessModifier = 'public'` to queries + `isPublic()` in remover |
| 7 | No validation that transformed files would compile | Safety | Dangling reference detection in both live and dry-run modes |

### Rebuild Required

All fixes span `const-catalog-core` and `const-catalog-backend`. Rebuild the backend (Maven will rebuild the core module too):

```
docker compose --env-file=.env.mint up -d --build backend
```

After rebuilding, **re-scan any projects** that were previously scanned so the new same-class `USED_IN` relationships are recorded in Neo4j. Then run "Remove Unused" again:
- Constants like `FIND_SINGER_BY_ID` (same-class usage) should no longer appear in the removal list
- Logger fields like `_logger` will be protected regardless of naming convention
- `private`, `protected`, and package-private constants are completely excluded from both removal and transformation
- Any constant that is still referenced in the same file after removal will be caught and reported as FAILED instead of silently producing broken code
