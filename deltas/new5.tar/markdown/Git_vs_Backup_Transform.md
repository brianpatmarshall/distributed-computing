# Git vs Backup Transform — Honoring the Checkbox

## Problem

The "Create new branch" checkbox on the Transform page sends `createBranch: true/false` to the backend, but the backend ignores it. When dry run is off, it **always** attempts the git branch approach first, only falling back to backup-based transform if git fails.

The user should be able to choose:
- **Checkbox checked** → transform on a new git branch
- **Checkbox unchecked** → transform using the backup directory (no git)

---

## What Already Works (No Changes Needed)

### Frontend: `TransformPage.tsx`

The checkbox state is already sent correctly (line 79):

```typescript
createBranch: !dryRun && createBranch
```

- Checkbox unchecked + not dry run → `createBranch: false`
- Checkbox checked + not dry run → `createBranch: true`
- Dry run → `createBranch: false` (irrelevant — dry run path runs)

### Backend DTO: `TransformRequest.java`

The field already exists (line 56):

```java
@Builder.Default
private boolean createBranch = false;
```

Lombok generates `isCreateBranch()` automatically.

### Backend DTO: `TransformResponse.java`

The `branchName` field (line 48) is already optional — it's `null` when no branch is created.

### Response Message Logic (lines 159–169)

Already handles all three outcomes:

| Condition | Message |
|---|---|
| `isDryRun()` | "Dry run complete: X would be transformed..." |
| `branchResult.branchName() != null` | "...committed to branch 'main-transform'" |
| `branchResult.error() != null` | "...git branch failed: ..." |
| else (backup path) | Plain summary |

No changes needed here.

---

## The One Change Required

### File: `CodeTransformationService.java`

### Location: Lines 133–149

### Before

```java
// Phase 2: Transform (dry-run or live with git branch)
TransformationResult result;
BranchResult branchResult = BranchResult.SKIPPED;

if (request.isDryRun()) {
    List<TransformationEntry> entries = targetsByFile.entrySet().stream()
        .flatMap(entry -> transformer.dryRun(entry.getKey(), entry.getValue()).stream())
        .toList();
    result = new TransformationResult(projectPath, LocalDateTime.now(), entries);
} else {
    // Live run: create branch, transform in place, commit, switch back
    branchResult = transformOnBranch(projectPath, targetsByFile, false);
    if (branchResult.result() != null) {
        result = branchResult.result();
    } else {
        // Branch creation failed — fall back to backup-based transform
        log.warn("Git branch creation failed, falling back to backup-based transform: {}",
            branchResult.error());
        result = transformer.transformProject(projectPath, targetsByFile);
    }
}
```

### After

```java
// Phase 2: Transform (dry-run, git branch, or backup-based)
TransformationResult result;
BranchResult branchResult = BranchResult.SKIPPED;

if (request.isDryRun()) {
    List<TransformationEntry> entries = targetsByFile.entrySet().stream()
        .flatMap(entry -> transformer.dryRun(entry.getKey(), entry.getValue()).stream())
        .toList();
    result = new TransformationResult(projectPath, LocalDateTime.now(), entries);
} else if (request.isCreateBranch()) {
    // Live run with git: create branch, transform in place, commit, switch back
    branchResult = transformOnBranch(projectPath, targetsByFile, false);
    if (branchResult.result() != null) {
        result = branchResult.result();
    } else {
        // Branch creation failed — fall back to backup-based transform
        log.warn("Git branch creation failed, falling back to backup-based transform: {}",
            branchResult.error());
        result = transformer.transformProject(projectPath, targetsByFile);
    }
} else {
    // Live run without git: backup originals, transform in place
    result = transformer.transformProject(projectPath, targetsByFile);
}
```

### What Changed

The `else` on line 138 became `else if (request.isCreateBranch())`, and a new `else` block was added for the backup-based path.

---

## Decision Flow After the Change

```
isDryRun?
├── YES → analyze only, write nothing
└── NO
    └── isCreateBranch?
        ├── YES → git branch approach
        │         ├── succeeded → use branch result
        │         └── failed → fall back to backup-based transform
        └── NO  → backup-based transform (copy originals to /app/backups, transform in place)
```

---

## How the Three Paths Work

| Path | Triggered by | What happens to original files | Where to find changes |
|---|---|---|---|
| **Dry run** | Dry Run checkbox ON | Untouched | Response only (no disk writes) |
| **Git branch** | Dry Run OFF, Create Branch ON | Safe on original branch | New branch: `<current>-transform` |
| **Backup** | Dry Run OFF, Create Branch OFF | Copied to `/app/backups` | Modified in place in the project |

---

## Testing

### Manual Test Plan

1. **Dry run** — check both checkboxes are off, check Dry Run on. Run transform. Verify no files changed on disk.

2. **Git branch** — check Dry Run off, Create Branch on. Run transform. Verify:
   - You're still on the original branch
   - A `<branch>-transform` branch exists with the changes committed
   - Original files are unmodified

3. **Backup** — check both checkboxes off (Dry Run off, Create Branch off). Run transform. Verify:
   - Original files are backed up in `/app/backups` (or `./backups` on the host via the volume mount)
   - Project files are modified in place

4. **Git failure fallback** — check Create Branch on, but point to a directory that isn't a git repo and where git init would fail. Verify it falls back to backup-based transform with a warning in the response message.
