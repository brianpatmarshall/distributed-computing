# Remote Debugging Guide

Java's **JDWP** (Java Debug Wire Protocol) lets a running JVM expose a TCP debug port. Your IDE connects to that port over the network and can set breakpoints, inspect variables, step through code, and evaluate expressions — exactly like local debugging, but the JVM is running elsewhere (in a Docker container, on a remote server, etc.).

This guide covers every scenario a Constants Catalog developer might encounter.

## Table of Contents

1. [How JDWP Works](#how-jdwp-works)
2. [Debugging the Dockerized Backend](#debugging-the-dockerized-backend)
3. [Debugging When Running Locally](#debugging-when-running-locally)
4. [Debugging the CLI Module](#debugging-the-cli-module)
5. [JDWP Flag Reference](#jdwp-flag-reference)
6. [IDE Configuration](#ide-configuration)
7. [Debugging from a Remote Machine](#debugging-from-a-remote-machine)
8. [Debugging Startup and Bean Initialization](#debugging-startup-and-bean-initialization)
9. [Debugging Core Module Code from the Backend](#debugging-core-module-code-from-the-backend)
10. [Debugging Tests](#debugging-tests)
11. [Quick Reference](#quick-reference)
12. [Security Considerations](#security-considerations)

---

## How JDWP Works

```mermaid
sequenceDiagram
    participant JVM as Java VM<br/>(target)
    participant IDE as IDE Debugger<br/>(your machine)

    Note over JVM: Starts with JDWP agent<br/>listening on port 5005
    IDE->>JVM: TCP connect to :5005
    JVM-->>IDE: Handshake (JDWP protocol)
    IDE->>JVM: Set breakpoint at ScanService.java:42
    JVM-->>IDE: Breakpoint confirmed
    Note over JVM: Thread hits line 42...
    JVM-->>IDE: Thread suspended, here are the local variables
    IDE->>JVM: Step over / resume / evaluate expression
```

The JVM acts as a **server** — it opens a socket and waits. Your IDE acts as a **client** — it connects and issues debug commands. All communication flows over a single TCP connection using the JDWP binary protocol.

---

## Debugging the Dockerized Backend

The `docker-compose.yml` already has JDWP wired up on the backend service. Two pieces make it work:

**1. The JDWP agent** (environment variable on the backend service):

```yaml
environment:
  - JAVA_TOOL_OPTIONS=-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005
```

**2. The port mapping** (exposes container port 5005 to the host):

```yaml
ports:
  - "9090:8080"   # REST API
  - "5005:5005"   # JDWP debug port
```

To use it, just start the stack and attach your IDE:

```bash
docker compose up -d
# The backend JVM is now listening on localhost:5005
```

```mermaid
flowchart LR
    subgraph Host Machine
        IDE["IDE Debugger<br/>localhost:5005"]
    end

    subgraph Docker Network
        BE["Backend Container<br/>*:5005 (JDWP)<br/>*:8080 (HTTP)"]
        NEO["Neo4j<br/>:7687"]
        VK["ValKey<br/>:6379"]
    end

    IDE -->|"TCP :5005"| BE
    BE --> NEO
    BE --> VK
```

No code changes, no rebuilds. The debug port is live as soon as the container starts.

---

## Debugging When Running Locally

When running the backend outside Docker with `spring-boot:run`, pass the JDWP agent via JVM arguments:

```bash
cd const-catalog-backend
mvn spring-boot:run \
  -Dspring-boot.run.jvmArguments="-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005"
```

Or if running the fat JAR directly:

```bash
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005 \
  -jar const-catalog-backend/target/const-catalog-backend-1.0-SNAPSHOT.jar
```

In both cases, attach your IDE to `localhost:5005`.

> **Note:** When running locally, Neo4j and ValKey must still be reachable. You can start just those two services with `docker compose up -d neo4j valkey`.

---

## Debugging the CLI Module

The CLI is a standalone shaded JAR that runs and exits quickly. Use **`suspend=y`** so the JVM waits for the debugger before executing `main()`:

```bash
java -agentlib:jdwp=transport=dt_socket,server=y,suspend=y,address=*:5005 \
  -jar const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT-shaded.jar [args...]
```

The process will print `Listening for transport dt_socket at address: 5005` and freeze until you attach. Once your IDE connects, execution begins and you can step through the CLI code.

---

## JDWP Flag Reference

```
-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005
              │                      │         │         │
              │                      │         │         └─ *:5005 = listen on all interfaces, port 5005
              │                      │         └─ suspend=n: start immediately, don't wait for debugger
              │                      └─ server=y: JVM listens (IDE connects to it)
              └─ dt_socket: TCP socket transport
```

| Parameter   | Value          | When to Change                                                               |
|-------------|----------------|------------------------------------------------------------------------------|
| `transport` | `dt_socket`    | Always use this. The only other option (`dt_shmem`) is Windows-only shared memory. |
| `server`    | `y`            | Set to `n` if you want the JVM to connect to a listening IDE (rare).          |
| `suspend`   | `n`            | Use `y` for CLI tools or to debug startup / bean initialization.              |
| `address`   | `*:5005`       | Change port if 5005 conflicts. Use `127.0.0.1:5005` to restrict to localhost. |

---

## IDE Configuration

### IntelliJ IDEA

1. **Run > Edit Configurations...** > click the **+** button > look for **Remote JVM Debug** (IntelliJ 2022+) or just **Remote** (older versions). If you don't see it immediately, type `remote` in the search/filter field at the top of the template list.
2. Fill in the fields:

| Field                  | Value                               |
|------------------------|-------------------------------------|
| Name                   | `Constants Backend (Docker)`        |
| Debugger mode          | Attach to remote JVM                |
| Host                   | `localhost`                         |
| Port                   | `5005`                              |
| Use module classpath   | `const-catalog-backend`             |

3. Click the **Debug** button (bug icon).
4. You will see `Connected to the target VM, address: 'localhost:5005'` in the Debug console.

```mermaid
flowchart LR
    A["Run > Edit Configurations"] --> B["+ Remote JVM Debug<br/>(or just Remote)"]
    B --> C["Host: localhost, Port: 5005"]
    C --> D["Click Debug 🪲"]
    D --> E["Connected!<br/>Set breakpoints, step, inspect"]
```

### VS Code

Install the [Debugger for Java](https://marketplace.visualstudio.com/items?itemName=vscjava.vscode-java-debug) extension pack, then add to `.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "java",
      "name": "Attach to Backend (Docker)",
      "request": "attach",
      "hostName": "localhost",
      "port": 5005,
      "projectName": "const-catalog-backend"
    }
  ]
}
```

Press **F5** or open the **Run and Debug** sidebar and select the configuration.

### Eclipse

1. **Run > Debug Configurations... > Remote Java Application > New**
2. Fill in:

| Field           | Value                    |
|-----------------|--------------------------|
| Project         | `const-catalog-backend`  |
| Connection Type | Standard (Socket Attach) |
| Host            | `localhost`              |
| Port            | `5005`                   |

3. Click **Debug**.

---

## Debugging from a Remote Machine

If the Docker stack is running on a remote server (a dev VM, a shared lab machine, etc.), **do not expose port 5005 to the network**. JDWP has no authentication. Instead, use an SSH tunnel:

```bash
# On your local workstation:
ssh -L 5005:localhost:5005 user@remote-server
```

This forwards your local port 5005 through the SSH connection to the remote server's localhost:5005. Then configure your IDE to attach to `localhost:5005` as usual.

```mermaid
flowchart LR
    subgraph Your Workstation
        IDE["IDE<br/>→ localhost:5005"]
    end

    subgraph "SSH Tunnel (encrypted)"
        TUNNEL["ssh -L 5005:localhost:5005"]
    end

    subgraph Remote Server
        DOCKER["Docker<br/>backend:5005"]
    end

    IDE --> TUNNEL --> DOCKER
```

For additional safety, restrict the Docker port binding to localhost only:

```yaml
ports:
  - "127.0.0.1:5005:5005"
```

---

## Debugging Startup and Bean Initialization

If you need to debug something that happens during Spring Boot startup — `@PostConstruct` methods, bean wiring, configuration loading — the application will have already passed those code paths before you can attach. The fix is `suspend=y`:

```yaml
# In docker-compose.yml, change:
JAVA_TOOL_OPTIONS: -agentlib:jdwp=transport=dt_socket,server=y,suspend=y,address=*:5005
```

The JVM will **freeze immediately** and wait for a debugger to attach before loading any classes. This lets you catch issues in:

- `Neo4jConfig` / `ValKeyConfig` — database connection setup
- `SiteConfigBeanPostProcessor` — custom annotation post-processing
- `SiteConfigurationService` `@PostConstruct` — initial configuration loading
- `WebConfig` — CORS and servlet configuration

> **Important:** Change `suspend` back to `n` when you're done. With `suspend=y`, the container will hang on every restart until a debugger attaches, and the Docker health check will fail after its timeout.

---

## Debugging Core Module Code from the Backend

The `const-catalog-core` module is a compile dependency of the backend. When the backend JVM has JDWP active, you can set breakpoints in core classes too:

- `JavaFileParser` — AST parsing of source files
- `ProjectScanner` — file discovery and scanning orchestration
- `ConfigLookupTransformer` — constant replacement logic
- `JavaCodeTransformer` — AST modification visitor

Your IDE just needs the core module's source on its classpath. If you opened the root `pom.xml` as a Maven project (IntelliJ) or imported the parent project (Eclipse), this happens automatically — all three modules are resolved together.

---

## Debugging Tests

Maven Surefire has built-in JDWP support. Run:

```bash
cd const-catalog-backend
mvn test -Dmaven.surefire.debug
```

This launches the test JVM with `suspend=y` on port **5005**. The output will show:

```
Listening for transport dt_socket at address: 5005
```

Attach your IDE, and tests will execute under the debugger. To customize the port or target a specific test:

```bash
# Custom port
mvn test -Dmaven.surefire.debug="-agentlib:jdwp=transport=dt_socket,server=y,suspend=y,address=*:8000"

# Single test class
mvn test -Dmaven.surefire.debug -Dtest=GraphPopulatorServiceTest

# Single test method
mvn test -Dmaven.surefire.debug -Dtest=GraphPopulatorServiceTest#testPopulateGraph
```

> **Tip:** Most IDEs can also debug individual tests natively (right-click > Debug). Use `mvn test -Dmaven.surefire.debug` when you need to reproduce a failure that only occurs under Maven's test lifecycle (e.g., Surefire forking, TestContainers resource lifecycle).

---

## Quick Reference

| Scenario                    | Command / Config                                                                 | Port | `suspend` |
|-----------------------------|----------------------------------------------------------------------------------|------|-----------|
| Docker backend              | `docker compose up -d` (already configured)                                      | 5005 | `n`       |
| Local `spring-boot:run`     | `mvn spring-boot:run -Dspring-boot.run.jvmArguments="..."`                       | 5005 | `n`       |
| Fat JAR                     | `java -agentlib:jdwp=... -jar backend.jar`                                       | 5005 | `n`       |
| CLI tool                    | `java -agentlib:jdwp=... -jar cli-shaded.jar`                                    | 5005 | `y`       |
| Unit / integration tests    | `mvn test -Dmaven.surefire.debug`                                                | 5005 | `y`       |
| Startup / bean init         | Change `suspend=n` to `suspend=y` in docker-compose.yml                          | 5005 | `y`       |
| Remote server               | `ssh -L 5005:localhost:5005 user@host`, then attach to `localhost:5005`           | 5005 | `n`       |

---

## Security Considerations

JDWP has **no authentication or encryption**. Anyone who can reach the debug port can:

- Read and modify any variable in the running JVM
- Execute arbitrary code via expression evaluation
- Dump the entire heap, including secrets and credentials

**Rules for safe use:**

1. **Never enable JDWP in production.** Remove or comment out the `JAVA_TOOL_OPTIONS` environment variable before deploying.
2. **Bind to localhost only** when possible: `address=127.0.0.1:5005` instead of `address=*:5005`.
3. **Use SSH tunnels** for remote debugging — never expose port 5005 directly on the network.
4. **Restrict Docker port mappings** on shared machines: `"127.0.0.1:5005:5005"` instead of `"5005:5005"`.
5. **Don't leave `suspend=y` enabled** — it will cause health check failures and block container startup.
