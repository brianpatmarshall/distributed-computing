# Optimizing GraphPopulatorService: Batch Writes for Neo4j

This document explains why the current `GraphPopulatorService` is slow and provides step-by-step instructions for optimizing it with batched writes.

---

## The Problem

Every node and relationship is saved to Neo4j **one at a time**. Each `repository.save()` call is a separate Bolt round trip — a Cypher statement is sent, the server processes it, and the result comes back over the network. For a moderately large project, the count of individual round trips looks like this:

| Method | What it saves | Round trips |
|--------|--------------|-------------|
| `createFileNodes` | FileNodes, one by one | N files × 2 (findByPath + save) |
| `createFileNodes` (end) | ProjectNode with all CONTAINS | 1 (but this one is expensive — see below) |
| `createConstantNodes` | ConstantNodes, one by one | N constants × 1 |
| `createParameterNodes` | ParameterNodes, one by one | N parameters × 1 |
| `createUsageRelationships` | Modified ParameterNodes | N modified params × 1 |
| `createConstantUsageRelationships` | Modified ConstantNodes | N modified constants × 1 |
| `setJavaFileFqns` | FileNodes, one by one | N java files × 1 |

For a project with 300 files, 500 constants, 200 parameters, and 1000 usages, that's roughly **2,500+ individual Bolt round trips** inside a single `@Transactional` block.

### The hidden cost in `projectRepository.save(project)`

Spring Data Neo4j's `save()` on `ProjectNode` traverses the **entire entity graph** reachable from the root. Because `ProjectNode.files` is a `Set<FileNode>`, saving the project after adding all files means SDN generates Cypher that:

1. Merges the ProjectNode itself
2. Merges **every** FileNode in the `files` set
3. Creates/merges the CONTAINS relationship for each one

This happens every time `projectRepository.save(project)` is called. In `createFileNodes`, it's called once at the end with all files attached — but in the current loop, each file is also saved individually before being added to the project. That's double work.

### The hidden cost in `constantRepository.save(node)` during usage relationships

When `createConstantUsageRelationships` calls `constantRepository.save(constant)`, SDN doesn't just save the constant — it traverses the constant's `definedIn` FileNode **and** every `UsageRelationship` with its `@TargetNode` FileNode. The deeper the entity graph, the more Cypher SDN generates per `save()`. This cost compounds: a constant with 10 usages triggers 10 relationship merges plus 10 file node merges on every save.

---

## The Solution: Two-Part Optimization

### Part A: Use `saveAll()` for Bulk Node Creation

Spring Data Neo4j's `saveAll(Iterable<T>)` generates a single `UNWIND`-based Cypher statement that creates/merges all nodes in one Bolt round trip. This is dramatically faster than individual `save()` calls.

### Part B: Decouple the CONTAINS Relationship from the Save Loop

Instead of building up `ProjectNode.files` and saving the project (which triggers a full graph traversal), create the CONTAINS relationships with a single custom Cypher query.

---

## Step-by-Step Changes

All changes are in one file:

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/GraphPopulatorService.java`

Unless otherwise noted. Steps 4 and 7 add a method to `FileRepository`.

---

### Step 0: Add a Batch Size Constant

At the top of the `GraphPopulatorService` class (after line 35), add:

```java
private static final int BATCH_SIZE = 500;
```

This is the chunk size for `saveAll()` calls. 500 is a good balance — large enough to minimize round trips, small enough to keep individual transactions manageable. You can tune this later based on your data size.

Also add this import at the top of the file:

```java
import java.util.ArrayList;
import java.util.List;
```

And add a generic helper method at the bottom of the class (before the closing brace):

```java
/*
 * Splits a list into chunks of the given size.
 * Used to batch saveAll() calls to avoid overwhelming the Bolt connection.
 */
private <T> List<List<T>> partition(List<T> list, int size) {
    List<List<T>> partitions = new ArrayList<>();
    for (int i = 0; i < list.size(); i += size) {
        partitions.add(list.subList(i, Math.min(i + size, list.size())));
    }
    return partitions;
}
```

---

### Step 1: Batch `createFileNodes`

**Current code (lines 141-157):**

```java
private Map<String, FileNode> createFileNodes(Set<String> filePaths, ProjectNode project) {
    Map<String, FileNode> cache = new HashMap<>();

    for (String path : filePaths) {
        FileNode file = fileRepository.findByPath(path)
            .orElseGet(() -> {
                FileNode newFile = FileNode.fromPath(path);
                return fileRepository.save(newFile);
            });

        project.addFile(file);
        cache.put(path, file);
    }

    projectRepository.save(project);
    return cache;
}
```

**Replace with:**

```java
private Map<String, FileNode> createFileNodes(Set<String> filePaths, ProjectNode project) {
    Map<String, FileNode> cache = new HashMap<>();

    // Separate existing files from new files
    List<FileNode> newFiles = new ArrayList<>();

    for (String path : filePaths) {
        fileRepository.findByPath(path).ifPresentOrElse(
            existing -> cache.put(path, existing),
            () -> newFiles.add(FileNode.fromPath(path))
        );
    }

    // Batch-save all new files
    for (List<FileNode> batch : partition(newFiles, BATCH_SIZE)) {
        List<FileNode> saved = fileRepository.saveAll(batch);
        saved.forEach(f -> cache.put(f.getPath(), f));
    }

    // Create CONTAINS relationships in bulk
    List<String> allPaths = new ArrayList<>(cache.keySet());
    for (List<String> batch : partition(allPaths, BATCH_SIZE)) {
        fileRepository.createContainsRelationships(project.getId(), batch);
    }

    log.debug("Created {} file nodes ({} new)", cache.size(), newFiles.size());
    return cache;
}
```

**What changed:**
- Existing files are looked up one by one (this is still N queries, but read-only lookups are fast). New files are collected into a list.
- All new files are batch-saved with `saveAll()` in chunks of 500.
- Instead of calling `project.addFile(file)` + `projectRepository.save(project)` (which triggers a full entity graph traversal), we use a custom Cypher query to create the CONTAINS relationships in bulk.
- The `projectRepository.save(project)` call at the end is **removed entirely**.

---

### Step 2: Add the Custom Cypher Method to FileRepository

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/repository/FileRepository.java`

Add this method to the interface:

```java
@Query("""
    MATCH (p:Project) WHERE p.id = $projectId
    MATCH (f:File) WHERE f.path IN $filePaths
    MERGE (p)-[:CONTAINS]->(f)
    """)
void createContainsRelationships(String projectId, List<String> filePaths);
```

This replaces the SDN entity-graph traversal with a single targeted Cypher `MERGE`. The `MERGE` is idempotent — safe for re-scans.

Add the `List` import if it's not already there:

```java
import java.util.List;
```

---

### Step 3: Batch `createConstantNodes`

**Current code (lines 159-173):**

```java
private Map<String, ConstantNode>
createConstantNodes(ProjectScanner.ScanResult result, Map<String, FileNode> fileCache) {
    Map<String, ConstantNode> cache = new HashMap<>();

    for (Constant constant : result.constants()) {
        FileNode file = fileCache.get(constant.fileName());
        ConstantNode node = ConstantNode.fromConstant(constant, file);
        ConstantNode saved = constantRepository.save(node);
        String key = constant.className() + "." + constant.name();
        cache.put(key, saved);
    }

    log.debug("Created {} constant nodes", result.constants().size());
    return cache;
}
```

**Replace with:**

```java
private Map<String, ConstantNode>
createConstantNodes(ProjectScanner.ScanResult result, Map<String, FileNode> fileCache) {
    Map<String, ConstantNode> cache = new HashMap<>();

    // Build all ConstantNode objects in memory first
    List<ConstantNode> nodes = new ArrayList<>();
    List<String> keys = new ArrayList<>();

    for (Constant constant : result.constants()) {
        FileNode file = fileCache.get(constant.fileName());
        ConstantNode node = ConstantNode.fromConstant(constant, file);
        nodes.add(node);
        keys.add(constant.className() + "." + constant.name());
    }

    // Batch-save in chunks
    int index = 0;
    for (List<ConstantNode> batch : partition(nodes, BATCH_SIZE)) {
        List<ConstantNode> saved = constantRepository.saveAll(batch);
        for (ConstantNode s : saved) {
            cache.put(keys.get(index++), s);
        }
    }

    log.debug("Created {} constant nodes", result.constants().size());
    return cache;
}
```

**What changed:**
- All `ConstantNode` objects are built in memory first (cheap — no I/O).
- They're saved in one `saveAll()` call per 500-node chunk instead of N individual `save()` calls.
- The cache key list runs in parallel with the node list to maintain the mapping.

### Important note about `saveAll()` and relationships

When SDN executes `saveAll()` for `ConstantNode`, it still traverses the `definedIn` FileNode relationship. This is fine here because these are the **initial saves** — the `usages` set is empty, so SDN only traverses the single `definedIn` edge per node. The expensive case is Step 5 below, where usages have been added.

---

### Step 4: Batch `createParameterNodes`

**Current code (lines 175-190):**

```java
private Map<String, ParameterNode> createParameterNodes(
        ProjectScanner.ScanResult result,
        Map<String, FileNode> fileCache) {

    Map<String, ParameterNode> cache = new HashMap<>();

    for (Parameter parameter : result.parameters()) {
        FileNode file = fileCache.get(parameter.definitionFile());
        ParameterNode node = ParameterNode.fromParameter(parameter, file);
        ParameterNode saved = parameterRepository.save(node);
        cache.put(parameter.name(), saved);
    }

    log.debug("Created {} parameter nodes", result.parameters().size());
    return cache;
}
```

**Replace with:**

```java
private Map<String, ParameterNode> createParameterNodes(
        ProjectScanner.ScanResult result,
        Map<String, FileNode> fileCache) {

    Map<String, ParameterNode> cache = new HashMap<>();

    List<ParameterNode> nodes = new ArrayList<>();
    List<String> names = new ArrayList<>();

    for (Parameter parameter : result.parameters()) {
        FileNode file = fileCache.get(parameter.definitionFile());
        ParameterNode node = ParameterNode.fromParameter(parameter, file);
        nodes.add(node);
        names.add(parameter.name());
    }

    int index = 0;
    for (List<ParameterNode> batch : partition(nodes, BATCH_SIZE)) {
        List<ParameterNode> saved = parameterRepository.saveAll(batch);
        for (ParameterNode s : saved) {
            cache.put(names.get(index++), s);
        }
    }

    log.debug("Created {} parameter nodes", result.parameters().size());
    return cache;
}
```

Same pattern as Step 3. Build in memory, batch-save.

---

### Step 5: Batch `createUsageRelationships`

This is the trickiest step. The current code adds `UsageRelationship` objects to the `ParameterNode.usages` set and then saves each modified parameter. Each save traverses the full entity graph (definedIn + all usages + their target files).

**Current code (lines 192-225):**

```java
private void createUsageRelationships(
        ProjectScanner.ScanResult result,
        Map<String, FileNode> fileCache,
        Map<String, ParameterNode> parameterCache) {

    Set<ParameterNode> modified = new java.util.LinkedHashSet<>();

    for (ParameterUsage usage : result.parameterUsages()) {
        ParameterNode parameter = parameterCache.get(usage.parameterName());
        if (parameter == null) {
            log.warn("Usage references unknown parameter: {}", usage.parameterName());
            continue;
        }

        FileNode file = fileCache.get(usage.usedInFile());
        if (file == null) {
            log.warn("Usage references unknown file: {}", usage.usedInFile());
            continue;
        }

        UsageRelationship usageRel = UsageRelationship.create(
            file,
            usage.usedInClass(),
            usage.lineNumber(),
            usage.context()
        );

        parameter.addUsage(usageRel);
        modified.add(parameter);
    }

    modified.forEach(parameterRepository::save);
    log.debug("Created {} usage relationships", result.parameterUsages().size());
}
```

**Replace with:**

```java
private void createUsageRelationships(
        ProjectScanner.ScanResult result,
        Map<String, FileNode> fileCache,
        Map<String, ParameterNode> parameterCache) {

    Set<ParameterNode> modified = new java.util.LinkedHashSet<>();

    for (ParameterUsage usage : result.parameterUsages()) {
        ParameterNode parameter = parameterCache.get(usage.parameterName());
        if (parameter == null) {
            log.warn("Usage references unknown parameter: {}", usage.parameterName());
            continue;
        }

        FileNode file = fileCache.get(usage.usedInFile());
        if (file == null) {
            log.warn("Usage references unknown file: {}", usage.usedInFile());
            continue;
        }

        UsageRelationship usageRel = UsageRelationship.create(
            file,
            usage.usedInClass(),
            usage.lineNumber(),
            usage.context()
        );

        parameter.addUsage(usageRel);
        modified.add(parameter);
    }

    // Batch-save modified parameters with their new usages
    List<ParameterNode> modifiedList = new ArrayList<>(modified);
    for (List<ParameterNode> batch : partition(modifiedList, BATCH_SIZE)) {
        parameterRepository.saveAll(batch);
    }

    log.debug("Created {} usage relationships across {} parameters",
        result.parameterUsages().size(), modified.size());
}
```

**What changed:**
- The in-memory relationship building (the loop) stays the same — that's just Java objects, no I/O.
- The single-save-per-parameter at the end is replaced with `saveAll()` in batches.
- `saveAll()` for entities with relationships is still heavier than for bare nodes, because SDN traverses the relationship graph. But batching reduces the number of Bolt round trips from N to ceil(N/500).

---

### Step 6: Batch `createConstantUsageRelationships`

Same pattern as Step 5.

**Current code (lines 227-261):**

```java
private void createConstantUsageRelationships(
        ProjectScanner.ScanResult result,
        Map<String, FileNode> fileCache,
        Map<String, ConstantNode> constantCache) {

    Set<ConstantNode> modified = new java.util.LinkedHashSet<>();

    for (ConstantUsage usage : result.constantUsages()) {
        String key = usage.definingClassName() + "." + usage.constantName();
        ConstantNode constant = constantCache.get(key);
        if (constant == null) {
            log.warn("Usage references unknown constant: {}", key);
            continue;
        }

        FileNode file = fileCache.get(usage.usedInFile());
        if (file == null) {
            log.warn("Usage references unknown file: {}", usage.usedInFile());
            continue;
        }

        UsageRelationship usageRel = UsageRelationship.create(
            file,
            usage.usedInClass(),
            usage.lineNumber(),
            usage.context()
        );

        constant.addUsage(usageRel);
        modified.add(constant);
    }

    modified.forEach(constantRepository::save);
    log.debug("Created {} constant usage relationships", result.constantUsages().size());
}
```

**Replace the last two lines** (`modified.forEach...` and the `log.debug`) with:

```java
    // Batch-save modified constants with their new usages
    List<ConstantNode> modifiedList = new ArrayList<>(modified);
    for (List<ConstantNode> batch : partition(modifiedList, BATCH_SIZE)) {
        constantRepository.saveAll(batch);
    }

    log.debug("Created {} constant usage relationships across {} constants",
        result.constantUsages().size(), modified.size());
```

---

### Step 7: Batch `setJavaFileFqns`

**Current code (lines 263-276):**

```java
private void setJavaFileFqns(
        ProjectScanner.ScanResult result,
        Map<String, FileNode> fileCache) {

    for (Map.Entry<String, String> entry : result.javaFileFqns().entrySet()) {
        FileNode file = fileCache.get(entry.getKey());
        if (file != null) {
            file.setFqn(entry.getValue());
            fileRepository.save(file);
        }
    }

    log.debug("Set FQN on {} Java file nodes", result.javaFileFqns().size());
}
```

**Replace with:**

```java
private void setJavaFileFqns(
        ProjectScanner.ScanResult result,
        Map<String, FileNode> fileCache) {

    List<FileNode> toSave = new ArrayList<>();

    for (Map.Entry<String, String> entry : result.javaFileFqns().entrySet()) {
        FileNode file = fileCache.get(entry.getKey());
        if (file != null) {
            file.setFqn(entry.getValue());
            toSave.add(file);
        }
    }

    for (List<FileNode> batch : partition(toSave, BATCH_SIZE)) {
        fileRepository.saveAll(batch);
    }

    log.debug("Set FQN on {} Java file nodes", toSave.size());
}
```

---

### Step 8: Add Timing Logs to `populateGraph`

This step is optional but strongly recommended. It lets you measure the improvement.

**Replace the `populateGraph` method body (lines 43-97) with:**

```java
@Transactional
public void populateGraph(String projectPath, String projectName, ProjectScanner.ScanResult scanResult) {
    log.info("Populating graph for project: {} ({} constants, {} parameters, {} const usages, {} param usages)",
        projectName,
        scanResult.constants().size(),
        scanResult.parameters().size(),
        scanResult.constantUsages().size(),
        scanResult.parameterUsages().size());

    long start = System.currentTimeMillis();

    // Step 1: Create or update the project node
    ProjectNode project = projectRepository.findByRootPath(projectPath)
        .map(existing -> updateProject(existing, scanResult))
        .orElseGet(() -> createProject(projectPath, projectName, scanResult));
    log.info("  Step 1 (project node): {}ms", System.currentTimeMillis() - start);

    // Step 2: Collect all unique file paths
    long stepStart = System.currentTimeMillis();
    Set<String> allFilePaths = collectAllFilePaths(scanResult);
    log.info("  Step 2 (collect paths): {}ms — {} unique paths", System.currentTimeMillis() - stepStart, allFilePaths.size());

    // Step 3: Create file nodes
    stepStart = System.currentTimeMillis();
    Map<String, FileNode> fileCache = createFileNodes(allFilePaths, project);
    log.info("  Step 3 (file nodes): {}ms", System.currentTimeMillis() - stepStart);

    // Step 4: Create constant nodes
    stepStart = System.currentTimeMillis();
    Map<String, ConstantNode> constantCache = createConstantNodes(scanResult, fileCache);
    log.info("  Step 4 (constant nodes): {}ms", System.currentTimeMillis() - stepStart);

    // Step 5: Create parameter nodes
    stepStart = System.currentTimeMillis();
    Map<String, ParameterNode> parameterCache = createParameterNodes(scanResult, fileCache);
    log.info("  Step 5 (parameter nodes): {}ms", System.currentTimeMillis() - stepStart);

    // Step 6: Create parameter usage relationships
    stepStart = System.currentTimeMillis();
    createUsageRelationships(scanResult, fileCache, parameterCache);
    log.info("  Step 6 (param usages): {}ms", System.currentTimeMillis() - stepStart);

    // Step 7: Create constant usage relationships
    stepStart = System.currentTimeMillis();
    createConstantUsageRelationships(scanResult, fileCache, constantCache);
    log.info("  Step 7 (const usages): {}ms", System.currentTimeMillis() - stepStart);

    // Step 8: Set FQNs
    stepStart = System.currentTimeMillis();
    setJavaFileFqns(scanResult, fileCache);
    log.info("  Step 8 (FQNs): {}ms", System.currentTimeMillis() - stepStart);

    log.info("Graph population complete for project: {} — total: {}ms", projectName, System.currentTimeMillis() - start);
}
```

---

## Summary of Changes

| File | Change |
|------|--------|
| `GraphPopulatorService.java` | Add `BATCH_SIZE` constant |
| `GraphPopulatorService.java` | Add `partition()` helper method |
| `GraphPopulatorService.java` | Rewrite `createFileNodes` — batch `saveAll()` + custom Cypher for CONTAINS |
| `GraphPopulatorService.java` | Rewrite `createConstantNodes` — batch `saveAll()` |
| `GraphPopulatorService.java` | Rewrite `createParameterNodes` — batch `saveAll()` |
| `GraphPopulatorService.java` | Rewrite `createUsageRelationships` — batch `saveAll()` |
| `GraphPopulatorService.java` | Rewrite `createConstantUsageRelationships` — batch `saveAll()` |
| `GraphPopulatorService.java` | Rewrite `setJavaFileFqns` — batch `saveAll()` |
| `GraphPopulatorService.java` | Add timing logs to `populateGraph` |
| `FileRepository.java` | Add `createContainsRelationships()` custom Cypher method |

---

## Expected Impact

| Metric | Before | After |
|--------|--------|-------|
| Bolt round trips (300 files, 500 constants, 200 params, 1000 usages) | ~2,500+ | ~15-20 |
| `projectRepository.save(project)` traversals | 1 (traverses all 300 files) | 0 (replaced by direct Cypher) |
| Entity graph traversal depth per save | Full (node + relationships + target nodes) | Same per `saveAll()`, but batched |

The biggest win comes from replacing individual `save()` calls with `saveAll()` — it's not just fewer round trips, it's also fewer Cypher compilation steps on the Neo4j server side.

---

## Testing

1. **Before you change anything:** Run a scan against a medium-sized project and note the total time. If you added the timing logs from Step 8 first (before the batching changes), you'll see exactly which step is slowest.

2. **After the changes:** Run the same scan. Compare per-step times and overall duration.

3. **Re-scan idempotency:** Run the same scan twice. The second run should update existing nodes without creating duplicates. Check the Neo4j browser (`http://localhost:7474`) and verify node counts haven't doubled.

4. **Edge cases:**
   - Empty project (no Java files, no property files) — should complete without error.
   - Project with fewer than 500 nodes — should work identically (one batch covers everything).
   - Project with exactly 500 nodes — verify no off-by-one in the `partition()` method.

---

## Future Optimization: Raw Cypher for Relationships

If the batched `saveAll()` approach for usage relationships (Steps 5 and 6) is still too slow, the next level of optimization is bypassing SDN entirely for relationship creation and using raw Cypher with `UNWIND`:

```java
@Query("""
    UNWIND $rows AS row
    MATCH (p:Parameter) WHERE p.id = row.parameterId
    MATCH (f:File) WHERE f.id = row.fileId
    CREATE (p)-[:USED_IN {className: row.className, lineNumber: row.lineNumber, context: row.context}]->(f)
    """)
void createParameterUsages(List<Map<String, Object>> rows);
```

This avoids SDN's entity-graph traversal entirely. But it's more work — you have to construct the parameter maps manually. Try the `saveAll()` approach first and only escalate to raw Cypher if the usage relationship steps are still the bottleneck (the timing logs will tell you).
