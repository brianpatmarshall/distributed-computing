# SiteConfigurationService Architecture

## Overview

The SiteConfigurationService provides a centralized configuration management system that replaces hardcoded constants with runtime-configurable values. It implements a two-tier caching strategy with distributed invalidation for high performance and consistency across multiple application instances.

## The Problem It Solves

Before:
```java
public class EmailService {
    private static final String SMTP_HOST = "mail.yahoo.com";  // Hardcoded!
    private static final int SMTP_PORT = 587;                   // Can't change without recompile
}
```

After:
```java
public class EmailService {
    private final SiteConfigurationService config;

    public void sendEmail() {
        String host = config.lookup("smtp.host");              // Runtime configurable
        int port = config.lookupInt("smtp.port", 587);         // With type-safe defaults
    }
}
```

## Architecture Diagram

```mermaid
flowchart TB
    subgraph Neo4j["Neo4j Graph Database"]
        Constants[(Constants<br/>scanned)]
        Parameters[(Parameters<br/>defined)]
    end

    subgraph ValKey["ValKey Redis-compatible"]
        ConfigStore[("Configuration Store<br/>config:smtp.host = mail.com<br/>config:smtp.port = 587")]
        PubSub["Pub/Sub Channel<br/>config:changes"]
    end

    subgraph App1["Application Instance 1"]
        Cache1[Caffeine<br/>Local Cache]
        SCS1[SiteConfigurationService]
    end

    subgraph App2["Application Instance 2"]
        Cache2[Caffeine<br/>Local Cache]
        SCS2[SiteConfigurationService]
    end

    subgraph AppN["Application Instance N"]
        CacheN[Caffeine<br/>Local Cache]
        SCSN[SiteConfigurationService]
    end

    Neo4j -->|Export| ConfigStore
    ConfigStore <-->|GET/SET| SCS1
    ConfigStore <-->|GET/SET| SCS2
    ConfigStore <-->|GET/SET| SCSN

    PubSub -->|INVALIDATE| Cache1
    PubSub -->|INVALIDATE| Cache2
    PubSub -->|INVALIDATE| CacheN

    SCS1 <--> Cache1
    SCS2 <--> Cache2
    SCSN <--> CacheN

    style Neo4j fill:#008cc1,color:#fff
    style ValKey fill:#dc382d,color:#fff
    style App1 fill:#6db33f,color:#fff
    style App2 fill:#6db33f,color:#fff
    style AppN fill:#6db33f,color:#fff
```

## Component Details

### 1. SiteConfigurationService

The main service providing configuration lookups with a cache-aside pattern.

**Key Features:**
- Sub-millisecond lookups via Caffeine local cache
- Type-safe lookup methods (`lookupInt`, `lookupBoolean`, `lookupDouble`)
- Batch operations for efficiency
- Automatic cache invalidation via pub/sub

```java
// Basic lookup
String host = config.lookup("smtp.host");

// With default value
String host = config.lookup("smtp.host", "localhost");

// Type-safe lookups
int port = config.lookupInt("smtp.port", 587);
boolean ssl = config.lookupBoolean("smtp.ssl", true);
long timeout = config.lookupLong("smtp.timeout.ms", 30000L);

// Batch lookup
Map<String, String> settings = config.lookupBatch(List.of("smtp.host", "smtp.port", "smtp.user"));

// Prefix-based lookup
Map<String, String> smtpSettings = config.lookupByPrefix("smtp.");
```

### 2. ConfigurationChangeListener

Subscribes to ValKey pub/sub for real-time cache invalidation.

```mermaid
sequenceDiagram
    participant A as Instance A
    participant VK as ValKey
    participant B as Instance B
    participant N as Instance N

    A->>VK: store("smtp.host", "new.mail.com")
    VK->>VK: SET config:smtp.host "new.mail.com"
    A->>VK: PUBLISH config:changes "smtp.host"

    par Broadcast to all subscribers
        VK->>A: MESSAGE "smtp.host"
        VK->>B: MESSAGE "smtp.host"
        VK->>N: MESSAGE "smtp.host"
    end

    A->>A: invalidateLocal("smtp.host")
    B->>B: invalidateLocal("smtp.host")
    N->>N: invalidateLocal("smtp.host")
```

**Event-Driven Integration:**
```java
@Component
public class SmtpReloader {

    @EventListener
    public void onConfigChange(ConfigurationChangedEvent event) {
        if (event.getKey().startsWith("smtp.")) {
            reconnectSmtpServer();
        }
    }
}
```

### 3. ConfigurationExportService

Bridges Neo4j (discovery) and ValKey (runtime) by exporting cataloged configuration.

```mermaid
flowchart LR
    subgraph Neo4j["Neo4j"]
        C[Constants]
        P[Parameters]
    end

    subgraph Export["Export Service"]
        Strategy{Strategy?}
    end

    subgraph ValKey["ValKey"]
        Store[(Config Store)]
    end

    C --> Strategy
    P --> Strategy

    Strategy -->|CONSTANTS_AS_CONFIG| Store
    Strategy -->|PARAMETERS_AS_CONFIG| Store
    Strategy -->|MERGED| Store
    Strategy -->|FULL| Store
```

**Export Strategies:**

| Strategy | Description | Use Case |
|----------|-------------|----------|
| `CONSTANTS_AS_CONFIG` | Export constants that look like config (HOST, PORT, URL patterns) | Migrating legacy hardcoded values |
| `PARAMETERS_AS_CONFIG` | Export only property file parameters | Standard config management |
| `MERGED` | Both, with parameters overriding constants | Gradual migration |
| `FULL` | Everything with full key paths | Complete export |

**Key Derivation:**
```
Constant: SMTP_HOST in class EmailConfig
  -> ValKey key: smtp.host (converted to dot notation)

Parameter: mail.server.host in application.properties
  -> ValKey key: mail.server.host (preserved)
```

### 4. ValKeyConfig

Spring configuration for ValKey (Redis-compatible) connections.

```mermaid
classDiagram
    class ValKeyConfig {
        +ClientResources clientResources()
        +RedisURI redisUri()
        +RedisClient redisClient()
        +StatefulRedisConnection redisConnection()
        +StatefulRedisPubSubConnection redisPubSubConnection()
        +Caffeine caffeineBuilder()
    }

    class RedisClient {
        +connect()
        +connectPubSub()
    }

    class StatefulRedisConnection {
        +sync()
        +async()
    }

    class StatefulRedisPubSubConnection {
        +sync()
        +addListener()
    }

    ValKeyConfig --> RedisClient : creates
    RedisClient --> StatefulRedisConnection : creates
    RedisClient --> StatefulRedisPubSubConnection : creates
```

### 5. ConfigurationController

REST controller providing OpenAPI-documented endpoints for configuration management.

```mermaid
flowchart TB
    subgraph Controller["ConfigurationController"]
        subgraph Export["Export Operations"]
            E1["POST /export"]
            E2["POST /export/project"]
            E3["DELETE /export"]
        end

        subgraph Lookup["Lookup Operations"]
            L1["GET /lookup/{key}"]
            L2["GET /lookup/batch"]
            L3["GET /lookup/prefix/{prefix}"]
        end

        subgraph Store["Store Operations"]
            S1["POST /store"]
            S2["POST /store/batch"]
            S3["DELETE /{key}"]
        end

        subgraph Cache["Cache Management"]
            C1["POST /cache/invalidate"]
            C2["GET /stats"]
            C3["GET /stats/cache"]
            C4["GET /health"]
        end
    end

    style Export fill:#e74c3c,color:#fff
    style Lookup fill:#3498db,color:#fff
    style Store fill:#27ae60,color:#fff
    style Cache fill:#9b59b6,color:#fff
```

## Data Flow

### Lookup Flow (Cache Hit)

```mermaid
flowchart LR
    A[lookup] --> B{Caffeine<br/>Cache}
    B -->|HIT| C[Return Value]

    style B fill:#27ae60,color:#fff
    style C fill:#3498db,color:#fff
```

**Total time: ~50 nanoseconds**

### Lookup Flow (Cache Miss)

```mermaid
flowchart TB
    A["lookup('smtp.host')"] --> B{Caffeine<br/>Cache}
    B -->|MISS| C[Fetch from ValKey]
    C --> D["GET config:smtp.host"]
    D --> E["Return 'mail.example.com'"]
    E --> F[Populate Cache]
    F --> G[Return Value]

    style B fill:#e74c3c,color:#fff
    style C fill:#dc382d,color:#fff
    style F fill:#27ae60,color:#fff
```

**Total time: ~1-2 milliseconds (network)**

### Update Flow

```mermaid
flowchart TB
    A["store('smtp.host', 'new.mail.com')"] --> B[Update Local Cache]
    A --> C[ValKey SET]
    C --> D[ValKey PUBLISH]

    D --> E[Instance A<br/>already updated]
    D --> F[Instance B<br/>invalidate]
    D --> G[Instance N<br/>invalidate]

    style A fill:#9b59b6,color:#fff
    style D fill:#e74c3c,color:#fff
    style F fill:#f39c12,color:#fff
    style G fill:#f39c12,color:#fff
```

---

## Using Swagger UI

The Constants Catalog API is fully documented using OpenAPI 3.0 (Swagger). This provides an interactive interface for exploring and testing all API endpoints.

### Accessing Swagger UI

After starting the application, access the following URLs:

| Resource | URL |
|----------|-----|
| **Swagger UI** | http://localhost:8080/swagger-ui.html |
| **OpenAPI JSON** | http://localhost:8080/v3/api-docs |
| **OpenAPI YAML** | http://localhost:8080/v3/api-docs.yaml |

### Swagger UI Interface

```mermaid
flowchart TB
    subgraph SwaggerUI["Swagger UI Interface"]
        Header["API Title and Description"]
        Tags["API Tags Groups"]

        subgraph Operations["Operations by Tag"]
            Scan["Scan - Project scanning"]
            Query["Query - Graph queries"]
            Config["Configuration - Config management"]
            Export["Export - Neo4j to ValKey"]
            Cache["Cache - Cache management"]
            Stats["Statistics - Dashboard data"]
        end

        subgraph Details["Operation Details"]
            Summary["Summary and Description"]
            Params["Parameters"]
            ReqBody["Request Body with Examples"]
            Responses["Response Schemas"]
            TryIt["Try It Out Button"]
        end
    end

    Header --> Tags
    Tags --> Operations
    Operations --> Details

    style SwaggerUI fill:#85ea2d,color:#000
    style Operations fill:#49cc90,color:#fff
    style Details fill:#61affe,color:#fff
```

### Available API Tags

| Tag | Description | Key Endpoints |
|-----|-------------|---------------|
| **Scan** | Project scanning operations | `POST /api/scan` |
| **Query** | Neo4j graph queries | `GET /api/query/precanned`, `POST /api/query/execute` |
| **Configuration** | Config value management | `GET /api/config/lookup/{key}`, `POST /api/config/store` |
| **Export** | Export from Neo4j to ValKey | `POST /api/config/export` |
| **Cache** | Cache management | `POST /api/config/cache/invalidate`, `GET /api/config/stats/cache` |
| **Statistics** | Database statistics | `GET /api/stats`, `GET /api/stats/health` |

### Using Try It Out

Swagger UI allows you to test API endpoints directly from the browser:

1. **Navigate to an endpoint** - Click on any endpoint to expand it
2. **Click Try it out** - Enables the input fields
3. **Fill in parameters** - Enter required values or use the provided examples
4. **Click Execute** - Sends the request to the server
5. **View response** - See the response body, headers, and status code

### Example: Testing Configuration Lookup

```mermaid
sequenceDiagram
    participant User
    participant Swagger as Swagger UI
    participant API as Backend API
    participant ValKey

    User->>Swagger: Navigate to GET /api/config/lookup/{key}
    User->>Swagger: Click Try it out
    User->>Swagger: Enter key: smtp.host
    User->>Swagger: Click Execute
    Swagger->>API: GET /api/config/lookup/smtp.host
    API->>ValKey: GET config:smtp.host
    ValKey-->>API: mail.example.com
    API-->>Swagger: {"key":"smtp.host","value":"mail.example.com","found":true}
    Swagger-->>User: Display formatted response
```

### Example Requests from Swagger UI

**Scan a Project:**
```bash
curl -X 'POST' \
  'http://localhost:8080/api/scan' \
  -H 'Content-Type: application/json' \
  -d '{"projectPath": "/path/to/project"}'
```

**Export Configuration:**
```bash
curl -X 'POST' \
  'http://localhost:8080/api/config/export' \
  -H 'Content-Type: application/json' \
  -d '{"strategy": "MERGED"}'
```

**Lookup a Value:**
```bash
curl -X 'GET' \
  'http://localhost:8080/api/config/lookup/smtp.host'
```

**Store a Value:**
```bash
curl -X 'POST' \
  'http://localhost:8080/api/config/store' \
  -H 'Content-Type: application/json' \
  -d '{"key": "smtp.host", "value": "mail.example.com"}'
```

**Execute Cypher Query:**
```bash
curl -X 'POST' \
  'http://localhost:8080/api/query/execute' \
  -H 'Content-Type: application/json' \
  -d '{"cypher": "MATCH (c:Constant) WHERE c.type = 'String' RETURN c.name, c.value LIMIT 10"}'
```

### Downloading the OpenAPI Specification

You can download the OpenAPI specification for use with other tools:

- **For Postman**: Import the JSON from `/v3/api-docs`
- **For Code Generation**: Use the YAML from `/v3/api-docs.yaml` with OpenAPI Generator
- **For Documentation**: Export and host the spec with tools like Redoc

---

## API Reference

### Configuration Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/config/export` | Export config from Neo4j to ValKey |
| `POST` | `/api/config/export/project` | Export for specific project |
| `DELETE` | `/api/config/export` | Clear all exported config |
| `GET` | `/api/config/lookup/{key}` | Lookup single value |
| `GET` | `/api/config/lookup/batch?keys=a,b,c` | Lookup multiple values |
| `GET` | `/api/config/lookup/prefix/{prefix}` | Lookup by key prefix |
| `POST` | `/api/config/store` | Store a value |
| `POST` | `/api/config/store/batch` | Store multiple values |
| `DELETE` | `/api/config/{key}` | Delete a value |
| `POST` | `/api/config/cache/invalidate` | Invalidate cache entries |
| `GET` | `/api/config/stats` | Get service statistics |
| `GET` | `/api/config/stats/cache` | Get cache statistics |
| `GET` | `/api/config/health` | Health check |

### Scan Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/scan` | Scan a Java project |

### Query Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/query/precanned` | List available pre-canned queries |
| `GET` | `/api/query/precanned/{id}` | Execute a pre-canned query |
| `POST` | `/api/query/execute` | Execute ad-hoc Cypher query |

### Statistics Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/stats` | Get database statistics |
| `GET` | `/api/stats/constants` | Get all constants |
| `GET` | `/api/stats/parameters` | Get all parameters |
| `GET` | `/api/stats/health` | Health check |

---

## Configuration

### application.yml

```yaml
# ValKey Connection
valkey:
  host: ${VALKEY_HOST:localhost}
  port: ${VALKEY_PORT:6379}
  password: ${VALKEY_PASSWORD:}
  database: ${VALKEY_DATABASE:0}
  timeout: ${VALKEY_TIMEOUT:5000}

# Caffeine Local Cache
cache:
  caffeine:
    max-size: ${CACHE_MAX_SIZE:10000}
    expire-after-write-minutes: ${CACHE_EXPIRE_MINUTES:60}

# SpringDoc OpenAPI / Swagger UI
springdoc:
  api-docs:
    path: /v3/api-docs
    enabled: true
  swagger-ui:
    path: /swagger-ui.html
    enabled: true
    operations-sorter: method
    tags-sorter: alpha
    display-request-duration: true
    filter: true
```

### Docker Compose

```yaml
services:
  valkey:
    image: valkey/valkey:8-alpine
    ports:
      - "6379:6379"
    command: ["valkey-server", "--appendonly", "yes"]
    healthcheck:
      test: ["CMD", "valkey-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5
```

---

## Migration Guide

```mermaid
flowchart TB
    subgraph Step1["Step 1: Scan"]
        S1[Scan Project]
        S1 --> S1R[Constants and Parameters<br/>stored in Neo4j]
    end

    subgraph Step2["Step 2: Review"]
        S2[Query Neo4j]
        S2 --> S2R[Identify config<br/>candidates]
    end

    subgraph Step3["Step 3: Export"]
        S3[Export to ValKey]
        S3 --> S3R[Config available<br/>for runtime lookup]
    end

    subgraph Step4["Step 4: Update Code"]
        S4[Replace hardcoded<br/>values]
        S4 --> S4R[Use SiteConfigurationService]
    end

    subgraph Step5["Step 5: Verify"]
        S5[Test lookups<br/>via Swagger UI]
        S5 --> S5R[Confirm values<br/>accessible]
    end

    Step1 --> Step2 --> Step3 --> Step4 --> Step5

    style Step1 fill:#3498db,color:#fff
    style Step2 fill:#9b59b6,color:#fff
    style Step3 fill:#e74c3c,color:#fff
    style Step4 fill:#27ae60,color:#fff
    style Step5 fill:#f39c12,color:#fff
```

### Step 1: Scan Your Project

Using Swagger UI or curl:
```bash
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{"projectPath": "/path/to/your/project"}'
```

### Step 2: Review Constants in Neo4j

Open Neo4j Browser at http://localhost:7474 and run:

```cypher
// Find constants that look like configuration
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
WHERE c.name =~ '(?i).*(HOST|PORT|URL|PASSWORD|TIMEOUT).*'
RETURN c.name, c.value, c.className, f.fileName
ORDER BY c.name
```

Or use Swagger UI to execute the pre-canned query:
```
GET /api/query/precanned/config-candidates
```

### Step 3: Export to ValKey

```bash
curl -X POST http://localhost:8080/api/config/export \
  -H "Content-Type: application/json" \
  -d '{"strategy": "MERGED"}'
```

### Step 4: Update Your Code

Replace hardcoded constants with service lookups:

```java
// Before
private static final String DB_HOST = "prod-db.example.com";

// After
@Autowired
private SiteConfigurationService config;

public void connect() {
    String dbHost = config.lookup("db.host", "localhost");
}
```

### Step 5: Verify via Swagger UI

1. Open http://localhost:8080/swagger-ui.html
2. Navigate to **Configuration** then `GET /api/config/lookup/{key}`
3. Click **Try it out**
4. Enter `db.host` as the key
5. Click **Execute**
6. Verify the response shows the expected value

---

## Best Practices

### 1. Use Meaningful Key Names

```java
// Good
config.lookup("email.smtp.host")
config.lookup("database.connection.pool.size")

// Avoid
config.lookup("host1")
config.lookup("val")
```

### 2. Always Provide Defaults

```java
// Good - app works even if config missing
int timeout = config.lookupInt("http.timeout.ms", 30000);

// Risky - NPE if config missing
String host = config.lookup("some.host");  // Could be null!
```

### 3. Group Related Configuration

```java
// Lookup all SMTP settings at once
Map<String, String> smtpConfig = config.lookupByPrefix("smtp.");
```

### 4. Handle Configuration Changes

```java
@EventListener
public void onConfigChange(ConfigurationChangedEvent event) {
    log.info("Config changed: {}", event.getKey());
    // React to changes (reconnect, refresh, etc.)
}
```

### 5. Monitor Cache Performance

Use Swagger UI to check statistics:
```
GET /api/config/stats
```

Look for:
- High hit rate (greater than 95% is good)
- Low eviction count (cache is sized appropriately)
- Listener connected (pub/sub working)

---

## Troubleshooting

```mermaid
flowchart TB
    subgraph Issue1["Cache Not Invalidating"]
        I1A[Check pub/sub connection]
        I1B[Verify listener stats]
        I1A --> I1B
    end

    subgraph Issue2["High Cache Miss Rate"]
        I2A[Check cache size config]
        I2B[Verify TTL settings]
        I2C[Consider pre-warming]
        I2A --> I2B --> I2C
    end

    subgraph Issue3["ValKey Connection Issues"]
        I3A[Check ValKey is running]
        I3B[Test connectivity with CLI]
        I3A --> I3B
    end

    subgraph Issue4["Swagger UI Not Loading"]
        I4A[Check springdoc config]
        I4B[Verify dependency added]
        I4C[Check for CORS issues]
        I4A --> I4B --> I4C
    end
```

### Cache Not Invalidating

1. Check pub/sub connection via Swagger UI:
```
GET /api/config/health
```

2. Verify listener stats:
```
GET /api/config/stats
```

### High Cache Miss Rate

1. Check cache size configuration in `application.yml`
2. Verify TTL is appropriate for your use case
3. Consider pre-warming cache on startup

### ValKey Connection Issues

1. Check ValKey is running:
```bash
docker-compose logs valkey
```

2. Test connectivity:
```bash
docker exec const-catalog-valkey valkey-cli ping
```

### Swagger UI Not Loading

1. Verify the dependency is in `pom.xml`:
```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
</dependency>
```

2. Check springdoc is enabled in `application.yml`:
```yaml
springdoc:
  swagger-ui:
    enabled: true
```

3. Ensure no security filters are blocking `/swagger-ui/**` or `/v3/api-docs/**`

---

## Technology Stack

```mermaid
mindmap
  root((SiteConfiguration<br/>Service))
    Java 21
      Records
      Pattern Matching
      Virtual Threads
    Lombok
      RequiredArgsConstructor
      Slf4j
      Builder
    Caffeine
      Local Cache
      Statistics
      Eviction Policies
    Lettuce
      Async Client
      PubSub Support
      Connection Pooling
    Spring Boot 3.4
      DI Container
      Configuration
      Events
    ValKey 8
      Redis Compatible
      Persistence
      PubSub
    SpringDoc OpenAPI
      Swagger UI
      OpenAPI 3.0
      Interactive Docs
```

---

## Conclusion

The SiteConfigurationService transforms your application from one with scattered hardcoded values to one with centralized, runtime-configurable settings. The two-tier caching strategy ensures sub-millisecond lookups while the pub/sub mechanism maintains consistency across all application instances.

**Key Benefits:**
- No recompilation needed to change configuration
- Consistent view across all instances
- High performance with local caching
- Audit trail through Neo4j catalog
- Gradual migration path from hardcoded values
- Full API documentation via Swagger UI
- Interactive API testing and exploration
