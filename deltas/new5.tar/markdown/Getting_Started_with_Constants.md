# Getting Started with Constants Catalog

## The Paradox of Constants

There is a peculiar irony in software development: we call them "constants," yet they are among the most likely things to change.

Consider a database connection string. We declare it `private static final`—the most emphatic way Java offers to say "this shall not change." And yet, when the database moves, when the port shifts, when the password rotates, we find ourselves recompiling, redeploying, and restarting. The constant was never truly constant; it was merely hardcoded.

This is the philosophical foundation of the Constants Catalog: **the recognition that what we name "constant" is often merely "convenient."**

```mermaid
graph LR
    subgraph "The Illusion"
        A[static final String DB_HOST = 'prod-db.internal'] --> B[Compiled into bytecode]
        B --> C[Deployed to production]
        C --> D{Database moves?}
        D -->|Yes| E[Recompile]
        E --> F[Redeploy]
        F --> G[Restart]
        G --> C
    end

    style A fill:#ff6b6b,stroke:#333,color:#000
    style D fill:#ffd93d,stroke:#333,color:#000
    style E fill:#ff6b6b,stroke:#333,color:#000
```

## Why This Tool Exists

Every mature codebase accumulates configuration debt. It happens gradually, innocuously:

- A developer hardcodes a timeout because "it's just for testing"
- A URL gets embedded because "we'll never change providers"
- A port number becomes a constant because "it's always 8080"

Years pass. The codebase grows. These scattered decisions become archaeological layers, each one a small bet against change that eventually comes due.

```mermaid
graph TB
    subgraph "Configuration Debt Accumulation"
        Y1[Year 1: 5 hardcoded values] --> Y2[Year 2: 23 hardcoded values]
        Y2 --> Y3[Year 3: 87 hardcoded values]
        Y3 --> Y4[Year 4: 200+ hardcoded values]
        Y4 --> CRISIS[Configuration Crisis]
    end

    subgraph "The Questions"
        CRISIS --> Q1[Where are they all?]
        CRISIS --> Q2[Which ones matter?]
        CRISIS --> Q3[What depends on what?]
    end

    style CRISIS fill:#ff6b6b,stroke:#333,color:#000
    style Q1 fill:#4ecdc4,stroke:#333,color:#000
    style Q2 fill:#4ecdc4,stroke:#333,color:#000
    style Q3 fill:#4ecdc4,stroke:#333,color:#000
```

The Constants Catalog exists to make this invisible debt visible. It answers questions that are surprisingly hard to answer otherwise:

- **Where are our hardcoded values?** Not just "somewhere in the code," but precisely which files, which classes, which lines.
- **What should be externalized?** Constants named `DATABASE_HOST` or `API_TIMEOUT` are begging to be parameters.
- **What parameters do we define but never use?** Dead configuration is clutter that confuses and misleads.
- **What parameters are used everywhere?** High-usage parameters have high blast radius when changed.

## The Graph Perspective

We chose Neo4J as our storage engine deliberately. Configuration relationships form a natural graph:

```mermaid
graph TB
    subgraph "Neo4J Graph Model"
        P[🗂️ Project<br/>myapp] -->|CONTAINS| F1[📄 File<br/>Config.java]
        P -->|CONTAINS| F2[📄 File<br/>app.properties]
        P -->|CONTAINS| F3[📄 File<br/>Service.java]

        F1 -->|DEFINES| C1[🔷 Constant<br/>DB_HOST]
        F1 -->|DEFINES| C2[🔷 Constant<br/>TIMEOUT]

        F2 -->|DEFINES| P1[⚙️ Parameter<br/>db.host]
        F2 -->|DEFINES| P2[⚙️ Parameter<br/>api.timeout]

        P1 -->|USED_IN| F3
        P2 -->|USED_IN| F3
        P2 -->|USED_IN| F1
    end

    style P fill:#6c5ce7,stroke:#333,color:#fff
    style F1 fill:#00cec9,stroke:#333,color:#000
    style F2 fill:#00cec9,stroke:#333,color:#000
    style F3 fill:#00cec9,stroke:#333,color:#000
    style C1 fill:#fd79a8,stroke:#333,color:#000
    style C2 fill:#fd79a8,stroke:#333,color:#000
    style P1 fill:#fdcb6e,stroke:#333,color:#000
    style P2 fill:#fdcb6e,stroke:#333,color:#000
```

This structure enables queries that would be awkward or impossible with relational storage:

- "Find all constants that share the same value" (consolidation candidates)
- "Show me the path from parameter definition to usage" (impact analysis)
- "Which files have the highest configuration coupling?" (architectural insights)

The graph is not merely a storage choice; it's a **way of seeing** configuration as interconnected rather than isolated.

---

## System Architecture

Before diving into setup, understanding the architecture helps contextualize each component's role:

```mermaid
flowchart TB
    subgraph "User Interfaces"
        CLI[🖥️ CLI Tool<br/>const-catalog-cli.jar]
        WEB[🌐 Web UI<br/>React + Tailwind]
    end

    subgraph "Backend Services"
        API[🔌 REST API<br/>Spring Boot]
        SCAN[📡 Scan Service]
        QUERY[🔍 Query Service]
        GRAPH[📊 Graph Populator]
    end

    subgraph "Core Engine"
        CORE[⚙️ Core Module]
        PARSER_J[Java Parser]
        PARSER_P[Property Parser]
        SCANNER[Project Scanner]
    end

    subgraph "Storage"
        NEO4J[(🔵 Neo4J<br/>Graph Database)]
        CSV[📁 CSV Export]
    end

    WEB --> API
    CLI --> CORE
    CLI --> CSV

    API --> SCAN
    API --> QUERY
    SCAN --> CORE
    SCAN --> GRAPH
    GRAPH --> NEO4J
    QUERY --> NEO4J

    CORE --> SCANNER
    SCANNER --> PARSER_J
    SCANNER --> PARSER_P

    style NEO4J fill:#008cc1,stroke:#333,color:#fff
    style API fill:#6db33f,stroke:#333,color:#fff
    style CORE fill:#f0932b,stroke:#333,color:#000
    style WEB fill:#00d8ff,stroke:#333,color:#000
```

---

## Prerequisites

Before beginning, ensure you have:

- **Java 21** or later
- **Maven 3.8+**
- **Docker and Docker Compose** (for Neo4J and containerized deployment)
- **Node.js 18+** (for frontend development)

---

## Two Ways to Scan: Choose Your Approach

The Constants Catalog offers two distinct approaches for scanning projects and populating Neo4j. Choose based on your environment and needs:

```mermaid
flowchart TB
    subgraph "Choose Your Approach"
        START[I want to scan a project] --> Q1{Do I have Docker running?}

        Q1 -->|Yes| Q2{Do I want the Web UI?}
        Q1 -->|No| APPROACH_B

        Q2 -->|Yes| APPROACH_A[Approach A:<br/>Full Stack + Direct Neo4j]
        Q2 -->|No| Q3{Is Neo4j already running<br/>somewhere else?}

        Q3 -->|Yes| APPROACH_B[Approach B:<br/>CLI + CSV Export]
        Q3 -->|No| APPROACH_A
    end

    subgraph "Approach A Benefits"
        A1[Web UI for exploration]
        A2[Real-time scanning]
        A3[Pre-built queries]
        A4[No manual import needed]
    end

    subgraph "Approach B Benefits"
        B1[No Docker required]
        B2[Works offline]
        B3[Import to any Neo4j]
        B4[CI/CD friendly]
    end

    APPROACH_A --> A1
    APPROACH_B --> B1

    style APPROACH_A fill:#6db33f,stroke:#333,color:#fff
    style APPROACH_B fill:#9b59b6,stroke:#333,color:#fff
```

| Aspect | Approach A: Full Stack | Approach B: CLI + CSV |
|--------|------------------------|----------------------|
| **Best for** | Interactive exploration, teams | CI/CD, air-gapped environments |
| **Requires** | Docker, ports 3000/8080/7474/7687 | Just Java 21 |
| **Neo4j loading** | Automatic via Spring Data | Manual CSV import |
| **Web UI** | Yes | No |
| **Query interface** | Web-based + API | Neo4j Browser only |

---

## Approach A: Full Stack with Direct Neo4j Loading

This approach runs the complete stack: Neo4j database, Spring Boot backend, and React frontend. Scanning happens via API calls that directly populate Neo4j.

```mermaid
flowchart LR
    subgraph "Approach A Architecture"
        USER[You] -->|browser| WEB[Web UI :3000]
        WEB -->|/api/scan| API[Backend :8080]
        API -->|scan| CORE[Core Scanner]
        CORE -->|results| API
        API -->|Spring Data| NEO4J[(Neo4j :7687)]
        USER -->|explore| WEB
        WEB -->|/api/query| API
        API -->|Cypher| NEO4J
    end

    style WEB fill:#00d8ff,stroke:#333,color:#000
    style API fill:#6db33f,stroke:#333,color:#fff
    style NEO4J fill:#008cc1,stroke:#333,color:#fff
```

### Step A1: Build the Project

```bash
# Navigate to project root
cd const-catalog

# Build all modules (skip tests for faster build)
mvn clean install -DskipTests
```

**What this produces:**
```
const-catalog-core/target/const-catalog-core-1.0-SNAPSHOT.jar      # Parsing engine
const-catalog-backend/target/const-catalog-backend-1.0-SNAPSHOT.jar # Spring Boot app
const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT-shaded.jar  # Standalone CLI
```

### Step A2: Start the Docker Stack

```bash
# Start all services in background
docker-compose up -d

# Verify all containers are running
docker-compose ps
```

**Expected output:**
```
NAME                    STATUS
const-catalog-neo4j     running (healthy)
const-catalog-backend   running
const-catalog-frontend  running
```

### Step A3: Wait for Services to Initialize

Neo4j needs time to start. Wait for healthy status:

```bash
# Watch logs until you see "Started" messages
docker-compose logs -f backend

# Or check health endpoint (retry until successful)
curl http://localhost:8080/api/stats/health
```

**Expected response:**
```json
{
  "status": "healthy",
  "database": "connected",
  "projectCount": 0
}
```

### Step A4: Scan Your Project (Three Options)

#### Option A4a: Via Web UI (Recommended for first-time users)

1. Open browser to **http://localhost:3000**
2. Click **Scan** in the navigation
3. Enter absolute path: `/path/to/your/java/project`
4. Click **Scan Project**
5. Watch results populate in real-time

```mermaid
sequenceDiagram
    participant Browser
    participant Frontend
    participant Backend
    participant Neo4j

    Browser->>Frontend: Navigate to /scan
    Frontend->>Browser: Show scan form
    Browser->>Frontend: Enter path, click Scan
    Frontend->>Backend: POST /api/scan
    Backend->>Backend: ProjectScanner.scan()
    Backend->>Neo4j: GraphPopulatorService.populateGraph()
    Neo4j-->>Backend: Nodes created
    Backend-->>Frontend: ScanResponse
    Frontend-->>Browser: Show results summary
```

#### Option A4b: Via REST API (For automation)

```bash
# Scan a project
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{"projectPath": "/absolute/path/to/your/project"}'
```

**Example response:**
```json
{
  "success": true,
  "projectPath": "/home/user/myapp",
  "projectName": "myapp",
  "scannedAt": "2024-01-15T10:30:00",
  "javaFilesScanned": 150,
  "propertyFilesScanned": 12,
  "constantsFound": 487,
  "parametersFound": 95,
  "parameterUsagesFound": 234,
  "message": "Scan completed successfully"
}
```

#### Option A4c: Via curl with Windows paths

```bash
# Windows paths need proper escaping
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{"projectPath": "C:\\Users\\dev\\projects\\myapp"}'
```

### Step A5: Explore Results

1. **Web UI**: Navigate to **Query** page at http://localhost:3000
2. **Neo4j Browser**: Open http://localhost:7474 (login: neo4j/password)
3. **API**: `curl http://localhost:8080/api/stats`

```mermaid
flowchart TB
    subgraph "Exploration Options"
        subgraph "Web UI :3000"
            W1[Pre-canned queries]
            W2[Custom Cypher editor]
            W3[Results table view]
        end

        subgraph "Neo4j Browser :7474"
            N1[Visual graph exploration]
            N2[Full Cypher console]
            N3[Schema visualization]
        end

        subgraph "REST API :8080"
            A1[GET /api/stats]
            A2[POST /api/query]
            A3[GET /api/stats/constants]
        end
    end

    style W1 fill:#00d8ff,stroke:#333,color:#000
    style N1 fill:#008cc1,stroke:#333,color:#fff
    style A1 fill:#6db33f,stroke:#333,color:#fff
```

### Step A6: Shutdown

```bash
# Stop all services
docker-compose down

# Stop and remove all data (clean slate)
docker-compose down -v
```

---

## Approach B: CLI with CSV Export

This approach uses the standalone CLI to scan projects and export CSV files. You then import these CSVs into any Neo4j instance manually.

```mermaid
flowchart LR
    subgraph "Approach B Architecture"
        CLI[CLI Tool] -->|scan| CORE[Core Scanner]
        CORE -->|results| CLI
        CLI -->|write| CSV[CSV Files]
        CSV -->|manual import| NEO4J[(Any Neo4j)]
    end

    style CLI fill:#9b59b6,stroke:#333,color:#fff
    style CSV fill:#f1c40f,stroke:#333,color:#000
    style NEO4J fill:#008cc1,stroke:#333,color:#fff
```

### Step B1: Build the CLI Module

```bash
# Navigate to project root
cd const-catalog

# Build just core and CLI (faster than full build)
mvn clean install -pl const-catalog-core,const-catalog-cli -DskipTests
```

**The `-pl` flag means "project list"** - it builds only the specified modules.

### Step B2: Run the CLI Scanner

```bash
# Basic usage - outputs to <project>/neo4j-export/
java -jar const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT-shaded.jar /path/to/your/project

# With custom output directory
java -jar const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT-shaded.jar /path/to/project /path/to/output
```

**Example:**
```bash
$ java -jar const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT-shaded.jar ~/projects/myapp

Scanning project: /home/user/projects/myapp
Scanning Java files...
  Found 150 Java files
  Extracted 487 constants
Scanning property files...
  Found 12 property files
  Extracted 95 parameters
Detecting parameter usages...
  Found 234 parameter usages
Exporting to CSV...
  Written: /home/user/projects/myapp/neo4j-export/constants.csv
  Written: /home/user/projects/myapp/neo4j-export/parameters.csv
  Written: /home/user/projects/myapp/neo4j-export/files.csv
  Written: /home/user/projects/myapp/neo4j-export/constant_in_file.csv
  Written: /home/user/projects/myapp/neo4j-export/parameter_defined_in.csv
  Written: /home/user/projects/myapp/neo4j-export/parameter_used_in.csv
  Written: /home/user/projects/myapp/neo4j-export/import-neo4j.cypher
Scan complete!
```

### Step B3: Examine the Output Files

```bash
ls -la ~/projects/myapp/neo4j-export/
```

| File | Contents |
|------|----------|
| `constants.csv` | All `static final` fields with name, type, value, class, line |
| `parameters.csv` | All config parameters with name, value, line |
| `files.csv` | All source files with path, name, type |
| `constant_in_file.csv` | Relationships: which constant is in which file |
| `parameter_defined_in.csv` | Relationships: where each parameter is defined |
| `parameter_used_in.csv` | Relationships: where parameters are referenced |
| `import-neo4j.cypher` | Ready-to-run Cypher script for importing everything |

### Step B4: Start Neo4j (If Not Already Running)

**Option B4a: Using Docker (standalone Neo4j)**
```bash
docker run -d \
  --name neo4j \
  -p 7474:7474 \
  -p 7687:7687 \
  -e NEO4J_AUTH=neo4j/password \
  -v $(pwd)/neo4j-export:/import \
  neo4j:5
```

**Option B4b: Using Neo4j Desktop**
1. Create a new project
2. Add a local DBMS
3. Start the database
4. Copy CSV files to the `import` directory

**Option B4c: Using Neo4j Aura (cloud)**
1. Create an Aura instance
2. Use the import tool in Aura console

### Step B5: Import CSV Files into Neo4j

#### Method 1: Run the Generated Cypher Script

```bash
# Copy CSVs to Neo4j import directory
cp ~/projects/myapp/neo4j-export/*.csv /path/to/neo4j/import/

# Connect via cypher-shell and run the script
cat ~/projects/myapp/neo4j-export/import-neo4j.cypher | cypher-shell -u neo4j -p password
```

#### Method 2: Use Neo4j Browser

1. Open http://localhost:7474
2. Login with neo4j/password
3. Copy contents of `import-neo4j.cypher`
4. Paste into the query editor
5. Run each `LOAD CSV` statement

#### Method 3: Run Individual LOAD CSV Commands

```cypher
// Step 1: Create constraints for better performance
CREATE CONSTRAINT IF NOT EXISTS FOR (f:File) REQUIRE f.path IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (c:Constant) REQUIRE c.id IS UNIQUE;
CREATE CONSTRAINT IF NOT EXISTS FOR (p:Parameter) REQUIRE p.id IS UNIQUE;

// Step 2: Load files
LOAD CSV WITH HEADERS FROM 'file:///files.csv' AS row
CREATE (f:File {
  path: row.path,
  fileName: row.fileName,
  fileType: row.fileType
});

// Step 3: Load constants
LOAD CSV WITH HEADERS FROM 'file:///constants.csv' AS row
CREATE (c:Constant {
  id: row.id,
  name: row.name,
  type: row.type,
  value: row.value,
  className: row.className,
  lineNumber: toInteger(row.lineNumber)
});

// Step 4: Load parameters
LOAD CSV WITH HEADERS FROM 'file:///parameters.csv' AS row
CREATE (p:Parameter {
  id: row.id,
  name: row.name,
  value: row.value,
  lineNumber: toInteger(row.lineNumber)
});

// Step 5: Create DEFINED_IN relationships for constants
LOAD CSV WITH HEADERS FROM 'file:///constant_in_file.csv' AS row
MATCH (c:Constant {id: row.constantId})
MATCH (f:File {path: row.filePath})
CREATE (c)-[:DEFINED_IN {lineNumber: toInteger(row.lineNumber)}]->(f);

// Step 6: Create DEFINED_IN relationships for parameters
LOAD CSV WITH HEADERS FROM 'file:///parameter_defined_in.csv' AS row
MATCH (p:Parameter {id: row.parameterId})
MATCH (f:File {path: row.filePath})
CREATE (p)-[:DEFINED_IN {lineNumber: toInteger(row.lineNumber)}]->(f);

// Step 7: Create USED_IN relationships
LOAD CSV WITH HEADERS FROM 'file:///parameter_used_in.csv' AS row
MATCH (p:Parameter {name: row.parameterName})
MATCH (f:File {path: row.filePath})
CREATE (p)-[:USED_IN {
  className: row.className,
  lineNumber: toInteger(row.lineNumber),
  context: row.context
}]->(f);
```

### Step B6: Verify the Import

```cypher
// Count nodes
MATCH (n) RETURN labels(n)[0] as label, count(*) as count;

// Sample constants
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
RETURN c.name, c.value, f.fileName
LIMIT 10;

// Find configuration candidates
MATCH (c:Constant)
WHERE c.name =~ '(?i).*(HOST|PORT|URL|PASSWORD).*'
RETURN c.name, c.value;
```

---

## Quick Reference: Both Approaches

```mermaid
flowchart TB
    subgraph "Approach A: Full Stack"
        A1[mvn clean install] --> A2[docker-compose up -d]
        A2 --> A3[curl POST /api/scan]
        A3 --> A4[Browse http://localhost:3000]
    end

    subgraph "Approach B: CLI + CSV"
        B1[mvn install -pl core,cli] --> B2[java -jar cli.jar /project]
        B2 --> B3[Copy CSVs to Neo4j import/]
        B3 --> B4[Run import-neo4j.cypher]
    end

    style A4 fill:#00d8ff,stroke:#333,color:#000
    style B4 fill:#008cc1,stroke:#333,color:#fff
```

| Step | Approach A Command | Approach B Command |
|------|-------------------|-------------------|
| Build | `mvn clean install` | `mvn install -pl const-catalog-core,const-catalog-cli` |
| Start infra | `docker-compose up -d` | `docker run neo4j:5` (or use existing) |
| Scan | `curl -X POST localhost:8080/api/scan -d '{"projectPath":"/path"}'` | `java -jar const-catalog-cli*.jar /path` |
| Import | Automatic | `cypher-shell < import-neo4j.cypher` |
| Explore | http://localhost:3000 | http://localhost:7474 |

---

## Step 1: Clone and Build

```bash
# Clone the repository (or navigate to the project root)
cd const-catalog

# Build all Maven modules
mvn clean install
```

This produces three artifacts:
- `const-catalog-core-1.0-SNAPSHOT.jar` — The scanning and parsing engine
- `const-catalog-backend-1.0-SNAPSHOT.jar` — Spring Boot REST API
- `const-catalog-cli-1.0-SNAPSHOT.jar` — Standalone CLI tool (uber-jar)

```mermaid
graph LR
    subgraph "Maven Build"
        POM[Parent POM] --> CORE[const-catalog-core]
        CORE --> BACKEND[const-catalog-backend]
        CORE --> CLI[const-catalog-cli]
    end

    subgraph "Artifacts"
        CORE --> JAR1[core.jar<br/>Parsing Engine]
        BACKEND --> JAR2[backend.jar<br/>Spring Boot App]
        CLI --> JAR3[cli.jar<br/>Uber JAR]
    end

    style CORE fill:#f0932b,stroke:#333,color:#000
    style BACKEND fill:#6db33f,stroke:#333,color:#fff
    style CLI fill:#9b59b6,stroke:#333,color:#fff
```

## Step 2: Start the Infrastructure

The simplest path to a running system is Docker Compose:

```bash
docker-compose up -d
```

This starts:
- **Neo4J** on ports 7474 (browser) and 7687 (bolt)
- **Backend** on port 8080
- **Frontend** on port 3000

```mermaid
flowchart LR
    subgraph "Docker Compose Stack"
        subgraph "Port 3000"
            FE[🌐 Frontend<br/>nginx]
        end

        subgraph "Port 8080"
            BE[🔌 Backend<br/>Spring Boot]
        end

        subgraph "Ports 7474/7687"
            DB[(🔵 Neo4J)]
        end

        FE -->|/api/*| BE
        BE -->|bolt://| DB
    end

    USER[👤 User] --> FE
    DEV[👨‍💻 Developer] --> DB

    style FE fill:#00d8ff,stroke:#333,color:#000
    style BE fill:#6db33f,stroke:#333,color:#fff
    style DB fill:#008cc1,stroke:#333,color:#fff
```

Watch the logs to confirm healthy startup:

```bash
docker-compose logs -f
```

## Step 3: Verify the Connection

Open your browser to [http://localhost:3000](http://localhost:3000). You should see the Space Command interface with a connected status indicator in the header.

Alternatively, check the health endpoint directly:

```bash
curl http://localhost:8080/api/stats/health
```

Expected response:
```json
{
  "status": "healthy",
  "database": "connected",
  "projectCount": 0
}
```

## Step 4: Scan Your First Project

### The Scanning Process

```mermaid
sequenceDiagram
    participant User
    participant API as REST API
    participant Scanner as Project Scanner
    participant JavaParser as Java Parser
    participant PropParser as Property Parser
    participant Graph as Graph Populator
    participant Neo4J as Neo4J

    User->>API: POST /api/scan {projectPath}
    API->>Scanner: scan(projectPath)

    loop For each file
        Scanner->>Scanner: Walk directory tree
        alt Java file
            Scanner->>JavaParser: parseConstants(file)
            JavaParser-->>Scanner: List<Constant>
            Scanner->>JavaParser: parseUsages(file, params)
            JavaParser-->>Scanner: List<ParameterUsage>
        else Property file
            Scanner->>PropParser: parseParameters(file)
            PropParser-->>Scanner: List<Parameter>
        end
    end

    Scanner-->>API: ScanResult
    API->>Graph: populateGraph(result)

    Graph->>Neo4J: Create ProjectNode
    Graph->>Neo4J: Create FileNodes
    Graph->>Neo4J: Create ConstantNodes + relationships
    Graph->>Neo4J: Create ParameterNodes + relationships
    Graph->>Neo4J: Create UsageRelationships

    Graph-->>API: Complete
    API-->>User: ScanResponse
```

### Option A: Via the Web Interface

1. Navigate to the **Scan** page
2. Enter the absolute path to a Java project
3. Click **Scan Project**
4. Watch as files are parsed and the graph populates

### Option B: Via the CLI

For environments without the backend running:

```bash
java -jar const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT.jar /path/to/your/project
```

This generates CSV files in `<project>/neo4j-export/` that can be imported manually into Neo4J.

### Option C: Via the API

```bash
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{"projectPath": "/path/to/your/project"}'
```

## Step 5: Explore the Results

Navigate to the **Query** page. The pre-built queries offer immediate insights:

| Query                        | Purpose                                            |
|------------------------------|----------------------------------------------------|
| **All Constants**            | See every `static final` field discovered          |
| **Configuration Candidates** | Constants that look like they should be parameters |
| **Unused Parameters**        | Defined but never referenced in code               |
| **Sensitive Parameters**     | Names suggesting secrets (password, key, token)    |
| **Duplicate Values**         | Constants with identical values across files       |

```mermaid
flowchart TB
    subgraph "Pre-Canned Query Categories"
        subgraph "EXPLORATION"
            E1[All Constants]
            E2[All Parameters]
            E3[File Summary]
        end

        subgraph "ANALYSIS"
            A1[Config Candidates]
            A2[Unused Parameters]
            A3[Cross-File Params]
            A4[Duplicate Values]
        end

        subgraph "SECURITY"
            S1[Sensitive Params]
            S2[Connection Strings]
        end

        subgraph "ORGANIZATION"
            O1[Params by Prefix]
        end
    end

    style E1 fill:#74b9ff,stroke:#333,color:#000
    style E2 fill:#74b9ff,stroke:#333,color:#000
    style E3 fill:#74b9ff,stroke:#333,color:#000
    style A1 fill:#fdcb6e,stroke:#333,color:#000
    style A2 fill:#fdcb6e,stroke:#333,color:#000
    style A3 fill:#fdcb6e,stroke:#333,color:#000
    style A4 fill:#fdcb6e,stroke:#333,color:#000
    style S1 fill:#ff7675,stroke:#333,color:#000
    style S2 fill:#ff7675,stroke:#333,color:#000
    style O1 fill:#a29bfe,stroke:#333,color:#000
```

For deeper exploration, write custom Cypher in the query editor:

```cypher
// Find constants that might be connection strings
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
WHERE c.value CONTAINS 'jdbc:' OR c.value CONTAINS 'http://'
RETURN c.name, c.value, f.fileName
```

## Step 6: Interpret and Act

The catalog reveals; humans decide. Common actions after scanning:

```mermaid
flowchart LR
    subgraph "Discovery"
        SCAN[Scan Project] --> RESULTS[View Results]
    end

    subgraph "Analysis"
        RESULTS --> CONFIG[Config Candidates?]
        RESULTS --> UNUSED[Unused Params?]
        RESULTS --> DUPES[Duplicates?]
        RESULTS --> SECRETS[Sensitive Data?]
    end

    subgraph "Action"
        CONFIG -->|Yes| EXTERN[Externalize to properties]
        UNUSED -->|Yes| DELETE[Remove dead config]
        DUPES -->|Yes| CONSOLIDATE[Unify constants]
        SECRETS -->|Yes| DOCUMENT[Document & secure]
    end

    style EXTERN fill:#00b894,stroke:#333,color:#fff
    style DELETE fill:#00b894,stroke:#333,color:#fff
    style CONSOLIDATE fill:#00b894,stroke:#333,color:#fff
    style DOCUMENT fill:#00b894,stroke:#333,color:#fff
```

1. **Externalize configuration candidates** — Move hardcoded values to property files
2. **Remove dead parameters** — Delete unused configuration
3. **Consolidate duplicates** — Unify constants with identical values
4. **Document sensitive paths** — Note which files handle secrets

---

## Development Workflow

For active development on the tool itself:

```mermaid
flowchart TB
    subgraph "Development Mode"
        DEV_BE[Backend Dev<br/>mvn spring-boot:run] --> NEO4J[(Neo4J<br/>docker)]
        DEV_FE[Frontend Dev<br/>npm run dev] -->|proxy /api| DEV_BE
        BROWSER[Browser<br/>localhost:3000] --> DEV_FE
    end

    subgraph "Production Mode"
        DOCKER[docker-compose up] --> PROD_NEO4J[(Neo4J)]
        DOCKER --> PROD_BE[Backend Container]
        DOCKER --> PROD_FE[Frontend Container]
        PROD_BE --> PROD_NEO4J
        PROD_FE --> PROD_BE
    end
```

### Backend Development

```bash
# Run the Spring Boot application with hot reload
cd const-catalog-backend
mvn spring-boot:run
```

### Frontend Development

```bash
cd const-catalog-frontend
npm install
npm run dev
```

The frontend development server proxies API requests to `localhost:8080`.

### Running Tests

```bash
# Core module tests (57 tests)
mvn test -pl const-catalog-core

# All tests across all modules
mvn test
```

---

## Code Walkthrough

The following sections highlight the most philosophically and technically significant portions of the codebase. These are the places where design decisions crystallize into implementation.

### The Scanner: Walking the Unknown

The `ProjectScanner` faces a fundamental challenge: it must explore an arbitrary filesystem structure without knowing what it will find. The solution is a visitor pattern that separates **traversal** from **processing**:

```mermaid
flowchart TB
    subgraph "Visitor Pattern"
        START[Start at Project Root] --> VISIT{Visit Directory}
        VISIT -->|Excluded?| SKIP[Skip Subtree]
        VISIT -->|Continue| FILES{Visit Files}
        FILES -->|*.java| JAVA[Add to Java list]
        FILES -->|*.properties| PROP[Add to Property list]
        FILES -->|*.yml| PROP
        FILES -->|other| IGNORE[Ignore]
        JAVA --> NEXT[Next file/dir]
        PROP --> NEXT
        IGNORE --> NEXT
        SKIP --> NEXT
        NEXT --> VISIT
    end

    style SKIP fill:#ff7675,stroke:#333,color:#000
    style JAVA fill:#74b9ff,stroke:#333,color:#000
    style PROP fill:#fdcb6e,stroke:#333,color:#000
```

```java
// const-catalog-core/src/main/java/com/boeing/constcatalog/scanner/ProjectScanner.java

Files.walkFileTree(projectRoot, new SimpleFileVisitor<>() {
    @Override
    public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
        String dirName = dir.getFileName().toString();
        if (EXCLUDED_DIRS.contains(dirName)) {
            log.debug("Skipping excluded directory: {}", dir);
            return FileVisitResult.SKIP_SUBTREE;
        }
        return FileVisitResult.CONTINUE;
    }

    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
        String fileName = file.getFileName().toString().toLowerCase();

        if (fileName.endsWith(".java")) {
            javaFiles.add(file);
        } else if (isPropertyFile(fileName)) {
            propertyFiles.add(file);
        }

        return FileVisitResult.CONTINUE;
    }
});
```

Notice the **exclusion list**: `target`, `build`, `node_modules`. These directories represent generated artifacts, not source truth. The scanner seeks **intent**, not **output**.

### The Parser: Understanding Structure

The `JavaFileParser` uses JavaParser to build an Abstract Syntax Tree, then visits it to extract constants. The key insight is the definition of "constant"—not just any field, but specifically `static final`:

```mermaid
flowchart TB
    subgraph "AST Traversal"
        SOURCE[Java Source File] --> PARSE[JavaParser.parse]
        PARSE --> AST[Abstract Syntax Tree]
        AST --> VISIT[Visit Nodes]

        VISIT --> CLASS{ClassDeclaration?}
        CLASS -->|Yes| TRACK[Track class name]
        TRACK --> FIELDS

        VISIT --> FIELDS{FieldDeclaration?}
        FIELDS --> CHECK{static final?}
        CHECK -->|Yes| EXTRACT[Extract Constant]
        CHECK -->|No| SKIP2[Skip]

        EXTRACT --> NAME[Get name]
        EXTRACT --> TYPE[Get type]
        EXTRACT --> VALUE[Get initializer]
        EXTRACT --> LINE[Get line number]

        NAME --> CONST[Create Constant record]
        TYPE --> CONST
        VALUE --> CONST
        LINE --> CONST
    end

    style EXTRACT fill:#00b894,stroke:#333,color:#fff
    style CONST fill:#6c5ce7,stroke:#333,color:#fff
```

```java
// const-catalog-core/src/main/java/com/boeing/constcatalog/parser/JavaFileParser.java

@Override
public void visit(FieldDeclaration field, Void arg) {
    boolean isStatic = field.getModifiers().stream()
        .anyMatch(m -> m.getKeyword() == Modifier.Keyword.STATIC);
    boolean isFinal = field.getModifiers().stream()
        .anyMatch(m -> m.getKeyword() == Modifier.Keyword.FINAL);

    if (isStatic && isFinal) {
        for (VariableDeclarator variable : field.getVariables()) {
            String name = variable.getNameAsString();
            String type = variable.getTypeAsString();
            String value = variable.getInitializer()
                .map(Object::toString)
                .orElse("");
            int lineNumber = field.getBegin()
                .map(pos -> pos.line)
                .orElse(0);

            constants.add(new Constant(
                name, type, value, fileName, currentClass, lineNumber
            ));
        }
    }
    super.visit(field, arg);
}
```

The visitor pattern recurses through inner classes (`currentClass` tracks context), ensuring we capture constants regardless of nesting depth.

### The Graph Populator: Two-Phase Integrity

Populating the graph requires careful ordering. Parameters reference files; files reference projects. The `GraphPopulatorService` uses a two-phase approach:

```mermaid
flowchart TB
    subgraph "Phase 1: Create Nodes"
        SR[ScanResult] --> P1[1. Create/Update Project]
        P1 --> P2[2. Collect File Paths]
        P2 --> P3[3. Create FileNodes]
        P3 --> CACHE1[fileCache Map]
        P3 --> P4[4. Create ConstantNodes]
        P4 --> P5[5. Create ParameterNodes]
        P5 --> CACHE2[parameterCache Map]
    end

    subgraph "Phase 2: Create Relationships"
        CACHE1 --> R1[Create DEFINED_IN<br/>Constant → File]
        CACHE1 --> R2[Create DEFINED_IN<br/>Parameter → File]
        CACHE2 --> R3[Create USED_IN<br/>Parameter → File]
        CACHE1 --> R3
    end

    style CACHE1 fill:#fdcb6e,stroke:#333,color:#000
    style CACHE2 fill:#fdcb6e,stroke:#333,color:#000
    style R1 fill:#74b9ff,stroke:#333,color:#000
    style R2 fill:#74b9ff,stroke:#333,color:#000
    style R3 fill:#74b9ff,stroke:#333,color:#000
```

```java
// const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/GraphPopulatorService.java

@Transactional
public void populateGraph(String projectPath, String projectName,
                          ProjectScanner.ScanResult scanResult) {

    // Step 1: Create or update the project node
    ProjectNode project = projectRepository.findByRootPath(projectPath)
        .map(existing -> updateProject(existing, scanResult))
        .orElseGet(() -> createProject(projectPath, projectName, scanResult));

    // Step 2: Collect all unique file paths
    Set<String> allFilePaths = collectAllFilePaths(scanResult);

    // Step 3: Create file nodes with cache for relationship building
    Map<String, FileNode> fileCache = createFileNodes(allFilePaths, project);

    // Step 4: Create constant nodes with DEFINED_IN relationships
    createConstantNodes(scanResult, fileCache);

    // Step 5: Create parameter nodes
    Map<String, ParameterNode> parameterCache =
        createParameterNodes(scanResult, fileCache);

    // Step 6: Add USED_IN relationships
    createUsageRelationships(scanResult, fileCache, parameterCache);
}
```

The `fileCache` and `parameterCache` maps are critical: they allow relationship creation without additional database queries. This is **functional thinking** applied to graph construction—pure transformations with explicit state passing.

### The Query Service: Safe Exploration

The `QueryService` enables ad-hoc Cypher queries while preventing writes. This is defense-in-depth:

```mermaid
flowchart TB
    subgraph "Query Validation"
        INPUT[User Cypher Query] --> CHECK{Contains write<br/>keywords?}
        CHECK -->|CREATE| REJECT[Reject Query]
        CHECK -->|DELETE| REJECT
        CHECK -->|SET| REJECT
        CHECK -->|MERGE| REJECT
        CHECK -->|DROP| REJECT
        CHECK -->|None| EXECUTE[Execute Query]
        EXECUTE --> NEO4J[(Neo4J)]
        NEO4J --> FORMAT[Format Results]
        FORMAT --> RESPONSE[JSON Response]
    end

    style REJECT fill:#ff7675,stroke:#333,color:#000
    style EXECUTE fill:#00b894,stroke:#333,color:#fff
```

```java
// const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/QueryService.java

private boolean isReadOnlyQuery(String cypher) {
    String upper = cypher.toUpperCase();
    return !upper.contains("CREATE") &&
           !upper.contains("DELETE") &&
           !upper.contains("SET") &&
           !upper.contains("REMOVE") &&
           !upper.contains("MERGE") &&
           !upper.contains("DROP");
}
```

This is not security through obscurity—Neo4J permissions should also restrict writes. But application-level validation catches mistakes before they reach the database, providing **fail-fast behavior** and **clear error messages**.

### Pre-Canned Queries: Encoded Expertise

The pre-canned queries represent **domain knowledge encoded as code**. Consider the "Configuration Candidates" query:

```mermaid
flowchart LR
    subgraph "Pattern Matching"
        CONST[Constant Name] --> REGEX{Matches Pattern?}
        REGEX -->|HOST| FLAG[Configuration Candidate]
        REGEX -->|PORT| FLAG
        REGEX -->|URL| FLAG
        REGEX -->|ENDPOINT| FLAG
        REGEX -->|PASSWORD| FLAG
        REGEX -->|TIMEOUT| FLAG
        REGEX -->|KEY| FLAG
        REGEX -->|SECRET| FLAG
        REGEX -->|None| IGNORE[Regular Constant]
    end

    style FLAG fill:#ff7675,stroke:#333,color:#000
    style IGNORE fill:#b2bec3,stroke:#333,color:#000
```

```java
// const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/QueryService.java

PreCannedQuery.builder()
    .id("config-candidates")
    .name("Configuration Candidates")
    .description("Constants that look like they should be externalized")
    .category("ANALYSIS")
    .cypher("""
        MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
        WHERE c.name =~ '(?i).*(HOST|PORT|URL|ENDPOINT|PATH|KEY|SECRET|PASSWORD|TIMEOUT).*'
        RETURN c.name as name, c.type as type, c.value as value,
               c.className as className, f.fileName as file
        ORDER BY c.name
        """)
    .build()
```

The regex `(?i).*(HOST|PORT|URL|...).*` encodes the heuristic: "names containing these words are probably environment-specific." This is **pattern recognition** distilled into a query.

### The Entity Model: Rich Relationships

Neo4J's strength is relationship properties. The `UsageRelationship` class annotates edges with context:

```mermaid
classDiagram
    class ParameterNode {
        +Long id
        +String name
        +String value
        +int lineNumber
        +FileNode definedIn
        +Set~UsageRelationship~ usages
    }

    class UsageRelationship {
        +Long id
        +FileNode file
        +String className
        +int lineNumber
        +String context
    }

    class FileNode {
        +Long id
        +String path
        +String fileName
        +String fileType
    }

    ParameterNode "1" --> "*" UsageRelationship : usages
    UsageRelationship "*" --> "1" FileNode : file
    ParameterNode "*" --> "1" FileNode : definedIn
```

```java
// const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/entity/UsageRelationship.java

@RelationshipProperties
@Data
@Builder
public class UsageRelationship {

    @Id @GeneratedValue
    private Long id;

    @TargetNode
    private FileNode file;

    private String className;
    private int lineNumber;
    private String context;  // The actual code: getProperty("db.host")
}
```

The `context` field preserves the **original expression**. When reviewing parameter usage, developers see not just "used in FileX" but "used via `config.getProperty("db.host")`". This transforms abstract relationships into **concrete understanding**.

### The Frontend: Functional React

The React components favor functional patterns and React Query for server state:

```mermaid
flowchart TB
    subgraph "React Query State Management"
        COMPONENT[React Component] --> HOOK[useQuery / useMutation]
        HOOK --> CACHE[Query Cache]
        HOOK -->|fetch| API[Backend API]
        API -->|response| CACHE
        CACHE -->|data| COMPONENT

        subgraph "Automatic Features"
            CACHE --> STALE[Stale detection]
            CACHE --> REFETCH[Background refetch]
            CACHE --> RETRY[Retry on failure]
        end
    end

    style CACHE fill:#fdcb6e,stroke:#333,color:#000
    style API fill:#6db33f,stroke:#333,color:#fff
```

```typescript
// const-catalog-frontend/src/pages/QueryPage.tsx

const { data: preCannedQueries } = useQuery({
  queryKey: ['preCannedQueries'],
  queryFn: getPreCannedQueries,
})

const queryMutation = useMutation({
  mutationFn: executeQuery,
  onSuccess: setResult,
})
```

React Query separates **server state** (what the backend knows) from **UI state** (what the user is doing). This distinction eliminates entire categories of synchronization bugs.

---

## Closing Thoughts

The Constants Catalog is, at its heart, a tool for **seeing what was invisible**. Configuration decisions made years ago by developers long gone become visible, queryable, actionable.

```mermaid
flowchart LR
    subgraph "The Journey"
        INVISIBLE[Invisible<br/>Configuration Debt] --> VISIBLE[Visible<br/>Graph Model]
        VISIBLE --> QUERYABLE[Queryable<br/>Cypher Insights]
        QUERYABLE --> ACTIONABLE[Actionable<br/>Improvements]
    end

    style INVISIBLE fill:#636e72,stroke:#333,color:#fff
    style VISIBLE fill:#74b9ff,stroke:#333,color:#000
    style QUERYABLE fill:#fdcb6e,stroke:#333,color:#000
    style ACTIONABLE fill:#00b894,stroke:#333,color:#fff
```

But visibility is only the first step. The harder work is **deciding what to do** with what you see. Not every constant needs externalization. Not every unused parameter is dead weight. The tool reveals; wisdom interprets.

Use the catalog to understand your codebase's configuration landscape. Let the graph show you patterns you couldn't see in flat files. And remember: the goal isn't zero constants—it's **intentional constants**, where hardcoding is a choice, not an accident.

---

*"The beginning of wisdom is the definition of terms."* — Socrates

In our case, the beginning of configuration wisdom is knowing which terms we've defined, where we've defined them, and whether they're truly as constant as their declarations claim.
