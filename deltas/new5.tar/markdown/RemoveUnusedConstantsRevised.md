# Remove Unused Constants

A detailed description of the "Remove Unused" candidate scope in the Transform page — how it works, the code involved, design decisions, and known limitations.

---

## Table of Contents

1. [What It Does](#1-what-it-does)
2. [End-to-End Flow](#2-end-to-end-flow)
3. [Frontend: Selecting the Scope](#3-frontend-selecting-the-scope)
4. [Backend: Routing to handleRemoveUnused](#4-backend-routing-to-handleremoveunused)
5. [Neo4j Query: Finding Unused Constants](#5-neo4j-query-finding-unused-constants)
6. [Core: UnusedConstantRemover](#6-core-unusedconstantremover)
7. [Safety Mechanisms](#7-safety-mechanisms)
8. [Dry Run vs. Live Run](#8-dry-run-vs-live-run)
9. [Git Branch Integration](#9-git-branch-integration)
10. [Test Coverage](#10-test-coverage)
11. [Does This Work?](#11-does-this-work)

---

## 1. What It Does

When a user selects "Remove Unused" in the Candidate Scope dropdown on the Transform page, the system:

1. Queries Neo4j for all `public static final` constants in the scanned project that have **no `USED_IN` relationships**
2. Parses each source file containing unused constants using JavaParser
3. Removes the field declarations from the AST
4. Validates no dangling references remain
5. Writes the modified files to a backups directory (with `.orig` copies of the originals)
6. Optionally commits the changes to a new git branch

This is fundamentally different from the other candidate scopes (ALL, CONSTANTS_ONLY, PARAMETERS_ONLY), which **replace** constant usages with `config.lookup()` calls. REMOVE_UNUSED **deletes** the declarations entirely.

### Scope Comparison

```mermaid
graph LR
    A[Transform Request] --> B{Candidate Scope?}
    B -->|ALL| C[Replace usages with<br/>config.lookup calls]
    B -->|CONSTANTS_ONLY| C
    B -->|PARAMETERS_ONLY| C
    B -->|REMOVE_UNUSED| D[Delete declarations<br/>from source files]
    C --> E[ConfigLookupTransformer]
    D --> F[UnusedConstantRemover]
```

---

## 2. End-to-End Flow

```mermaid
sequenceDiagram
    actor User
    participant FE as TransformPage.tsx
    participant API as TransformController
    participant SVC as CodeTransformationService
    participant Neo as Neo4j
    participant REM as UnusedConstantRemover
    participant FS as File System
    participant Git as GitService

    User->>FE: Click "Transform" (scope=REMOVE_UNUSED)
    FE->>API: POST /api/transform
    API->>SVC: transform(request)
    SVC->>SVC: scope == REMOVE_UNUSED → handleRemoveUnused()

    rect rgb(40, 40, 80)
        Note over SVC,Neo: Phase 1: Find unused constants
        SVC->>Neo: Cypher: MATCH constants with no USED_IN
        Neo-->>SVC: List of ConstantWithFile
    end

    SVC->>SVC: Group targets by file path

    rect rgb(40, 80, 40)
        Note over SVC,FS: Phase 2: Remove or dry-run
        alt Dry Run
            SVC->>REM: dryRun(file, targets)
            REM->>REM: Parse AST, report what would be removed
        else Live Run
            SVC->>REM: removeFromFile(file, targets, backupsDir)
            REM->>FS: Copy original → .orig backup
            REM->>REM: Parse AST, remove declarations
            REM->>REM: Validate no dangling references
            REM->>FS: Write modified source
        end
    end

    rect rgb(80, 40, 40)
        Note over SVC,Git: Phase 2.5: Optional git branch
        alt createBranch && !dryRun
            SVC->>Git: createAndCheckoutBranch()
            SVC->>FS: Copy modified files back to source
            SVC->>Git: addFilesAndCommit()
            SVC->>Git: checkoutBranch(original)
        end
    end

    SVC-->>API: TransformResponse
    API-->>FE: JSON response
    FE->>User: Show results table
```

---

## 3. Frontend: Selecting the Scope

**File:** `const-catalog-frontend/src/pages/TransformPage.tsx`

The scope is defined as a TypeScript union type:

```typescript
type CandidateScope = 'ALL' | 'CONSTANTS_ONLY' | 'PARAMETERS_ONLY' | 'REMOVE_UNUSED'
```

It appears as a radio button option labeled "Remove Unused" in the Transform page UI. When selected, the help text changes to explain the removal behavior:

```typescript
{candidateScope === 'REMOVE_UNUSED' ? (
  <>
    The remover will:
    <ul>
      <li>Query the graph for constants with no usages in any scanned file</li>
      <li>Remove their static final field declarations from source</li>
      <li>Protect special names (serialVersionUID, LOG, LOGGER, etc.)</li>
      <li>Backup original files as *.java.orig</li>
    </ul>
  </>
) : (
  // ... normal transform help text
)}
```

**File:** `const-catalog-frontend/src/types/index.ts`

```typescript
export interface TransformRequest {
  projectPath: string
  dryRun: boolean
  candidateScope?: 'CONSTANTS_ONLY' | 'PARAMETERS_ONLY' | 'ALL' | 'REMOVE_UNUSED'
  createBranch?: boolean
  fileFilter?: string
}
```

### Request Flow

```mermaid
flowchart LR
    subgraph Frontend
        A[TransformPage state] -->|mutate| B[transformProject]
        B -->|Axios POST| C["/api/transform"]
    end
    subgraph Backend
        C --> D[TransformController]
        D --> E[CodeTransformationService]
    end
```

---

## 4. Backend: Routing to handleRemoveUnused

**File:** `const-catalog-backend/.../service/CodeTransformationService.java`

The `transform()` method checks the scope and routes immediately if it's REMOVE_UNUSED:

```java
public TransformResponse transform(TransformRequest request) {
    String projectPath = request.getProjectPath();
    CandidateScope scope = request.getCandidateScope();

    if (scope == CandidateScope.REMOVE_UNUSED) {
        return handleRemoveUnused(request);  // Entirely separate code path
    }

    // ... normal transformation logic for ALL, CONSTANTS_ONLY, PARAMETERS_ONLY
}
```

```mermaid
flowchart TD
    A[transform] --> B{scope?}
    B -->|REMOVE_UNUSED| C[handleRemoveUnused]
    B -->|ALL| D[findConfigurationCandidates<br/>+ findParameterCandidates]
    B -->|CONSTANTS_ONLY| E[findConfigurationCandidates]
    B -->|PARAMETERS_ONLY| F[findParameterCandidates]
    C --> G[UnusedConstantRemover]
    D --> H[ConfigLookupTransformer]
    E --> H
    F --> H
```

**Why a separate method?** The normal transformation replaces usages with `config.lookup()` calls — it modifies lines where constants are *used*. REMOVE_UNUSED does the opposite — it deletes lines where constants are *declared*. The logic is fundamentally different:
- Different Neo4j query (unused vs. configuration-candidate)
- Different core class (`UnusedConstantRemover` vs. `ConfigLookupTransformer`)
- Different AST operation (removal vs. replacement)

**File:** `const-catalog-backend/.../dto/TransformRequest.java`

```java
public enum CandidateScope {
    CONSTANTS_ONLY,
    PARAMETERS_ONLY,
    ALL,
    REMOVE_UNUSED
}
```

---

## 5. Neo4j Query: Finding Unused Constants

**File:** `CodeTransformationService.java`, method `findUnusedConstants()`

```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE c.accessModifier = 'public'
  AND NOT exists { MATCH (c)-[:USED_IN]->() }
  AND NOT coalesce(c.isEnum, false) = true
RETURN c.name AS constantName,
       c.type AS constantType,
       c.value AS constantValue,
       c.className AS className,
       c.lineNumber AS lineNumber,
       f.path AS filePath
ORDER BY f.path, c.lineNumber
```

### Graph Pattern

```mermaid
graph LR
    P[("Project<br/>{rootPath}")] -->|CONTAINS| F[("File<br/>{path}")]
    C[("Constant<br/>{name, type, value,<br/>accessModifier}")] -->|DEFINED_IN| F
    C -. "NO USED_IN<br/>(this is what makes<br/>it 'unused')" .-> X[("Any File")]

    style C fill:#ff6666,stroke:#cc0000,color:#fff
    style X fill:#999,stroke:#666,stroke-dasharray: 5 5
```

**How this query works:**

1. `MATCH (p:Project {rootPath: $path})` — Find the project node matching the scanned project path
2. `-[:CONTAINS]->(f:File)` — Traverse to all files in the project
3. `<-[:DEFINED_IN]-(c:Constant)` — Find constants defined in those files
4. `WHERE c.accessModifier = 'public'` — Only public constants (private/protected are internal)
5. `AND NOT exists { MATCH (c)-[:USED_IN]->() }` — Keep only constants with **no** `USED_IN` relationships
6. `AND NOT coalesce(c.isEnum, false) = true` — Exclude enum constants

**What "unused" means here:** A constant is unused if the scanner found no references to it in any Java file in the project. This depends entirely on the scan being comprehensive.

---

## 6. Core: UnusedConstantRemover

**File:** `const-catalog-core/.../transformer/UnusedConstantRemover.java`

This is the core engine that performs the actual AST manipulation. It lives in `const-catalog-core` (no Spring dependency) so it can be tested independently.

### Constructor

```java
public UnusedConstantRemover() {
    ParserConfiguration config = new ParserConfiguration()
        .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_21);
    this.javaParser = new JavaParser(config);
}
```

### removeFromFile() — The Core Algorithm

```mermaid
flowchart TD
    A[Start: sourceFile + targets] --> B[Copy original to .orig backup]
    B --> C[Parse file with JavaParser]
    C --> D{Parse OK?}
    D -->|No| E[Return FAILED for all targets]
    D -->|Yes| F[Build targetsByName lookup map]
    F --> G[Walk all public static final fields]
    G --> H{For each field variable}
    H --> I{Name in targets?}
    I -->|No| H
    I -->|Yes| J{Protected name<br/>or Logger type?}
    J -->|Yes| K[SKIPPED: Protected]
    J -->|No| L{Line number<br/>within tolerance?}
    L -->|No| M[SKIPPED: Line mismatch]
    L -->|Yes| N[Add to removal candidates]
    N --> H
    H -->|Done| O[Sort candidates bottom-up by line]
    O --> P[Remove each candidate from AST]
    P --> Q[Check for dangling references]
    Q --> R{Any dangling?}
    R -->|No| S[Write modified file]
    R -->|Yes| T[Re-parse original,<br/>remove only safe candidates]
    T --> S

    style E fill:#ff4444,color:#fff
    style K fill:#ffaa00,color:#000
    style M fill:#ffaa00,color:#000
    style S fill:#44aa44,color:#fff
```

### Step-by-Step Details

**Step 1: Setup backups**

```java
Path absSource = sourceFile.toAbsolutePath();
Path relPath = absSource.getRoot().relativize(absSource);
Path outputPath = backupsDir.resolve(relPath);
Path backupOrigPath = Path.of(outputPath + ".orig");

Files.createDirectories(outputPath.getParent());
Files.copy(sourceFile, backupOrigPath, StandardCopyOption.REPLACE_EXISTING);
```

The original file is copied to `backups/<relative-path>.orig`. The modified version is written to `backups/<relative-path>`. The original source file is **never** modified directly.

**Step 2: Parse the file**

```java
ParseResult<CompilationUnit> parseResult = javaParser.parse(sourceFile);
```

JavaParser converts the source file into an AST. If parsing fails, all targets for this file are reported as failed.

**Step 3: Build a lookup map of targets**

```java
Map<String, ConstantTarget> targetsByName = targets.stream()
    .collect(Collectors.toMap(ConstantTarget::constantName, t -> t, (a, b) -> a));
```

Targets are keyed by constant name for O(1) lookup. The merge function `(a, b) -> a` handles duplicate names by keeping the first occurrence.

**Step 4: Walk all `public static final` fields and collect removal candidates**

```java
for (FieldDeclaration field : compilationUnit.findAll(FieldDeclaration.class)) {
    if (!isStaticFinal(field)) continue;
    if (!isPublic(field)) continue;

    for (VariableDeclarator var : field.getVariables()) {
        String name = var.getNameAsString();
        ConstantTarget target = targetsByName.get(name);
        if (target == null) continue;

        // Check protected names and logger types
        // Check line number tolerance
        // Add to candidates list
    }
}
```

**Why iterate all fields instead of searching by name?** A field declaration can contain multiple variables (`public static final int A = 1, B = 2;`). JavaParser models this as one `FieldDeclaration` with two `VariableDeclarator` nodes. By iterating fields, the code handles multi-variable declarations correctly.

**Step 5: Sort candidates bottom-up**

```java
candidates.sort(Comparator.comparingInt(
    (RemovalCandidate c) -> c.var.getBegin().map(p -> p.line).orElse(0)).reversed());
```

Candidates are sorted by line number in descending order (highest line first). This is critical: when you remove a node from the AST, all subsequent line numbers shift. By removing from the bottom up, earlier line numbers remain valid.

**Step 6: Remove each candidate and validate**

```java
for (RemovalCandidate candidate : candidates) {
    if (field.getVariables().size() == 1) {
        field.remove();                // Remove entire declaration
    } else {
        variableDeclarator.remove();   // Remove only this variable
    }
}

// Validate: no dangling references
Set<String> danglingRefs = findDanglingReferences(compilationUnit, removedNames);
```

### Multi-Variable Declaration Handling

```mermaid
graph TD
    subgraph "Before: public static final int A = 1, B = 2, C = 3;"
        F1["FieldDeclaration"] --> V1["A = 1"]
        F1 --> V2["B = 2"]
        F1 --> V3["C = 3"]
    end

    subgraph "After removing A: public static final int B = 2, C = 3;"
        F2["FieldDeclaration"] --> V4["B = 2"]
        F2 --> V5["C = 3"]
    end

    subgraph "After removing A, B, C: entire line removed"
        F3["(removed)"]
    end

    style F3 fill:#ff4444,color:#fff,stroke-dasharray: 5 5
```

---

## 7. Safety Mechanisms

### Safety Layer Architecture

```mermaid
flowchart TD
    A[Constant candidate<br/>from Neo4j] --> B{accessModifier<br/>= 'public'?}
    B -->|No| Z1[Excluded at query level]
    B -->|Yes| C{isPublic in AST?}
    C -->|No| Z2[Skipped by remover]
    C -->|Yes| D{Protected name?<br/>serialVersionUID, LOG,<br/>LOGGER, VERSION, etc.}
    D -->|Yes| Z3[Skipped: Protected name]
    D -->|No| E{Logger type?<br/>Logger, Log, Slf4jLogger}
    E -->|Yes| Z4[Skipped: Logger field]
    E -->|No| F{Line number<br/>tolerance OK?}
    F -->|No| Z5[Skipped: Line mismatch]
    F -->|Yes| G[Remove from AST]
    G --> H{Dangling<br/>reference?}
    H -->|Yes| Z6[FAILED: Still referenced]
    H -->|No| I[TRANSFORMED: Constant removed]

    style Z1 fill:#666,color:#fff
    style Z2 fill:#ffaa00,color:#000
    style Z3 fill:#ffaa00,color:#000
    style Z4 fill:#ffaa00,color:#000
    style Z5 fill:#ffaa00,color:#000
    style Z6 fill:#ff4444,color:#fff
    style I fill:#44aa44,color:#fff
```

### Protected Names

```java
private static final Set<String> PROTECTED_NAMES = Set.of(
    "serialVersionUID", "VERSION", "LOG", "LOGGER", "logger", "_logger", "log", "_log"
);
```

These constants are never removed, even if Neo4j reports them as unused:
- **`serialVersionUID`** — Required for Java serialization compatibility
- **`VERSION`** — Often used by frameworks or build tools outside of Java code
- **`LOG`, `LOGGER`, `logger`, `_logger`, `log`, `_log`** — Logging fields

### Logger Type Detection

```java
private static final Set<String> LOGGER_TYPE_NAMES = Set.of(
    "Logger", "Log", "Slf4jLogger"
);
```

Any field declared as `Logger`, `Log`, or `Slf4jLogger` is protected regardless of its name. This catches non-standard names like `auditLog`, `metricsLogger`, etc.

### Line Number Tolerance

```java
private static final int LINE_TOLERANCE = 3;
```

If the AST line number differs from the Neo4j line number by more than 3 lines, the constant is skipped. This prevents removing the wrong field when the file has been modified since the last scan.

### Dangling Reference Detection

After removing constants from the AST, the remover scans for remaining `NameExpr` and `FieldAccessExpr` nodes that reference removed names:

```java
private Set<String> findDanglingReferences(CompilationUnit cu, Set<String> removedNames) {
    Set<String> dangling = new LinkedHashSet<>();
    cu.findAll(NameExpr.class).forEach(nameExpr -> {
        if (removedNames.contains(nameExpr.getNameAsString())) {
            dangling.add(nameExpr.getNameAsString());
        }
    });
    cu.findAll(FieldAccessExpr.class).forEach(fieldAccess -> {
        if (removedNames.contains(fieldAccess.getNameAsString())) {
            dangling.add(fieldAccess.getNameAsString());
        }
    });
    return dangling;
}
```

If dangling references are found, those removals are marked FAILED and the file is re-written with only the safe removals.

### Backup Files

Every file is backed up as `*.orig` before modification. The original source file is never modified directly.

```mermaid
graph LR
    subgraph "backups/"
        O["AppConfig.java.orig<br/>(original)"]
        M["AppConfig.java<br/>(modified)"]
    end
    subgraph "source/"
        S["AppConfig.java<br/>(untouched)"]
    end
    S -.->|"copy"| O
    S -.->|"parse + modify"| M
```

---

## 8. Dry Run vs. Live Run

```mermaid
flowchart LR
    subgraph "Dry Run (dryRun: true)"
        A1[Parse AST] --> B1[Walk fields]
        B1 --> C1[Report what<br/>would be removed]
        C1 --> D1[Check dangling refs<br/>on cloned AST]
        D1 --> E1[No files written]
    end

    subgraph "Live Run (dryRun: false)"
        A2[Parse AST] --> B2[Walk fields]
        B2 --> C2[Remove from AST]
        C2 --> D2[Check dangling refs]
        D2 --> E2[Write backup + modified file]
    end
```

### Dry Run (`dryRun: true`)

```java
if (request.isDryRun()) {
    List<TransformationEntry> entries = targetsByFile.entrySet().stream()
        .flatMap(entry -> unusedRemover.dryRun(entry.getKey(), entry.getValue()).stream())
        .toList();
    result = new TransformationResult(projectPath, LocalDateTime.now(), entries);
}
```

- Does not create backup files
- Does not modify the AST (clones it for validation)
- Does not write any files
- Reports "Would remove unused constant 'X'" or "Removal would break compilation"

### Live Run (`dryRun: false`)

```java
result = unusedRemover.removeFromProject(projectPath, targetsByFile);
```

- Creates `.orig` backups
- Modifies the AST
- Validates dangling references
- Writes modified files to `backups/`

---

## 9. Git Branch Integration

```mermaid
sequenceDiagram
    participant SVC as CodeTransformationService
    participant Git as GitService
    participant FS as File System

    SVC->>Git: isGitRepo(projectDir)?
    alt Not a git repo
        SVC->>Git: initRepoWithInitialCommit()
        Git-->>SVC: "main"
    else Existing repo
        SVC->>Git: getCurrentBranch()
        Git-->>SVC: "adding-constant-data"
    end

    SVC->>Git: createAndCheckoutBranch("adding-constant-data-transformed")

    loop For each transformed file
        SVC->>FS: Copy from backups/ to source path
    end

    SVC->>Git: addFilesAndCommit(transformedFiles, message)
    SVC->>Git: checkoutBranch("adding-constant-data")
```

When both `dryRun: false` and `createBranch: true`:

1. Checks if the project is a git repo (initializes one if not)
2. Creates a new branch named `<current-branch>-transformed`
3. Copies modified files from `backups/` back to their original source paths
4. Commits **only the transformed files** (not `git add -A`)
5. Switches back to the original branch

---

## 10. Test Coverage

**File:** `const-catalog-core/.../transformer/UnusedConstantRemoverTest.java`

56 tests across 8 categories:

```mermaid
pie title Test Distribution (56 tests)
    "Basic removal" : 5
    "Logger & name protection" : 5
    "Line tolerance" : 3
    "Multi-variable declarations" : 3
    "Visibility filtering" : 4
    "Dangling reference detection" : 5
    "File output verification" : 16
    "Edge cases & dry run" : 15
```

| Category | Tests | Key scenarios |
|---|---|---|
| Basic removal | 5 | Single, multiple, complex initializers, project-level, empty targets |
| Logger & name protection | 5 | `_logger`, type-based Logger, all 8 protected names, VERSION |
| Line tolerance | 3 | Small drift OK, large drift rejected, zero = unknown |
| Multi-variable | 3 | Partial removal, all variables, single variable |
| Visibility | 4 | Private skipped, protected skipped, package-private skipped, dry run |
| Dangling references | 5 | Same-file usage, qualified refs, mixed safe/unsafe, dry run detection |
| File output | 16 | All types (String, int, long, boolean, double), imports, methods, constructors, inner classes, annotations, static blocks, comments, Javadoc, realistic service class, backup verification |
| Edge cases | 15 | Syntax errors, nonexistent file, duplicates, enums, class structure |

---

## 11. Does This Work?

**The code is structurally sound.** The algorithm is correct: query Neo4j for unused public constants, parse with JavaParser, remove from AST bottom-up, validate no dangling references, write to backups.

### Decision Tree for Users

```mermaid
flowchart TD
    A[Want to remove<br/>unused constants?] --> B[Run Dry Run first]
    B --> C{Results look right?}
    C -->|Yes| D{Want a safety net?}
    C -->|No| E[Check if project<br/>was fully scanned]
    D -->|Yes| F[Enable Create Branch]
    D -->|No| G[Uncheck Dry Run,<br/>run live]
    F --> G
    G --> H[Review output in<br/>backups/ directory]

    style B fill:#4488ff,color:#fff
    style F fill:#44aa44,color:#fff
```

### Important Caveats

| Risk | Cause | Mitigation |
|---|---|---|
| False "unused" report | File failed to parse during scan | Always dry run first; check scan logs |
| Cross-project references | Only scanned project is in graph | Scan all dependent projects together |
| Reflection/framework usages | Scanner can't detect `Field.get()`, `@Value`, etc. | Review dry run results manually |
| Line number drift | File modified since last scan | Line tolerance of 3; re-scan before removing |
| Same-class usage missed | Scanner blind spot (now fixed) | Scanner records same-class usages |

**Recommendation:** Always dry run first, review the results, and use the git branch option when performing live removals so the original code is preserved.
