# Neo4j Storage Optimization — GraphPopulatorService

> **Date:** 5 March 2026
> **Branch:** `adding-constant-data`

---

## The Bottleneck

The entire `populateGraph()` runs in **one giant `@Transactional`** and does **individual `save()` calls** for every single entity:

- **Step 3**: One `fileRepository.findByPath()` + `save()` per unique file
- **Step 4**: One `constantRepository.save()` per constant
- **Step 5**: One `parameterRepository.save()` per parameter
- **Steps 6–7**: One `save()` per modified constant/parameter (with accumulated relationships)
- **Step 8**: One `fileRepository.save()` per Java file FQN

For a project with 5,000 constants across 500 files, that's easily **6,000+ individual Cypher round-trips** inside a single transaction — each one waiting for a network round-trip to Neo4j.

---

## Recommendations (ranked by impact)

### 1. Use `saveAll()` instead of individual `save()` calls

**Effort:** Low | **Impact:** High

All four repositories extend `Neo4jRepository`, which inherits `saveAll(Iterable<T>)`. Collecting entities into lists and calling `saveAll()` once per step lets the Spring Data Neo4j driver batch them into far fewer Cypher statements.

Example for constants: instead of saving inside the loop, build a `List<ConstantNode>`, then call `constantRepository.saveAll(nodeList)` once.

### 2. Replace `findByPath()` lookups with a single bulk fetch

**Effort:** Low | **Impact:** Medium–High

Step 3 does `fileRepository.findByPath(path)` **per file** — N individual queries. Instead:

- Fetch all existing files for the project in one query (e.g., `findAllByPathIn(Collection<String> paths)`)
- Build the cache from that single result
- Create only the missing ones with a single `saveAll()`

### 3. Raw Cypher `UNWIND` for USED_IN relationships

**Effort:** Medium | **Impact:** High

Steps 6–7 load already-saved constants/parameters, add `UsageRelationship` objects, then re-save the parent entity. Spring Data Neo4j persists the full entity graph each time. For heavy-relationship scenarios, a **raw Cypher `UNWIND` batch** is far more efficient:

```cypher
UNWIND $rows AS row
MATCH (c:Constant {name: row.constantName, className: row.className})
MATCH (f:File {path: row.filePath})
CREATE (c)-[:USED_IN {className: row.usedInClass, lineNumber: row.line, context: row.ctx}]->(f)
```

This creates all USED_IN relationships in a single Cypher statement — orders of magnitude faster than individual OGM saves.

### 4. Raw Cypher `UNWIND` for FQN updates

**Effort:** Low | **Impact:** Medium

Step 8 does `fileRepository.save(file)` inside a loop just to set FQN. A single Cypher `UNWIND` update would be much faster:

```cypher
UNWIND $rows AS row
MATCH (f:File {path: row.path})
SET f.fqn = row.fqn
```

### 5. Chunk into 1,000-entity batches

**Effort:** Low | **Impact:** Medium (large projects)

If scanning projects with tens of thousands of constants, even `saveAll()` on 20,000 entities can strain memory and transaction size. Partition into chunks:

```java
Lists.partition(allConstants, 1000).forEach(batch -> {
    constantRepository.saveAll(batch);
});
```

Each `saveAll()` call would still be within the same `@Transactional`, but the driver sends smaller payloads. For separate transactions per batch (to avoid one giant rollback on failure), extract the batched save into a separate `@Transactional(propagation = REQUIRES_NEW)` method.

### 6. Per-step transactions instead of one giant one

**Effort:** Low | **Impact:** Medium

The all-or-nothing atomicity is probably not critical here — a partial scan is better than no scan. Breaking into per-step transactions (or per-batch) reduces lock contention and memory pressure in Neo4j.

---

## Summary

| Priority | Change | Effort | Impact |
|----------|--------|--------|--------|
| 1 | `saveAll()` instead of per-entity `save()` | Low | High |
| 2 | Bulk `findAllByPathIn()` instead of per-file lookup | Low | Medium–High |
| 3 | Raw Cypher `UNWIND` for USED_IN relationships | Medium | High |
| 4 | Raw Cypher `UNWIND` for FQN updates | Low | Medium |
| 5 | Chunking into 1,000-entity batches | Low | Medium |
| 6 | Per-step transactions instead of one giant one | Low | Medium |

Items 1 and 2 alone should give a dramatic speedup with minimal code changes. Item 3 (Cypher UNWIND for relationships) is the next big lever if performance is still insufficient.
