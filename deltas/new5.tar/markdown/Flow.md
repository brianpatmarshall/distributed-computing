# Constants Catalog

A full-stack application for parsing Java projects to catalog hardcoded constants and configuration parameters, storing them in Neo4j for analysis and visualization.

## Architecture

4 modules in a Maven multi-module project (Java 21):

| Module | Role | Tech |
|--------|------|------|
| **const-catalog-core** | Parsing engine - scans Java/property files, extracts constants & parameter usages | JavaParser, SLF4J |
| **const-catalog-backend** | REST API, Neo4j graph population, query execution | Spring Boot 3.4.1, Spring Data Neo4j |
| **const-catalog-cli** | Standalone CLI that exports to CSV for manual Neo4j import | Uber JAR |
| **const-catalog-frontend** | Web UI for scanning projects and querying results | React 18, TypeScript, Vite, TailwindCSS |

## Infrastructure (Docker Compose)

5 services: Neo4j (graph DB), ValKey (Redis-compatible cache/pubsub), Backend, Frontend, and a ValKey CLI tool.

## Core Data Flow

1. **ProjectScanner** walks the file tree (skipping `target/`, `node_modules/`, etc.)
2. **JavaFileParser** extracts `static final` fields as constants, and detects `@Value` / property getter usages
3. **PropertyFileParser** extracts parameters from `.properties` / `.yml` files
4. **GraphPopulatorService** creates Neo4j nodes (Project, File, Constant, Parameter) and relationships (DEFINED_IN, USED_IN)
5. **QueryService** runs pre-canned or custom Cypher queries (read-only enforced)

## Current Branch: `addPathAndView`

Two commits so far (`Initial Commit` and `Added File View`). The working tree shows:
- **Modified:** `JavaFileParser.java` (unstaged changes in core parser)
- Several untracked files (wiki pages, WSL configs, resources)

## Key Numbers

~45 Java source files, ~13 frontend components/pages, and comprehensive documentation in `markdown/`.
