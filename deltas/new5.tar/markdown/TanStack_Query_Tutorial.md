# TanStack Query Tutorial

A practical guide to TanStack Query (formerly React Query) as used in the Constants Catalog frontend.

---

## Table of Contents

1. [The Problem TanStack Query Solves](#1-the-problem-tanstack-query-solves)
2. [Core Concepts](#2-core-concepts)
3. [Setting Up: QueryClient and QueryClientProvider](#3-setting-up-queryclient-and-queryclientprovider)
4. [useQuery: Fetching Data](#4-usequery-fetching-data)
5. [useMutation: Sending Data](#5-usemutation-sending-data)
6. [Query Keys: The Cache Address System](#6-query-keys-the-cache-address-system)
7. [The Query Lifecycle: Loading, Error, and Success States](#7-the-query-lifecycle-loading-error-and-success-states)
8. [Polling with refetchInterval](#8-polling-with-refetchinterval)
9. [Global Defaults vs Per-Query Overrides](#9-global-defaults-vs-per-query-overrides)
10. [Project Walkthrough: Every TanStack Usage in This Codebase](#10-project-walkthrough-every-tanstack-usage-in-this-codebase)
11. [What This Project Does NOT Use (Yet)](#11-what-this-project-does-not-use-yet)
12. [Common Patterns and Best Practices](#12-common-patterns-and-best-practices)

---

## 1. The Problem TanStack Query Solves

### The Traditional Approach

Without TanStack Query, fetching data in a React component requires manually orchestrating several concerns:

```tsx
// The "old way" - manually managing everything
function Dashboard() {
  const [stats, setStats] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    setIsLoading(true)
    fetch('/api/stats')
      .then(res => res.json())
      .then(data => {
        setStats(data)
        setIsLoading(false)
      })
      .catch(err => {
        setError(err)
        setIsLoading(false)
      })
  }, [])

  if (isLoading) return <Spinner />
  if (error) return <ErrorMessage />
  return <StatsDisplay stats={stats} />
}
```

This works, but you're now responsible for:
- **Three pieces of state** (`data`, `loading`, `error`) for every API call
- **When to refetch** (component mount? interval? after a user action?)
- **Caching** — if you navigate away and come back, do you re-fetch or show stale data?
- **Deduplication** — if two components need the same data, do you fetch it twice?
- **Race conditions** — what if the user triggers two fetches and the first one returns last?
- **Retry logic** — what if the network blips? Do you retry? How many times?

Multiply this by every API endpoint in your app, and you have a lot of boilerplate that is easy to get wrong.

### The TanStack Query Approach

TanStack Query handles all of the above. The same component becomes:

```tsx
function Dashboard() {
  const { data: stats, isLoading, isError } = useQuery({
    queryKey: ['stats'],
    queryFn: getStats,
  })

  if (isLoading) return <Spinner />
  if (isError) return <ErrorMessage />
  return <StatsDisplay stats={stats} />
}
```

Two lines of configuration replace three `useState` calls, a `useEffect`, and all the wiring. Behind the scenes, TanStack Query provides caching, automatic retries, deduplication, background refetching, and state synchronization across components.

### Why Not Just Use `useEffect` + `fetch`?

| Concern | `useEffect` + `fetch` | TanStack Query |
|---|---|---|
| Loading/error states | Manual `useState` for each | Built-in `isLoading`, `isError` |
| Caching | None (or build your own) | Automatic, configurable |
| Deduplication | None | Same `queryKey` = one request |
| Retries | Manual | Configurable (`retry: 1`) |
| Background refetch | Manual `setInterval` | `refetchInterval` option |
| Race conditions | Must handle manually | Handled automatically |
| Stale data | Must track manually | `staleTime` option |

---

## 2. Core Concepts

TanStack Query is built around a few key ideas:

### Queries vs. Mutations

This is the fundamental distinction:

- **Query** (`useQuery`): For **reading** data. GET requests. "Give me the current stats." Queries are declarative — you describe what data you want, and TanStack Query figures out when and how to fetch it.

- **Mutation** (`useMutation`): For **writing** data. POST/PUT/DELETE requests. "Scan this project." "Run this Cypher query." Mutations are imperative — you call `.mutate()` when the user clicks a button.

The mental model: queries are automatic (they run when the component mounts), mutations are manual (they run when you tell them to).

### The QueryClient

The `QueryClient` is the central brain. It owns the cache, manages background refetches, coordinates deduplication, and holds your default configuration. There is one per application, created once and provided via React context.

### Query Keys

Every query has a unique key (like `['stats']` or `['health']`). This key serves as:
1. The **cache address** — TanStack Query stores and retrieves cached results by this key
2. The **identity** — two components with the same key share the same data
3. The **invalidation target** — you can tell TanStack Query "refetch everything with key `['stats']`"

---

## 3. Setting Up: QueryClient and QueryClientProvider

**File: `const-catalog-frontend/src/main.tsx`**

```tsx
import React from 'react'
import ReactDOM from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import App from './App'
import './index.css'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000,
      retry: 1,
    },
  },
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>,
)
```

### What's Happening

**Step 1: Create the QueryClient.** This is where you set application-wide defaults.

- `staleTime: 30000` — Data is considered "fresh" for 30 seconds after it's fetched. During this window, if a component mounts and requests the same query key, TanStack Query returns the cached result instantly without making a network request. After 30 seconds, the data is "stale" and will be refetched the next time it's needed (e.g., when the component re-mounts or the window regains focus).

- `retry: 1` — If a query fails (network error, 5xx response), retry it once before giving up. The default is 3 retries, but this project uses 1 to fail faster. Each retry uses exponential backoff by default.

**Step 2: Wrap the app in `QueryClientProvider`.** This makes the `queryClient` instance available to every component via React context. Without this wrapper, `useQuery` and `useMutation` would throw an error because they wouldn't be able to find a QueryClient.

### Why These Specific Defaults?

The Constants Catalog is a developer tool running locally. A 30-second stale time is a reasonable balance — dashboard stats don't change every second, but you don't want to show data that's minutes old either. One retry is appropriate because if the backend is down, retrying three times just delays the error message.

---

## 4. useQuery: Fetching Data

`useQuery` is used for declarative data fetching — you tell it what data you want, and it manages the entire lifecycle.

### Basic Structure

```tsx
const { data, isLoading, isError } = useQuery({
  queryKey: ['someKey'],       // Cache address
  queryFn: someAsyncFunction,  // How to fetch
})
```

### Required Options

| Option | Type | Purpose |
|---|---|---|
| `queryKey` | `unknown[]` | Unique cache identifier. Must be an array. |
| `queryFn` | `() => Promise<T>` | Async function that fetches and returns the data. |

### Key Return Values

| Field | Type | Meaning |
|---|---|---|
| `data` | `T \| undefined` | The resolved data. `undefined` until the first successful fetch. |
| `isLoading` | `boolean` | `true` on the initial fetch when there is no cached data. |
| `isFetching` | `boolean` | `true` whenever a fetch is in progress (including background refetches). |
| `isError` | `boolean` | `true` if the query failed (after retries). |
| `error` | `Error \| null` | The error object if the query failed. |
| `isSuccess` | `boolean` | `true` if the query has data and no error. |

### isLoading vs. isFetching

This distinction matters:
- `isLoading` is `true` only on the **first** fetch when there's no cached data. It's for showing a loading skeleton on initial page load.
- `isFetching` is `true` on **every** fetch, including background refetches. It's for showing a subtle refresh indicator (like a spinner in the corner).

If you use `isLoading` for your loading state (as this project does), the UI won't flash a loading spinner every time data is refetched in the background — the user sees the previous data while the new data loads.

---

## 5. useMutation: Sending Data

`useMutation` is used for imperative data changes — it gives you a `.mutate()` function that you call in response to user actions.

### Basic Structure

```tsx
const mutation = useMutation({
  mutationFn: someAsyncFunction,  // The POST/PUT/DELETE function
  onSuccess: (data) => { ... },   // Called when it succeeds
  onError: (error) => { ... },    // Called when it fails
})

// Later, in a button handler:
mutation.mutate(someArgument)
```

### Why Not Use useQuery for POST Requests?

The key difference is **intent**:
- Queries are for reading. They run automatically, cache results, and refetch in the background.
- Mutations are for writing. They only run when you call `.mutate()`, they don't cache results, and they don't refetch.

Using `useQuery` for a POST request would mean the request fires every time the component mounts — you don't want to scan a project or execute a Cypher query just because the user navigated to the page.

### Key Options

| Option | Type | Purpose |
|---|---|---|
| `mutationFn` | `(vars: T) => Promise<R>` | The async function to call. Receives the argument passed to `.mutate()`. |
| `onSuccess` | `(data: R) => void` | Called with the result when the mutation succeeds. |
| `onError` | `(error: Error) => void` | Called when the mutation fails. |
| `onSettled` | `(data, error) => void` | Called after either success or failure. |

### Key Return Values

| Field | Type | Meaning |
|---|---|---|
| `mutate` | `(vars: T) => void` | Call this to trigger the mutation. |
| `isPending` | `boolean` | `true` while the mutation is in progress. |
| `isSuccess` | `boolean` | `true` if the mutation succeeded. |
| `isError` | `boolean` | `true` if the mutation failed. |
| `data` | `R \| undefined` | The result data (if successful). |
| `error` | `Error \| null` | The error (if failed). |
| `reset` | `() => void` | Resets the mutation state back to idle. |

---

## 6. Query Keys: The Cache Address System

Query keys are the backbone of TanStack Query's caching. They determine when data is shared, when it's refetched, and how it's invalidated.

### Simple Keys

All three queries in this project use simple, static keys:

```tsx
queryKey: ['health']          // Header.tsx
queryKey: ['stats']           // Dashboard.tsx
queryKey: ['preCannedQueries'] // QueryPage.tsx
```

Each is a single-element array with a string. This means:
- There is exactly one cached entry for health data, one for stats, and one for pre-canned queries.
- Any component using `queryKey: ['stats']` will share the same cached data.

### Parameterized Keys (Not Used in This Project, But Important)

If you needed to fetch stats for a specific project, you'd add the project ID to the key:

```tsx
queryKey: ['stats', projectId]
```

Now each project gets its own cache entry. TanStack Query treats `['stats', 'project-a']` and `['stats', 'project-b']` as completely separate queries with separate data, loading states, and refetch schedules.

### Why Arrays?

Keys are arrays so they can be hierarchical. You can invalidate at different levels:

```tsx
// Invalidate everything under 'stats'
queryClient.invalidateQueries({ queryKey: ['stats'] })

// Invalidate only stats for project-a
queryClient.invalidateQueries({ queryKey: ['stats', 'project-a'] })
```

The first call would refetch `['stats']`, `['stats', 'project-a']`, and `['stats', 'project-b']`. The second call would only refetch `['stats', 'project-a']`.

---

## 7. The Query Lifecycle: Loading, Error, and Success States

Every query goes through a predictable lifecycle. Understanding this lifecycle is essential for building good UIs.

### First Mount (No Cached Data)

```
Component mounts
  → isLoading: true, data: undefined
  → queryFn executes
  → Success? → isLoading: false, data: <result>
  → Failure? → retry (up to 1 time per our config)
    → Still failing? → isLoading: false, isError: true
```

### Subsequent Mount (Cached Data Exists)

```
Component mounts
  → isLoading: false, data: <cached result> (instant!)
  → Is data stale? (older than 30 seconds per our staleTime)
    → Yes → isFetching: true, background refetch starts
      → Success? → data updates seamlessly, isFetching: false
    → No → nothing happens, cached data is fresh enough
```

This is why TanStack Query feels fast — returning cached data instantly while refreshing in the background gives the user immediate feedback without sacrificing freshness.

### State Diagram

```
                    ┌─────────────┐
                    │   LOADING   │  isLoading: true
         ┌────────►│  (no cache) │  data: undefined
         │         └──────┬──────┘
         │                │
    Component         queryFn()
     mounts               │
         │          ┌─────┴─────┐
         │          ▼           ▼
         │    ┌──────────┐  ┌──────────┐
         │    │ SUCCESS  │  │  ERROR   │
         │    │          │  │          │
         │    │ data: T  │  │ isError  │
         │    └────┬─────┘  └──────────┘
         │         │
         │    staleTime expires
         │         │
         │    ┌────▼──────────┐
         │    │  BACKGROUND   │  isFetching: true
         └────┤   REFETCH     │  data: <previous> (still visible!)
              └───────────────┘
```

---

## 8. Polling with refetchInterval

The `refetchInterval` option causes a query to automatically re-execute on a fixed schedule:

```tsx
const { data: health } = useQuery({
  queryKey: ['health'],
  queryFn: healthCheck,
  refetchInterval: 30000,  // Every 30 seconds
})
```

### How It Works

1. Initial fetch runs when the component mounts.
2. A timer starts: every 30 seconds, `healthCheck()` runs again.
3. `data` updates automatically with the latest result.
4. If the component unmounts, the timer stops (no memory leaks).

### Why Use This Instead of `setInterval`?

With `setInterval`, you'd need to:
- Start the interval in `useEffect`
- Clean it up on unmount
- Manually update state
- Handle errors
- Avoid race conditions if the response takes longer than the interval

`refetchInterval` handles all of this. It also integrates with the cache, so if another component requests `['health']` data, it gets the latest polled result without a separate request.

### When to Use Polling vs. Other Strategies

| Strategy | Use When |
|---|---|
| `refetchInterval` | You need periodic updates (health checks, dashboards) |
| `refetchOnWindowFocus` | Data should refresh when the user returns to the tab (enabled by default) |
| `invalidateQueries` | Data should refresh after a specific user action (e.g., after a mutation) |
| WebSocket / SSE | You need real-time updates (this project uses SSE for scan progress separately) |

---

## 9. Global Defaults vs. Per-Query Overrides

The QueryClient configuration sets defaults. Individual queries can override them.

### How the Defaults Apply

From `main.tsx`:
```tsx
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000,  // Applied to ALL useQuery calls
      retry: 1,          // Applied to ALL useQuery calls
    },
  },
})
```

These apply to every `useQuery` in the app unless explicitly overridden.

### Per-Query Overrides in This Project

The `['health']` query in `Header.tsx` adds `refetchInterval: 30000`:

```tsx
const { data: health } = useQuery({
  queryKey: ['health'],
  queryFn: healthCheck,
  refetchInterval: 30000,  // Only this query polls; others don't
})
```

The `['stats']` and `['preCannedQueries']` queries don't set `refetchInterval`, so they use the defaults only (no polling).

### Precedence

Per-query options merge with and override global defaults:
```
Effective options = Global defaults + Per-query overrides
```

For the health query:
- `staleTime: 30000` (from global)
- `retry: 1` (from global)
- `refetchInterval: 30000` (from per-query override)

---

## 10. Project Walkthrough: Every TanStack Usage in This Codebase

### 10.1 Global Setup — `main.tsx`

```tsx
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30000,
      retry: 1,
    },
  },
})
```

Creates the singleton QueryClient with conservative defaults appropriate for a local developer tool.

---

### 10.2 Health Check Polling — `Header.tsx`

```tsx
import { useQuery } from '@tanstack/react-query'
import { healthCheck } from '../services/api'

export default function Header() {
  const { data: health, isLoading, isError } = useQuery({
    queryKey: ['health'],
    queryFn: healthCheck,
    refetchInterval: 30000,
  })

  const isConnected = health?.status === 'healthy'
  // Renders a green/red connection indicator in the header
}
```

**API function** (`services/api.ts`):
```tsx
export async function healthCheck(): Promise<HealthResponse> {
  const response = await api.get<HealthResponse>('/stats/health')
  return response.data
}
```

**What's happening:**
- On mount, calls `GET /api/stats/health`
- Returns a `HealthResponse` with `status`, `database`, and `projectCount`
- Re-polls every 30 seconds so the header always shows current backend status
- `data: health` renames the `data` field to `health` via destructuring
- `isLoading` is used to show a neutral state while the first check runs
- `isError` triggers a "disconnected" indicator if the backend is unreachable

**Why useQuery and not useMutation?** This is a read-only status check that should run automatically and continuously. The user never clicks "check health" — it just happens.

---

### 10.3 Dashboard Statistics — `Dashboard.tsx`

```tsx
import { useQuery } from '@tanstack/react-query'
import { getStats } from '../services/api'

export default function Dashboard() {
  const { data: stats, isLoading, isError } = useQuery({
    queryKey: ['stats'],
    queryFn: getStats,
  })

  if (isLoading) return <LoadingState />
  if (isError || !stats) return <ErrorState />

  return (
    // Renders stat cards: project count, file count, constant count, etc.
  )
}
```

**API function:**
```tsx
export async function getStats(): Promise<StatsResponse> {
  const response = await api.get<StatsResponse>('/stats')
  return response.data
}
```

**What's happening:**
- Fetches `GET /api/stats` on component mount
- Uses `staleTime: 30000` from global defaults — if the user navigates away and back within 30 seconds, the cached stats display instantly without a network request
- No `refetchInterval` — stats only refresh when the component remounts or the stale time expires and the window is refocused
- Shows a full-page loading skeleton while the first fetch is in progress
- Shows a full-page error state if the fetch fails after 1 retry

**Why no polling?** Dashboard stats change only when a scan runs, which is an explicit user action. Polling every 30 seconds would be wasteful. If this project wanted stats to update after a scan, it could use `queryClient.invalidateQueries({ queryKey: ['stats'] })` in the scan mutation's `onSuccess` callback (see [Section 11](#11-what-this-project-does-not-use-yet)).

---

### 10.4 Pre-Canned Queries — `QueryPage.tsx`

```tsx
import { useQuery, useMutation } from '@tanstack/react-query'
import { getPreCannedQueries, executePreCannedQuery, executeQuery } from '../services/api'

export default function QueryPage() {
  const [cypher, setCypher] = useState('')
  const [result, setResult] = useState<QueryResponse | null>(null)

  // QUERY: Load the list of available pre-canned queries
  const { data: preCannedQueries } = useQuery({
    queryKey: ['preCannedQueries'],
    queryFn: getPreCannedQueries,
  })

  // MUTATION: Execute a pre-canned query by ID
  const preCannedMutation = useMutation({
    mutationFn: executePreCannedQuery,
    onSuccess: setResult,
  })

  // MUTATION: Execute an ad-hoc Cypher query
  const queryMutation = useMutation({
    mutationFn: executeQuery,
    onSuccess: setResult,
  })
}
```

**API functions:**
```tsx
export async function getPreCannedQueries(): Promise<PreCannedQuery[]> {
  const response = await api.get<PreCannedQuery[]>('/query/precanned')
  return response.data
}

export async function executePreCannedQuery(queryId: string): Promise<QueryResponse> {
  const response = await api.get<QueryResponse>(`/query/precanned/${queryId}`)
  return response.data
}

export async function executeQuery(request: QueryRequest): Promise<QueryResponse> {
  const response = await api.post<QueryResponse>('/query/execute', request)
  return response.data
}
```

**What's happening:**

This page mixes both patterns — a `useQuery` for data that's needed on page load, and two `useMutation`s for user-initiated actions.

**The useQuery (`preCannedQueries`):**
- Fetches the list of available pre-canned queries when the page mounts
- This list is static (it comes from backend configuration), so the 30-second stale time is more than sufficient
- The data populates a dropdown/selector in the UI
- No destructuring of `isLoading` or `isError` — the component simply doesn't render the dropdown until `preCannedQueries` has data (using optional chaining)

**The first useMutation (`preCannedMutation`):**
- Called when the user selects a pre-canned query: `preCannedMutation.mutate('query-id')`
- `mutationFn: executePreCannedQuery` — receives the query ID string and calls `GET /api/query/precanned/{id}`
- `onSuccess: setResult` — shorthand for `(data) => setResult(data)`. When the query executes successfully, the result is stored in local state and rendered in a results table

**The second useMutation (`queryMutation`):**
- Called when the user writes and submits a custom Cypher query: `queryMutation.mutate({ cypher: 'MATCH (n) RETURN n' })`
- `mutationFn: executeQuery` — receives a `QueryRequest` object and calls `POST /api/query/execute`
- Same `onSuccess: setResult` pattern

**Why are the query executions mutations, not queries?** Even though `executePreCannedQuery` uses HTTP GET, the conceptual operation is "run this query now because the user asked" — not "passively keep this data in sync." You don't want the query to re-execute every time the component re-renders or the user refocuses the window.

---

### 10.5 Project Scanning — `ScanPage.tsx`

```tsx
import { useMutation } from '@tanstack/react-query'
import { scanProject } from '../services/api'

export default function ScanPage() {
  const [projectPath, setProjectPath] = useState('')
  const [scanResult, setScanResult] = useState<ScanResponse | null>(null)

  const { isConnected, latestFiles, currentEvent, startStreaming, stopStreaming } =
    useScanProgress()

  const scanMutation = useMutation({
    mutationFn: scanProject,
    onSuccess: (data) => {
      setScanResult(data)
      stopStreaming()
    },
    onError: (error) => {
      setScanResult({
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error',
      })
      stopStreaming()
    },
  })

  const handleScan = (e: React.FormEvent) => {
    e.preventDefault()
    if (!projectPath.trim()) return
    setScanResult(null)

    if (watchProgress) {
      startStreaming(projectPath.trim())
    }

    scanMutation.mutate({ projectPath: projectPath.trim() })
  }
}
```

**API function:**
```tsx
export async function scanProject(request: ScanRequest): Promise<ScanResponse> {
  const response = await api.post<ScanResponse>('/scan', request)
  return response.data
}
```

**What's happening:**

This page is mutation-only — there's no data to fetch on page load.

- `mutationFn: scanProject` — sends `POST /api/scan` with the project path
- `onSuccess` stores the result and stops the SSE progress stream
- `onError` constructs a synthetic error response so the UI can display it uniformly, and also stops streaming
- `scanMutation.mutate({ projectPath: projectPath.trim() })` is called when the user submits the form
- `scanMutation.isPending` is available (though not destructured here) and can be used to disable the submit button during scanning

**The SSE integration:** Note how TanStack Query and the SSE-based `useScanProgress` hook work side by side. The mutation handles the final result of the scan (success/failure, counts), while the SSE stream provides real-time progress updates (file-by-file). TanStack Query is not used for the SSE stream because SSE is a fundamentally different pattern — it's a persistent connection pushing events, not a request-response cycle.

---

### 10.6 Code Transformation — `TransformPage.tsx`

```tsx
import { useMutation } from '@tanstack/react-query'
import { transformProject, getFileComparison } from '../services/api'

export default function TransformPage() {
  const [projectPath, setProjectPath] = useState('')
  const [dryRun, setDryRun] = useState(true)
  const [createBranch, setCreateBranch] = useState(false)
  const [result, setResult] = useState<TransformResponse | null>(null)
  const [comparison, setComparison] = useState<FileComparisonResponse | null>(null)

  const transformMutation = useMutation({
    mutationFn: transformProject,
    onSuccess: (data) => setResult(data),
    onError: (error) => {
      let message = 'Unknown error'
      if (axios.isAxiosError(error) && error.response?.data?.message) {
        message = error.response.data.message
      } else if (error instanceof Error) {
        message = error.message
      }

      setResult({
        success: false,
        message,
        projectPath,
        transformedAt: new Date().toISOString(),
        dryRun,
        totalTransformed: 0,
        totalSkipped: 0,
        totalFailed: 0,
        entries: [],
      })
    },
  })

  const compareMutation = useMutation({
    mutationFn: (filePath: string) => getFileComparison(filePath),
    onSuccess: (data) => setComparison(data),
  })

  const handleTransform = (e: React.FormEvent) => {
    e.preventDefault()
    transformMutation.mutate({
      projectPath: projectPath.trim(),
      dryRun,
      candidateScope,
      createBranch: !dryRun && createBranch,
    })
  }

  const handleViewComparison = (entry: TransformEntry) => {
    compareMutation.mutate(entry.filePath)
  }
}
```

**API functions:**
```tsx
export async function transformProject(request: TransformRequest): Promise<TransformResponse> {
  const response = await api.post<TransformResponse>('/transform', request)
  return response.data
}

export async function getFileComparison(filePath: string): Promise<FileComparisonResponse> {
  const response = await api.get<FileComparisonResponse>('/transform/compare', {
    params: { path: filePath },
  })
  return response.data
}
```

**What's happening:**

Two mutations working together:

**`transformMutation`:**
- Sends `POST /api/transform` with project path, dry-run flag, candidate scope, and branch creation flag
- The `onError` handler is the most sophisticated in the project — it extracts the error message from the Axios response body (the backend sends structured error JSON), falling back to the generic Error message
- It constructs a full synthetic `TransformResponse` on error so the UI can render results and errors identically

**`compareMutation`:**
- After transformation results appear, the user can click on individual files to see before/after diffs
- Calls `GET /api/transform/compare?path=<filePath>`
- `onSuccess` stores the comparison data, which is rendered in a `DiffViewer` component

**Why is comparison a mutation instead of a query?** The comparison is a user-initiated, on-demand action — the user clicks a specific file to see its diff. Using `useQuery` would mean either fetching all comparisons upfront (wasteful) or dynamically changing the query key (possible but more complex than needed here).

---

### 10.7 API Layer — `services/api.ts`

All query and mutation functions live in a centralized API service file. This is worth examining as a pattern:

```tsx
import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})
```

Every function follows the same pattern:

```tsx
export async function someOperation(arg: InputType): Promise<OutputType> {
  const response = await api.get<OutputType>('/endpoint')  // or api.post
  return response.data
}
```

**Why this pattern matters for TanStack Query:**

1. **Separation of concerns** — The API functions know about HTTP and Axios. The components know about TanStack Query. Neither knows about the other's implementation details.

2. **Type safety** — Each function declares its return type (`Promise<StatsResponse>`, etc.). TanStack Query infers this type, so `data` in the component is correctly typed without manual annotation.

3. **Testability** — You can test API functions independently of React components, and test components with mocked API functions.

4. **Error propagation** — Axios throws on non-2xx responses. TanStack Query catches these throws and sets `isError: true`. No manual error handling needed in the query function itself (unless you want to transform the error, as `TransformPage` does in its `onError`).

---

## 11. What This Project Does NOT Use (Yet)

TanStack Query has many features beyond what this project currently uses. Understanding these gaps reveals opportunities for improvement.

### Cache Invalidation

Currently, after scanning a project, the Dashboard stats are stale — they reflect the pre-scan state until the user navigates away and back (and the stale time has expired). This could be improved:

```tsx
// In ScanPage.tsx
import { useQueryClient } from '@tanstack/react-query'

export default function ScanPage() {
  const queryClient = useQueryClient()

  const scanMutation = useMutation({
    mutationFn: scanProject,
    onSuccess: (data) => {
      setScanResult(data)
      stopStreaming()
      // Invalidate stats so Dashboard shows fresh data
      queryClient.invalidateQueries({ queryKey: ['stats'] })
    },
  })
}
```

`invalidateQueries` marks the cached data as stale and triggers a refetch if any component is currently using that query. If no component is mounted with that key, the cache is simply marked stale so the next mount will refetch.

### Optimistic Updates

For actions where you can predict the outcome, TanStack Query lets you update the cache immediately (before the server responds) and roll back if the request fails:

```tsx
const mutation = useMutation({
  mutationFn: updateProject,
  onMutate: async (newData) => {
    await queryClient.cancelQueries({ queryKey: ['project', id] })
    const previous = queryClient.getQueryData(['project', id])
    queryClient.setQueryData(['project', id], newData)
    return { previous }
  },
  onError: (err, newData, context) => {
    queryClient.setQueryData(['project', id], context.previous)
  },
})
```

This isn't needed in this project because mutations (scan, transform, query execution) are long-running operations where optimistic updates wouldn't make sense.

### Dependent Queries

Queries that depend on the result of another query:

```tsx
const { data: project } = useQuery({
  queryKey: ['project', projectId],
  queryFn: () => getProject(projectId),
})

const { data: files } = useQuery({
  queryKey: ['files', project?.id],
  queryFn: () => getFiles(project!.id),
  enabled: !!project,  // Only runs after project data is available
})
```

The `enabled` option prevents the second query from running until the first has resolved.

### Infinite Queries

For paginated lists with "load more" functionality:

```tsx
const { data, fetchNextPage, hasNextPage } = useInfiniteQuery({
  queryKey: ['constants'],
  queryFn: ({ pageParam = 0 }) => getConstants(pageParam),
  getNextPageParam: (lastPage) => lastPage.nextCursor,
})
```

This could be useful if the query results table needed to handle large result sets.

### React Query DevTools

TanStack Query provides a browser DevTools panel that shows all cached queries, their state, and timing:

```tsx
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'

// In main.tsx, inside QueryClientProvider:
<ReactQueryDevtools initialIsOpen={false} />
```

This adds a floating button in development that opens a panel showing every query key, its data, stale/fresh status, and fetch history. Very useful for debugging cache behavior.

---

## 12. Common Patterns and Best Practices

### Pattern: Destructuring with Rename

```tsx
const { data: stats } = useQuery(...)
```

The `data` field is generic. Renaming it to something descriptive (`stats`, `health`, `preCannedQueries`) makes the code more readable. This is standard JavaScript destructuring syntax, not a TanStack Query feature.

### Pattern: Centralized API Functions

Keep your `queryFn` and `mutationFn` implementations in a separate file (`services/api.ts`). This keeps components focused on UI logic and makes the API layer independently testable.

### Pattern: Synthetic Error Responses

When a mutation's `onError` constructs a fake success-shaped response (as `TransformPage` does), the component can use a single rendering path for both success and error states. This reduces conditional logic in JSX.

### When to Use useQuery vs. useMutation

| Use `useQuery` when... | Use `useMutation` when... |
|---|---|
| Data should load automatically | The user triggers the action |
| The operation is idempotent (safe to repeat) | The operation has side effects |
| You want caching and background refetch | You don't want automatic re-execution |
| HTTP GET semantics | HTTP POST/PUT/DELETE semantics |

### Naming Convention in This Project

| TanStack concept | Naming pattern | Example |
|---|---|---|
| Query key | Descriptive noun, camelCase | `['stats']`, `['health']`, `['preCannedQueries']` |
| Query function | `get*` or descriptive verb | `getStats`, `healthCheck`, `getPreCannedQueries` |
| Mutation variable | `*Mutation` | `scanMutation`, `queryMutation`, `transformMutation` |
| Mutation function | Action verb | `scanProject`, `executeQuery`, `transformProject` |

### Avoid These Common Mistakes

1. **Don't put derived state in `useState` when you have query data.** If you can compute it from `data`, compute it inline:
   ```tsx
   // Bad
   const [isConnected, setIsConnected] = useState(false)
   useEffect(() => setIsConnected(health?.status === 'healthy'), [health])

   // Good (as done in Header.tsx)
   const isConnected = health?.status === 'healthy'
   ```

2. **Don't forget that `data` is `undefined` before the first fetch.** Always use optional chaining (`health?.status`) or guard with `isLoading`/`isSuccess` before accessing nested fields.

3. **Don't use the same key for different data.** If you have two different API endpoints, they need different keys — even if the data looks similar.
