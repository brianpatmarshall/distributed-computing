# Lettuce Tutorial

Lettuce is a scalable, thread-safe Redis/ValKey client for Java built on top of Netty. It supports synchronous, asynchronous, and reactive programming models and covers the complete Redis API including data structures, Pub/Sub, transactions, pipelining, Sentinel, and Cluster.

**Repository:** https://github.com/redis/lettuce

## Table of Contents

1. [What Problem Does Lettuce Solve?](#what-problem-does-lettuce-solve)
2. [Getting Started](#getting-started)
3. [Core Concepts](#core-concepts)
4. [The Three APIs: Sync, Async, Reactive](#the-three-apis-sync-async-reactive)
5. [Connection Management and Thread Safety](#connection-management-and-thread-safety)
6. [ClientResources and ClientOptions](#clientresources-and-clientoptions)
7. [Pub/Sub](#pubsub)
8. [Pipelining and Transactions](#pipelining-and-transactions)
9. [High Availability: Sentinel and Cluster](#high-availability-sentinel-and-cluster)
10. [Codecs and Custom Serialization](#codecs-and-custom-serialization)
11. [How This Project Uses Lettuce](#how-this-project-uses-lettuce)
12. [Best Practices](#best-practices)
13. [Common Pitfalls](#common-pitfalls)
14. [Quick Reference](#quick-reference)

---

## What Problem Does Lettuce Solve?

Redis (and its compatible forks like ValKey) is an in-memory data store used for caching, messaging, and configuration. To talk to it from Java, you need a client library. The two main options are **Jedis** and **Lettuce**:

| Feature | Lettuce | Jedis |
|---------|---------|-------|
| **Thread Safety** | Thread-safe by design; one connection shared across threads | NOT thread-safe; requires connection pooling |
| **Programming Model** | Sync, Async (`CompletionStage`), Reactive (Project Reactor) | Synchronous only |
| **I/O Model** | Non-blocking, Netty-based | Blocking socket I/O |
| **Connection Pooling** | Optional (single connection often sufficient) | Required for multi-threaded use |
| **Auto-Reconnect** | Built-in by default | Must be handled manually |
| **Cluster Support** | Full, with async and reactive | Synchronous only |

Spring Data Redis uses **Lettuce as its default** since Spring Boot 2.0.

**Choose Lettuce when you need:** async/reactive support, high concurrency with minimal connections, Cluster or Sentinel HA, or you're building on Spring WebFlux / Project Reactor.

**Choose Jedis when you need:** a simpler synchronous client with minimal configuration.

```mermaid
graph TB
    subgraph "Your Application"
        SYNC["Sync API<br/>RedisCommands"]
        ASYNC["Async API<br/>RedisAsyncCommands"]
        REACTIVE["Reactive API<br/>RedisReactiveCommands"]
    end

    subgraph "Lettuce Core"
        CONN["StatefulRedisConnection<br/>(Thread-Safe, Long-Lived)"]
        CLIENT["RedisClient"]
        CR["ClientResources<br/>(Thread Pools, Event Bus)"]
    end

    subgraph "Netty Layer"
        EL["EventLoop<br/>(Non-Blocking I/O)"]
    end

    REDIS[("Redis / ValKey")]

    SYNC --> CONN
    ASYNC --> CONN
    REACTIVE --> CONN
    CONN --> CLIENT
    CLIENT --> CR
    CLIENT --> EL
    EL --> REDIS
```

---

## Getting Started

### Maven Dependency

```xml
<dependency>
    <groupId>io.lettuce</groupId>
    <artifactId>lettuce-core</artifactId>
    <version>6.3.2.RELEASE</version>
</dependency>
```

### Gradle Dependency

```groovy
implementation 'io.lettuce:lettuce-core:6.3.2.RELEASE'
```

### Minimal Example

```java
import io.lettuce.core.RedisClient;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;

public class HelloLettuce {

    public static void main(String[] args) {
        // 1. Create a client
        RedisClient client = RedisClient.create("redis://localhost:6379");

        // 2. Open a connection (long-lived, thread-safe)
        StatefulRedisConnection<String, String> connection = client.connect();

        // 3. Get the synchronous command API
        RedisCommands<String, String> commands = connection.sync();

        // 4. Use it
        commands.set("greeting", "Hello from Lettuce!");
        String value = commands.get("greeting");
        System.out.println(value); // "Hello from Lettuce!"

        // 5. Clean up (only at application shutdown)
        connection.close();
        client.shutdown();
    }
}
```

---

## Core Concepts

### RedisURI -- Where to Connect

Lettuce provides three ways to specify a connection target:

```java
// 1. From a URI string
RedisURI uri1 = RedisURI.create("redis://password@localhost:6379/0");

// 2. Using the builder (most flexible)
RedisURI uri2 = RedisURI.Builder
    .redis("localhost", 6379)
    .withPassword("password".toCharArray())
    .withDatabase(0)
    .withTimeout(Duration.ofSeconds(5))
    .build();

// 3. Direct constructor
RedisURI uri3 = new RedisURI("localhost", 6379, Duration.ofSeconds(60));
```

**URI schemes:**
- `redis://` -- plaintext
- `rediss://` -- SSL/TLS
- `redis-socket://` -- Unix domain socket
- `redis-sentinel://` -- Sentinel discovery

### RedisClient -- The Entry Point

`RedisClient` is lightweight and reusable. It creates connections but does not represent a connection itself:

```java
RedisClient client = RedisClient.create(RedisURI.create("redis://localhost:6379"));
```

### StatefulRedisConnection -- The Connection

A `StatefulRedisConnection` is a long-lived, thread-safe TCP connection to Redis. From it, you obtain one of three command APIs:

```java
StatefulRedisConnection<String, String> connection = client.connect();

RedisCommands<String, String> sync       = connection.sync();
RedisAsyncCommands<String, String> async = connection.async();
RedisReactiveCommands<String, String> rx = connection.reactive();
```

The two type parameters (`<String, String>`) represent the key type and value type, controlled by the **codec** (default: UTF-8 strings).

```mermaid
classDiagram
    class RedisClient {
        +create(RedisURI) RedisClient
        +connect() StatefulRedisConnection
        +connectPubSub() StatefulRedisPubSubConnection
        +setOptions(ClientOptions)
        +shutdown()
    }

    class StatefulRedisConnection {
        +sync() RedisCommands
        +async() RedisAsyncCommands
        +reactive() RedisReactiveCommands
        +close()
        +isOpen() boolean
    }

    class RedisCommands {
        +get(key) String
        +set(key, value) String
        +hset(key, field, value) Boolean
        +del(keys) Long
    }

    class RedisAsyncCommands {
        +get(key) RedisFuture~String~
        +set(key, value) RedisFuture~String~
    }

    class RedisReactiveCommands {
        +get(key) Mono~String~
        +set(key, value) Mono~String~
        +keys(pattern) Flux~String~
    }

    RedisClient --> StatefulRedisConnection : creates
    StatefulRedisConnection --> RedisCommands : sync()
    StatefulRedisConnection --> RedisAsyncCommands : async()
    StatefulRedisConnection --> RedisReactiveCommands : reactive()
```

---

## The Three APIs: Sync, Async, Reactive

### Choosing an API

```mermaid
flowchart TD
    START["Which API?"] --> Q1{"Need non-blocking I/O?"}
    Q1 -->|No| SYNC["Sync API<br/>connection.sync()<br/>Simple, blocking calls"]
    Q1 -->|Yes| Q2{"Using Project Reactor<br/>or WebFlux?"}
    Q2 -->|Yes| REACTIVE["Reactive API<br/>connection.reactive()<br/>Mono / Flux"]
    Q2 -->|No| ASYNC["Async API<br/>connection.async()<br/>CompletionStage"]
```

### Synchronous API

Blocks the calling thread until the response arrives:

```java
RedisCommands<String, String> sync = connection.sync();

// String commands
sync.set("user:1:name", "Alice");
String name = sync.get("user:1:name");  // "Alice"

// Hash commands
sync.hset("user:1", "email", "alice@example.com");
Map<String, String> user = sync.hgetall("user:1");

// List commands
sync.rpush("queue", "task1", "task2", "task3");
String task = sync.lpop("queue");  // "task1"

// Key expiration
sync.set("session:abc", "data");
sync.expire("session:abc", 3600);  // expires in 1 hour
```

A `RedisCommandTimeoutException` is thrown if the command doesn't complete within the configured timeout (default: 60 seconds).

### Asynchronous API

Returns `RedisFuture<T>` (which extends `CompletionStage<T>`) immediately:

```java
RedisAsyncCommands<String, String> async = connection.async();

// Returns immediately
RedisFuture<String> future = async.set("key", "value");

// Option A: Block and wait
String result = future.get(5, TimeUnit.SECONDS);

// Option B: Callback
future.thenAccept(res -> System.out.println("Set result: " + res));

// Option C: Compose multiple operations
async.set("k1", "v1")
    .thenCompose(ok -> async.get("k1").toCompletableFuture())
    .thenAccept(value -> System.out.println("Got: " + value));

// Await multiple futures at once
List<RedisFuture<?>> futures = new ArrayList<>();
futures.add(async.set("a", "1"));
futures.add(async.set("b", "2"));
futures.add(async.set("c", "3"));

LettuceFutures.awaitAll(5, TimeUnit.SECONDS,
    futures.toArray(new RedisFuture[0]));
```

### Reactive API (Project Reactor)

Returns `Mono<T>` for single-value operations and `Flux<T>` for multi-value operations:

```java
RedisReactiveCommands<String, String> reactive = connection.reactive();

// Mono for single-value operations
Mono<String> setResult = reactive.set("key", "value");
setResult.subscribe(result -> System.out.println("Set: " + result));

// Flux for multi-value operations
Flux<String> keys = reactive.keys("user:*");
keys.doOnNext(key -> System.out.println("Found: " + key))
    .subscribe();

// Composing operations
reactive.set("counter", "0")
    .then(reactive.incr("counter"))
    .flatMap(val -> reactive.get("counter"))
    .subscribe(val -> System.out.println("Counter = " + val));
```

---

## Connection Management and Thread Safety

### Key Principles

1. **Connections are thread-safe.** Multiple threads can share a single `StatefulRedisConnection`. Lettuce multiplexes commands over one TCP connection using Netty's non-blocking I/O.
2. **Connections are long-lived.** Do NOT open/close connections per request. Create one at startup and reuse it.
3. **Auto-reconnect is on by default.** If the connection drops, Lettuce reconnects and replays queued commands.

```mermaid
graph LR
    T1["Thread 1"] --> CONN["Single<br/>StatefulRedisConnection<br/>(Thread-Safe)"]
    T2["Thread 2"] --> CONN
    T3["Thread 3"] --> CONN
    TN["Thread N"] --> CONN
    CONN --> REDIS[("Redis / ValKey")]
```

### When You Need Separate Connections

A shared connection works for the vast majority of use cases. You need **dedicated** connections for:

| Scenario | Reason |
|----------|--------|
| **Blocking commands** (`BLPOP`, `BRPOP`) | They block the entire connection |
| **Transactions** (`MULTI`/`EXEC`) | Connection enters transactional state |
| **Pub/Sub subscriptions** | Connection enters subscription mode |
| **`WATCH` commands** | Require connection-level state isolation |

### Connection Pooling (When Needed)

For transaction-heavy workloads, use Apache Commons Pool 2:

```xml
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-pool2</artifactId>
    <version>2.12.0</version>
</dependency>
```

```java
GenericObjectPoolConfig<StatefulRedisConnection<String, String>> poolConfig =
    new GenericObjectPoolConfig<>();
poolConfig.setMaxTotal(8);
poolConfig.setMaxIdle(8);
poolConfig.setMinIdle(2);

GenericObjectPool<StatefulRedisConnection<String, String>> pool =
    ConnectionPoolSupport.createGenericObjectPool(
        () -> client.connect(),
        poolConfig);

// Borrow, use, and return (auto-returned via try-with-resources)
try (StatefulRedisConnection<String, String> conn = pool.borrowObject()) {
    conn.sync().multi();
    conn.sync().set("tx-key", "tx-value");
    conn.sync().exec();
}

pool.close();
```

---

## ClientResources and ClientOptions

### ClientResources -- Infrastructure-Level Configuration

`ClientResources` controls Netty thread pools, the event bus, DNS resolution, and reconnection strategy. It is **expensive to create** and should be shared across multiple `RedisClient` instances.

```java
ClientResources resources = DefaultClientResources.builder()
    .ioThreadPoolSize(4)               // Default: Runtime.availableProcessors()
    .computationThreadPoolSize(4)      // Default: Runtime.availableProcessors()
    .build();

RedisClient client = RedisClient.create(resources, RedisURI.create("redis://localhost"));

// IMPORTANT: When sharing resources, YOU must shut them down
client.shutdown();
resources.shutdown();
```

```mermaid
graph TD
    CR["ClientResources"] --> IO["I/O Thread Pool<br/>(default: availableProcessors)"]
    CR --> COMP["Computation Thread Pool<br/>(default: availableProcessors)"]
    CR --> EB["EventBus<br/>(connection/metrics events)"]
    CR --> DNS["DNS Resolver"]
    CR --> RD["Reconnect Delay<br/>(exponential backoff)"]
    CR --> TIMER["Timer<br/>(HashedWheelTimer)"]
```

### ClientOptions -- Connection Behavior

```java
ClientOptions options = ClientOptions.builder()
    .autoReconnect(true)                        // default: true
    .pingBeforeActivateConnection(true)         // verify connection on acquire
    .disconnectedBehavior(
        ClientOptions.DisconnectedBehavior.DEFAULT)  // buffer commands while disconnected
    .requestQueueSize(1000)                     // bound the queue (default: unbounded!)
    .socketOptions(SocketOptions.builder()
        .connectTimeout(Duration.ofSeconds(5))
        .keepAlive(true)
        .build())
    .timeoutOptions(
        TimeoutOptions.enabled(Duration.ofSeconds(5)))  // per-command timeout
    .build();

client.setOptions(options);
```

| Option | Default | Description |
|--------|---------|-------------|
| `autoReconnect` | `true` | Automatically reconnect on connection loss |
| `disconnectedBehavior` | `DEFAULT` | Buffer commands while disconnected; use `REJECT_COMMANDS` to fail fast |
| `requestQueueSize` | `Integer.MAX_VALUE` | Max queued commands -- **bound this in production** |
| `socketOptions.connectTimeout` | `10s` | TCP connect timeout |
| `timeoutOptions` | Disabled | Per-command timeout after dispatch |

---

## Pub/Sub

Lettuce provides a dedicated `StatefulRedisPubSubConnection` for Pub/Sub. This is a **separate** connection because a subscribed connection can only receive messages, not execute normal commands.

### Architecture

```mermaid
sequenceDiagram
    participant Publisher
    participant Redis as Redis / ValKey
    participant Sub1 as Subscriber 1
    participant Sub2 as Subscriber 2

    Sub1->>Redis: SUBSCRIBE "news"
    Sub2->>Redis: SUBSCRIBE "news"
    Publisher->>Redis: PUBLISH "news" "Breaking..."
    Redis-->>Sub1: message("news", "Breaking...")
    Redis-->>Sub2: message("news", "Breaking...")
```

### Subscribing with a Listener

```java
// Open a dedicated Pub/Sub connection
StatefulRedisPubSubConnection<String, String> pubSubConn = client.connectPubSub();

// Register a listener
pubSubConn.addListener(new RedisPubSubAdapter<String, String>() {
    @Override
    public void message(String channel, String message) {
        System.out.println("[" + channel + "] " + message);
    }

    @Override
    public void subscribed(String channel, long count) {
        System.out.println("Subscribed to " + channel);
    }
});

// Subscribe
pubSubConn.sync().subscribe("news", "alerts");
```

### Publishing

Use a **regular** connection (not the Pub/Sub connection) to publish:

```java
StatefulRedisConnection<String, String> conn = client.connect();
conn.sync().publish("news", "Breaking: Lettuce tutorial published!");
```

### Pattern Subscriptions

```java
pubSubConn.sync().psubscribe("user:*:notifications");
// Matches: user:123:notifications, user:456:notifications, etc.
```

### Reactive Pub/Sub

```java
RedisPubSubReactiveCommands<String, String> reactive = pubSubConn.reactive();

reactive.subscribe("news").subscribe();

reactive.observeChannels()
    .doOnNext(msg -> System.out.println(
        "[" + msg.getChannel() + "] " + msg.getMessage()))
    .subscribe();
```

### Lifecycle

Always clean up Pub/Sub resources:

```java
// Unsubscribe
pubSubConn.sync().unsubscribe("news", "alerts");

// Remove listener
pubSubConn.removeListener(myAdapter);

// Close the connection
pubSubConn.close();
```

---

## Pipelining and Transactions

### Pipelining

By default, Lettuce flushes every command immediately. For bulk operations, disable auto-flush and batch commands for significant throughput improvement:

```mermaid
sequenceDiagram
    participant App
    participant Lettuce
    participant Redis

    Note over App,Redis: Pipelining: batched flush
    App->>Lettuce: setAutoFlushCommands(false)
    App->>Lettuce: SET key1 val1
    App->>Lettuce: SET key2 val2
    App->>Lettuce: SET key3 val3
    App->>Lettuce: flushCommands()
    Lettuce->>Redis: SET key1 + SET key2 + SET key3
    Redis-->>Lettuce: OK, OK, OK
    Lettuce-->>App: futures complete
```

```java
RedisAsyncCommands<String, String> async = connection.async();

// Disable auto-flush
async.setAutoFlushCommands(false);

// Queue many commands
List<RedisFuture<?>> futures = new ArrayList<>();
for (int i = 0; i < 10_000; i++) {
    futures.add(async.set("key-" + i, "value-" + i));
}

// Flush them all at once
async.flushCommands();

// Wait for all to complete
LettuceFutures.awaitAll(Duration.ofSeconds(10),
    futures.toArray(new RedisFuture[0]));

// Re-enable auto-flush
async.setAutoFlushCommands(true);
```

**Warning:** Only use `setAutoFlushCommands(false)` in single-threaded scenarios. It affects all threads sharing the connection.

### Transactions (MULTI/EXEC)

Transactions group commands to execute atomically. Use a **dedicated connection** for transactions (not a shared one):

```java
RedisCommands<String, String> tx = connection.sync();

tx.multi();
tx.set("account:1:balance", "100");
tx.set("account:2:balance", "200");
TransactionResult result = tx.exec();
// result contains: ["OK", "OK"]
```

### Optimistic Locking with WATCH

```java
RedisCommands<String, String> cmd = connection.sync();

cmd.watch("balance");
String balance = cmd.get("balance");

int newBalance = Integer.parseInt(balance) - 50;
cmd.multi();
cmd.set("balance", String.valueOf(newBalance));
TransactionResult result = cmd.exec();
// result is null if "balance" was modified by another client between WATCH and EXEC
```

---

## High Availability: Sentinel and Cluster

### Redis Sentinel

Sentinel provides automatic failover. Lettuce discovers the current master from Sentinel nodes:

```java
RedisURI sentinelUri = RedisURI.Builder
    .sentinel("sentinel1.example.com", 26379, "mymaster")
    .withSentinel("sentinel2.example.com", 26379)
    .withSentinel("sentinel3.example.com", 26379)
    .build();

RedisClient client = RedisClient.create(sentinelUri);
StatefulRedisConnection<String, String> connection = client.connect();
// Lettuce auto-discovers the master and auto-fails-over
```

```mermaid
graph TB
    subgraph "Sentinel Cluster"
        S1["Sentinel 1"]
        S2["Sentinel 2"]
        S3["Sentinel 3"]
    end

    subgraph "Redis Instances"
        M["Master"]
        R1["Replica 1"]
        R2["Replica 2"]
    end

    S1 -.->|monitors| M
    S2 -.->|monitors| M
    S3 -.->|monitors| M
    M -->|replicates| R1
    M -->|replicates| R2

    APP["Lettuce Client"] -->|discovers master via| S1
    APP -->|connects to| M
```

### Read from Replicas

```java
StatefulRedisMasterReplicaConnection<String, String> connection =
    MasterReplica.connect(client, StringCodec.UTF8, sentinelUri);

// Route reads to replicas
connection.setReadFrom(ReadFrom.REPLICA_PREFERRED);
```

| ReadFrom | Behavior |
|----------|----------|
| `MASTER` | All reads from master (strongly consistent) |
| `MASTER_PREFERRED` | Master first, replica as fallback |
| `REPLICA` | Always read from replica |
| `REPLICA_PREFERRED` | Replica first, master as fallback |
| `LOWEST_LATENCY` | Lowest latency node |

### Redis Cluster

```java
RedisURI node1 = RedisURI.create("redis://cluster-node1:7000");
RedisURI node2 = RedisURI.create("redis://cluster-node2:7001");

RedisClusterClient clusterClient =
    RedisClusterClient.create(List.of(node1, node2));

// Enable topology refresh for failover
ClusterTopologyRefreshOptions topologyRefresh = ClusterTopologyRefreshOptions.builder()
    .enableAllAdaptiveRefreshTriggers()
    .enablePeriodicRefresh(Duration.ofMinutes(10))
    .build();

clusterClient.setOptions(ClusterClientOptions.builder()
    .topologyRefreshOptions(topologyRefresh)
    .build());

StatefulRedisClusterConnection<String, String> connection = clusterClient.connect();

// Commands are automatically routed to the correct node by hash slot
connection.sync().set("user:1", "Alice");
connection.sync().set("user:2", "Bob");

connection.close();
clusterClient.shutdown();
```

---

## Codecs and Custom Serialization

A `RedisCodec<K, V>` controls how keys and values are serialized to and from byte buffers on the wire.

### Built-in Codecs

| Codec | Key/Value Type | Use Case |
|-------|---------------|----------|
| `StringCodec.UTF8` | `String` / `String` | Default, general purpose |
| `StringCodec.ASCII` | `String` / `String` | ASCII-only optimization |
| `ByteArrayCodec.INSTANCE` | `byte[]` / `byte[]` | Raw binary data |

### Custom Codec: JSON with Jackson

```java
public class JsonCodec<T> implements RedisCodec<String, T> {
    private final ObjectMapper mapper = new ObjectMapper();
    private final Class<T> valueType;

    public JsonCodec(Class<T> valueType) {
        this.valueType = valueType;
    }

    @Override
    public String decodeKey(ByteBuffer bytes) {
        return StandardCharsets.UTF_8.decode(bytes).toString();
    }

    @Override
    public T decodeValue(ByteBuffer bytes) {
        try {
            byte[] array = new byte[bytes.remaining()];
            bytes.get(array);
            return mapper.readValue(array, valueType);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    @Override
    public ByteBuffer encodeKey(String key) {
        return StandardCharsets.UTF_8.encode(key);
    }

    @Override
    public ByteBuffer encodeValue(T value) {
        try {
            return ByteBuffer.wrap(mapper.writeValueAsBytes(value));
        } catch (JsonProcessingException e) {
            throw new UncheckedIOException(e);
        }
    }
}

// Usage
StatefulRedisConnection<String, User> connection =
    client.connect(new JsonCodec<>(User.class));

connection.sync().set("user:1", new User("Alice", "alice@example.com"));
User user = connection.sync().get("user:1");
```

### Codec Rules

1. **Thread-safety is mandatory.** Codecs are shared across all threads using the connection.
2. **Never throw exceptions from `encode` methods.** Encoding happens on the Netty event loop after protocol state is committed; an exception desynchronizes the command/response state.
3. **Consume ByteBuffers during decode.** The input buffer is backed by a Netty `ByteBuf` -- keeping a reference leads to corrupted data.

---

## How This Project Uses Lettuce

The Constants Catalog uses Lettuce to connect to **ValKey** (a Redis-compatible fork) for distributed configuration storage with Pub/Sub cache invalidation. Here's how the pieces fit together:

```mermaid
graph TB
    subgraph "Application Instance"
        SCS["SiteConfigurationService<br/>(lookup / store)"]
        CCL["ConfigurationChangeListener<br/>(Pub/Sub subscriber)"]
        CAFF["Caffeine Cache<br/>(local, in-memory)"]
    end

    subgraph "Lettuce Connections"
        SYNC_CONN["StatefulRedisConnection<br/>(sync read/write)"]
        PUBSUB_CONN["StatefulRedisPubSubConnection<br/>(subscribe to changes)"]
    end

    VALKEY[("ValKey<br/>(Redis-compatible)")]

    SCS --> CAFF
    SCS --> SYNC_CONN
    CCL --> PUBSUB_CONN
    CCL -->|invalidateLocal| CAFF
    SYNC_CONN --> VALKEY
    PUBSUB_CONN --> VALKEY
```

### ValKeyConfig: Client Setup

From `ValKeyConfig.java` -- shows the full Lettuce lifecycle configured as Spring beans:

```java
@Configuration
public class ValKeyConfig {

    @Value("${valkey.host:localhost}")
    private String valkeyHost;

    @Value("${valkey.port:6379}")
    private int valkeyPort;

    // Shared infrastructure resources (thread pools, timers)
    @Bean(destroyMethod = "shutdown")
    public ClientResources clientResources() {
        return DefaultClientResources.builder()
            .ioThreadPoolSize(4)
            .computationThreadPoolSize(4)
            .build();
    }

    // Connection URI with host, port, timeout
    @Bean
    public RedisURI redisUri() {
        return RedisURI.builder()
            .withHost(valkeyHost)
            .withPort(valkeyPort)
            .withDatabase(0)
            .withTimeout(Duration.ofMillis(5000))
            .build();
    }

    // The Lettuce client with auto-reconnect and ping-on-connect
    @Bean(destroyMethod = "shutdown")
    public RedisClient redisClient(ClientResources clientResources, RedisURI redisUri) {
        RedisClient client = RedisClient.create(clientResources, redisUri);
        client.setOptions(ClientOptions.builder()
            .autoReconnect(true)
            .pingBeforeActivateConnection(true)
            .build());
        return client;
    }

    // Main connection for read/write (thread-safe, shared)
    @Bean(destroyMethod = "close")
    @Primary
    public StatefulRedisConnection<String, String> redisConnection(RedisClient redisClient) {
        return redisClient.connect();
    }

    // Dedicated connection for Pub/Sub (separate because subscription mode)
    @Bean(destroyMethod = "close")
    public StatefulRedisPubSubConnection<String, String> redisPubSubConnection(
            RedisClient redisClient) {
        return redisClient.connectPubSub();
    }
}
```

Key points:
- **Two connections**: one for normal commands (`@Primary`), one for Pub/Sub
- **`destroyMethod`** on each bean ensures proper cleanup on application shutdown
- **`ClientResources` is shared** between both connections via the single `RedisClient`

### SiteConfigurationService: Cache-Aside Pattern

From `SiteConfigurationService.java` -- shows the sync command API used for reads and writes:

```java
@Service
public class SiteConfigurationService {

    private final StatefulRedisConnection<String, String> redisConnection;
    private RedisCommands<String, String> syncCommands;

    @PostConstruct
    void initialize() {
        this.syncCommands = redisConnection.sync();
    }

    // Read: Caffeine -> ValKey (cache-aside)
    public String lookup(String key) {
        return Optional.ofNullable(localCache.get(key, this::fetchFromValKey))
            .filter(v -> !NULL_SENTINEL.equals(v))
            .orElse(null);
    }

    private String fetchFromValKey(String key) {
        return syncCommands.get(CONFIG_KEY_PREFIX + key);
    }

    // Write: ValKey SET + PUBLISH change notification
    public void store(String key, String value) {
        syncCommands.set(CONFIG_KEY_PREFIX + key, value);
        publishChange(key);   // notify all instances
        localCache.put(key, value);
    }

    // Batch write: ValKey MSET
    public void storeBatch(Map<String, String> entries) {
        Map<String, String> prefixed = entries.entrySet().stream()
            .collect(Collectors.toMap(
                e -> CONFIG_KEY_PREFIX + e.getKey(),
                Map.Entry::getValue));
        syncCommands.mset(prefixed);
    }
}
```

### ConfigurationChangeListener: Pub/Sub Subscriber

From `ConfigurationChangeListener.java` -- shows the Pub/Sub listener pattern:

```java
@Component
public class ConfigurationChangeListener {

    private final StatefulRedisPubSubConnection<String, String> pubSubConnection;
    private final SiteConfigurationService configurationService;

    // Adapter handles incoming messages
    private final RedisPubSubAdapter<String, String> pubSubAdapter =
        new RedisPubSubAdapter<>() {
            @Override
            public void message(String channel, String message) {
                configurationService.invalidateLocal(message);
            }

            @Override
            public void subscribed(String channel, long count) {
                log.info("Subscribed to '{}', total: {}", channel, count);
            }
        };

    @PostConstruct
    void subscribe() {
        pubSubConnection.addListener(pubSubAdapter);
        pubSubConnection.sync().subscribe("config:changes");
    }

    @PreDestroy
    void unsubscribe() {
        pubSubConnection.sync().unsubscribe("config:changes");
        pubSubConnection.removeListener(pubSubAdapter);
    }
}
```

### The Flow: Write, Publish, Invalidate

```mermaid
sequenceDiagram
    participant App1 as Instance 1
    participant ValKey as ValKey
    participant App2 as Instance 2

    App1->>ValKey: SET config:db.host "new-host"
    App1->>ValKey: PUBLISH config:changes "db.host"
    App1->>App1: localCache.put("db.host", "new-host")

    ValKey-->>App2: MESSAGE config:changes "db.host"
    App2->>App2: localCache.invalidate("db.host")

    Note over App2: Next lookup("db.host")<br/>fetches fresh value from ValKey
```

---

## Best Practices

### 1. Configure Timeouts Explicitly

The default 60-second timeout is too long for most applications. Set it to match your SLA:

```java
RedisURI uri = RedisURI.Builder.redis("localhost")
    .withTimeout(Duration.ofSeconds(5))
    .build();
```

### 2. Bound the Request Queue

The default unbounded queue can cause OOM during prolonged disconnections:

```java
ClientOptions.builder()
    .requestQueueSize(1000)
    .disconnectedBehavior(ClientOptions.DisconnectedBehavior.REJECT_COMMANDS)
    .build();
```

### 3. Enable TCP Keep-Alive

Detect dead connections before commands time out:

```java
SocketOptions.builder()
    .connectTimeout(Duration.ofSeconds(5))
    .keepAlive(SocketOptions.KeepAliveOptions.builder()
        .enable()
        .idle(Duration.ofSeconds(5))
        .interval(Duration.ofSeconds(5))
        .count(3)
        .build())
    .build();
```

### 4. Share ClientResources

Create once, share across all `RedisClient` instances in the application:

```java
ClientResources shared = DefaultClientResources.builder()
    .ioThreadPoolSize(4)
    .computationThreadPoolSize(4)
    .build();

RedisClient client1 = RedisClient.create(shared, uri1);
RedisClient client2 = RedisClient.create(shared, uri2);
```

### 5. Use Separate Connections for Pub/Sub

Pub/Sub connections enter subscription mode and cannot execute normal commands:

```java
StatefulRedisConnection<String, String> dataConn = client.connect();
StatefulRedisPubSubConnection<String, String> pubSubConn = client.connectPubSub();
```

### 6. Shut Down Properly

Always shut down in order: connections, client, resources:

```java
connection.close();
client.shutdown();
resources.shutdown();  // only if externally created
```

### 7. Use Spring Bean Lifecycle

Let Spring manage the Lettuce lifecycle via `destroyMethod`:

```java
@Bean(destroyMethod = "close")
public StatefulRedisConnection<String, String> connection(RedisClient client) {
    return client.connect();
}

@Bean(destroyMethod = "shutdown")
public RedisClient redisClient() {
    return RedisClient.create("redis://localhost");
}
```

---

## Common Pitfalls

### Pitfall 1: Blocking the Netty Event Loop

```java
// BAD -- deadlocks the event loop!
async.get("key1").thenAccept(value -> {
    String other = connection.sync().get("key2"); // DEADLOCK
});

// GOOD -- chain async operations
async.get("key1")
    .thenCompose(value -> async.get("key2").toCompletableFuture())
    .thenAccept(other -> System.out.println(other));
```

### Pitfall 2: Transactions on a Shared Connection

`MULTI`/`EXEC` changes connection state. If multiple threads share the connection, commands from different threads interleave within the transaction. Use a **dedicated connection** or **connection pool** for transactions.

### Pitfall 3: Creating Connections Per Request

Lettuce connections are designed to be long-lived. Opening and closing per request wastes resources and defeats the purpose:

```java
// BAD
for (String key : keys) {
    StatefulRedisConnection<String, String> conn = client.connect();
    conn.sync().get(key);
    conn.close();
}

// GOOD
StatefulRedisConnection<String, String> conn = client.connect(); // once
for (String key : keys) {
    conn.sync().get(key);
}
```

### Pitfall 4: Ignoring Async Errors

Exceptions in `RedisFuture` are silently swallowed unless you handle them:

```java
async.set("key", "value")
    .exceptionally(ex -> {
        log.error("Redis SET failed", ex);
        return null;
    });
```

### Pitfall 5: setAutoFlushCommands(false) in Multi-Threaded Code

Disabling auto-flush affects **all threads** sharing the connection. Other threads' commands sit in the buffer until `flushCommands()` is called. Only use this for single-threaded bulk loading.

### Pitfall 6: Forgetting to Shut Down

Calling `connection.close()` but not `client.shutdown()` leaves Netty threads alive, preventing JVM shutdown:

```java
connection.close();
client.shutdown();      // don't forget this
resources.shutdown();   // and this, if externally created
```

### Troubleshooting Decision Tree

```mermaid
flowchart TD
    START["RedisCommandTimeoutException"] --> Q1{"Is Redis reachable?"}
    Q1 -->|No| A1["Check network,<br/>firewall, Redis status"]
    Q1 -->|Yes| Q2{"Slow command<br/>blocking server?"}
    Q2 -->|Yes| A2["Check SLOWLOG,<br/>avoid O(n) on large data"]
    Q2 -->|No| Q3{"Blocking the<br/>event loop?"}
    Q3 -->|Yes| A3["Never call sync()<br/>inside async callbacks"]
    Q3 -->|No| Q4{"Timeout too short?"}
    Q4 -->|Yes| A4["Increase timeout in<br/>RedisURI or ClientOptions"]
    Q4 -->|No| A5["Check queue size,<br/>network latency,<br/>codec performance"]
```

---

## Quick Reference

### Lifecycle

```mermaid
graph TD
    A["1. Create ClientResources<br/>(optional, share across clients)"] --> B["2. Create RedisClient"]
    B --> C["3. Set ClientOptions"]
    C --> D["4. Open Connection(s)"]
    D --> E["5. Get API: sync() / async() / reactive()"]
    E --> F["6. Execute Commands"]
    F --> G["7. Close Connection(s)"]
    G --> H["8. Shutdown Client"]
    H --> I["9. Shutdown ClientResources<br/>(if externally created)"]
```

### Command Cheat Sheet

| Operation | Sync | Async |
|-----------|------|-------|
| Set a value | `sync.set("k", "v")` | `async.set("k", "v")` |
| Get a value | `sync.get("k")` | `async.get("k")` |
| Delete | `sync.del("k1", "k2")` | `async.del("k1", "k2")` |
| Set with expiry | `sync.setex("k", 60, "v")` | `async.setex("k", 60, "v")` |
| Hash set | `sync.hset("h", "f", "v")` | `async.hset("h", "f", "v")` |
| Hash get all | `sync.hgetall("h")` | `async.hgetall("h")` |
| List push | `sync.rpush("l", "v1", "v2")` | `async.rpush("l", "v1", "v2")` |
| Publish | `sync.publish("ch", "msg")` | `async.publish("ch", "msg")` |
| Multi-set | `sync.mset(map)` | `async.mset(map)` |
| Keys by pattern | `sync.keys("prefix:*")` | `async.keys("prefix:*")` |
| Increment | `sync.incr("counter")` | `async.incr("counter")` |

### Additional Resources

- **Official Reference Guide:** https://redis.github.io/lettuce/
- **GitHub Repository:** https://github.com/redis/lettuce
- **Wiki (detailed topics):** https://github.com/lettuce-io/lettuce-core/wiki
- **Redis Client Guide:** https://redis.io/docs/latest/develop/clients/lettuce/
- **Baeldung Tutorial:** https://www.baeldung.com/java-redis-lettuce
