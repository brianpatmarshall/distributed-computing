# SseEmitter Diary

## What Problem Does SseEmitter Solve?

Picture this: a user kicks off a project scan that walks thousands of Java files, parses ASTs, and populates a graph database. That scan takes thirty seconds -- maybe two minutes on a large codebase. With a plain REST call the user stares at a spinner and wonders whether the system is working, hung, or just slow. With **Server-Sent Events (SSE)** the browser receives a stream of progress updates as each file is processed, turning a black box into a live dashboard.

`SseEmitter` is Spring's server-side handle for an SSE connection. You create one in a controller, hand it to an asynchronous service, and the service pushes events through it until the work is done. The browser subscribes with the standard `EventSource` API -- no WebSocket handshake, no STOMP broker, no extra dependency. It is HTTP, it is one-directional (server to client), and it simply works.

---

## Why SseEmitter Over the Alternatives?

| Approach | Direction | Complexity | When to Choose |
|----------|-----------|------------|----------------|
| **Polling** | Client &rarr; Server (repeated) | Low | Coarse-grained status where slight delay is acceptable. |
| **Long Polling** | Client &rarr; Server (held open) | Medium | Environments that block SSE (some corporate proxies). |
| **SSE / SseEmitter** | Server &rarr; Client (one-way stream) | Low | Real-time progress, logs, notifications -- anything where only the server talks. |
| **WebSocket** | Bidirectional | High | Chat, collaborative editing, gaming -- anything where the client and server both need to send messages continuously. |

SSE is the sweet spot when you need push without pull. It rides on plain HTTP, reconnects automatically, and Spring's `SseEmitter` integrates with the Servlet 3.1 async model out of the box. No extra dependencies, no message broker, no protocol upgrade.

---

## How It Works Under the Hood

```mermaid
sequenceDiagram
    participant Browser
    participant Controller
    participant AsyncService
    participant Scanner

    Browser->>Controller: GET /api/scan/stream?projectPath=...
    Controller->>Controller: new SseEmitter(600_000L)
    Controller->>AsyncService: scanProjectWithProgress(request, emitter, objectMapper)
    Controller-->>Browser: return emitter (HTTP 200, Content-Type: text/event-stream)

    Note over AsyncService: Runs on @Async thread pool

    loop For each file
        Scanner->>AsyncService: onProgress(fileName, index, total, ...)
        AsyncService->>Browser: emitter.send(event: "progress", data: JSON)
    end

    AsyncService->>Browser: emitter.send(event: "complete", data: JSON)
    AsyncService->>AsyncService: emitter.complete()
    Note over Browser: EventSource fires "complete" listener, connection closes
```

Three moving parts:

1. **Controller** -- Creates the `SseEmitter`, starts the async work, and returns the emitter immediately. The Servlet container keeps the HTTP response open.
2. **Async Service** -- Runs on a separate thread (Spring `@Async`). Calls `emitter.send()` as work progresses. Calls `emitter.complete()` when done.
3. **Browser** -- Opens an `EventSource`, listens for named events (`progress`, `complete`, `error`), and updates the UI.

---

## SseEmitter Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Created: new SseEmitter(timeout)
    Created --> Streaming: First send()
    Streaming --> Streaming: send() events
    Streaming --> Completed: complete()
    Streaming --> Error: completeWithError(e)
    Streaming --> TimedOut: Timeout elapsed
    Streaming --> ClientGone: Client disconnects
    Completed --> [*]
    Error --> [*]
    TimedOut --> [*]
    ClientGone --> [*]
```

| State | Trigger | What Happens |
|-------|---------|-------------|
| **Created** | `new SseEmitter(timeout)` | Emitter exists but no data has been sent. The Servlet async context is started. |
| **Streaming** | `emitter.send(...)` | Events flow to the client. Each `send()` writes to the HTTP output stream. |
| **Completed** | `emitter.complete()` | Server signals end-of-stream. The connection closes cleanly. |
| **Error** | `emitter.completeWithError(e)` | Server signals an error. Spring invokes the error callback. Connection closes. |
| **Timed Out** | Timeout elapsed | Spring invokes the timeout callback. The Servlet container closes the response. |
| **Client Gone** | Client disconnects | Next `send()` throws `IOException`. Your code should catch it gracefully. |

---

## Anatomy of This Project's Implementation

### The DTO -- A Lombok Record-Style Builder

```java
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Scan progress event streamed via SSE")
public class ScanProgressEvent {

    public enum EventType {
        FILE_DISCOVERED, FILE_PARSING, FILE_PARSED, SCAN_COMPLETE, ERROR
    }

    private EventType eventType;
    private String fileName;
    private String filePath;
    private int fileIndex;
    private int totalFiles;
    private int constantsFound;
    private int parametersFound;
    private LocalDateTime timestamp;
}
```

Lombok's `@Builder` gives us a fluent, immutable-feeling API for constructing events without hand-writing a dozen overloaded constructors. The `@Schema` annotations feed SpringDoc so the OpenAPI spec documents the SSE payload automatically.

### The Controller -- Minimal, Focused

```java
@GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public SseEmitter streamScan(@RequestParam String projectPath) {
    var emitter = new SseEmitter(600_000L);

    log.info("SSE scan stream requested for: {}", projectPath);

    scanService.scanProjectWithProgress(
        new ScanRequest(projectPath), emitter, objectMapper
    );

    return emitter;
}
```

The controller does exactly three things: create the emitter, kick off the async work, and return. It does **not** loop, wait, or block. The Servlet container keeps the response open because `SseEmitter` implements `ResponseBodyEmitter`, which plugs into Servlet 3.1 async processing.

### The Service -- Where the Work Happens

```java
@Async
public void scanProjectWithProgress(ScanRequest request, SseEmitter emitter,
                                     ObjectMapper objectMapper) {
    Path projectPath = Paths.get(request.getProjectPath()).toAbsolutePath();

    try {
        validateProjectPath(projectPath);

        ProjectScanner.ScanProgressListener listener =
            (fileName, filePath, fileIndex, totalFiles, constantsFound, parametersFound) -> {
                try {
                    var event = ScanProgressEvent.builder()
                        .eventType(ScanProgressEvent.EventType.FILE_PARSING)
                        .fileName(fileName).filePath(filePath)
                        .fileIndex(fileIndex).totalFiles(totalFiles)
                        .constantsFound(constantsFound).parametersFound(parametersFound)
                        .timestamp(LocalDateTime.now())
                        .build();

                    emitter.send(SseEmitter.event()
                        .name("progress")
                        .data(objectMapper.writeValueAsString(event)));
                } catch (Exception e) {
                    log.debug("Failed to send SSE event: {}", e.getMessage());
                }
            };

        var scanResult = projectScanner.scan(projectPath, listener);
        graphPopulator.populateGraph(projectPath.toString(),
                                      extractProjectName(projectPath), scanResult);

        emitter.send(SseEmitter.event()
            .name("complete")
            .data(objectMapper.writeValueAsString(/* completion event */)));
        emitter.complete();

    } catch (Exception e) {
        log.error("SSE scan failed for project: {}", projectPath, e);
        emitter.completeWithError(e);
    }
}
```

Key decisions:

- **`@Async`** -- Frees the Servlet thread immediately. The work runs on Spring's async executor.
- **Lambda listener** -- The core scanner calls back for each file. The listener adapts that callback into an SSE event. This is a functional seam: scanning knows nothing about HTTP.
- **Swallowed `send()` exceptions** -- If the client disconnects mid-scan, the `send()` throws. We log at `DEBUG` and keep scanning. The scan result still populates the graph even if nobody is watching.
- **`completeWithError(e)`** -- Signals the container that the async operation failed.

---

## The Browser Side -- EventSource

```javascript
function startScan(projectPath) {
    const source = new EventSource(
        `/api/scan/stream?projectPath=${encodeURIComponent(projectPath)}`
    );

    source.addEventListener("progress", (e) => {
        const event = JSON.parse(e.data);
        updateProgressBar(event.fileIndex, event.totalFiles);
        updateFileLabel(event.fileName);
    });

    source.addEventListener("complete", (e) => {
        const event = JSON.parse(e.data);
        showCompletionSummary(event);
        source.close();
    });

    source.addEventListener("error", (e) => {
        showErrorBanner("Scan failed. Check server logs.");
        source.close();
    });
}
```

`EventSource` automatically reconnects on transient network failures. Closing it explicitly on `"complete"` or `"error"` prevents unwanted reconnection when the stream is truly finished.

---

## Best Practices

### 1. Always Set a Timeout

```java
var emitter = new SseEmitter(600_000L); // 10 minutes
```

The default timeout is **30 seconds** (container-dependent). For long-running operations that is almost certainly too short. Set it to the maximum realistic duration of the work plus a margin.

### 2. Register Lifecycle Callbacks

```java
emitter.onCompletion(() -> log.info("SSE stream completed"));
emitter.onTimeout(()   -> log.warn("SSE stream timed out"));
emitter.onError(e      -> log.error("SSE stream error", e));
```

These callbacks run on the Servlet container's thread when the corresponding event fires. They are your cleanup hook -- cancel background tasks, release resources, remove the emitter from a registry.

### 3. Guard Every `send()` Call

```java
try {
    emitter.send(SseEmitter.event().name("progress").data(payload));
} catch (IOException e) {
    log.debug("Client disconnected: {}", e.getMessage());
    // Do NOT rethrow -- let the scan continue.
}
```

A disconnected client causes `send()` to throw. If you let it propagate, you kill the async task. Swallow it (or log at `DEBUG`) and keep working if the side effects (graph population) are still valuable.

### 4. Use Named Events

```java
emitter.send(SseEmitter.event()
    .name("progress")      // <-- named event
    .data(json));
```

Named events let the browser discriminate with `addEventListener("progress", ...)` instead of using the generic `onmessage`. This is cleaner and less error-prone.

### 5. Serialize Explicitly

Jackson's `ObjectMapper` gives you control over date formats, null handling, and field naming. Passing it through from the controller (where Spring configures it) ensures your SSE payloads are serialized with the same settings as normal REST responses.

### 6. Keep the Controller Thin

The controller's job is to create the emitter and start the work. All logic -- validation, scanning, event building, error handling -- belongs in the service. This keeps the controller testable with MockMvc and the service testable with plain JUnit.

### 7. Thread Pool Sizing

Spring's default `@Async` executor is a `SimpleAsyncTaskExecutor` that creates a new thread per invocation. For production, configure a bounded thread pool:

```java
@Configuration
@EnableAsync
public class AsyncConfig {

    @Bean
    public TaskExecutor sseTaskExecutor() {
        var executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(8);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("sse-scan-");
        return executor;
    }
}
```

Then reference it by name:

```java
@Async("sseTaskExecutor")
public void scanProjectWithProgress(...) { ... }
```

### 8. Heartbeats for Long Silences

If the work has long gaps between events (database writes, network calls), the client or a proxy may assume the connection is dead. Send periodic heartbeats:

```java
emitter.send(SseEmitter.event().comment("heartbeat"));
```

SSE comments (lines starting with `:`) are ignored by `EventSource` listeners but keep the TCP connection alive.

---

## The Functional Style -- Java 21 Patterns

The listener lambda in the service is already functional, but we can push further.

### Sealed Event Hierarchy (Alternative to Enum + Builder)

```java
public sealed interface ScanEvent permits ScanEvent.Progress, ScanEvent.Complete, ScanEvent.Error {

    LocalDateTime timestamp();

    record Progress(
        String fileName, String filePath,
        int fileIndex, int totalFiles,
        int constantsFound, int parametersFound,
        LocalDateTime timestamp
    ) implements ScanEvent {}

    record Complete(
        int totalFiles, int constantsFound, int parametersFound,
        LocalDateTime timestamp
    ) implements ScanEvent {}

    record Error(
        String message, LocalDateTime timestamp
    ) implements ScanEvent {}
}
```

With pattern matching you dispatch on the event type without casts or `instanceof` chains:

```java
private String eventName(ScanEvent event) {
    return switch (event) {
        case ScanEvent.Progress _ -> "progress";
        case ScanEvent.Complete _ -> "complete";
        case ScanEvent.Error _    -> "error";
    };
}
```

### Functional Listener with Consumer

Instead of a custom `@FunctionalInterface`, accept a `Consumer<ScanEvent>`:

```java
public ScanResult scan(Path root, Consumer<ScanEvent> onEvent) throws IOException {
    // ... inside the file loop:
    onEvent.accept(new ScanEvent.Progress(
        file.getName(), file.getPath(),
        index, total, constants, params,
        LocalDateTime.now()
    ));
}
```

The service wires it to the emitter:

```java
Consumer<ScanEvent> ssePublisher = event -> {
    try {
        emitter.send(SseEmitter.event()
            .name(eventName(event))
            .data(objectMapper.writeValueAsString(event)));
    } catch (Exception e) {
        log.debug("SSE send failed: {}", e.getMessage());
    }
};

var result = projectScanner.scan(projectPath, ssePublisher);
```

This approach eliminates the six-argument callback in favor of a single typed object. The sealed interface guarantees exhaustiveness in every `switch`.

---

## Complete Sample -- Standalone SSE Endpoint

A minimal working example you can drop into any Spring Boot 3.x / Java 21 project:

```java
@RestController
@RequestMapping("/api/tasks")
@RequiredArgsConstructor
@Slf4j
public class TaskStreamController {

    private final TaskExecutor sseTaskExecutor;
    private final ObjectMapper objectMapper;

    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter streamTask(@RequestParam String taskId) {

        var emitter = new SseEmitter(300_000L); // 5 minutes

        emitter.onCompletion(() -> log.info("Stream completed for task {}", taskId));
        emitter.onTimeout(()   -> log.warn("Stream timed out for task {}", taskId));
        emitter.onError(e      -> log.error("Stream error for task {}", taskId, e));

        sseTaskExecutor.execute(() -> executeAndStream(taskId, emitter));

        return emitter;
    }

    private void executeAndStream(String taskId, SseEmitter emitter) {
        try {
            var steps = List.of("Validating", "Processing", "Persisting", "Indexing");

            for (int i = 0; i < steps.size(); i++) {
                // Simulate work
                Thread.sleep(1_000);

                var payload = Map.of(
                    "step",    steps.get(i),
                    "current", i + 1,
                    "total",   steps.size()
                );

                emitter.send(SseEmitter.event()
                    .name("progress")
                    .data(objectMapper.writeValueAsString(payload)));
            }

            emitter.send(SseEmitter.event()
                .name("complete")
                .data("{\"status\": \"done\"}"));
            emitter.complete();

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            emitter.completeWithError(e);
        } catch (Exception e) {
            log.error("Task {} failed", taskId, e);
            emitter.completeWithError(e);
        }
    }
}
```

Pair it with a matching `EventSource` on the client:

```javascript
const source = new EventSource("/api/tasks/stream?taskId=42");

source.addEventListener("progress", (e) => {
    const { step, current, total } = JSON.parse(e.data);
    console.log(`[${current}/${total}] ${step}`);
});

source.addEventListener("complete", () => {
    console.log("Done.");
    source.close();
});

source.onerror = () => {
    console.error("Connection lost.");
    source.close();
};
```

---

## Architecture at a Glance

```mermaid
graph LR
    subgraph Browser
        ES[EventSource]
    end

    subgraph Spring Boot
        C[ScanController]
        S[ScanService @Async]
        E[SseEmitter]
    end

    subgraph Core
        PS[ProjectScanner]
    end

    subgraph Data
        N[(Neo4j)]
    end

    ES -- "GET /api/scan/stream" --> C
    C -- "creates" --> E
    C -- "starts async" --> S
    S -- "scan(path, listener)" --> PS
    PS -- "onProgress()" --> S
    S -- "emitter.send()" --> E
    E -- "text/event-stream" --> ES
    S -- "populateGraph()" --> N
```

---

## Common Pitfalls

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| Forgetting `@EnableAsync` | `@Async` methods run synchronously; emitter is returned **after** all work is done. No streaming. | Add `@EnableAsync` to a `@Configuration` class. |
| Default timeout too short | Stream cuts off mid-operation. Browser shows error. | Set an explicit timeout: `new SseEmitter(600_000L)`. |
| Unguarded `send()` | Client disconnect kills the async task with an `IOException`. | Wrap every `send()` in a try/catch. Log at `DEBUG`. |
| Returning `void` from the controller | Spring does not know the response is async; the container closes it immediately. | Return the `SseEmitter` instance. |
| Calling `emitter.complete()` twice | `IllegalStateException` at runtime. | Track completion state, or structure your code so `complete()` is called in exactly one place. |
| Proxy buffering | Nginx or a reverse proxy buffers the response, delivering all events at once. | Add `X-Accel-Buffering: no` header, or configure `proxy_buffering off` in Nginx. |
| CORS blocking EventSource | Browser refuses the SSE connection from a different origin. | Configure CORS on the SSE endpoint the same as any other API endpoint. |

---

## Testing SseEmitter Endpoints

### Integration Test with MockMvc

```java
@WebMvcTest(ScanController.class)
class ScanControllerTest {

    @Autowired MockMvc mockMvc;
    @MockBean ScanService scanService;

    @Test
    void streamEndpointReturnsSseContentType() throws Exception {
        mockMvc.perform(get("/api/scan/stream")
                .param("projectPath", "/tmp/test-project"))
            .andExpect(status().isOk())
            .andExpect(header().string("Content-Type",
                containsString("text/event-stream")));
    }
}
```

### Unit Test with SseEmitter Directly

```java
@Test
void serviceSendsProgressAndCompleteEvents() throws Exception {
    var emitter = new SseEmitter(10_000L);
    var events = new CopyOnWriteArrayList<String>();

    // Capture what gets sent
    emitter.onCompletion(() -> events.add("COMPLETED"));

    scanService.scanProjectWithProgress(
        new ScanRequest("/path/to/project"), emitter, new ObjectMapper()
    );

    // Wait for async completion, then assert events were sent
    // (In practice, use Awaitility or a CountDownLatch)
}
```

---

## Summary

`SseEmitter` gives you server-push over plain HTTP with zero extra dependencies in a Spring Boot application. It plugs into Servlet async processing, pairs naturally with `@Async` services, and the browser's `EventSource` API handles reconnection automatically.

**Use it when:**
- The server has progress to report (scans, builds, imports, batch jobs).
- Communication is one-directional (server &rarr; client).
- You want the simplest possible infrastructure.

**Do not use it when:**
- The client needs to send messages back (use WebSocket).
- You need pub/sub fan-out to many clients (use a message broker + WebSocket/STOMP).
- The environment blocks HTTP streaming (fall back to polling).

In this project, `SseEmitter` turns a minutes-long project scan into a live, file-by-file progress stream -- and the implementation fits in under 80 lines of service code.
