# Working with SSE

A practical guide to Server-Sent Events as used in the Constants Catalog project. Contains recipes for common patterns and problems.

---

## Table of Contents

1. [What Is SSE?](#1-what-is-sse)
2. [How SSE Works](#2-how-sse-works)
3. [SSE in This Project](#3-sse-in-this-project)
4. [Recipe: Disable a Button Immediately on Click](#4-recipe-disable-a-button-immediately-on-click)
5. [Recipe: Show a Status Message During a Silent Phase](#5-recipe-show-a-status-message-during-a-silent-phase)
6. [Recipe: Configure Timeouts for Long-Running Scans](#6-recipe-configure-timeouts-for-long-running-scans)
7. [Recipe: Debug SSE Problems](#7-recipe-debug-sse-problems)

---

## 1. What Is SSE?

**SSE** stands for **Server-Sent Events**. It's a standard HTTP protocol for streaming events from a server to a browser over a single, long-lived connection.

```mermaid
sequenceDiagram
    participant Browser
    participant Server

    Browser->>Server: GET /api/scan/stream (Accept: text/event-stream)
    Server-->>Browser: HTTP 200 (Content-Type: text/event-stream)

    loop For each file parsed
        Server-->>Browser: event: progress<br/>data: {"fileIndex":1,"totalFiles":50}
    end

    Server-->>Browser: event: complete<br/>data: {"constantsFound":127}
    Note over Browser,Server: Connection closes
```

Key characteristics:

| Feature | SSE |
|---|---|
| Direction | Server → Browser only (one-way) |
| Protocol | Plain HTTP (no upgrade handshake) |
| Reconnection | Automatic (browser reconnects if connection drops) |
| Data format | Text only (we use JSON) |
| Browser API | `EventSource` — built into every modern browser |
| Proxy support | Works through any HTTP proxy (with buffering disabled) |

### When to Use SSE

SSE is the right choice when:
- The server needs to push updates to the client
- The client doesn't need to send messages back during the stream
- You want simplicity — no WebSocket upgrade, no library, just HTTP

In this project, SSE streams real-time scan progress: file names, counts, and a completion signal.

---

## 2. How SSE Works

### The Wire Protocol

SSE uses a simple text format. The server sends events separated by blank lines:

```
event: progress
data: {"fileIndex":1,"totalFiles":50,"fileName":"Config.java"}

event: progress
data: {"fileIndex":2,"totalFiles":50,"fileName":"Service.java"}

event: complete
data: {"constantsFound":127,"parametersFound":45}

```

Each event has:
- `event:` — A name (optional). The browser can listen for specific names.
- `data:` — The payload. Can be any text; we use JSON.
- A blank line — Separates events.

### The Browser API

```javascript
const eventSource = new EventSource('/api/scan/stream?projectPath=/src/myproject');

eventSource.addEventListener('progress', (event) => {
    const data = JSON.parse(event.data);
    console.log(`File ${data.fileIndex} of ${data.totalFiles}`);
});

eventSource.addEventListener('complete', (event) => {
    const data = JSON.parse(event.data);
    console.log(`Done: ${data.constantsFound} constants found`);
    eventSource.close();
});

eventSource.onerror = () => {
    eventSource.close();
};
```

### The Spring Boot Side

```java
@GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public SseEmitter streamScan(@RequestParam("projectPath") String projectPath) {
    SseEmitter emitter = new SseEmitter(3_600_000L); // 1 hour timeout

    // Run scan on async thread — returns immediately
    scanService.scanProjectWithProgress(new ScanRequest(projectPath), emitter, objectMapper);

    return emitter; // Spring holds the HTTP connection open
}
```

The `SseEmitter` is thread-safe. The controller returns it immediately; the async scan thread calls `emitter.send()` to push events as they happen.

### The Proxy Layer (nginx)

SSE requires `proxy_buffering off` in nginx. Without it, events accumulate in a buffer and the browser receives nothing until the buffer fills:

```nginx
location /api/scan/stream {
    proxy_pass http://backend:8080/api/scan/stream;
    proxy_buffering off;
    proxy_cache off;
    gzip off;
    proxy_set_header Connection '';
    proxy_read_timeout 3600s;
}
```

---

## 3. SSE in This Project

### Architecture

```mermaid
flowchart LR
    subgraph Browser
        ES["EventSource"]
        Hook["useScanProgress"]
        Page["ScanPage.tsx"]
    end

    subgraph nginx
        PROXY["proxy_buffering off"]
    end

    subgraph "Spring Boot"
        CTRL["ScanController"]
        SVC["ScanService @Async"]
        SCAN["ProjectScanner"]
    end

    Page -->|startStreaming| Hook
    Hook -->|"new EventSource(url)"| ES
    ES <-->|HTTP SSE| PROXY
    PROXY <-->|proxy_pass| CTRL
    CTRL -->|"return SseEmitter"| SVC
    SVC -->|"scan with listener"| SCAN
    SCAN -->|"onProgress callback"| SVC
    SVC -->|"emitter.send(event)"| CTRL
```

### Data Flow Per Event

```mermaid
sequenceDiagram
    participant Scanner as ProjectScanner
    participant Service as ScanService
    participant Emitter as SseEmitter
    participant nginx
    participant ES as EventSource
    participant Hook as useScanProgress
    participant UI as ScanPage

    Scanner->>Service: onProgress("Config.java", 5, 50, 12, 3)
    Service->>Service: Build ScanProgressEvent
    Service->>Service: Serialize to JSON
    Service->>Emitter: send(event().name("progress").data(json))
    Emitter->>nginx: event: progress\ndata: {...}\n\n
    nginx->>ES: Forward immediately (no buffering)
    ES->>Hook: 'progress' event listener fires
    Hook->>Hook: JSON.parse(event.data)
    Hook->>Hook: setCurrentEvent(data)
    Hook->>UI: React re-render
    UI->>UI: Update progress bar, file list
```

---

## 4. Recipe: Disable a Button Immediately on Click

### The Problem

When the user clicks "Scan Project" with SSE enabled, the button should disable immediately. But the `isConnected` flag from the `useScanProgress` hook only becomes `true` when the `EventSource.onopen` event fires — which happens after the HTTP connection is established. For large projects, the backend spends seconds walking the file tree before the connection opens. During that gap, the button stays enabled.

```mermaid
sequenceDiagram
    participant User
    participant Button
    participant EventSource
    participant Backend

    User->>Button: Click
    Note over Button: ❌ Button still enabled!
    Button->>EventSource: new EventSource(url)
    EventSource->>Backend: GET /api/scan/stream
    Backend->>Backend: Walk file tree (takes seconds)
    Backend-->>EventSource: 200 OK, text/event-stream
    EventSource->>EventSource: onopen fires
    Note over Button: ✅ isConnected = true, button finally disabled
```

### The Fix

Add an `isStarting` state that becomes `true` on click — before the EventSource is even created:

```mermaid
sequenceDiagram
    participant User
    participant Button
    participant EventSource
    participant Backend

    User->>Button: Click
    Note over Button: ✅ isStarting = true — disabled immediately
    Button->>EventSource: new EventSource(url)
    EventSource->>Backend: GET /api/scan/stream
    Backend->>Backend: Walk file tree
    Backend-->>EventSource: 200 OK
    EventSource->>EventSource: onopen fires
    Note over Button: isConnected = true, isStarting cleared
```

### The Code

**Step 1: Add `isStarting` state**

```tsx
const [isStarting, setIsStarting] = useState(false)

// Clear isStarting once the SSE connection is established or scan completes
useEffect(() => {
    if (isConnected || isComplete) {
        setIsStarting(false)
    }
}, [isConnected, isComplete])
```

**Step 2: Set it on click**

```tsx
const handleScan = (e: React.FormEvent) => {
    e.preventDefault()
    if (!projectPath.trim()) return
    setScanResult(null)
    setIsStarting(true)  // ← Immediately disables button

    if (watchProgress) {
        startStreaming(projectPath.trim())
    } else {
        scanMutation.mutate({ projectPath: projectPath.trim() })
    }
}
```

**Step 3: Wire the button**

```tsx
<button
  disabled={scanMutation.isPending || isStarting || isConnected || !projectPath.trim()}
>
  {(scanMutation.isPending || isStarting || isConnected) ? (
    <><Loader2 className="animate-spin" /> Scanning...</>
  ) : (
    <><Play /> Scan Project</>
  )}
</button>
```

### Timeline After Fix

| Event | `isStarting` | `isConnected` | Button |
|---|---|---|---|
| User clicks | `true` | `false` | **Disabled** (via isStarting) |
| EventSource opens | `false` | `true` | **Disabled** (via isConnected) |
| Events stream | `false` | `true` | **Disabled** |
| Scan completes | `false` | `false` | **Enabled** |

No gap. The button disables on the same React render as the click handler.

### Why Not Just Use `isConnected`?

`isConnected` is managed by the `useScanProgress` hook, which sets it inside the `EventSource.onopen` callback. This is asynchronous — it doesn't happen during the click handler. React batches state updates, but the EventSource connection takes real time (network round-trip + backend processing). The user can click the button multiple times during that window.

`isStarting` is set synchronously in the click handler — same render, no gap.

---

## 5. Recipe: Show a Status Message During a Silent Phase

### The Problem

The scan has two phases:
1. **File parsing** — SSE events stream for every file. The user sees the progress bar and file list.
2. **Graph population** — Writing to Neo4j. No events. The spinner keeps going but the UI looks frozen.

### The Fix

Send a special progress event between phases:

**Backend** (`ScanService.java`):

```java
// After parsing, before graph population
ScanProgressEvent graphEvent = ScanProgressEvent.builder()
    .eventType(ScanProgressEvent.EventType.FILE_PARSED)
    .fileName("Populating graph database...")
    .constantsFound(scanResult.constants().size())
    .parametersFound(scanResult.parameters().size())
    .build();
emitter.send(SseEmitter.event().name("progress").data(...));

// Then graph population starts (silent)
graphPopulator.populateGraph(...);
```

**Frontend** (`ScanPage.tsx`):

```tsx
<div className="text-neon-cyan font-medium">
  {currentEvent?.fileName?.startsWith('Populating')
    ? 'Populating graph database...'
    : 'Scanning in progress...'}
</div>
{currentEvent && (
  <div className="text-terminal-dim text-sm mt-1">
    {currentEvent.fileName?.startsWith('Populating')
      ? `${currentEvent.constantsFound} constants, ${currentEvent.parametersFound} parameters being written to Neo4j`
      : `File ${currentEvent.fileIndex} of ${currentEvent.totalFiles} | ${currentEvent.constantsFound} constants, ${currentEvent.parametersFound} parameters found`}
  </div>
)}
```

### What the User Sees

```mermaid
flowchart TD
    A["Phase 1: Scanning in progress...<br/>File 523 of 2000<br/>145 constants, 30 parameters found<br/>▓▓▓▓▓▓▓░░░░ 26%"] --> B["Phase 1 complete<br/>File 2000 of 2000<br/>▓▓▓▓▓▓▓▓▓▓▓ 100%"]
    B --> C["Phase 2: Populating graph database...<br/>892 constants, 245 parameters<br/>being written to Neo4j"]
    C --> D["Scan Completed Successfully<br/>Results panel appears"]

    style A fill:#4488ff,color:#fff
    style C fill:#ff8844,color:#fff
    style D fill:#44aa44,color:#fff
```

---

## 6. Recipe: Configure Timeouts for Long-Running Scans

### The Problem

Three timeouts must agree, or the connection dies mid-scan:

```mermaid
flowchart LR
    A["SseEmitter<br/>timeout"] --> B["nginx<br/>proxy_read_timeout"]
    B --> C["EventSource<br/>(browser, no timeout)"]

    style A fill:#ff8844,color:#fff
    style B fill:#009639,color:#fff
    style C fill:#61dafb,color:#000
```

If nginx's timeout is shorter than the emitter's, nginx closes the connection first and the browser sees an error.

### The Fix

Set both to the same value (currently 1 hour):

**nginx** (`const-catalog-frontend/nginx.conf`):

```nginx
location /api/scan/stream {
    proxy_read_timeout 3600s;  # 1 hour
}
```

**Spring Boot** (`ScanController.java`):

```java
SseEmitter emitter = new SseEmitter(3_600_000L);  // 1 hour in milliseconds
```

### Which Timeout Fires?

| Scenario | What happens |
|---|---|
| nginx timeout < emitter timeout | nginx closes first → browser gets error → emitter is orphaned |
| nginx timeout > emitter timeout | Emitter closes first → Spring sends error → nginx forwards it → browser handles it cleanly |
| nginx timeout == emitter timeout | Either could fire first. Safe because both result in connection close. |

**Best practice:** Set them equal. The `proxy_read_timeout` counts time between receiving data, not total connection time. Since progress events stream every few seconds during parsing, the timeout only matters during the silent graph population phase.

---

## 7. Recipe: Debug SSE Problems

### Symptom: No progress events at all

```mermaid
flowchart TD
    A["No events in browser"] --> B["Check Network tab"]
    B --> C{stream request<br/>visible?}
    C -->|No| D["Frontend not sending request.<br/>Check handleScan and startStreaming."]
    C -->|Yes| E{Status code?}
    E -->|200| F["Check EventSource tab<br/>in Network for messages"]
    E -->|500| G["Backend error.<br/>Check: docker logs backend"]
    E -->|Red/failed| H["Connection failed.<br/>Check nginx config."]
    F --> I{Messages arriving?}
    I -->|Yes| J["Frontend not processing them.<br/>Check useScanProgress hook."]
    I -->|No| K["Backend not sending.<br/>Check @EnableAsync, @RequestParam."]

    style D fill:#ff4444,color:#fff
    style G fill:#ff4444,color:#fff
    style H fill:#ff4444,color:#fff
    style J fill:#ff4444,color:#fff
    style K fill:#ff4444,color:#fff
```

### Symptom: Events stop mid-scan

| Possible cause | How to check | Fix |
|---|---|---|
| nginx timeout | `docker logs` shows no error; browser shows connection closed | Increase `proxy_read_timeout` |
| SseEmitter timeout | Backend logs: "AsyncRequestTimeoutException" | Increase `new SseEmitter(timeout)` |
| nginx buffering | Events arrive in bursts, not real-time | Add `proxy_buffering off` |
| Backend exception | Events stop, then error event arrives | Check `docker logs backend` for stack trace |

### Symptom: Button doesn't disable

| Possible cause | How to check | Fix |
|---|---|---|
| Missing `isStarting` state | Button stays enabled for 1-2 seconds after click | Add `isStarting` pattern (Recipe 4) |
| Only checking `isPending` | Button works for POST but not SSE | Add `isConnected` to disabled check |
| Only checking `isConnected` | Button works for SSE but not POST | Add `isPending` to disabled check |

### Quick Diagnostic Commands

```bash
# Test SSE directly, bypassing frontend and nginx
curl -N http://localhost:9090/api/scan/stream?projectPath=/src/myproject

# Test through nginx
curl -N http://localhost:3001/api/scan/stream?projectPath=/src/myproject

# Check backend logs
docker logs const-catalog-backend --tail 50

# Check if @EnableAsync is active
docker logs const-catalog-backend 2>&1 | grep -i "async\|EnableAsync"

# Check nginx config
docker exec const-catalog-frontend cat /etc/nginx/conf.d/default.conf
```
