# Maintainer's Diary: Constants Catalog

## What Is This Application?

If you have ever inherited a large Java codebase, you know the feeling: somewhere deep in the source tree, somebody wrote `private static final String DB_HOST = "prod-db-03.internal"` and went on vacation. Three years later, that server name has migrated twice, the constant is still there, and nobody is quite sure which services still reference it.

The Constants Catalog exists to answer that question at scale. It scans Java projects, catalogs every hardcoded constant and externalized parameter it can find, stores the results in a Neo4j graph database, and then lets you explore the data through a browser-based UI. The four things it helps you do are:

1. **Discover** -- What constants and parameters exist in the codebase?
2. **Analyze** -- Which constants look like they should be externalized (URLs, ports, passwords, timeouts)?
3. **Query** -- Who uses what, where, and how often?
4. **Transform** -- Automatically rewrite constant usages to pull from a centralized configuration service instead.

The relationship data is what makes the graph valuable. A flat list of constants tells you they exist; the graph tells you that `SSH_PORT` is defined in `NetworkConfig.java`, used across four other files, and shares its value with an identical constant in `LegacyUtils.java`. That context is what turns an inventory into an action plan.

---

## Setup

### Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| **Java** | 21+ | The entire backend and core are compiled against Java 21. Records, pattern matching with `instanceof`, text blocks, and the `switch` expression are used throughout. |
| **Maven** | 3.8+ | Multi-module build system. The parent POM at the project root manages all dependency versions centrally. |
| **Docker & Docker Compose** | Recent stable | Runs Neo4j, ValKey, the backend, and the frontend as containers. |
| **Node.js** | 18+ | Only needed if you develop the frontend outside Docker. |

### Recommended IDEs

**IntelliJ IDEA** for `const-catalog-core` and `const-catalog-backend`. These are Maven Java modules with Lombok annotations, Spring Boot auto-configuration, and Neo4j repository interfaces. IntelliJ's Lombok plugin and Spring support make navigation painless. Open the root `pom.xml` as a project, and IntelliJ will detect all three modules automatically.

**VS Code** for `const-catalog-frontend`. Install the **Tailwind CSS IntelliSense** extension -- it gives you autocomplete for the custom color palette and utility classes defined in `tailwind.config.js`. The **ES7+ React/Redux/React-Native snippets** extension is also helpful. See the companion document [Frontend Maintainer's Diary](./Frontend_Maintainers_Diary.md) for a deeper treatment of the frontend stack, including a Tailwind tutorial and guidance on `tailwind.config.js` and `index.css`.

### Building the Java Modules

From the project root:

```bash
mvn clean install
```

This builds three artifacts:

- **const-catalog-core** -- Shared library containing the scanner, parsers, transformer, and domain models. No Spring dependency.
- **const-catalog-backend** -- Spring Boot application (fat JAR). Depends on `const-catalog-core`.
- **const-catalog-cli** -- Command-line interface (shaded JAR). Depends on `const-catalog-core`.

The parent POM pins all major dependency versions centrally:

| Dependency | Version | Role |
|------------|---------|------|
| Spring Boot | 3.4.1 | Web framework, Neo4j integration, async support |
| JavaParser | 3.28.0 | AST parsing and transformation of Java source files |
| Neo4j Driver | 5.27.0 | Bolt protocol driver for graph database |
| Caffeine | 3.1.8 | In-memory local cache |
| Lettuce | 6.3.2 | Redis/ValKey client for distributed cache |
| Lombok | 1.18.42 | Reduces boilerplate (`@Data`, `@Builder`, `@Slf4j`) |
| SpringDoc OpenAPI | 2.3.0 | Swagger UI at `/swagger-ui.html` |

---

## Containers

The application stack is orchestrated by `docker-compose.yml` at the project root. Four services run in production mode; a fifth is available on-demand for debugging.

| Service | Image | Ports | Purpose |
|---------|-------|-------|---------|
| **neo4j** | `neo4j:5.15-community` | 7474 (browser), 7687 (bolt) | Graph database. Auth is disabled for local development. |
| **valkey** | `valkey/valkey:8-alpine` | 6379 | Redis-compatible in-memory store for distributed configuration and pub/sub cache invalidation. |
| **backend** | Built from `const-catalog-backend/Dockerfile` | 8080 (HTTP), 5005 (debug) | Spring Boot REST API. |
| **frontend** | Built from `const-catalog-frontend/Dockerfile` | 3001 | React app served via nginx. |
| **valkey-cli** | `valkey/valkey:8-alpine` | -- | On-demand interactive CLI (`docker compose run --rm valkey-cli`). |

### Starting on Windows (MSYS2 / Git Bash / PowerShell)

The default `.env` file at the project root is configured for Windows paths:

```
HOST_SRC_PATH=C:/Users/brian/src
HOST_ESRC_PATH=E:/src
HOST_CSRC_PATH=C:/src
```

```bash
docker compose up -d
```

Docker Compose picks up `.env` automatically.

### Starting on WSL2 Ubuntu

WSL2 sees Windows drives under `/mnt/`, so the paths need translating. A separate `.env.wsl` file is provided:

```
HOST_SRC_PATH=/mnt/c/Users/brian/src
HOST_ESRC_PATH=/mnt/e/src
HOST_CSRC_PATH=/mnt/c/src
```

```bash
docker compose --env-file=.env.wsl up -d
```

### Stopping and Cleaning Up

```bash
docker compose down       # Stop all containers
docker compose down -v    # Stop and remove volumes (deletes Neo4j data)
```

### Inspecting ValKey

```bash
docker compose run --rm valkey-cli                       # Interactive CLI
docker compose exec valkey valkey-cli PING               # Quick health check
docker compose exec valkey valkey-cli KEYS "config:*"    # List configuration keys
docker compose exec valkey valkey-cli GET config:smtp.host
```

---

## Partitioning the Work

The application breaks down into three layers of concern:

### Part 1: Analyzing Codebases and Building the Graph

This is the `const-catalog-core` module. It has no Spring dependency and no Neo4j dependency -- it is a pure Java library that reads source files and produces structured data.

#### The Scanner: `ProjectScanner`

`ProjectScanner` is the entry point. Given a project root directory, it walks the file tree using Java's `FileVisitor` pattern, collecting `.java` files and property files (`.properties`, `.yml`, `.yaml`, `.env`, `.json`, `.xml`). It skips build artifact directories (`target`, `build`, `node_modules`, `.git`, `.idea`, `.gradle`, `.mvn`, `bin`, `.settings`).

The scan happens in two passes:

1. **Property files first.** The `PropertyFileParser` extracts key-value pairs from each property file. This produces a set of known parameter names.
2. **Java files second.** The `JavaFileParser` parses each `.java` file using JavaParser's AST and extracts:
   - **Constants**: `public static final` fields and enum constants.
   - **Parameter usages**: Calls to methods like `getProperty("db.host")`, `getString("timeout")`, or `@Value("${smtp.host}")` annotations -- but only when the argument matches a known parameter name from pass 1.
   - **Constant usages**: References to constants defined in other classes, detected via `FieldAccessExpr` (e.g., `AppConfig.DB_HOST`) and `NameExpr` (e.g., `DB_HOST` via static import).
   - **Fully qualified names (FQN)**: The package + class name for each Java file.

The result is a `ScanResult` record containing flat lists of constants, parameters, parameter usages, constant usages, and file statistics.

#### The Graph Populator: `GraphPopulatorService`

This is where the flat scan results become a graph. `GraphPopulatorService` runs inside a `@Transactional` block and executes eight ordered steps:

1. Create or update the **Project** node (keyed by root path).
2. Collect all unique file paths from constants, parameters, and usages.
3. Create **File** nodes with a lookup cache.
4. Create **Constant** nodes with `DEFINED_IN` relationships to their files.
5. Create **Parameter** nodes with `DEFINED_IN` relationships to their files.
6. Create `USED_IN` relationships from parameters to the Java files that consume them.
7. Create `USED_IN` relationships from constants to the Java files that reference them.
8. Set the FQN on Java file nodes.

#### The Neo4j Graph Model

```
(Project) --[CONTAINS]--> (File)
(Constant) --[DEFINED_IN]--> (File)
(Constant) --[USED_IN]--> (File)
(Parameter) --[DEFINED_IN]--> (File)
(Parameter) --[USED_IN]--> (File)
```

The node types and their key properties:

| Node | Properties |
|------|-----------|
| **Project** | `name`, `rootPath`, `scannedAt`, `totalFiles`, `totalConstants`, `totalParameters` |
| **File** | `path`, `fileName`, `fileType` (JAVA, PROPERTIES, YAML, ENV, XML), `fqn` |
| **Constant** | `name`, `type`, `value`, `className`, `lineNumber`, `accessModifier`, `isEnum`, `enumClassName` |
| **Parameter** | `name`, `value`, `lineNumber` |

The `USED_IN` relationship carries its own properties: `className`, `lineNumber`, and `context` (the code snippet where the usage occurs). This makes it possible to query not just *that* a constant is used somewhere, but *how* it is used.

### Part 2: The Spring Boot Backend

The backend (`const-catalog-backend`) is a standard Spring Boot 3 application that routes frontend HTTP requests to the business logic in `const-catalog-core` and the graph database. It lives behind four REST controller families:

| Controller | Base Path | Responsibility |
|------------|-----------|---------------|
| `ScanController` | `/api/scan` | Accepts project paths, triggers scanning, streams progress via SSE. |
| `QueryController` | `/api/query` | Runs pre-canned and ad-hoc Cypher queries against Neo4j. |
| `StatsController` | `/api/stats` | Returns dashboard statistics, constant/parameter lists, health checks. |
| `TransformController` | `/api/transform` | Runs code transformation, returns before/after file comparisons. |

The routing is straightforward Spring MVC:

```
POST /api/scan                   -> ScanController.scanProject()
GET  /api/scan/stream?projectPath=... -> ScanController.streamScan()  [SSE]

GET  /api/query/precanned        -> QueryController.getPreCannedQueries()
GET  /api/query/precanned/{id}   -> QueryController.executePreCannedQuery()
POST /api/query/execute          -> QueryController.executeQuery()

GET  /api/stats                  -> StatsController.getStats()
GET  /api/stats/constants        -> StatsController.getConstants()
GET  /api/stats/parameters       -> StatsController.getParameters()
GET  /api/stats/health           -> StatsController.healthCheck()

POST /api/transform              -> TransformController.transformProject()
GET  /api/transform/compare?path=... -> TransformController.compareFile()
```

Swagger UI is available at `http://localhost:8080/swagger-ui.html` and documents every endpoint with examples.

#### Caching: Two-Tier with Caffeine and ValKey

The `SiteConfigurationService` implements a two-tier cache:

- **Tier 1 (Caffeine)**: In-memory, local to the JVM. Configured with a max size of 10,000 entries and a 60-minute TTL. This eliminates network round-trips for frequently accessed configuration.
- **Tier 2 (ValKey)**: Redis-compatible distributed store. Shared across application instances. Supports pub/sub for cache invalidation -- when one instance updates a value, it publishes a message and all subscribers evict their local Caffeine entry.

Lookup follows a read-through pattern: check Caffeine first, then ValKey, then fall back to a default value.

### Part 3: The Frontend

The frontend is a React 18 + TypeScript application built with Vite and styled with Tailwind CSS. It uses a custom "Space Command" dark theme.

A full treatment of the frontend -- including a Tailwind tutorial, explanations of `tailwind.config.js` and `index.css`, setup instructions, and how to start the dev server -- is provided in a separate companion document: [Frontend Maintainer's Diary](./Frontend_Maintainers_Diary.md).

---

## The Four Tabs

### Dashboard

**Route:** `/` (root)

**What it shows:** Aggregate statistics from the graph database. The Dashboard makes a single `GET /api/stats` call on mount and displays:

- Total counts of projects, files, constants, and parameters.
- A breakdown of constants by Java type (String, int, long, etc.).
- The top 10 files ranked by constant count.
- The most-used parameters ranked by usage count.

This is the landing page, and it answers the question: "How big is our configuration landscape?"

### Scan

**Route:** `/scan`

**What it does:** Triggers a scan of a Java project directory.

The user enters a **project path** into an input field and clicks Scan. The frontend opens an SSE connection to `GET /api/scan/stream?projectPath=...` and renders real-time progress (file name, progress percentage, running constant/parameter counts) as events arrive.

#### Understanding the Project Path (Important)

The project path is resolved *inside the backend container*, not on the host machine. This is the single most common source of confusion when scanning for the first time.

The `docker-compose.yml` mounts host directories into the container as read-only volumes:

```yaml
volumes:
  - ./projects:/projects:ro
  - ${HOST_SRC_PATH:-/src}:/src:ro
  - ${HOST_ESRC_PATH:-/tmp/empty}:/esrc:ro
  - ${HOST_CSRC_PATH:-/tmp/empty}:/csrc:ro
```

This means:

| You want to scan... | The host path is... | In the container it becomes... | You enter in the UI... |
|---|---|---|---|
| A project in `./projects/` | `./projects/my-app` | `/projects/my-app` | `/projects/my-app` |
| Something under your `src` dir | `C:/Users/brian/src/my-app` (Windows) | `/src/my-app` | `/src/my-app` |
| Something on the E: drive | `E:/src/my-app` (Windows) | `/esrc/my-app` | `/esrc/my-app` |
| Something under C:\src | `C:/src/my-app` (Windows) | `/csrc/my-app` | `/csrc/my-app` |

On WSL2 Ubuntu (using `.env.wsl`), the host paths change but the container paths remain identical:

| Host path (WSL2) | Container path |
|---|---|
| `/mnt/c/Users/brian/src/my-app` | `/src/my-app` |
| `/mnt/e/src/my-app` | `/esrc/my-app` |
| `/mnt/c/src/my-app` | `/csrc/my-app` |

If the path you enter does not exist inside the container, the scan will fail with "Project path does not exist." Always think in terms of the container's filesystem.

### Query

**Route:** `/query`

**What it does:** Lets you explore the graph data through pre-canned queries or ad-hoc Cypher.

The Query page loads the list of pre-canned queries from `GET /api/query/precanned` and displays them as selectable cards grouped by category:

| Category | Queries |
|----------|---------|
| **Exploration** | All Constants, All Parameters, File Summary |
| **Analysis** | Configuration Candidates, Unused Parameters, Cross-File Parameters, Duplicate Values |
| **Security** | Sensitive Parameters, Connection Strings |
| **Organization** | Parameters by Prefix |

Each pre-canned query is a hand-crafted Cypher statement defined in `QueryService`. Results come back as columns + rows and render in a sortable table.

For power users, a Cypher input area allows ad-hoc queries. The QueryService validates that only read operations are submitted (`MATCH`/`RETURN` are allowed; `CREATE`/`DELETE`/`SET`/`MERGE`/`REMOVE`/`DROP` are blocked).

#### The Repository Package and Adding a New Query

If you want to add a new query that the backend itself can use (not just the UI), you work in the `repository` package. This package contains four Spring Data Neo4j repository interfaces:

| Repository | Entity | Description |
|---|---|---|
| `ProjectRepository` | `ProjectNode` | Find projects by root path, get database-level stats. |
| `FileRepository` | `FileNode` | Find files by path, get file statistics. |
| `ConstantRepository` | `ConstantNode` | The richest repository. Find by name, class, type, file path. Find configuration candidates, duplicate values, connection strings, unused constants, cross-file constants, type distribution, files with most constants. |
| `ParameterRepository` | `ParameterNode` | Find by name, unused parameters, sensitive parameters, parameters by prefix, most-used parameters. |

**How to add a query to `ConstantRepository`:**

Spring Data Neo4j supports two styles. For simple property-based lookups, just declare a method following the naming convention:

```java
List<ConstantNode> findByName(String name);
List<ConstantNode> findByClassName(String className);
```

Spring generates the Cypher automatically from the method name.

For anything more complex, use the `@Query` annotation with raw Cypher:

```java
@Query("""
    MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
    WHERE f.path = $filePath
    RETURN c
    ORDER BY c.lineNumber
    """)
List<ConstantNode> findByFilePath(String filePath);
```

Method parameters become Cypher parameters via `$paramName`. The return type can be:

- `List<ConstantNode>` -- when the RETURN clause returns full nodes that map to the entity.
- A custom record -- when the RETURN clause returns computed columns.

For example, the duplicate-values query returns two columns (`value` and `count`) that do not map to `ConstantNode`, so it uses an inner record:

```java
@Query("""
    MATCH (c:Constant)
    WITH c.value as value, collect(c) as constants
    WHERE size(constants) > 1
    RETURN value, size(constants) as count
    ORDER BY count DESC
    """)
List<DuplicateValueResult> findDuplicateValues();

record DuplicateValueResult(String value, long count) {}
```

To make a new repository query available in the UI, you would also add it as a pre-canned query in `QueryService` (with an `id`, `name`, `description`, `category`, and `cypher` string) and the frontend will pick it up automatically from the `/api/query/precanned` endpoint.

### Transform

**Route:** `/transform`

**What it does:** Rewrites Java source code to replace hardcoded constant usages with `config.lookupType()` calls, using the graph data to know which constants are configuration candidates and where they are used.

The Transform tab sends a `POST /api/transform` request with:

- `projectPath` -- the scanned project path (container-relative, same as the Scan tab).
- `dryRun` -- `true` to preview changes without modifying files, `false` to execute.
- `candidateScope` -- `CONSTANTS_ONLY`, `PARAMETERS_ONLY`, or `ALL` (default).

Results appear as a table listing each transformation entry with status (transformed, skipped, failed), the constant name, the derived property key, and the file path. For executed transformations, a "View Diff" button calls `GET /api/transform/compare?path=...` and renders a side-by-side comparison of the original and transformed code.

---

## The Transformation Process

Transformation is the most complex feature, so it deserves a dedicated explanation.

### How It Works End-to-End

1. **`TransformController`** receives the request and delegates to `CodeTransformationService`.

2. **`CodeTransformationService`** queries Neo4j to identify candidates:
   - For constants: finds all `Constant` nodes whose names match configuration-like patterns (HOST, PORT, URL, URI, PATH, KEY, SECRET, PASSWORD, TIMEOUT, ENDPOINT, DATABASE, CONNECTION, SERVER, CLIENT).
   - For parameters: finds all `Parameter` nodes that have `USED_IN` relationships (meaning their getter calls were detected during scanning).
   - Groups all targets by the source file they need to be applied to.

3. **`ConfigLookupTransformer`** (in `const-catalog-core`) does the actual AST surgery on each file:

   a. **Parse** the Java file into an AST using JavaParser.
   b. **Walk** the AST with a `ModifierVisitor`, looking for three kinds of nodes:
      - `NameExpr` -- a bare identifier like `SSH_PORT` (from a static import). Replaced with `config.lookupInt("ssh.port", 22)`.
      - `FieldAccessExpr` -- a qualified reference like `NetworkConfig.SSH_PORT`. Same replacement.
      - `MethodCallExpr` -- a property getter like `getProperty("db.host")`. Replaced with `config.lookup("db.host")`.
   c. **Add** a `@Autowired private SiteConfigurationService config;` field to the class if one does not already exist.
   d. **Add** the required import statements.
   e. **Write** the modified source to a backups directory, preserving the original directory structure. The original file is saved as `*.java.orig`.

4. **Result aggregation.** Each target is marked as `transformed`, `skipped` (no usages found), or `failed` (parse error, IO error). The response includes summary counts and per-entry details.

### The `ConstantTarget` Model

The `ConstantTarget` record is the unit of work for transformation. It carries:

| Field | Meaning | Example |
|-------|---------|---------|
| `constantName` | The original constant or parameter name | `DB_HOST` |
| `propertyKey` | The derived configuration key | `db.host` |
| `originalValue` | The hardcoded value | `"localhost"` |
| `originalType` | The Java type | `String` |
| `className` | The declaring class | `AppConfig` |
| `lineNumber` | Line in the source file | `42` |
| `sourceKind` | Whether it is a `CONSTANT` or `PARAMETER` | `CONSTANT` |

The `derivePropertyKey()` method converts `SCREAMING_SNAKE_CASE` to `dot.notation`:

```java
public static String derivePropertyKey(String constantName) {
    return constantName.toLowerCase().replace("_", ".");
}
// DB_HOST -> db.host
// API_BASE_URL -> api.base.url
```

### Lookup Method Selection

The transformer chooses the appropriate `config.lookupXxx()` method based on the original Java type:

| Java Type | Lookup Method | Generated Code |
|-----------|--------------|----------------|
| `String` | `lookup` | `config.lookup("db.host")` |
| `int` / `Integer` | `lookupInt` | `config.lookupInt("ssh.port", 22)` |
| `long` / `Long` | `lookupLong` | `config.lookupLong("max.size", 1048576L)` |
| `boolean` / `Boolean` | `lookupBoolean` | `config.lookupBoolean("feature.enabled", true)` |
| `double` / `Double` | `lookupDouble` | `config.lookupDouble("rate.limit", 1.5)` |

For non-String types, the original hardcoded value becomes the default argument so behavior is preserved if the configuration key is not set.

### Backup Strategy

Transformed files are *never* written back to the original read-only mounted source. Instead:

- A `backups/` directory is created (writable volume in Docker: `./backups:/app/backups`).
- The directory structure of the source is preserved under `backups/`.
- The original file is copied to `<path>.java.orig`.
- The transformed file is written to `<path>.java`.

This means the original source code is always safe. You can inspect the diff, and if something went wrong, the `.orig` file is right there.

---

## A Note on JavaParser

JavaParser (version 3.28.0) is the backbone of both scanning and transformation. It deserves a brief explanation because, as a maintainer, you will encounter it frequently.

### What It Is

JavaParser is a library that parses Java source code into an Abstract Syntax Tree (AST). Every element of the Java language -- classes, methods, fields, expressions, annotations -- becomes a tree node you can inspect, query, or modify programmatically.

### How We Use It

We use JavaParser in two fundamentally different ways:

**1. Read-only parsing (in `JavaFileParser`)**

The `VoidVisitorAdapter` pattern. You subclass `VoidVisitorAdapter<Void>` and override `visit()` methods for the node types you care about. The adapter walks the tree and calls your methods. You collect data, but you never change the tree.

```java
compilationUnit.accept(new VoidVisitorAdapter<Void>() {
    @Override
    public void visit(FieldDeclaration field, Void arg) {
        // Extract data from the field
        boolean isPublic = field.getModifiers().stream()
            .anyMatch(m -> m.getKeyword() == Modifier.Keyword.PUBLIC);
        // ...
        super.visit(field, arg);  // Continue walking children
    }
}, null);
```

This is how we discover constants (`public static final` fields), enum constants, `@Value` annotations, and property getter calls.

**2. Read-write transformation (in `ConfigLookupTransformer`)**

The `ModifierVisitor` pattern. Instead of `VoidVisitorAdapter`, you subclass `ModifierVisitor<Void>`. The key difference: your `visit()` methods *return* a node. If you return the original node, nothing changes. If you return a different node, the tree is modified in place.

```java
cu.accept(new ModifierVisitor<Void>() {
    @Override
    public Visitable visit(NameExpr n, Void arg) {
        if (shouldReplace(n)) {
            // Return a replacement node -- the tree is modified
            return createConfigLookupCall(target);
        }
        return super.visit(n, arg);  // Leave unchanged
    }
}, null);
```

After the visitor completes, `cu.toString()` produces the modified source code with all replacements applied.

### The Visitor Pattern Summary

| Visitor | Returns | Mutates Tree? | Use Case |
|---------|---------|---------------|----------|
| `VoidVisitorAdapter` | `void` | No | Scanning, data extraction |
| `ModifierVisitor` | `Visitable` (the replacement node) | Yes | Transformation, code rewriting |

### Key AST Node Types in Our Code

| Node Type | What It Represents | Example Source |
|-----------|--------------------|---------------|
| `FieldDeclaration` | A field with modifiers | `public static final int PORT = 8080;` |
| `VariableDeclarator` | A single variable within a field | `PORT = 8080` (inside the FieldDeclaration) |
| `NameExpr` | A simple name reference | `PORT` (when used somewhere in code) |
| `FieldAccessExpr` | A qualified field access | `Config.PORT` |
| `MethodCallExpr` | A method invocation | `getProperty("db.host")` |
| `StringLiteralExpr` | A string literal | `"db.host"` |
| `AnnotationExpr` | An annotation | `@Value("${db.host}")` |
| `ClassOrInterfaceDeclaration` | A class or interface | `public class Config { ... }` |
| `EnumDeclaration` | An enum type | `public enum Status { ... }` |
| `EnumConstantDeclaration` | A single enum value | `ACTIVE` (inside the EnumDeclaration) |
| `CompilationUnit` | The root of a parsed file | The entire `.java` file |

### Configuration

The transformer configures JavaParser for Java 21:

```java
ParserConfiguration config = new ParserConfiguration()
    .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_21);
this.javaParser = new JavaParser(config);
```

The scanner uses the default configuration, which is sufficient for extracting field declarations and method calls.

---

## Closing Thoughts

This application is not large, but it has a satisfying layered structure. The `const-catalog-core` module knows nothing about Spring or Neo4j -- it reads files and produces data. The backend translates that data into a graph and serves it over HTTP. The frontend renders it for human consumption.

If you are picking up this codebase for the first time, start by scanning a small project you know well. Watch the graph populate in Neo4j's browser (`http://localhost:7474`), run a few pre-canned queries, and try a dry-run transformation. The pieces will click into place once you see real data flowing through the system.

For frontend-specific guidance -- the Tailwind theme system, component architecture, how to start the dev server, and how `tailwind.config.js` and `index.css` define the visual language -- see the companion document: [Frontend Maintainer's Diary](./Frontend_Maintainers_Diary.md).
