# Recipe: Disabling the Scan Button During Scanning

How the Scan button is disabled when a scan starts and re-enabled when it stops. This is already implemented in `ScanPage.tsx` — this document explains the mechanism so you can replicate the pattern elsewhere.

---

## The Problem

Without disabling the button, the user could click "Scan Project" multiple times while a scan is in progress. This would launch concurrent scans on the same project, causing `ConcurrentModificationException` in the scanner and duplicate data in Neo4j.

## The Solution

**File:** `const-catalog-frontend/src/pages/ScanPage.tsx`

### How It Works

```mermaid
stateDiagram-v2
    [*] --> Enabled: Page loads

    Enabled --> Disabled: User clicks "Scan Project"
    note right of Disabled
        Button shows spinner + "Scanning..."
        Two conditions can disable:
        • scanMutation.isPending (POST scan)
        • isConnected (SSE scan)
    end note

    Disabled --> Enabled: Scan completes or fails
    note right of Enabled
        Button shows play icon + "Scan Project"
        Both conditions are false
    end note
```

### The Code

The button has two attributes that control this:

```tsx
<button
  type="submit"
  disabled={scanMutation.isPending || isConnected || !projectPath.trim()}
  className="btn btn-primary flex items-center gap-2"
>
  {(scanMutation.isPending || isConnected) ? (
    <>
      <Loader2 className="w-4 h-4 animate-spin" />
      Scanning...
    </>
  ) : (
    <>
      <Play className="w-4 h-4" />
      Scan Project
    </>
  )}
</button>
```

### Line-by-Line

**`disabled={scanMutation.isPending || isConnected || !projectPath.trim()}`**

Three conditions disable the button:

| Condition | When it's `true` | Purpose |
|---|---|---|
| `scanMutation.isPending` | POST scan is in progress (checkbox unchecked) | Prevents double POST |
| `isConnected` | SSE stream is open (checkbox checked) | Prevents double SSE |
| `!projectPath.trim()` | Input is empty or whitespace | Prevents empty scan |

**`{(scanMutation.isPending \|\| isConnected) ? ... : ...}`**

Swaps the button content between two states:

| State | Icon | Label |
|---|---|---|
| Scanning | `<Loader2 className="animate-spin" />` (spinning circle) | "Scanning..." |
| Idle | `<Play />` (play triangle) | "Scan Project" |

### The Two Scan Paths

The button covers both scan paths because there are two different flags:

```mermaid
flowchart TD
    A["User clicks Scan Project"] --> B{Watch progress<br/>checked?}
    B -->|Yes| C["startStreaming()<br/>isConnected = true<br/>Button disabled"]
    B -->|No| D["scanMutation.mutate()<br/>isPending = true<br/>Button disabled"]

    C --> E["SSE complete event"]
    E --> F["isConnected = false<br/>Button enabled"]

    D --> G["POST response received"]
    G --> H["isPending = false<br/>Button enabled"]

    style C fill:#4488ff,color:#fff
    style D fill:#ff8844,color:#fff
    style F fill:#44aa44,color:#fff
    style H fill:#44aa44,color:#fff
```

### When Is the Button Re-Enabled?

| Scan path | Disabled by | Re-enabled when |
|---|---|---|
| SSE (checkbox on) | `isConnected = true` | `useScanProgress` receives `'complete'` or `'error'` event → calls `stopStreaming()` → `isConnected = false` |
| POST (checkbox off) | `scanMutation.isPending = true` | TanStack Query receives response (success or error) → `isPending = false` |

In both cases, the transition is **automatic** — React re-renders the component when the state changes, and the button's `disabled` prop evaluates to `false`.

### Error Cases

If the scan **fails**, the button is still re-enabled:

- **SSE error:** The `EventSource.onerror` handler calls `stopStreaming()` → `isConnected = false`
- **POST error:** TanStack Query sets `isPending = false` when the mutation fails (after the `onError` callback runs)

The user sees the error message in the results panel and can retry.

---

## Recipe: Apply This Pattern to Another Button

To disable any button during an async operation:

### Step 1: Identify the loading state

For a TanStack Query mutation:
```tsx
const myMutation = useMutation({ mutationFn: myApiCall })
// myMutation.isPending is true while the request is in flight
```

For a custom hook with connection state:
```tsx
const { isConnected } = useMyHook()
// isConnected is true while the operation is in progress
```

### Step 2: Wire the button

```tsx
<button
  disabled={myMutation.isPending}
  onClick={() => myMutation.mutate(data)}
>
  {myMutation.isPending ? (
    <>
      <Loader2 className="w-4 h-4 animate-spin" />
      Working...
    </>
  ) : (
    <>
      <Play className="w-4 h-4" />
      Do The Thing
    </>
  )}
</button>
```

### Step 3: That's it

No manual state management needed. TanStack Query manages `isPending` automatically — it becomes `true` when `mutate()` is called and `false` when the response arrives (success or error). The button re-renders automatically via React's reactive updates.

---

## Common Mistakes

| Mistake | Problem | Fix |
|---|---|---|
| Using `useState` for loading | Must manually set `true`/`false` in every code path | Use `mutation.isPending` — automatic |
| Forgetting the error case | Button stays disabled after a failed request | TanStack resets `isPending` on error too |
| Only checking one scan path | SSE scan isn't covered, or POST scan isn't covered | Check both: `isPending \|\| isConnected` |
| Not disabling on empty input | User can submit empty form | Add `\|\| !input.trim()` |
