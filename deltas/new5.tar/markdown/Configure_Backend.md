# Configuring the Backend

How to configure the Constants Catalog backend, including the config store backend selection, database connections, and Docker deployment.

---

## Table of Contents

1. [Config Store Backend Selection](#1-config-store-backend-selection)
2. [ValKey Configuration](#2-valkey-configuration)
3. [MongoDB Configuration](#3-mongodb-configuration)
4. [Neo4j Configuration](#4-neo4j-configuration)
5. [Docker Compose Deployment](#5-docker-compose-deployment)
6. [Configuration Precedence](#6-configuration-precedence)

---

## 1. Config Store Backend Selection

The backend stores configuration key-value pairs (scanned constants and parameters) in a pluggable store. Two implementations are available:

| Backend | Property Value | When to Use |
|---|---|---|
| ValKey (Redis-compatible) | `valkey` (default) | Standard deployment. Includes pub/sub for distributed cache invalidation across multiple app instances. |
| MongoDB | `mongodb` | When you need document-based storage, JSON queryability, or already have MongoDB infrastructure. |

### How to Switch

**Option A: application.yml**

```yaml
config:
  store:
    type: mongodb    # or "valkey" (default if omitted)
```

**Option B: Environment variable**

```bash
CONFIG_STORE_TYPE=mongodb
```

**Option C: Docker Compose**

```yaml
# In docker-compose.yml under backend service:
backend:
  environment:
    - CONFIG_STORE_TYPE=mongodb
```

The property `config.store.type` controls which Spring bean is created via `@ConditionalOnProperty`. Only one store is active at a time. The `SiteConfigurationService` doesn't know which backend is in use — it calls the `ConfigStore` interface.

---

## 2. ValKey Configuration

ValKey is the default backend. No additional configuration is needed if you're running the standard Docker Compose stack.

### Properties

| Property | Env Var | Default | Description |
|---|---|---|---|
| `valkey.host` | `VALKEY_HOST` | `localhost` | ValKey server hostname |
| `valkey.port` | `VALKEY_PORT` | `6379` | ValKey server port |
| `valkey.password` | `VALKEY_PASSWORD` | (empty) | Authentication password |
| `valkey.database` | `VALKEY_DATABASE` | `0` | Redis database number |
| `valkey.timeout` | `VALKEY_TIMEOUT` | `5000` | Connection timeout in milliseconds |

### Caffeine Local Cache

The L1 local cache sits in front of ValKey (or MongoDB) to minimize network round-trips:

| Property | Env Var | Default | Description |
|---|---|---|---|
| `cache.caffeine.max-size` | `CACHE_MAX_SIZE` | `10000` | Maximum number of cached entries |
| `cache.caffeine.expire-after-write-minutes` | `CACHE_EXPIRE_MINUTES` | `60` | Minutes before a cached entry is considered stale |

### Example: application.yml (ValKey)

```yaml
config:
  store:
    type: valkey    # default, can be omitted

valkey:
  host: ${VALKEY_HOST:localhost}
  port: ${VALKEY_PORT:6379}
  password: ${VALKEY_PASSWORD:}
  database: 0
  timeout: 5000

cache:
  caffeine:
    max-size: 10000
    expire-after-write-minutes: 60
```

---

## 3. MongoDB Configuration

MongoDB is an optional backend. It stores each configuration entry as a document:

```json
{
  "_id": "db.host",
  "key": "db.host",
  "value": "localhost"
}
```

### Properties

| Property | Env Var | Default | Description |
|---|---|---|---|
| `config.store.type` | `CONFIG_STORE_TYPE` | `valkey` | Must be set to `mongodb` to activate |
| `config.store.mongodb.uri` | `CONFIG_STORE_MONGODB_URI` | `mongodb://localhost:27017` | MongoDB connection string |
| `config.store.mongodb.database` | `CONFIG_STORE_MONGODB_DATABASE` | `const-catalog` | Database name for config storage |

### Example: application.yml (MongoDB)

```yaml
config:
  store:
    type: mongodb
    mongodb:
      uri: ${CONFIG_STORE_MONGODB_URI:mongodb://localhost:27017}
      database: ${CONFIG_STORE_MONGODB_DATABASE:const-catalog}

cache:
  caffeine:
    max-size: 10000
    expire-after-write-minutes: 60
```

### Limitations

- **No pub/sub:** MongoDB standalone doesn't support distributed cache invalidation. If you run multiple application instances, Caffeine caches may serve stale data until TTL expires. MongoDB Change Streams (replica set) could address this in the future.
- **No batch optimization:** `setBatch()` iterates and upserts one document at a time. For bulk imports, this is slower than ValKey's `MSET`.

---

## 4. Neo4j Configuration

Neo4j is the graph database for storing scanned project data (constants, parameters, files, relationships). It's always required regardless of which config store backend is active.

| Property | Env Var | Default | Description |
|---|---|---|---|
| `spring.neo4j.uri` | `NEO4J_URI` | `bolt://localhost:7687` | Neo4j Bolt connection URI |
| `spring.neo4j.authentication.username` | `NEO4J_USERNAME` | (empty) | Neo4j username |
| `spring.neo4j.authentication.password` | `NEO4J_PASSWORD` | (empty) | Neo4j password |

---

## 5. Docker Compose Deployment

### Standard (ValKey — default)

```bash
docker compose --env-file=.env.mint up -d
```

This starts: neo4j, valkey, backend, frontend. The backend uses ValKey as the config store.

### With MongoDB

```bash
# Start all services plus MongoDB
docker compose --env-file=.env.mint --profile mongodb up -d

# Tell the backend to use MongoDB
# Add to docker-compose.yml under backend environment:
#   CONFIG_STORE_TYPE: mongodb
#   CONFIG_STORE_MONGODB_URI: mongodb://mongo:27017
#   CONFIG_STORE_MONGODB_DATABASE: const-catalog
```

Or override at the command line:

```bash
CONFIG_STORE_TYPE=mongodb docker compose --env-file=.env.mint --profile mongodb up -d
```

### Docker Compose Services

| Service | Port | Profile | Purpose |
|---|---|---|---|
| `neo4j` | 7474 (HTTP), 7687 (Bolt) | default | Graph database |
| `valkey` | 6379 | default | Config store (default backend) |
| `mongo` | 27017 | `mongodb` | Config store (optional backend) |
| `backend` | 9090 → 8080 | default | Spring Boot REST API |
| `frontend` | 3001 → 80 | default | React UI via nginx |

### Network

All services are on the `const-catalog-network` bridge network. Inside the network, services reference each other by name (`neo4j`, `valkey`, `mongo`, `backend`).

From the host, services are accessed via their mapped ports (e.g., `localhost:9090` for the backend, `localhost:27017` for MongoDB).

---

## 6. Configuration Precedence

Spring Boot resolves configuration in this order (highest priority first):

1. **Environment variables** — `CONFIG_STORE_TYPE=mongodb` overrides everything
2. **Command-line arguments** — `--config.store.type=mongodb`
3. **`application.yml`** — file in `src/main/resources/`
4. **Defaults in code** — `@Value("${config.store.type:valkey}")` fallback

For Docker deployments, environment variables (set in `docker-compose.yml` or `.env` files) are the recommended approach. They override `application.yml` without requiring a rebuild.

### Environment Variable Naming

Spring Boot converts property names to env vars by uppercasing and replacing dots/hyphens with underscores:

| Property | Environment Variable |
|---|---|
| `config.store.type` | `CONFIG_STORE_TYPE` |
| `config.store.mongodb.uri` | `CONFIG_STORE_MONGODB_URI` |
| `valkey.host` | `VALKEY_HOST` |
| `spring.neo4j.uri` | `NEO4J_URI` (custom mapping via `${}`) |
