# MongoDB Fencing in the Land of Musketeers

*In the service of Louis XIII (Sam Soheili), a Musketeer must know his weapons. This tutorial teaches you to wield MongoDB from the command line — connecting, inserting, querying, updating, and deleting documents — all from inside the Docker container.*

---

## Table of Contents

1. [Entering the Garrison](#1-entering-the-garrison)
2. [Connecting to MongoDB](#2-connecting-to-mongodb)
3. [Choosing Your Database](#3-choosing-your-database)
4. [The Document: MongoDB's Unit of Data](#4-the-document-mongodbs-unit-of-data)
5. [Inserting Documents](#5-inserting-documents)
6. [Finding Documents](#6-finding-documents)
7. [Updating Documents](#7-updating-documents)
8. [The Upsert: Insert-or-Update in One Thrust](#8-the-upsert-insert-or-update-in-one-thrust)
9. [Deleting Documents](#9-deleting-documents)
10. [Replacing Documents](#10-replacing-documents)
11. [Querying by Pattern](#11-querying-by-pattern)
12. [Counting and Aggregating](#12-counting-and-aggregating)
13. [Working with the Config Collection](#13-working-with-the-config-collection)
14. [Bulk Operations: The Flurry](#14-bulk-operations-the-flurry)
15. [Indexes: Speed on the Piste](#15-indexes-speed-on-the-piste)
16. [Housekeeping](#16-housekeeping)
17. [Quick Reference Card](#17-quick-reference-card)

---

## 1. Entering the Garrison

First, make sure MongoDB is running:

```bash
docker compose --profile=mongodb up -d mongo
```

Verify it's up:

```bash
docker compose ps
```

You should see `const-catalog-mongo` with status `Up (healthy)`.

Now enter the container:

```bash
docker exec -it const-catalog-mongo bash
```

You're now inside the MongoDB container as root. Your prompt changes to something like `root@abc123:/# `.

---

## 2. Connecting to MongoDB

From inside the container, launch the MongoDB shell:

```bash
mongosh
```

You'll see a welcome message and a prompt:

```
test>
```

This means you're connected to the default `test` database. The `mongosh` shell is JavaScript-based — you can use variables, loops, and functions.

To connect from **outside** the container (if you have `mongosh` installed locally):

```bash
mongosh mongodb://localhost:27017
```

Or skip the `bash` step entirely and go straight to the shell:

```bash
docker exec -it const-catalog-mongo mongosh
```

---

## 3. Choosing Your Database

List all databases:

```javascript
show dbs
```

Switch to the Constants Catalog database:

```javascript
use const-catalog
```

The prompt changes to `const-catalog>`. If the database doesn't exist yet, MongoDB creates it when you first write data to it.

List collections in the current database:

```javascript
show collections
```

If the application has been running with `config.store.type=mongodb`, you'll see a `config` collection.

---

## 4. The Document: MongoDB's Unit of Data

MongoDB stores data as **documents** — JSON-like objects. In the Constants Catalog, a configuration entry looks like:

```json
{
  "_id": "db.host",
  "key": "db.host",
  "value": "localhost"
}
```

- `_id` is the primary key. Every document must have one. If you don't provide it, MongoDB generates an `ObjectId`.
- Fields are key-value pairs. Values can be strings, numbers, booleans, arrays, or nested objects.
- Documents in the same collection don't need the same fields — there's no fixed schema.

---

## 5. Inserting Documents

### Insert one document

```javascript
db.musketeers.insertOne({
  name: "Athos",
  rank: "Musketeer",
  skills: ["swordsmanship", "strategy", "wine tasting"],
  missions: 47
})
```

MongoDB responds with:

```json
{ "acknowledged": true, "insertedId": ObjectId("...") }
```

Since we didn't provide `_id`, MongoDB generated an `ObjectId`.

### Insert with an explicit _id

```javascript
db.musketeers.insertOne({
  _id: "athos",
  name: "Athos",
  rank: "Musketeer",
  missions: 47
})
```

Now `_id` is the string `"athos"` instead of an auto-generated ObjectId.

### Insert many documents at once

```javascript
db.musketeers.insertMany([
  { _id: "porthos", name: "Porthos", rank: "Musketeer", missions: 42 },
  { _id: "aramis", name: "Aramis", rank: "Musketeer", missions: 38 },
  { _id: "dartagnan", name: "D'Artagnan", rank: "Cadet", missions: 12 }
])
```

### What happens if _id already exists?

```javascript
db.musketeers.insertOne({ _id: "athos", name: "Imposter" })
```

Error: `E11000 duplicate key error`. MongoDB enforces uniqueness on `_id`. You cannot insert a duplicate — you must update or upsert instead.

---

## 6. Finding Documents

### Find all documents

```javascript
db.musketeers.find()
```

### Find with pretty printing

```javascript
db.musketeers.find().pretty()
```

### Find by _id

```javascript
db.musketeers.find({ _id: "athos" })
```

### Find one document (returns the first match, not a cursor)

```javascript
db.musketeers.findOne({ _id: "athos" })
```

### Find by a field value

```javascript
db.musketeers.find({ rank: "Musketeer" })
```

### Find with comparison operators

```javascript
// Musketeers with more than 40 missions
db.musketeers.find({ missions: { $gt: 40 } })

// Musketeers with 38 to 47 missions (inclusive)
db.musketeers.find({ missions: { $gte: 38, $lte: 47 } })
```

Common operators:
| Operator | Meaning |
|---|---|
| `$eq` | Equal (default) |
| `$ne` | Not equal |
| `$gt` | Greater than |
| `$gte` | Greater than or equal |
| `$lt` | Less than |
| `$lte` | Less than or equal |
| `$in` | Matches any value in array |
| `$regex` | Regular expression match |

### Find with multiple conditions (AND)

```javascript
db.musketeers.find({ rank: "Musketeer", missions: { $gt: 40 } })
```

### Find with OR

```javascript
db.musketeers.find({
  $or: [
    { name: "Athos" },
    { name: "Porthos" }
  ]
})
```

### Return only specific fields (projection)

```javascript
// Only return name and missions, exclude _id
db.musketeers.find({}, { name: 1, missions: 1, _id: 0 })
```

### Sort results

```javascript
// Sort by missions descending
db.musketeers.find().sort({ missions: -1 })
```

### Limit results

```javascript
db.musketeers.find().sort({ missions: -1 }).limit(2)
```

---

## 7. Updating Documents

### Update one field

```javascript
// D'Artagnan is promoted
db.musketeers.updateOne(
  { _id: "dartagnan" },
  { $set: { rank: "Musketeer" } }
)
```

`$set` changes only the specified fields. All other fields remain untouched.

### Update multiple fields

```javascript
db.musketeers.updateOne(
  { _id: "dartagnan" },
  { $set: { rank: "Musketeer", missions: 13 } }
)
```

### Increment a numeric field

```javascript
// Athos completed another mission
db.musketeers.updateOne(
  { _id: "athos" },
  { $inc: { missions: 1 } }
)
```

### Add to an array

```javascript
db.musketeers.updateOne(
  { _id: "dartagnan" },
  { $push: { skills: "diplomacy" } }
)
```

### Update many documents at once

```javascript
// All Musketeers get a bonus mission
db.musketeers.updateMany(
  { rank: "Musketeer" },
  { $inc: { missions: 1 } }
)
```

### Remove a field

```javascript
db.musketeers.updateOne(
  { _id: "athos" },
  { $unset: { skills: "" } }
)
```

### Common update operators

| Operator | Effect |
|---|---|
| `$set` | Set field to a value |
| `$unset` | Remove a field |
| `$inc` | Increment a numeric field |
| `$push` | Append to an array |
| `$pull` | Remove from an array |
| `$rename` | Rename a field |

---

## 8. The Upsert: Insert-or-Update in One Thrust

*In fencing, a riposte answers an attack with a counterattack in one motion.* The upsert answers "does this exist?" and "store this value" in a single atomic operation:

```javascript
db.musketeers.updateOne(
  { _id: "milady" },                               // filter
  { $set: { name: "Milady de Winter", rank: "Spy", missions: 99 } },  // update
  { upsert: true }                                  // create if not found
)
```

If `_id: "milady"` exists, it's updated. If not, a new document is inserted with `_id: "milady"` and the `$set` fields.

Run it again with different data:

```javascript
db.musketeers.updateOne(
  { _id: "milady" },
  { $set: { missions: 100 } },
  { upsert: true }
)
```

This time it updates the existing document. The `name` and `rank` fields remain unchanged because `$set` only touches the fields you specify.

**This is exactly what `MongoConfigStore.set()` does** in the Constants Catalog — using `replaceOne` with `upsert: true` to store configuration values. Whether the key exists or not, one operation handles it.

---

## 9. Deleting Documents

### Delete one document

```javascript
db.musketeers.deleteOne({ _id: "milady" })
```

Response: `{ "acknowledged": true, "deletedCount": 1 }`

### Delete many documents

```javascript
// Remove all Cadets
db.musketeers.deleteMany({ rank: "Cadet" })
```

### Delete all documents in a collection (keep the collection)

```javascript
db.musketeers.deleteMany({})
```

### Drop the entire collection (removes collection and indexes)

```javascript
db.musketeers.drop()
```

---

## 10. Replacing Documents

`replaceOne` replaces the **entire** document (except `_id`) instead of updating specific fields:

```javascript
// This replaces ALL fields (except _id)
db.musketeers.replaceOne(
  { _id: "athos" },
  { name: "Athos, Comte de la Fère", rank: "Musketeer", missions: 50 }
)
```

After this, the document only has `_id`, `name`, `rank`, and `missions`. Any fields that were there before (like `skills`) are gone.

**`updateOne` with `$set` vs `replaceOne`:**

| Operation | Effect |
|---|---|
| `updateOne({ _id: "x" }, { $set: { rank: "General" } })` | Changes only `rank`, all other fields preserved |
| `replaceOne({ _id: "x" }, { rank: "General" })` | Document becomes `{ _id: "x", rank: "General" }` — everything else is gone |

The Constants Catalog uses `replaceOne` with `upsert: true` because each config document has a known, fixed structure (`_id`, `key`, `value`) and we always write the complete document.

---

## 11. Querying by Pattern

### Regex queries

Find all keys starting with `db.`:

```javascript
db.config.find({ _id: { $regex: "^db\\." } })
```

The `^` anchors to the start. The `\\.` matches a literal dot (`.` in regex means "any character").

Find all musketeers whose name contains "th":

```javascript
db.musketeers.find({ name: { $regex: "th", $options: "i" } })
```

The `$options: "i"` makes it case-insensitive. Matches "Athos" and "Porthos".

### Array queries

Find musketeers who have "strategy" in their skills:

```javascript
db.musketeers.find({ skills: "strategy" })
```

MongoDB automatically searches inside arrays — no special syntax needed.

Find musketeers who have both "strategy" and "swordsmanship":

```javascript
db.musketeers.find({ skills: { $all: ["strategy", "swordsmanship"] } })
```

### Exists queries

Find documents that have a `skills` field:

```javascript
db.musketeers.find({ skills: { $exists: true } })
```

---

## 12. Counting and Aggregating

### Count documents

```javascript
db.musketeers.countDocuments({ rank: "Musketeer" })
```

### Distinct values

```javascript
db.musketeers.distinct("rank")
// ["Musketeer", "Cadet"]
```

### Simple aggregation

Total missions across all musketeers:

```javascript
db.musketeers.aggregate([
  { $group: { _id: null, totalMissions: { $sum: "$missions" } } }
])
```

Missions per rank:

```javascript
db.musketeers.aggregate([
  { $group: { _id: "$rank", count: { $sum: 1 }, totalMissions: { $sum: "$missions" } } },
  { $sort: { totalMissions: -1 } }
])
```

---

## 13. Working with the Config Collection

The Constants Catalog stores configuration in the `config` collection. Here's how to work with it:

```javascript
use const-catalog

// See all config entries
db.config.find()

// Look up a specific key
db.config.findOne({ _id: "db.host" })

// Set a config value (upsert)
db.config.replaceOne(
  { _id: "db.host" },
  { _id: "db.host", key: "db.host", value: "localhost" },
  { upsert: true }
)

// Find all database-related config
db.config.find({ _id: { $regex: "^db\\." } })

// Count config entries
db.config.countDocuments()

// Delete a config entry
db.config.deleteOne({ _id: "db.host" })

// Wipe all config (careful!)
db.config.deleteMany({})
```

The document structure matches what `MongoConfigStore` writes:

```json
{ "_id": "db.host", "key": "db.host", "value": "localhost" }
```

---

## 14. Bulk Operations: The Flurry

*A flurry is a rapid series of attacks.* Bulk operations send multiple writes in a single network round-trip:

```javascript
db.config.bulkWrite([
  {
    replaceOne: {
      filter: { _id: "db.host" },
      replacement: { _id: "db.host", key: "db.host", value: "prod-db.local" },
      upsert: true
    }
  },
  {
    replaceOne: {
      filter: { _id: "db.port" },
      replacement: { _id: "db.port", key: "db.port", value: "5432" },
      upsert: true
    }
  },
  {
    replaceOne: {
      filter: { _id: "db.name" },
      replacement: { _id: "db.name", key: "db.name", value: "catalog" },
      upsert: true
    }
  }
])
```

Response shows how many were inserted, modified, and upserted:

```json
{
  "insertedCount": 0,
  "matchedCount": 1,
  "modifiedCount": 1,
  "upsertedCount": 2
}
```

---

## 15. Indexes: Speed on the Piste

### See existing indexes

```javascript
db.config.getIndexes()
```

Every collection has a default index on `_id`. Since we query on `_id` for all operations, no additional indexes are needed.

### Create an index (if you had other query patterns)

```javascript
// Index on the value field (not needed for our use case, just for illustration)
db.config.createIndex({ value: 1 })
```

### Drop an index

```javascript
db.config.dropIndex("value_1")
```

### Explain a query (see if it uses an index)

```javascript
db.config.find({ _id: "db.host" }).explain("executionStats")
```

Look for `"stage": "IDHACK"` or `"stage": "IXSCAN"` — this means the query used an index. `"stage": "COLLSCAN"` means it scanned every document (slow on large collections).

---

## 16. Housekeeping

### See database stats

```javascript
db.stats()
```

### See collection stats

```javascript
db.config.stats()
```

### List current operations

```javascript
db.currentOp()
```

### Drop the test database (clean up after experimenting)

```javascript
use const-catalog-test
db.dropDatabase()
```

### Exit the shell

```javascript
exit
```

Or press `Ctrl+D`.

### Exit the container

```bash
exit
```

---

## 17. Quick Reference Card

```
┌──────────────────────────────────────────────────────────────┐
│            MONGODB FENCING QUICK REFERENCE                    │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ENTER THE GARRISON                                          │
│    docker exec -it const-catalog-mongo mongosh               │
│    use const-catalog                                         │
│                                                              │
│  INSERT                                                      │
│    db.coll.insertOne({ _id: "k", value: "v" })              │
│    db.coll.insertMany([ {..}, {..} ])                        │
│                                                              │
│  FIND                                                        │
│    db.coll.find()                       # all                │
│    db.coll.find({ _id: "k" })          # by key             │
│    db.coll.find({ n: { $gt: 10 } })    # comparison         │
│    db.coll.find({ _id: /^db\./ })      # regex              │
│    db.coll.findOne({ _id: "k" })       # first match        │
│                                                              │
│  UPDATE                                                      │
│    db.coll.updateOne({ _id: "k" }, { $set: { v: "new" } })  │
│    db.coll.updateOne({ _id: "k" }, { $inc: { n: 1 } })      │
│    db.coll.updateMany({ rank: "X" }, { $set: { a: 1 } })    │
│                                                              │
│  UPSERT                                                      │
│    db.coll.updateOne(                                        │
│      { _id: "k" },                                          │
│      { $set: { value: "v" } },                              │
│      { upsert: true }                                        │
│    )                                                         │
│    db.coll.replaceOne(                                       │
│      { _id: "k" },                                          │
│      { _id: "k", key: "k", value: "v" },                    │
│      { upsert: true }                                        │
│    )                                                         │
│                                                              │
│  DELETE                                                      │
│    db.coll.deleteOne({ _id: "k" })     # one                │
│    db.coll.deleteMany({ rank: "X" })   # by filter          │
│    db.coll.deleteMany({})              # all docs            │
│    db.coll.drop()                      # drop collection     │
│                                                              │
│  AGGREGATE                                                   │
│    db.coll.countDocuments({ rank: "X" })                     │
│    db.coll.distinct("rank")                                  │
│    db.coll.aggregate([ { $group: {..} } ])                   │
│                                                              │
│  HOUSEKEEPING                                                │
│    show dbs                            # list databases      │
│    show collections                    # list collections    │
│    db.coll.getIndexes()                # list indexes        │
│    db.coll.find().explain()            # query plan          │
│    db.dropDatabase()                   # drop current db     │
│                                                              │
│  "All for one, and one for all!"                             │
└──────────────────────────────────────────────────────────────┘
```
