# Configuring the Royal ConfigStore

*An urgent message from His Royal Highness, Louis XIII (Sam Soheili), Roi de France et de Navarre:*

> *"Mes chers Mousquetaires,*
>
> *It has come to our royal attention that the configuration vaults of our realm require proper stewardship. Whether you choose to entrust your secrets to the swift couriers of ValKey or to the fortified archives of MongoDB, you must know how to provision these stores with the precision of a Musketeer's blade.*
>
> *By royal decree, this tutorial shall guide you through every step — from selecting your store to verifying its readiness for duty in service of the Crown.*
>
> *Allez, Mousquetaires. The kingdom awaits."*
>
> *— Louis XIII, le Palais du Louvre, ce jour*

---

## Table of Contents

1. [The Two Vaults of the Kingdom](#1-the-two-vaults-of-the-kingdom)
2. [The Default: ValKey](#2-the-default-valkey)
3. [Switching to MongoDB](#3-switching-to-mongodb)
4. [Configuration by Environment](#4-configuration-by-environment)
5. [Docker Compose Setup](#5-docker-compose-setup)
6. [application.yml Reference](#6-applicationyml-reference)
7. [How Spring Selects the Store](#7-how-spring-selects-the-store)
8. [Verifying Your Store is Active](#8-verifying-your-store-is-active)
9. [The ConfigStore Interface](#9-the-configstore-interface)
10. [How SiteConfigurationService Uses the Store](#10-how-siteconfigurationservice-uses-the-store)
11. [Running Tests Against Each Store](#11-running-tests-against-each-store)
12. [Common Configurations](#12-common-configurations)
13. [Troubleshooting](#13-troubleshooting)

---

## 1. The Two Vaults of the Kingdom

The Constants Catalog supports two configuration store backends. You choose one; the application code doesn't care which.

**ValKey** — The swift courier. An in-memory, Redis-compatible key-value store. Fast, supports pub/sub for cache invalidation, but data lives in memory (with append-only file persistence).

**MongoDB** — The fortified archive. A document database that writes to disk. Durable, queryable, but no pub/sub support in standalone mode.

```mermaid
flowchart TD
    SCS["SiteConfigurationService"] --> CS["ConfigStore\n(interface)"]
    CS --> VK["ValKeyConfigStore\n(default)"]
    CS --> MG["MongoConfigStore\n(optional)"]

    style CS fill:#4488ff,color:#fff
    style VK fill:#ff8844,color:#fff
    style MG fill:#44aa44,color:#fff
```

The selection is controlled by a single property: `config.store.type`.

---

## 2. The Default: ValKey

If you set nothing, you get ValKey. It is the default because `matchIfMissing = true` is set on the ValKey bean.

### Start the service

```bash
docker compose --env-file=.env up -d valkey # --env-file=.env.wsl if running from within WSL
```

### Verify it's running

```bash
docker exec const-catalog-valkey valkey-cli PING
```

Expected response: `PONG`

### Default configuration in application.yml

```yaml
valkey:
  host: ${VALKEY_HOST:localhost}
  port: ${VALKEY_PORT:6379}
  password: ${VALKEY_PASSWORD:}
  database: ${VALKEY_DATABASE:0}
  timeout: ${VALKEY_TIMEOUT:5000}
```

Each value has a default after the colon. If you don't set `VALKEY_HOST`, it defaults to `localhost`. In Docker Compose, the backend service sets `VALKEY_HOST=valkey` (the container name) to reach the ValKey container over the Docker network.

### Inspect stored keys

```bash
docker exec const-catalog-valkey valkey-cli KEYS "config:*"
```

Get a specific value:

```bash
docker exec const-catalog-valkey valkey-cli GET "config:db.host"
```

---

## 3. Switching to MongoDB

To use MongoDB instead of ValKey, you set one property: `config.store.type=mongodb`.

### Start the service

```bash
docker compose --env-file=.env --profile=mongodb up -d mongo # --env-file=.env.wsl if running from withing WSL
```

MongoDB runs under the `mongodb` profile, so it won't start unless you explicitly request it.

### Verify it's running

```bash
docker exec const-catalog-mongo mongosh --eval "db.adminCommand('ping')"
```

Expected: `{ ok: 1 }`

### Tell the backend to use MongoDB

There are three ways to set `config.store.type=mongodb`:

**Option A: Environment variable in docker-compose.yml**

Add to the backend service's `environment` section:

```yaml
backend:
  environment:
    - CONFIG_STORE_TYPE=mongodb
    - CONFIG_STORE_MONGODB_URI=mongodb://mongo:27017
    - CONFIG_STORE_MONGODB_DATABASE=const-catalog
```

Note: Spring Boot converts `config.store.type` to the environment variable `CONFIG_STORE_TYPE` (dots become underscores, all caps).

**Option B: Environment variable in .env**

Add to your `.env` file:

```
CONFIG_STORE_TYPE=mongodb
CONFIG_STORE_MONGODB_URI=mongodb://mongo:27017
CONFIG_STORE_MONGODB_DATABASE=const-catalog
```

Then reference them in docker-compose.yml:

```yaml
backend:
  environment:
    - CONFIG_STORE_TYPE=${CONFIG_STORE_TYPE:-valkey}
    - CONFIG_STORE_MONGODB_URI=${CONFIG_STORE_MONGODB_URI:-mongodb://mongo:27017}
    - CONFIG_STORE_MONGODB_DATABASE=${CONFIG_STORE_MONGODB_DATABASE:-const-catalog}
```

**Option C: application.yml (for local development without Docker)**

Add to `application.yml`:

```yaml
config:
  store:
    type: mongodb
    mongodb:
      uri: mongodb://localhost:27017
      database: const-catalog
```

### Inspect stored documents

```bash
docker exec -it const-catalog-mongo mongosh --eval "
  use('const-catalog');
  db.config.find().toArray();
"
```

---

## 4. Configuration by Environment

Here are the complete configuration properties for each store:

### ValKey Properties

| Property | Env Variable | Default | Description |
|---|---|---|---|
| `valkey.host` | `VALKEY_HOST` | `localhost` | ValKey server hostname |
| `valkey.port` | `VALKEY_PORT` | `6379` | ValKey server port |
| `valkey.password` | `VALKEY_PASSWORD` | *(empty)* | Password (if auth enabled) |
| `valkey.database` | `VALKEY_DATABASE` | `0` | Redis database number |
| `valkey.timeout` | `VALKEY_TIMEOUT` | `5000` | Connection timeout (ms) |

### MongoDB Properties

| Property | Env Variable | Default | Description |
|---|---|---|---|
| `config.store.type` | `CONFIG_STORE_TYPE` | `valkey` | Set to `mongodb` to activate |
| `config.store.mongodb.uri` | `CONFIG_STORE_MONGODB_URI` | `mongodb://localhost:27017` | MongoDB connection string |
| `config.store.mongodb.database` | `CONFIG_STORE_MONGODB_DATABASE` | `const-catalog` | Database name |

### Caffeine Cache Properties (applies to both stores)

| Property | Env Variable | Default | Description |
|---|---|---|---|
| `cache.caffeine.max-size` | `CACHE_MAX_SIZE` | `10000` | Max entries in local cache |
| `cache.caffeine.expire-after-write-minutes` | `CACHE_EXPIRE_MINUTES` | `60` | TTL for cached entries |

---

## 5. Docker Compose Setup

### ValKey only (default)

```bash
docker compose --env-file=.env up -d
```

This starts neo4j, valkey, backend, and frontend. No profile needed — ValKey has no profile restriction.

### ValKey + MongoDB (both running)

```bash
docker compose --env-file=.env --profile=mongodb up -d
```

Both are running, but the backend uses whichever `config.store.type` is set. Starting both is useful when you want to run MongoDB tests while the app uses ValKey.

### MongoDB as the primary store

```bash
# Add to .env:
#   CONFIG_STORE_TYPE=mongodb

docker compose --env-file=.env --profile=mongodb up -d
```

The backend reads `CONFIG_STORE_TYPE=mongodb` and creates a `MongoConfigStore` bean instead of `ValKeyConfigStore`.

**Important:** Even when using MongoDB as the config store, ValKey still starts (it has no profile restriction). The backend creates ValKey connection beans regardless — they're just not used by `SiteConfigurationService`. If you wanted to fully disable ValKey, you'd need to add a profile to the valkey service in docker-compose.yml.

---

## 6. application.yml Reference

The current `application.yml` only has explicit ValKey configuration. MongoDB properties are handled entirely through `@Value` defaults in `ConfigStoreConfig.java`.

To make MongoDB configuration explicit, you could add:

```yaml
# Config Store Selection
# ----------------------
# Set config.store.type to choose the backend.
# Default is "valkey" (no change needed for existing deployments).
config:
  store:
    type: ${CONFIG_STORE_TYPE:valkey}
    mongodb:
      uri: ${CONFIG_STORE_MONGODB_URI:mongodb://localhost:27017}
      database: ${CONFIG_STORE_MONGODB_DATABASE:const-catalog}
```

This is optional — the defaults in `ConfigStoreConfig.java` handle it — but makes the configuration self-documenting.

---

## 7. How Spring Selects the Store

The magic happens in `ConfigStoreConfig.java` through `@ConditionalOnProperty`:

```java
@Bean
@ConditionalOnProperty(name = "config.store.type", havingValue = "valkey", matchIfMissing = true)
public ConfigStore valKeyConfigStore(...) { ... }

@Bean
@ConditionalOnProperty(name = "config.store.type", havingValue = "mongodb")
public ConfigStore mongoConfigStore(...) { ... }
```

Spring evaluates these conditions at startup:

```mermaid
flowchart TD
    S["Spring Boot starts"] --> P{"config.store.type = ?"}
    P -->|"not set\n(matchIfMissing)"| VK["Create ValKeyConfigStore bean"]
    P -->|"valkey"| VK
    P -->|"mongodb"| MC["Create MongoClient bean"]
    MC --> MD["Create MongoDatabase bean"]
    MD --> MG["Create MongoConfigStore bean"]
    P -->|"anything else"| ERR["No ConfigStore bean\nStartup fails"]
    VK --> INJ["Inject into SiteConfigurationService"]
    MG --> INJ

    style VK fill:#ff8844,color:#fff
    style MG fill:#44aa44,color:#fff
    style ERR fill:#ff4444,color:#fff
```

Only one `ConfigStore` bean is created. `SiteConfigurationService` has `ConfigStore` as a constructor parameter — Spring injects whichever bean exists.

**What if you set an invalid value?**

If `config.store.type=oracle`, neither condition matches. No `ConfigStore` bean is created. Spring fails at startup with:

```
Parameter 0 of constructor in SiteConfigurationService required a bean
of type 'ConfigStore' that could not be found.
```

The error message tells you exactly what went wrong.

---

## 8. Verifying Your Store is Active

### Check the startup log

When the backend starts, it logs which store was selected:

```
Using ValKey config store backend
```

or

```
Using MongoDB config store backend
```

### Check via the API

The stats endpoint reports the active store:

```bash
curl -s http://localhost:9090/api/stats/health | jq .
```

Or if you have the application running locally (not in Docker):

```bash
curl -s http://localhost:8080/api/stats/health | jq .
```

### Check from inside the container

```bash
docker logs const-catalog-backend 2>&1 | grep "config store"
```

---

## 9. The ConfigStore Interface

Both stores implement the same 8-method contract:

```java
public interface ConfigStore {
    String get(String key);                      // Read one value
    void set(String key, String value);          // Write one value
    boolean delete(String key);                  // Delete one value
    void setBatch(Map<String, String> entries);  // Write many values
    List<String> keysByPrefix(String prefix);    // Find keys by prefix
    Map<String, String> getByPrefix(String prefix); // Find key-values by prefix
    void publishChange(String key);              // Notify cache invalidation
    String storeName();                          // "ValKey" or "MongoDB"
}
```

### How each store implements them

| Method | ValKey | MongoDB |
|---|---|---|
| `get(key)` | `GET config:key` | `find({_id: key})` |
| `set(key, value)` | `SET config:key value` | `replaceOne({_id: key}, doc, upsert)` |
| `delete(key)` | `DEL config:key` | `deleteOne({_id: key})` |
| `setBatch(entries)` | `MSET config:k1 v1 config:k2 v2` | Loop of `replaceOne` calls |
| `keysByPrefix(prefix)` | `KEYS config:prefix*` | `find({_id: /^prefix/})` |
| `getByPrefix(prefix)` | `KEYS` + `GET` per key | `find({_id: /^prefix/})` |
| `publishChange(key)` | `PUBLISH config:changes key` | No-op (standalone) |

**Key differences:**
- ValKey prefixes all keys with `config:` internally. MongoDB uses the key directly as `_id`.
- ValKey's `setBatch` uses `MSET` (one atomic command). MongoDB loops and upserts one by one.
- ValKey has native pub/sub. MongoDB's `publishChange` is a no-op until Change Streams are implemented (requires a replica set).

---

## 10. How SiteConfigurationService Uses the Store

`SiteConfigurationService` is the only consumer of `ConfigStore`. It adds a Caffeine L1 cache on top:

```mermaid
flowchart LR
    REQ["lookup('db.host')"] --> L1{"Caffeine cache\n(in-memory, JVM)"}
    L1 -->|hit| RES["Return value"]
    L1 -->|miss| L2["ConfigStore.get('db.host')"]
    L2 -->|ValKey| VK["GET config:db.host"]
    L2 -->|MongoDB| MG["find({_id: 'db.host'})"]
    VK --> CACHE["Store in Caffeine\nreturn value"]
    MG --> CACHE

    style L1 fill:#4488ff,color:#fff
    style VK fill:#ff8844,color:#fff
    style MG fill:#44aa44,color:#fff
```

- **Cache hit:** Returned immediately from Caffeine. No network call.
- **Cache miss:** `ConfigStore.get(key)` is called. The result is stored in Caffeine for future lookups.
- **Write:** `ConfigStore.set(key, value)` writes to the store. `ConfigStore.publishChange(key)` notifies other instances (ValKey only). The local Caffeine cache is also updated.

This two-tier design means the choice of ValKey vs MongoDB only affects cache-miss latency and write durability. The hot path (cache hits) is identical.

---

## 11. Running Tests Against Each Store

### ValKey tests

```bash
# Make sure ValKey is running
docker compose --env-file=.env up -d valkey

# Run the tests
mvn test -pl const-catalog-backend -Dtest=ValKeyConfigStoreTest
```

### MongoDB tests

```bash
# Make sure MongoDB is running
docker compose --env-file=.env --profile=mongodb up -d mongo

# Run the tests
mvn test -pl const-catalog-backend -Dtest=MongoConfigStoreTest
```

Both test suites skip gracefully if their backing service isn't running. You'll see tests reported as **skipped**, not failed.

### Running both

```bash
docker compose --env-file=.env --profile=mongodb up -d valkey mongo

mvn test -pl const-catalog-backend -Dtest="ValKeyConfigStoreTest,MongoConfigStoreTest"
```

**Remember:** Install the core module first if it has changed:

```bash
mvn install -pl const-catalog-core -DskipTests
```

---

## 12. Common Configurations

### Local development with ValKey (default, no changes needed)

```bash
docker compose --env-file=.env up -d
# Backend uses ValKey at localhost:6379
```

### Local development with MongoDB

`.env`:
```
HOST_SRC_PATH=/home/bmarshall/src
CONFIG_STORE_TYPE=mongodb
```

```bash
docker compose --env-file=.env --profile=mongodb up -d
```

### Docker Compose with MongoDB as primary

`docker-compose.yml` backend environment:
```yaml
backend:
  environment:
    - NEO4J_URI=bolt://neo4j:7687
    - SPRING_PROFILES_ACTIVE=docker
    - VALKEY_HOST=valkey
    - VALKEY_PORT=6379
    - CONFIG_STORE_TYPE=mongodb
    - CONFIG_STORE_MONGODB_URI=mongodb://mongo:27017
    - CONFIG_STORE_MONGODB_DATABASE=const-catalog
```

### Local development without Docker (IDE)

`application.yml` override or VM arguments in your run configuration:

For ValKey:
```
-Dvalkey.host=localhost -Dvalkey.port=6379
```

For MongoDB:
```
-Dconfig.store.type=mongodb
-Dconfig.store.mongodb.uri=mongodb://localhost:27017
-Dconfig.store.mongodb.database=const-catalog
```

### Production with MongoDB and authentication

```yaml
config:
  store:
    type: mongodb
    mongodb:
      uri: mongodb://user:password@mongo-primary:27017,mongo-secondary:27017/const-catalog?replicaSet=rs0&authSource=admin
      database: const-catalog
```

With a replica set, Change Streams become available and `publishChange()` could be implemented for distributed cache invalidation.

---

## 13. Troubleshooting

### "No qualifying bean of type 'ConfigStore'"

`config.store.type` is set to something other than `valkey` or `mongodb`. Check your environment variables:

```bash
docker exec const-catalog-backend env | grep -i config
```

### "Unable to connect to ValKey"

ValKey isn't running, or the hostname is wrong.

```bash
# Check if ValKey is up
docker compose ps valkey

# Check connectivity from the backend container
docker exec const-catalog-backend sh -c "nc -zv valkey 6379"
```

When running locally (not in Docker), the host should be `localhost`, not `valkey`.

### "MongoTimeoutException: Timed out after 30000 ms"

MongoDB isn't running, or the URI is wrong.

```bash
# Check if MongoDB is up
docker compose --profile=mongodb ps mongo

# Test connectivity
docker exec const-catalog-mongo mongosh --eval "db.adminCommand('ping')"
```

Common mistakes:
- Forgot `--profile=mongodb` when starting Docker Compose
- Using `mongo:27017` from outside Docker (should be `localhost:27017`)
- Using `localhost:27017` from inside Docker (should be `mongo:27017`)

### "Backend starts but uses the wrong store"

Check the log:

```bash
docker logs const-catalog-backend 2>&1 | grep "Using.*config store"
```

If it says "Using ValKey" but you expected MongoDB, the `CONFIG_STORE_TYPE` variable isn't reaching the backend. Verify:

```bash
docker exec const-catalog-backend env | grep CONFIG_STORE
```

### MongoDB tests skip with "MongoDB not available"

Start MongoDB first:

```bash
docker compose --env-file=.env --profile=mongodb up -d mongo
```

Then wait for it to be healthy:

```bash
docker compose --profile=mongodb ps
```

The `Status` column should show `Up (healthy)`, not `Up (health: starting)`.

---

## Appendix: Configuring an External MongoDB

When you have a MongoDB instance running outside of Docker Compose — on a remote server, a managed service like Atlas, or a shared development database — you don't need the local `mongo` service at all. You just point the backend at the external URI using environment variables, and both `application.yml` and `docker-compose.yml` pick them up in one fell swoop.

### Step 1: Define the environment variables

Add to your `.env` file:

```
CONFIG_STORE_TYPE=mongodb
CONFIG_STORE_MONGODB_URI=mongodb://user:password@your-external-host:27017
CONFIG_STORE_MONGODB_DATABASE=const-catalog
```

For a replica set or Atlas cluster:

```
CONFIG_STORE_MONGODB_URI=mongodb://user:password@host1:27017,host2:27017,host3:27017/?replicaSet=rs0&authSource=admin
```

For Atlas:

```
CONFIG_STORE_MONGODB_URI=mongodb+srv://user:password@cluster0.abc123.mongodb.net/?retryWrites=true&w=majority
```

### Step 2: Update application.yml (one-time)

Add the config store section if it doesn't already exist:

```yaml
config:
  store:
    type: ${CONFIG_STORE_TYPE:valkey}
    mongodb:
      uri: ${CONFIG_STORE_MONGODB_URI:mongodb://localhost:27017}
      database: ${CONFIG_STORE_MONGODB_DATABASE:const-catalog}
```

The `${VAR:default}` syntax means: use the environment variable if set, otherwise fall back to the default. This single block works for local development (defaults to ValKey), Docker with local mongo, and external MongoDB — all controlled by environment variables.

### Step 3: Update docker-compose.yml (one-time)

Add the environment variables to the backend service:

```yaml
backend:
  environment:
    - NEO4J_URI=bolt://neo4j:7687
    - SPRING_PROFILES_ACTIVE=docker
    - VALKEY_HOST=valkey
    - VALKEY_PORT=6379
    - CONFIG_STORE_TYPE=${CONFIG_STORE_TYPE:-valkey}
    - CONFIG_STORE_MONGODB_URI=${CONFIG_STORE_MONGODB_URI:-mongodb://mongo:27017}
    - CONFIG_STORE_MONGODB_DATABASE=${CONFIG_STORE_MONGODB_DATABASE:-const-catalog}
```

The `${VAR:-default}` syntax (shell/compose) passes the `.env` values into the container. If the variables aren't set, the defaults fall back to the local Docker mongo service.

### Step 4: Start without the local mongo service

```bash
docker compose --env-file=.env up -d
```

No `--profile=mongodb` needed. The backend connects to your external MongoDB via the URI in `.env`. The local `mongo` service stays stopped.

### Why this works in one fell swoop

Both `application.yml` and `docker-compose.yml` reference the same environment variable names:

```mermaid
flowchart LR
    ENV[".env file\nCONFIG_STORE_TYPE=mongodb\nCONFIG_STORE_MONGODB_URI=mongodb://..."] --> DC["docker-compose.yml\npasses vars to container"]
    DC --> APP["application.yml\nresolves vars at startup"]
    APP --> BEAN["ConfigStoreConfig\ncreates MongoConfigStore"]

    style ENV fill:#44aa44,color:#fff
    style BEAN fill:#ff8844,color:#fff
```

Change the `.env` file and everything downstream picks it up. No code changes, no rebuilds. To switch back to ValKey, remove or comment out the three lines in `.env` and restart.

### Verifying the connection

```bash
# Check the backend log
docker logs const-catalog-backend 2>&1 | grep "config store"
# Should show: "Using MongoDB config store backend"

# Test from your local machine (if mongosh is installed)
mongosh "mongodb://user:password@your-external-host:27017" --eval "db.adminCommand('ping')"
```

### Security notes

- **Don't commit `.env` with credentials.** Keep `.env` in `.gitignore` and share credentials through a secure channel.
- **Use `authSource`** in the URI if your credentials are in a different database (commonly `admin`).
- **For TLS/SSL**, append `&tls=true` to the URI. Atlas connections use TLS by default.
