# Constants Catalog Frontend - Developer Guide

## Table of Contents

1. [Overview](#1-overview)
2. [Technology Stack](#2-technology-stack)
3. [Project Structure](#3-project-structure)
4. [Architecture](#4-architecture)
5. [Application Bootstrap](#5-application-bootstrap)
6. [Routing](#6-routing)
7. [Layout System](#7-layout-system)
8. [Component Reference](#8-component-reference)
9. [Page Reference](#9-page-reference)
10. [Custom Hooks](#10-custom-hooks)
11. [API Service Layer](#11-api-service-layer)
12. [Type System](#12-type-system)
13. [Theming and Styling](#13-theming-and-styling)
14. [Build and Deployment](#14-build-and-deployment)
15. [Hard-to-Understand Passages](#15-hard-to-understand-passages)

---

## 1. Overview

The Constants Catalog Frontend is a single-page application (SPA) that provides a visual interface for scanning Java projects, cataloging their constants and configuration parameters into a Neo4j graph database, querying that graph with Cypher, and transforming hard-coded constants into externalised config lookups.

The UI follows a **"Space Command"** dark theme with neon accents, monospaced typography, and terminal-inspired interaction patterns.

---

## 2. Technology Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| UI Framework | React | 18.2 | Component-based rendering |
| Language | TypeScript | 5.3 | Static type safety |
| Build Tool | Vite | 5.0 | Dev server, HMR, production bundling |
| Routing | React Router DOM | 6.21 | Client-side SPA routing |
| Server State | TanStack React Query | 5.17 | Async data fetching, caching, mutations |
| HTTP Client | Axios | 1.6 | REST API communication |
| Styling | Tailwind CSS | 3.4 | Utility-first CSS framework |
| Icons | Lucide React | 0.303 | SVG icon library |
| Utilities | clsx | 2.0 | Conditional class-name joining |
| Production Server | Nginx | alpine | Static file serving, reverse proxy |
| Containerisation | Docker | multi-stage | Reproducible builds |

---

## 3. Project Structure

```
const-catalog-frontend/
├── index.html                 # HTML shell with font preloading
├── package.json               # Dependencies and scripts
├── vite.config.ts             # Vite dev server + API proxy config
├── tailwind.config.js         # Space Command theme tokens
├── postcss.config.js          # PostCSS pipeline (Tailwind + Autoprefixer)
├── tsconfig.json              # TypeScript strict-mode config
├── tsconfig.node.json         # TypeScript config for Vite itself
├── Dockerfile                 # Multi-stage build (Node -> Nginx)
├── nginx.conf                 # Production reverse proxy config
└── src/
    ├── main.tsx               # React entrypoint; QueryClient setup
    ├── App.tsx                # BrowserRouter + route definitions
    ├── index.css              # Tailwind directives + global theme styles
    ├── components/            # Reusable UI components
    │   ├── Layout.tsx         # Shell: Header + Sidebar + <Outlet> + CommandLine
    │   ├── Header.tsx         # HUD top-bar with health polling
    │   ├── Sidebar.tsx        # Navigation links
    │   ├── CommandLine.tsx    # Terminal footer (executes ad-hoc Cypher)
    │   ├── CommandLineResults.tsx  # Slide-up results panel
    │   ├── ResultsTable.tsx   # Dynamic data grid for query output
    │   ├── FileViewerModal.tsx    # Full-screen source file viewer
    │   └── DiffViewer.tsx     # Side-by-side code comparison
    ├── pages/                 # Route-level page components
    │   ├── Dashboard.tsx      # Stats overview (/ route)
    │   ├── ScanPage.tsx       # Project scanner (/scan)
    │   ├── QueryPage.tsx      # Cypher console (/query)
    │   └── TransformPage.tsx  # Code transformer (/transform)
    ├── hooks/
    │   └── useScanProgress.ts # SSE hook for real-time scan events
    ├── services/
    │   └── api.ts             # Axios client + all API functions
    └── types/
        └── index.ts           # TypeScript interfaces mirroring backend DTOs
```

---

## 4. Architecture

### 4.1 High-Level Component Tree

```mermaid
graph TD
    main["main.tsx<br/><small>React.StrictMode + QueryClientProvider</small>"]
    app["App.tsx<br/><small>BrowserRouter + Routes</small>"]
    layout["Layout.tsx<br/><small>Shell structure</small>"]
    header["Header.tsx"]
    sidebar["Sidebar.tsx"]
    outlet["&lt;Outlet /&gt;<br/><small>Current page</small>"]
    cmdline["CommandLine.tsx"]
    cmdresults["CommandLineResults.tsx"]
    dash["Dashboard.tsx"]
    scan["ScanPage.tsx"]
    query["QueryPage.tsx"]
    transform["TransformPage.tsx"]

    main --> app
    app --> layout
    layout --> header
    layout --> sidebar
    layout --> outlet
    layout --> cmdline
    cmdline --> cmdresults
    outlet --> dash
    outlet --> scan
    outlet --> query
    outlet --> transform
```

### 4.2 Data Flow Architecture

```mermaid
graph LR
    subgraph Browser
        RC["React Components"]
        RQ["React Query Cache<br/><small>staleTime: 30s</small>"]
        AX["Axios Client<br/><small>baseURL: /api</small>"]
    end

    subgraph "Dev Server (Vite)"
        VP["Vite Proxy<br/><small>:3000 → :8080</small>"]
    end

    subgraph "Prod Server (Nginx)"
        NX["Nginx<br/><small>:80 → backend:8080</small>"]
    end

    subgraph Backend
        API["Spring Boot REST<br/><small>:8080/api/*</small>"]
        NEO["Neo4j Graph DB"]
    end

    RC <--> RQ
    RQ <--> AX
    AX --> VP
    AX --> NX
    VP --> API
    NX --> API
    API <--> NEO
```

### 4.3 Component Class Diagram

```mermaid
classDiagram
    class Layout {
        +render() JSX
    }
    class Header {
        -health: HealthResponse
        -isLoading: boolean
        -isError: boolean
        +render() JSX
    }
    class Sidebar {
        +render() JSX
    }
    class CommandLine {
        -command: string
        -history: string[]
        -historyIndex: number
        -isLoading: boolean
        -result: QueryResponse
        -isPanelOpen: boolean
        -inputRef: RefObject
        +handleSubmit(e) void
        +handleKeyDown(e) void
        +handleClose() void
        +render() JSX
    }
    class CommandLineResults {
        <<props>>
        +data: QueryResponse
        +isOpen: boolean
        +onToggle() void
        +onClose() void
        +render() JSX
    }
    class ResultsTable {
        <<props>>
        +data: QueryResponse
        +onFileClick(path) void
        +render() JSX
    }
    class FileViewerModal {
        <<props>>
        +filePath: string
        +onClose() void
        -fileData: FileContentResponse
        -loading: boolean
        -error: string
        +render() JSX
    }
    class DiffViewer {
        <<props>>
        +originalContent: string
        +transformedContent: string
        +filePath: string
        +onClose() void
        -leftRef: RefObject
        -rightRef: RefObject
        +render() JSX
    }
    class Dashboard {
        -stats: StatsResponse
        +render() JSX
    }
    class QueryPage {
        -cypher: string
        -result: QueryResponse
        -selectedQuery: string
        -fileViewerPath: string
        +handlePreCannedSelect(id) void
        +handleExecuteQuery(e) void
        +render() JSX
    }
    class ScanPage {
        -projectPath: string
        -scanResult: ScanResponse
        -watchProgress: boolean
        +handleScan(e) void
        +render() JSX
    }
    class TransformPage {
        -projectPath: string
        -dryRun: boolean
        -result: TransformResponse
        -comparison: FileComparisonResponse
        +handleTransform(e) void
        +handleViewComparison(entry) void
        +render() JSX
    }

    Layout *-- Header
    Layout *-- Sidebar
    Layout *-- CommandLine
    CommandLine *-- CommandLineResults
    CommandLineResults *-- ResultsTable
    QueryPage *-- ResultsTable
    QueryPage *-- FileViewerModal
    TransformPage *-- DiffViewer
    ScanPage ..> useScanProgress : uses
    Dashboard ..> StatCard : renders
    Dashboard ..> InsightCard : renders
    ScanPage ..> ResultStat : renders
```

---

## 5. Application Bootstrap

### `main.tsx`

This is the React entrypoint. It performs three things:

1. **Creates a `QueryClient`** with application-wide defaults:
   - `staleTime: 30000` — cached data is considered fresh for 30 seconds before React Query refetches in the background.
   - `retry: 1` — failed requests are retried once, then surface the error.

2. **Wraps the app** in `<React.StrictMode>` (development double-renders to catch side-effects) and `<QueryClientProvider>` (makes the cache available to all `useQuery`/`useMutation` calls).

3. **Mounts** into the `#root` div declared in `index.html`.

### Bootstrap Sequence Diagram

```mermaid
sequenceDiagram
    participant Browser
    participant index.html
    participant main.tsx
    participant App.tsx
    participant Layout.tsx

    Browser->>index.html: Load page
    index.html->>Browser: Load JetBrains Mono font
    index.html->>main.tsx: <script type="module">
    main.tsx->>main.tsx: Create QueryClient (staleTime=30s, retry=1)
    main.tsx->>App.tsx: Render <App /> inside StrictMode + QueryClientProvider
    App.tsx->>Layout.tsx: BrowserRouter matches "/" → render Layout
    Layout.tsx->>Browser: Render Header + Sidebar + Outlet + CommandLine
```

---

## 6. Routing

### `App.tsx`

All routes are nested under a single `<Layout />` wrapper using React Router's `<Outlet />` pattern:

| Path | Component | Description |
|------|-----------|-------------|
| `/` | `<Dashboard />` | System overview with stat cards |
| `/scan` | `<ScanPage />` | Scan a Java project into the graph |
| `/query` | `<QueryPage />` | Execute Cypher queries (pre-built or ad-hoc) |
| `/transform` | `<TransformPage />` | Replace constants with config lookups |

Because `<Layout />` is the parent route element, every page inherits the Header, Sidebar, and CommandLine footer.

### Route Resolution Sequence

```mermaid
sequenceDiagram
    participant User
    participant BrowserRouter
    participant Routes
    participant Layout
    participant Outlet

    User->>BrowserRouter: Navigate to /query
    BrowserRouter->>Routes: Match path="/query"
    Routes->>Layout: Render parent <Layout />
    Layout->>Outlet: Render <Outlet /> in main area
    Outlet->>Routes: Resolve child route
    Routes->>Outlet: Render <QueryPage />
```

---

## 7. Layout System

### `Layout.tsx`

The Layout establishes the application shell as a full-height flex column:

```
┌──────────────────────────────────────────────────┐
│  Header (fixed height, border-b)                 │
├───────────┬──────────────────────────────────────┤
│           │                                      │
│  Sidebar  │   Main Content (<Outlet />)          │
│  (w-64)   │   (flex-1, scrollable)               │
│           │                                      │
│           │                                      │
├───────────┴──────────────────────────────────────┤
│  CommandLineResults (slide-up, conditional)       │
├──────────────────────────────────────────────────┤
│  CommandLine footer (fixed height, border-t)     │
└──────────────────────────────────────────────────┘
```

The `min-h-screen flex flex-col` on the outer div ensures the footer always sticks to the bottom. The middle `flex flex-1` section splits horizontally between the Sidebar and the main content area.

**Key detail:** `CommandLine` returns a React fragment (`<>...</>`) containing both the `CommandLineResults` panel and the `<footer>`. This means the results panel slots naturally between the main content and the footer without any changes to `Layout.tsx`.

---

## 8. Component Reference

### 8.1 `Header.tsx`

**Purpose:** HUD-style top bar showing application branding and live system health.

**State Management:** Uses `useQuery` to poll `GET /api/stats/health` every 30 seconds.

**Sections:**
- **Left:** Application logo `<CONST_CATALOG/>` with subtitle
- **Right:** Neo4j connection status (green/red dot), system status text, project count

```mermaid
sequenceDiagram
    participant Header
    participant ReactQuery
    participant API

    loop Every 30 seconds
        Header->>ReactQuery: useQuery(['health'])
        ReactQuery->>API: GET /api/stats/health
        API-->>ReactQuery: { status, database, projectCount }
        ReactQuery-->>Header: Re-render with health data
    end
```

**Status dot logic:**
- `health.status === 'healthy'` → green pulsing dot + "ONLINE"
- Query loading → "CHECKING..."
- Query error → "ERROR" + red dot

---

### 8.2 `Sidebar.tsx`

**Purpose:** Vertical navigation with route links.

**Pattern:** Declarative `navItems` array drives the navigation. Each item maps to a `<NavLink>` from React Router.

```typescript
const navItems = [
  { to: '/',          icon: LayoutDashboard, label: 'Dashboard',  description: 'System Overview' },
  { to: '/scan',      icon: Scan,            label: 'Scan',       description: 'Analyze Projects' },
  { to: '/query',     icon: Terminal,         label: 'Query',      description: 'Execute Cypher' },
  { to: '/transform', icon: Wand2,           label: 'Transform',  description: 'Replace Constants' },
]
```

**Active state styling:** `NavLink`'s render-prop `className` function receives `{ isActive }`. Active links get a cyan background and border; inactive links are dim and brighten on hover. The `clsx` utility handles the conditional class composition.

---

### 8.3 `CommandLine.tsx`

**Purpose:** Terminal-style footer for executing ad-hoc Cypher queries from any page.

**State:**

| State Variable | Type | Purpose |
|---|---|---|
| `command` | `string` | Current input text |
| `history` | `string[]` | All previously executed commands |
| `historyIndex` | `number` | Position in history (-1 = not browsing) |
| `isLoading` | `boolean` | True while query is in flight |
| `result` | `QueryResponse \| null` | Last query response |
| `isPanelOpen` | `boolean` | Whether results panel is visible |

**Key behaviours:**

1. **Submit** (`Enter`): Calls `executeQuery({ cypher })`, stores result, opens panel.
2. **History navigation** (`ArrowUp`/`ArrowDown`): Walks backwards/forwards through `history[]`.
3. **Escape**: Closes the results panel (minimise).
4. **Close (X button)**: Closes panel AND clears the result entirely.
5. **"Show results" link**: Re-opens a minimised panel without re-executing the query.

**Right-side indicator logic:**
- Loading → spinning `<Loader2>` icon
- Result exists but panel closed → clickable "Show results (N)" link
- Otherwise → "Press Enter to execute"

```mermaid
sequenceDiagram
    participant User
    participant CommandLine
    participant API
    participant CommandLineResults

    User->>CommandLine: Type Cypher + press Enter
    CommandLine->>CommandLine: Push to history, clear input
    CommandLine->>API: POST /api/query/execute { cypher }
    API-->>CommandLine: QueryResponse
    CommandLine->>CommandLine: setResult(response), setIsPanelOpen(true)
    CommandLine->>CommandLineResults: Render with data + isOpen=true
    CommandLineResults->>User: Display slide-up results panel

    User->>CommandLine: Press Escape
    CommandLine->>CommandLine: setIsPanelOpen(false)
    Note over CommandLineResults: Panel hidden, result preserved

    User->>CommandLine: Click "Show results (N)"
    CommandLine->>CommandLine: setIsPanelOpen(true)
    CommandLine->>CommandLineResults: Re-render panel
```

---

### 8.4 `CommandLineResults.tsx`

**Purpose:** Expandable results panel displayed above the CommandLine footer.

**Props:**

| Prop | Type | Description |
|------|------|-------------|
| `data` | `QueryResponse` | The query result to display |
| `isOpen` | `boolean` | Controls visibility |
| `onToggle` | `() => void` | Called when minimise button clicked |
| `onClose` | `() => void` | Called when X button clicked |

**Rendering:** When `isOpen` is `false`, returns `null` (completely unmounted). When open, renders a header bar with row count and minimize/close buttons, then delegates to `<ResultsTable data={data} />` for the data grid.

**Animation:** Uses the custom `animate-slide-up` Tailwind class which transitions from `maxHeight: 0, opacity: 0` to `maxHeight: 50vh, opacity: 1` over 200ms.

**Scroll containment:** The body div is capped at `max-h-[50vh]` with `overflow-auto` to prevent the results from consuming the entire screen.

---

### 8.5 `ResultsTable.tsx`

**Purpose:** Dynamic data grid that renders any Cypher query result.

**Props:**

| Prop | Type | Description |
|------|------|-------------|
| `data` | `QueryResponse` | Columns, rows, success/error state |
| `onFileClick` | `(path: string) => void` | Optional callback for clickable file names |

**Rendering paths:**
1. `data.success === false` → red error box with `data.error`
2. `data.rows` is empty → "No results found" placeholder
3. Normal → `<table>` with dynamic columns from `data.columns`

**File click pattern (hard to understand):**

The component hides the `filePath` column from display but uses its values as navigation targets. When a cell is in a "file column" (`file` or `definedIn`) AND the row has a `filePath` value AND `onFileClick` is provided, the cell renders as a clickable button instead of plain text.

```typescript
// filePath column is filtered out of display columns
const columns = allColumns.filter((col) => col !== 'filePath')

// But used as the click target for file-name columns
const isClickable = hasFilePath && fileColumns.has(col) && row.filePath && onFileClick
```

**`formatCellValue` helper:** Recursively formats cell values — `null`/`undefined` become `'-'`, arrays are joined with commas, objects are JSON-stringified, everything else is `String()`.

---

### 8.6 `FileViewerModal.tsx`

**Purpose:** Full-screen overlay for viewing source file contents with line numbers.

**Lifecycle:**

```mermaid
sequenceDiagram
    participant QueryPage
    participant FileViewerModal
    participant API

    QueryPage->>FileViewerModal: Mount with filePath
    FileViewerModal->>API: GET /api/files/content?path=...
    API-->>FileViewerModal: { path, fileName, content, lineCount }
    FileViewerModal->>FileViewerModal: Split content into lines, render table

    alt User presses Escape
        FileViewerModal->>QueryPage: onClose()
    else User clicks backdrop
        FileViewerModal->>QueryPage: onClose()
    else User clicks X button
        FileViewerModal->>QueryPage: onClose()
    end
```

**Stale closure prevention (hard to understand):**

The `useEffect` that fetches file content uses a `cancelled` flag to avoid setting state on an unmounted component:

```typescript
useEffect(() => {
  let cancelled = false
  async function fetchFile() {
    // ... fetch ...
    if (!cancelled) { setFileData(data) }
  }
  fetchFile()
  return () => { cancelled = true }  // cleanup on unmount or filePath change
}, [filePath])
```

This pattern is necessary because the async `fetchFile` may resolve after the component unmounts or the `filePath` prop changes. Without it, React would log a "can't perform state update on unmounted component" warning and potentially display stale data.

**Escape key handling:** Uses a `useCallback`-wrapped handler registered via `addEventListener('keydown', ...)`. The `useCallback` dependency on `onClose` ensures the event listener is refreshed if the parent changes the callback identity.

---

### 8.7 `DiffViewer.tsx`

**Purpose:** Side-by-side code comparison modal showing original and transformed file contents.

**Synchronized scrolling (hard to understand):**

Both panels must scroll together. This is implemented with a `syncing` guard flag:

```typescript
useEffect(() => {
  let syncing = false

  const handleLeftScroll = () => {
    if (syncing) return    // prevent infinite loop
    syncing = true
    right.scrollTop = left.scrollTop
    syncing = false
  }

  const handleRightScroll = () => {
    if (syncing) return
    syncing = true
    left.scrollTop = right.scrollTop
    syncing = false
  }

  left.addEventListener('scroll', handleLeftScroll)
  right.addEventListener('scroll', handleRightScroll)
  // cleanup ...
}, [])
```

**Why the guard is needed:** When the left panel scrolls, `handleLeftScroll` sets `right.scrollTop`, which fires the `scroll` event on the right panel, which would call `handleRightScroll`, which would set `left.scrollTop` again — creating an infinite loop. The `syncing` boolean breaks the cycle.

**Line diff highlighting:** Changed lines are detected by simple string inequality (`origLine !== transLine`). Left-side changes get a red border/background; right-side changes get green. This is a line-level diff, not a character-level diff.

**Line count normalisation:** The viewer uses `Math.max(origLines.length, transLines.length)` so both panels always have the same number of rows, keeping the line numbers aligned even if one file is longer.

---

## 9. Page Reference

### 9.1 `Dashboard.tsx`

**Route:** `/`

**Data fetching:** `useQuery(['stats'], getStats)` — fetches `GET /api/stats`.

**Sub-components (file-local):**

| Component | Props | Purpose |
|-----------|-------|---------|
| `StatCard` | `icon`, `label`, `value`, `color` | Coloured metric tile |
| `InsightCard` | `title`, `description`, `action`, `href` | Clickable link card |
| `LoadingState` | none | Pulsing "Loading..." placeholder |
| `ErrorState` | none | Red error message |

**Bar chart rendering (hard to understand):**

The "Constants by Type" section renders proportional bars using inline `width` styles:

```typescript
width: `${Math.min(100, (item.count / stats.constantCount) * 200)}px`
```

The formula scales each type's count relative to the total constant count, multiplied by 200px (so a type that accounts for 50% of all constants gets a 100px bar). `Math.min(100, ...)` caps at 100px to prevent overflow when a single type dominates.

---

### 9.2 `ScanPage.tsx`

**Route:** `/scan`

**Core interaction:**
1. User enters a project path and clicks "Scan Project"
2. If "Watch scan progress" is checked, an SSE connection is opened via `useScanProgress`
3. A `POST /api/scan` mutation fires simultaneously
4. Real-time progress events update a live progress bar and scrolling file list
5. When the scan completes, the SSE connection closes and results are displayed

```mermaid
sequenceDiagram
    participant User
    participant ScanPage
    participant useScanProgress
    participant API_REST as API (REST)
    participant API_SSE as API (SSE)

    User->>ScanPage: Enter path, click "Scan Project"

    alt watchProgress is true
        ScanPage->>useScanProgress: startStreaming(projectPath)
        useScanProgress->>API_SSE: EventSource(/api/scan/stream?projectPath=...)
        API_SSE-->>useScanProgress: progress events (FILE_DISCOVERED, FILE_PARSING, FILE_PARSED)
        useScanProgress-->>ScanPage: Re-render with latestFiles, currentEvent, isConnected
    end

    ScanPage->>API_REST: POST /api/scan { projectPath }
    Note over API_REST: Scanning runs...

    loop Each file processed
        API_SSE-->>useScanProgress: { eventType, fileName, fileIndex, totalFiles, ... }
        useScanProgress-->>ScanPage: Update progress bar
    end

    API_SSE-->>useScanProgress: SCAN_COMPLETE event
    useScanProgress->>useScanProgress: stopStreaming()
    API_REST-->>ScanPage: ScanResponse
    ScanPage->>ScanPage: Display results summary
```

**Progress percentage calculation:**
```typescript
const progressPercent = currentEvent?.totalFiles
  ? Math.round((currentEvent.fileIndex / currentEvent.totalFiles) * 100)
  : 0
```

**Sub-component (file-local):**

| Component | Props | Purpose |
|-----------|-------|---------|
| `ResultStat` | `label`, `value`, `highlight?` | Summary metric in results card |

---

### 9.3 `QueryPage.tsx`

**Route:** `/query`

**Dual-mode interface:**
- **Left panel (1/3 width):** Pre-canned queries grouped by category
- **Right panel (2/3 width):** Cypher text editor + results table

**Query parameter deep-linking (hard to understand):**

The page reads `?q=` from the URL to auto-select and execute a pre-canned query:

```typescript
const [searchParams] = useSearchParams()

useEffect(() => {
  const queryId = searchParams.get('q')
  if (queryId && preCannedQueries) {
    const query = preCannedQueries.find((q) => q.id === queryId)
    if (query) {
      setSelectedQuery(queryId)
      handlePreCannedSelect(queryId)
    }
  }
}, [searchParams, preCannedQueries])
```

This enables the Dashboard's "Quick Insights" cards to link directly to `/query?q=config-candidates` and have the query execute immediately on page load.

**Category grouping:**
```typescript
const queryCategories = preCannedQueries?.reduce((acc, query) => {
  const category = query.category || 'OTHER'
  if (!acc[category]) acc[category] = []
  acc[category].push(query)
  return acc
}, {} as Record<string, PreCannedQuery[]>)
```
This `reduce` transforms a flat array of queries into a `{ CATEGORY: [query, ...] }` map used to render collapsible category sections.

**File viewer integration:** When `ResultsTable` fires `onFileClick`, `QueryPage` captures the path into `fileViewerPath` state, which conditionally renders `<FileViewerModal>`.

```mermaid
sequenceDiagram
    participant User
    participant QueryPage
    participant ResultsTable
    participant FileViewerModal
    participant API

    User->>QueryPage: Click pre-canned query "Config Candidates"
    QueryPage->>API: GET /api/query/precanned/config-candidates
    API-->>QueryPage: QueryResponse with rows
    QueryPage->>ResultsTable: Render results

    User->>ResultsTable: Click on file name cell
    ResultsTable->>QueryPage: onFileClick("/src/com/example/Config.java")
    QueryPage->>FileViewerModal: Mount with filePath
    FileViewerModal->>API: GET /api/files/content?path=...
    API-->>FileViewerModal: File contents
    FileViewerModal->>User: Display file with line numbers
```

---

### 9.4 `TransformPage.tsx`

**Route:** `/transform`

**Workflow:**
1. Enter project path, toggle dry-run mode
2. Click "Dry Run" or "Transform"
3. View summary stats (transformed / skipped / failed)
4. Click "View" on any entry to see a before/after diff

**Dry-run toggle:** The `dryRun` state (default `true`) is sent with the transform request. In dry-run mode, the backend reports what *would* change without modifying files.

**Status icons (file-local function):**
```typescript
const statusIcon = (status: string) => {
  switch (status) {
    case 'TRANSFORMED': return <CheckCircle className="..." />
    case 'SKIPPED':     return <SkipForward className="..." />
    case 'FAILED':      return <AlertTriangle className="..." />
    default:            return null
  }
}
```

**Diff viewer flow:**

```mermaid
sequenceDiagram
    participant User
    participant TransformPage
    participant API
    participant DiffViewer

    User->>TransformPage: Click "View" on a transform entry
    TransformPage->>API: GET /api/transform/compare?path=entry.filePath
    API-->>TransformPage: { originalContent, transformedContent, filePath }
    TransformPage->>DiffViewer: Mount with content strings
    DiffViewer->>User: Side-by-side comparison

    User->>DiffViewer: Click X or click backdrop
    DiffViewer->>TransformPage: onClose()
    TransformPage->>TransformPage: setComparison(null)
```

---

## 10. Custom Hooks

### `useScanProgress.ts`

**Purpose:** Abstracts the Server-Sent Events (SSE) lifecycle for real-time scan progress.

**Return value:**

| Field | Type | Description |
|-------|------|-------------|
| `events` | `ScanProgressEvent[]` | All received events since streaming started |
| `isConnected` | `boolean` | Whether the EventSource connection is open |
| `latestFiles` | `string[]` | Rolling window of last 25 file names |
| `currentEvent` | `ScanProgressEvent \| null` | Most recently received event |
| `startStreaming` | `(projectPath: string) => void` | Opens an SSE connection |
| `stopStreaming` | `() => void` | Closes the SSE connection |

**EventSource lifecycle (hard to understand):**

The hook stores the `EventSource` instance in a `useRef` (not state) because:
1. Changing a ref doesn't trigger re-renders
2. The ref is accessible inside callbacks without stale closure issues
3. `startStreaming` can close the previous connection synchronously before opening a new one

```typescript
const eventSourceRef = useRef<EventSource | null>(null)

const startStreaming = useCallback((projectPath: string) => {
  stopStreaming()          // Close any existing connection
  setEvents([])            // Reset event history
  setCurrentEvent(null)

  const eventSource = new EventSource(url)
  eventSourceRef.current = eventSource  // Store in ref, not state

  eventSource.addEventListener('progress', ...)
  eventSource.addEventListener('complete', ...)
  eventSource.addEventListener('error', ...)
}, [stopStreaming])
```

**Named SSE events:** The backend sends named events (`progress`, `complete`, `error`) rather than generic `message` events. This is why the code uses `addEventListener('progress', ...)` instead of `eventSource.onmessage`.

**Rolling window:**
```typescript
const latestFiles = events
  .filter((e) => e.fileName)
  .slice(-25)
  .map((e) => e.fileName)
```

This is derived (computed on every render) rather than stored in state. It filters events to only those with file names, takes the last 25, and extracts just the file name strings. This keeps the scrolling file list in ScanPage bounded.

---

## 11. API Service Layer

### `api.ts`

All backend communication goes through a single Axios instance:

```typescript
const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})
```

### Endpoint Map

```mermaid
classDiagram
    class APIService {
        +scanProject(ScanRequest) ScanResponse
        +getScanStreamUrl(string) string
        +getPreCannedQueries() PreCannedQuery[]
        +executePreCannedQuery(string) QueryResponse
        +executeQuery(QueryRequest) QueryResponse
        +getStats() StatsResponse
        +healthCheck() HealthResponse
        +getFileContent(string) FileContentResponse
        +transformProject(TransformRequest) TransformResponse
        +getFileComparison(string) FileComparisonResponse
    }
```

| Function | Method | Endpoint | Used By |
|----------|--------|----------|---------|
| `scanProject` | POST | `/api/scan` | ScanPage |
| `getScanStreamUrl` | — | `/api/scan/stream?projectPath=...` | useScanProgress (SSE) |
| `getPreCannedQueries` | GET | `/api/query/precanned` | QueryPage |
| `executePreCannedQuery` | GET | `/api/query/precanned/{id}` | QueryPage |
| `executeQuery` | POST | `/api/query/execute` | QueryPage, CommandLine |
| `getStats` | GET | `/api/stats` | Dashboard |
| `healthCheck` | GET | `/api/stats/health` | Header |
| `getFileContent` | GET | `/api/files/content?path=...` | FileViewerModal |
| `transformProject` | POST | `/api/transform` | TransformPage |
| `getFileComparison` | GET | `/api/transform/compare?path=...` | TransformPage |

**`getScanStreamUrl` is different:** It returns a URL string rather than making an HTTP call, because SSE connections use the browser's `EventSource` API directly, not Axios.

---

## 12. Type System

### `types/index.ts`

All interfaces mirror the backend's Java DTOs. This ensures compile-time type safety across the API boundary.

```mermaid
classDiagram
    class ScanRequest {
        +projectPath: string
    }
    class ScanResponse {
        +success: boolean
        +message: string
        +projectPath?: string
        +projectName?: string
        +scannedAt?: string
        +javaFilesScanned?: number
        +propertyFilesScanned?: number
        +constantsFound?: number
        +parametersFound?: number
        +parameterUsagesFound?: number
    }
    class QueryRequest {
        +cypher: string
    }
    class QueryResponse {
        +success: boolean
        +error?: string
        +columns?: string[]
        +rows?: Record~string, unknown~[]
        +rowCount?: number
    }
    class PreCannedQuery {
        +id: string
        +name: string
        +description: string
        +category: string
        +cypher?: string
    }
    class StatsResponse {
        +projectCount: number
        +fileCount: number
        +constantCount: number
        +parameterCount: number
        +constantsByType?: TypeCount[]
        +parametersByPrefix?: PrefixCount[]
        +topFiles?: FileCount[]
    }
    class HealthResponse {
        +status: string
        +database: string
        +projectCount: number
    }
    class FileContentResponse {
        +path: string
        +fileName: string
        +content: string
        +lineCount: number
    }
    class ScanProgressEvent {
        +eventType: string
        +fileName: string
        +filePath: string
        +fileIndex: number
        +totalFiles: number
        +constantsFound: number
        +parametersFound: number
        +timestamp: string
    }
    class TransformRequest {
        +projectPath: string
        +dryRun: boolean
    }
    class TransformResponse {
        +success: boolean
        +message: string
        +projectPath: string
        +transformedAt: string
        +dryRun: boolean
        +totalTransformed: number
        +totalSkipped: number
        +totalFailed: number
        +entries: TransformEntry[]
    }
    class TransformEntry {
        +filePath: string
        +className: string
        +constantName: string
        +propertyKey: string
        +originalValue: string
        +originalType: string
        +lineNumber: number
        +status: string
        +message: string
        +originalContent?: string
        +transformedContent?: string
        +backupFilePath?: string
    }
    class FileComparisonResponse {
        +filePath: string
        +originalContent: string
        +transformedContent: string
        +changes: string[]
    }

    TransformResponse *-- TransformEntry
    ScanRequest ..> ScanResponse : request/response
    QueryRequest ..> QueryResponse : request/response
    TransformRequest ..> TransformResponse : request/response
```

**`QueryResponse.rows` uses `Record<string, unknown>[]`:** This is the most flexible row type because Cypher queries can return arbitrary column shapes. Each row is a dictionary where keys are column names and values are unknown (could be string, number, array, nested object, null). The `ResultsTable.formatCellValue` function handles rendering all of these cases.

---

## 13. Theming and Styling

### Design System

The "Space Command" theme is built on three colour families:

| Family | Tokens | Usage |
|--------|--------|-------|
| `space-*` | `black`, `darker`, `dark`, `medium`, `light` | Background layers (darkest to lightest) |
| `neon-*` | `cyan`, `green`, `blue`, `purple`, `pink`, `orange`, `red` | Accents, borders, interactive states |
| `terminal-*` | `text`, `dim`, `bright` | Text hierarchy |

### Background Layering

```
space-black   (#0a0a0f) → Page background (body)
space-darker  (#0d0d14) → Header, Sidebar, Footer, Card backgrounds
space-dark    (#12121a) → Sub-headers, secondary panels
space-medium  (#1a1a24) → Table headers, hover states
space-light   (#252530) → Borders, subtle dividers
```

### CSS Class System (`index.css`)

The global stylesheet defines reusable component classes using Tailwind's `@apply`:

| Class | Purpose |
|-------|---------|
| `.btn` | Base button (padding, rounded, transitions, disabled state) |
| `.btn-primary` | Cyan-accented action button with neon glow on hover |
| `.btn-secondary` | Subdued button for secondary actions |
| `.btn-danger` | Red-accented destructive action button |
| `.data-table` | Full-width table with styled headers and hover rows |
| `.neon-border` | Subtle glowing border with inset box-shadow |
| `.status-dot` | 8x8 circle indicator with `.online`, `.offline`, `.pending` variants |
| `.code-block` | Styled preformatted code container |

### Custom Animations

| Animation | Duration | Easing | Description |
|-----------|----------|--------|-------------|
| `pulse-slow` | 3s | cubic-bezier | Gentle pulse for status indicators |
| `glow` | 2s | ease-in-out alternate | Oscillating neon box-shadow |
| `slide-up` | 0.2s | ease-out forwards | Panel entrance from 0 to 50vh height |

---

## 14. Build and Deployment

### Development

```bash
npm install        # Install dependencies
npm run dev        # Start Vite dev server on :3000
```

Vite proxies `/api` requests to `http://localhost:8080` (the Spring Boot backend).

### Production Build

The Dockerfile uses a **multi-stage build:**

```mermaid
graph LR
    subgraph "Stage 1: Builder (node:20-alpine)"
        A["npm install"] --> B["npm run build<br/>(tsc + vite build)"]
        B --> C["dist/ folder<br/>(static assets)"]
    end

    subgraph "Stage 2: Runtime (nginx:alpine)"
        D["Copy nginx.conf"]
        E["Copy dist/ to /usr/share/nginx/html"]
        D --> F["Serve on port 80"]
        E --> F
    end

    C --> E
```

### Nginx Configuration

| Concern | Configuration |
|---------|--------------|
| **API Proxy** | `location /api/` proxies to `http://backend:8080/api/` |
| **SPA Routing** | `try_files $uri $uri/ /index.html` — all non-file routes serve `index.html` |
| **SSE Support** | `proxy_http_version 1.1` + Upgrade headers for long-lived connections |
| **Timeouts** | 600s connect/send/read timeouts for long-running scans |
| **Static Assets** | `*.js`, `*.css`, images cached for 1 year with immutable header |
| **Compression** | gzip enabled for text/CSS/JSON/JS/XML |

### Docker Compose

```bash
docker compose --env-file .env.wsl up -d --build frontend
```

The `--build` flag forces a rebuild of the image; `up -d` replaces the running container.

---

## 15. Hard-to-Understand Passages

This section collects all the non-obvious code patterns in one place.

### 15.1 ResultsTable Hidden `filePath` Column

**File:** `ResultsTable.tsx`

The backend includes a `filePath` column in query results that contains the container-absolute path to a file. This path is *not* displayed in the table but is used as the navigation target when a user clicks on a file name cell.

```typescript
const allColumns = data.columns || []
const hasFilePath = allColumns.includes('filePath')
const columns = allColumns.filter((col) => col !== 'filePath') // hidden from display

const fileColumns = new Set(['file', 'definedIn']) // columns whose text IS a file name

// Per cell: is this a file-name column with a filePath available?
const isClickable = hasFilePath && fileColumns.has(col) && row.filePath && onFileClick
```

The separation exists because `file` or `definedIn` might show a short display name (e.g., `Constants.java`) while `filePath` holds the full path needed by the API (e.g., `/app/src/main/java/com/example/Constants.java`).

---

### 15.2 CommandLine History Navigation

**File:** `CommandLine.tsx`

The history is stored chronologically (`oldest → newest`). The `historyIndex` represents how many steps *back* from the end the user has navigated:

```
history = ["query A", "query B", "query C"]
                                         ↑ historyIndex = 0 (most recent)
                              ↑ historyIndex = 1
                   ↑ historyIndex = 2 (oldest)

historyIndex = -1 means "not browsing history" → input shows typed text
```

**ArrowUp:** Increments `historyIndex` (go further back in time), capped at `history.length - 1`.

**ArrowDown:** Decrements `historyIndex` (go towards present). At -1, restores the empty input.

The command at position `historyIndex` is `history[history.length - 1 - historyIndex]`.

---

### 15.3 DiffViewer Synchronized Scrolling Guard

**File:** `DiffViewer.tsx`

See [Section 8.7](#87-diffviewertsx) for the full explanation. The `syncing` flag is a local variable (not state) that prevents an infinite scroll-event loop between the two panels. It works because JavaScript is single-threaded: `handleLeftScroll` sets `syncing = true`, synchronously updates `right.scrollTop`, then sets `syncing = false` — all before the browser can fire `handleRightScroll`.

---

### 15.4 FileViewerModal Cancellation Token

**File:** `FileViewerModal.tsx`

See [Section 8.6](#86-fileviewermodaltsx). The `let cancelled = false` pattern in the `useEffect` prevents setting state after the component unmounts or the `filePath` prop changes. The cleanup function `return () => { cancelled = true }` runs before the next effect or on unmount.

---

### 15.5 SSE `useRef` for EventSource

**File:** `useScanProgress.ts`

The `EventSource` is stored in a `useRef` instead of `useState` because:
- Changing state triggers a re-render; changing a ref does not
- The `EventSource` object doesn't need to participate in React's rendering cycle
- `startStreaming` and `stopStreaming` can read/write the ref synchronously without stale closure issues
- If it were in state, `stopStreaming` would need the current `EventSource` from state, but `useCallback` would capture a stale value unless its dependency array included the EventSource — which would recreate the callback on every streaming start

---

### 15.6 QueryPage URL-Driven Auto-Execution

**File:** `QueryPage.tsx`

The `useEffect` watching `[searchParams, preCannedQueries]` enables deep-linking from Dashboard insight cards:

```
/query?q=config-candidates
```

The effect waits for both `searchParams` (always available) and `preCannedQueries` (fetched asynchronously) to be present before matching. Without the `preCannedQueries` dependency, the effect would fire before the query list loads and fail to find a match.

---

### 15.7 CommandLine Fragment Rendering

**File:** `CommandLine.tsx`, `Layout.tsx`

`CommandLine` returns a React fragment:

```tsx
return (
  <>
    {result && <CommandLineResults ... />}
    <footer>...</footer>
  </>
)
```

In `Layout.tsx`, `<CommandLine />` sits at the bottom of a `flex flex-col`. The fragment "unwraps" into two sibling elements: the results panel and the footer. Both participate in the parent's flex layout as if they were direct children of the Layout div. This avoids needing to modify Layout when adding the results panel.

---

*End of guide.*
