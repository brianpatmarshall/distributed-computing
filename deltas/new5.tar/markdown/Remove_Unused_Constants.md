# Remove Unused Constants

A detailed description of the "Remove Unused" candidate scope in the Transform page — how it works, the code involved, design decisions, and known limitations.

---

## Table of Contents

1. [What It Does](#1-what-it-does)
2. [End-to-End Flow](#2-end-to-end-flow)
3. [Frontend: Selecting the Scope](#3-frontend-selecting-the-scope)
4. [Backend: Routing to handleRemoveUnused](#4-backend-routing-to-handleremoveunused)
5. [Neo4j Query: Finding Unused Constants](#5-neo4j-query-finding-unused-constants)
6. [Core: UnusedConstantRemover](#6-core-unusedconstantremover)
7. [Safety Mechanisms](#7-safety-mechanisms)
8. [Dry Run vs. Live Run](#8-dry-run-vs-live-run)
9. [Git Branch Integration](#9-git-branch-integration)
10. [Test Coverage](#10-test-coverage)
11. [Does This Work?](#11-does-this-work)

---

## 1. What It Does

When a user selects "Remove Unused" in the Candidate Scope dropdown on the Transform page, the system:

1. Queries Neo4j for all `static final` constants in the scanned project that have **no `USED_IN` relationships** — meaning they were declared but never referenced in any scanned Java file
2. Parses each source file containing unused constants using JavaParser
3. Removes the field declarations from the AST
4. Writes the modified files to a backups directory (with `.orig` copies of the originals)
5. Optionally commits the changes to a new git branch

This is fundamentally different from the other candidate scopes (ALL, CONSTANTS_ONLY, PARAMETERS_ONLY), which **replace** constant usages with `config.lookup()` calls. REMOVE_UNUSED **deletes** the declarations entirely.

---

## 2. End-to-End Flow

```
User clicks "Transform" with scope = REMOVE_UNUSED
  │
  ▼
Frontend POST /api/transform { projectPath, dryRun, candidateScope: "REMOVE_UNUSED" }
  │
  ▼
TransformController.transform() → CodeTransformationService.transform()
  │
  ▼
CodeTransformationService detects scope == REMOVE_UNUSED → handleRemoveUnused()
  │
  ├── Phase 1: findUnusedConstants() — Cypher query against Neo4j
  │     Returns List<ConstantWithFile> (name, type, value, className, lineNumber, filePath)
  │
  ├── Group targets by file path → Map<Path, List<ConstantTarget>>
  │
  ├── Phase 2: For each file:
  │     ├── Dry run?  → unusedRemover.dryRun()   — parse, report what would be removed
  │     └── Live run? → unusedRemover.removeFromFile() — parse, remove, write
  │
  ├── Phase 2.5 (optional): createBranchWithTransformedFiles()
  │     Creates git branch, copies modified files back, commits
  │
  └── Phase 3: Build TransformResponse with entries, counts, message
```

---

## 3. Frontend: Selecting the Scope

**File:** `const-catalog-frontend/src/pages/TransformPage.tsx`

The scope is defined as a TypeScript union type:

```tsx
type CandidateScope = 'ALL' | 'CONSTANTS_ONLY' | 'PARAMETERS_ONLY' | 'REMOVE_UNUSED'
```

It appears as a radio button option labeled "Remove Unused" in the Transform page UI. When selected, the help text changes to explain the removal behavior:

```tsx
{candidateScope === 'REMOVE_UNUSED' ? (
  <>
    The remover will:
    <ul>
      <li>Query the graph for constants with no usages in any scanned file</li>
      <li>Remove their static final field declarations from source</li>
      <li>Protect special names (serialVersionUID, LOG, LOGGER, etc.)</li>
      <li>Backup original files as *.java.orig</li>
    </ul>
  </>
) : (
  // ... normal transform help text
)}
```

The scope is sent in the POST body as `candidateScope: 'REMOVE_UNUSED'` alongside `projectPath`, `dryRun`, and `createBranch`.

**File:** `const-catalog-frontend/src/types/index.ts`

```tsx
export interface TransformRequest {
  projectPath: string
  dryRun: boolean
  candidateScope?: 'CONSTANTS_ONLY' | 'PARAMETERS_ONLY' | 'ALL' | 'REMOVE_UNUSED'
  createBranch?: boolean
}
```

---

## 4. Backend: Routing to handleRemoveUnused

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/CodeTransformationService.java`

The `transform()` method checks the scope and routes immediately if it's REMOVE_UNUSED:

```java
public TransformResponse transform(TransformRequest request) {
    String projectPath = request.getProjectPath();
    CandidateScope scope = request.getCandidateScope();

    if (scope == CandidateScope.REMOVE_UNUSED) {
        return handleRemoveUnused(request);  // Entirely separate code path
    }

    // ... normal transformation logic for ALL, CONSTANTS_ONLY, PARAMETERS_ONLY
}
```

**Why a separate method?** The normal transformation replaces usages with `config.lookup()` calls — it modifies lines where constants are *used*. REMOVE_UNUSED does the opposite — it deletes lines where constants are *declared*. The logic is fundamentally different:
- Different Neo4j query (unused vs. configuration-candidate)
- Different core class (`UnusedConstantRemover` vs. `ConfigLookupTransformer`)
- Different AST operation (removal vs. replacement)

Sharing the same code path would require awkward branching throughout.

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/dto/TransformRequest.java`

```java
public enum CandidateScope {
    CONSTANTS_ONLY,
    PARAMETERS_ONLY,
    ALL,
    REMOVE_UNUSED
}
```

---

## 5. Neo4j Query: Finding Unused Constants

**File:** `CodeTransformationService.java`, method `findUnusedConstants()` (lines 414–440)

```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE NOT exists { MATCH (c)-[:USED_IN]->() }
  AND NOT coalesce(c.isEnum, false) = true
RETURN c.name AS constantName,
       c.type AS constantType,
       c.value AS constantValue,
       c.className AS className,
       c.lineNumber AS lineNumber,
       f.path AS filePath
ORDER BY f.path, c.lineNumber
```

**How this query works:**

1. `MATCH (p:Project {rootPath: $path})` — Find the project node matching the scanned project path
2. `-[:CONTAINS]->(f:File)` — Traverse to all files in the project
3. `<-[:DEFINED_IN]-(c:Constant)` — Find constants defined in those files
4. `WHERE NOT exists { MATCH (c)-[:USED_IN]->() }` — Keep only constants that have **no** `USED_IN` relationships. The `USED_IN` relationships are created during scanning by `GraphPopulatorService.createConstantUsageRelationships()`, which connects constants to files where they are referenced.
5. `AND NOT coalesce(c.isEnum, false) = true` — Exclude enum constants. Enum values are technically `static final` fields, but removing them changes the enum's API. `coalesce` handles the case where `isEnum` is null (defaults to `false`).

**What "unused" means here:** A constant is unused if the scanner found no references to it in any Java file in the project. This depends entirely on the scan being comprehensive — if a file was skipped or failed to parse, its usages weren't recorded, and the constant may be falsely reported as unused.

**Note:** There is also a `ConstantRepository.findUnusedConstants()` method:

```java
@Query("MATCH (c:Constant) WHERE NOT (c)-[:USED_IN]->() RETURN c ORDER BY c.name")
List<ConstantNode> findUnusedConstants();
```

This repository method queries across **all** projects (no project filter). It is not used by the REMOVE_UNUSED feature — the `CodeTransformationService` uses its own `findUnusedConstants(projectPath)` which filters by project path and joins with file nodes to get the file path. The repository method exists for the stats/query API.

---

## 6. Core: UnusedConstantRemover

**File:** `const-catalog-core/src/main/java/com/boeing/constcatalog/transformer/UnusedConstantRemover.java`

This is the core engine that performs the actual AST manipulation. It lives in `const-catalog-core` (no Spring dependency) so it can be tested independently.

### Constructor

```java
public UnusedConstantRemover() {
    ParserConfiguration config = new ParserConfiguration()
        .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_21);
    this.javaParser = new JavaParser(config);
}
```

The parser is configured for Java 21 language level to handle modern syntax (records, sealed classes, pattern matching) that might appear in the source files being modified.

### removeFromFile() — The Core Algorithm

The method processes one source file at a time. Here is the algorithm step by step:

**Step 1: Setup backups**

```java
Path absSource = sourceFile.toAbsolutePath();
Path relPath = absSource.getRoot().relativize(absSource);
Path outputPath = backupsDir.resolve(relPath);
Path backupOrigPath = Path.of(outputPath + ".orig");

Files.createDirectories(outputPath.getParent());
Files.copy(sourceFile, backupOrigPath, StandardCopyOption.REPLACE_EXISTING);
```

Before modifying anything, the original file is copied to `backups/<relative-path>.orig`. The modified version will be written to `backups/<relative-path>` (without `.orig`). The original source file is never modified directly — the git branch integration later copies the modified file back if requested.

**Step 2: Parse the file**

```java
ParseResult<CompilationUnit> parseResult = javaParser.parse(sourceFile);
```

JavaParser converts the source file into an AST (Abstract Syntax Tree). If parsing fails (syntax errors, unsupported constructs), all targets for this file are reported as failed.

**Step 3: Build a lookup map of targets**

```java
Map<String, ConstantTarget> targetsByName = targets.stream()
    .collect(Collectors.toMap(ConstantTarget::constantName, t -> t, (a, b) -> a));
```

The targets (from the Neo4j query) are keyed by constant name for O(1) lookup. The merge function `(a, b) -> a` handles duplicate names by keeping the first occurrence.

**Step 4: Walk all `static final` fields and collect removal candidates**

```java
for (FieldDeclaration field : compilationUnit.findAll(FieldDeclaration.class)) {
    if (!isStaticFinal(field)) continue;

    for (VariableDeclarator var : field.getVariables()) {
        String name = var.getNameAsString();
        ConstantTarget target = targetsByName.get(name);
        if (target == null) continue;

        // Check protected names
        // Check line number tolerance
        // Add to candidates list
    }
}
```

`findAll(FieldDeclaration.class)` returns every field declaration in the file. Only `static final` fields are considered. For each variable in the field, the code checks if it matches a target from Neo4j.

**Why iterate all fields instead of searching by name?** A field declaration can contain multiple variables (`static final int A = 1, B = 2;`). JavaParser models this as one `FieldDeclaration` with two `VariableDeclarator` nodes. By iterating fields, the code can handle multi-variable declarations correctly (see Step 6).

**Step 5: Sort candidates bottom-up**

```java
candidates.sort(Comparator.comparingInt(
    (RemovalCandidate c) -> c.var.getBegin().map(p -> p.line).orElse(0)).reversed());
```

Candidates are sorted by line number in descending order (highest line first). This is critical: when you remove a node from the AST, all subsequent line numbers shift. By removing from the bottom up, earlier line numbers remain valid.

**Step 6: Remove each candidate**

```java
for (RemovalCandidate candidate : candidates) {
    FieldDeclaration field = candidate.field;
    VariableDeclarator variableDeclarator = candidate.var;

    if (field.getVariables().size() == 1) {
        field.remove();                    // Remove entire declaration
    } else {
        variableDeclarator.remove();       // Remove only this variable
    }
}
```

Two cases:

- **Single variable** (`static final int MAX_RETRIES = 3;`) — Remove the entire `FieldDeclaration` node, which removes the line from the file.
- **Multi-variable** (`static final int A = 1, B = 2;`) — Remove only the specific `VariableDeclarator`. The declaration remains with the other variables intact. If both A and B are targeted, they are processed individually; when A is removed, `field.getVariables().size()` drops to 1, and then B's removal removes the entire field.

**Step 7: Write the modified file**

```java
if (anyRemoved) {
    Files.writeString(outputPath, compilationUnit.toString());
}
```

`compilationUnit.toString()` serializes the modified AST back to Java source code. The output goes to the backups directory, not the original file.

---

## 7. Safety Mechanisms

### Protected Names

```java
private static final Set<String> PROTECTED_NAMES = Set.of(
    "serialVersionUID", "VERSION", "LOG", "LOGGER", "logger"
);
```

These constants are never removed, even if Neo4j reports them as unused:
- `serialVersionUID` — Required for Java serialization compatibility. Removing it silently changes the serialized form.
- `VERSION` — Often used by frameworks or build tools outside of Java code.
- `LOG`, `LOGGER`, `logger` — Logging fields. They're "used" via the logging framework but may not appear as `USED_IN` relationships in the graph because the scanner doesn't track method call targets.

When a protected name is encountered, it's reported as "skipped" with the reason "Protected name — not removed."

### Line Number Tolerance

```java
private static final int LINE_TOLERANCE = 3;
```

The line number stored in Neo4j (from the scan) may differ from the line number in the current AST by a few lines. This happens when:
- The file has been modified since it was scanned (lines added or removed above the constant)
- The scanner and JavaParser disagree on where a declaration "starts" (e.g., annotations, comments)

If the AST line number differs from the Neo4j line number by more than 3 lines, the constant is skipped with a "Line mismatch" message. This prevents removing the wrong field when a name collision exists (e.g., two classes with a constant named `DEFAULT_VALUE`).

### Backup Files

Every file is backed up as `*.orig` before modification. If something goes wrong, the originals are preserved in the `backups/` directory with the same relative path structure.

### No Direct Source Modification

The modified file is written to the `backups/` directory, not to the original source path. The original file is only overwritten if the user selects "Create New Branch" — and even then, it's done on a separate git branch, so the original branch is untouched.

---

## 8. Dry Run vs. Live Run

### Dry Run (`dryRun: true`)

```java
if (request.isDryRun()) {
    List<TransformationEntry> entries = targetsByFile.entrySet().stream()
        .flatMap(entry -> unusedRemover.dryRun(entry.getKey(), entry.getValue()).stream())
        .toList();
    result = new TransformationResult(projectPath, LocalDateTime.now(), entries);
}
```

Calls `UnusedConstantRemover.dryRun()`, which parses the file and walks the AST identically to the live path, but:
- Does not create backup files
- Does not modify the AST
- Does not write any files
- Reports each candidate as "Would remove unused constant 'X'" instead of "Removed unused constant 'X'"

This lets the user preview exactly what would be removed before committing to the operation.

### Live Run (`dryRun: false`)

```java
result = unusedRemover.removeFromProject(projectPath, targetsByFile);
```

Calls `removeFromProject()` which creates the `backups/` directory and delegates to `removeFromFile()` for each file. Modified files are written to the backups directory. If "Create New Branch" is also selected, the modified files are copied back to the source and committed (see Section 9).

---

## 9. Git Branch Integration

When both `dryRun: false` and `createBranch: true`, the `handleRemoveUnused` method calls `createBranchWithTransformedFiles()` after the removal phase:

```java
BranchResult branchResult = BranchResult.SKIPPED;
if (request.isCreateBranch() && !request.isDryRun() && result.totalTransformed() > 0) {
    branchResult = createBranchWithTransformedFiles(projectPath, result);
}
```

This method:
1. Checks if the project is a git repo (initializes one if not)
2. Creates a new branch named `<current-branch>-transformed`
3. Copies modified files from `backups/` back to their original source paths
4. Commits all changes with the message "Transform constants to config lookups"
5. Switches back to the original branch

The result message reflects the branch: `"Removed 5 constants, skipped 2, failed 0 — committed to branch 'main-transformed'"`

---

## 10. Test Coverage

**File:** `const-catalog-core/src/test/java/com/boeing/constcatalog/transformer/UnusedConstantRemoverTest.java`

The test suite includes 11 tests:

| Test | What It Verifies |
|---|---|
| `testRemovesSingleUnusedConstant` | A single `static final` field is removed from the output |
| `testRemovesMultipleConstants` | Multiple constants in one file are all removed |
| `testProtectsSerialVersionUID` | `serialVersionUID` is skipped even when targeted |
| `testProtectsLoggerField` | `LOG` fields are skipped even when targeted |
| `testDryRunDoesNotModifyFile` | Dry run parses but does not write any files |
| `testSkipsNonStaticFinalFields` | Non-`static final` fields are not matched |
| `testMultiVariableDeclarationRemovesSingleVar` | From `int A = 1, B = 2;`, only the targeted variable is removed |
| `testPreservesBackupFile` | The `.orig` backup file is created with original content |
| `testSkipsWhenDeclarationNotFound` | Target not in the file is reported as skipped |
| `testRemoveFromProject` | Multi-file removal produces aggregated results |
| `testEmptyTargetListReturnsEmpty` | No targets → empty results (no crash) |

---

## 11. Does This Work?

**The code is structurally sound.** The algorithm is correct: query Neo4j for unused constants, parse with JavaParser, remove from AST bottom-up, write to backups. The safety mechanisms (protected names, line tolerance, backups) are well-considered. The test suite covers the core scenarios including edge cases. The frontend integration is clean — the scope routes to a completely separate backend code path.

**However, there are important caveats about accuracy:**

### The "unused" determination depends entirely on scan coverage

A constant is "unused" only if the scanner found zero references across all scanned files. If any file failed to parse during scanning (visible in the scan logs as "Failed to parse Java file" warnings), usages in that file were not recorded. The constant would be falsely reported as unused.

**Recommendation:** Always run a dry run first and review the list. If a constant looks like it should be used, check whether the file that uses it was successfully scanned.

### Cross-project references are not tracked

If project A defines a constant and project B uses it, scanning only project A would report that constant as unused. The graph only contains relationships within the scanned project.

### Reflection and framework usages are invisible

Constants used via reflection (`Field.get()`), annotation values, Spring `@Value` expressions, or string-concatenated references won't be detected by the JavaParser-based scanner. These will appear as unused even though they are functionally required.

### The line tolerance window could cause false positives

If the file has been modified since the last scan and a different `static final` field with the same name now sits within 3 lines of the original position, the wrong field could be removed. This is unlikely but possible in files with many similarly-named constants.

### Summary

The feature works correctly for its intended use case: identifying and removing dead `static final` constants from a scanned project, with dry run preview. **Always dry run first**, review the results, and use the git branch option when performing live removals so the original code is preserved.
