# Why Do This?

A collection of explanations for design decisions and patterns used in this project.

---

## Why Use `<React.StrictMode>`

`<React.StrictMode>` is a development-only wrapper that helps catch bugs early. It has **no effect in production builds** — zero runtime cost.

What it does:

1. **Double-renders components** — Calls your render function twice to expose impure renders (e.g., side effects that happen during rendering instead of in `useEffect`). If your component produces different output on the second call, something is wrong.

2. **Double-runs effects** — Mounts, unmounts, then re-mounts every component to verify your `useEffect` cleanup works correctly. This catches missing cleanup (leaked event listeners, unclosed connections, stale subscriptions).

3. **Flags deprecated APIs** — Warns in the console if you use legacy lifecycle methods (`componentWillMount`, etc.) or the old string ref API.

4. **Detects unexpected side effects** — By running things twice, it surfaces code that accidentally depends on being called exactly once (e.g., incrementing a counter in render, or mutating external state).

In this project, it wraps everything in `main.tsx:17-21`. The main practical benefit is catching `useEffect` cleanup bugs — for example, if `useScanProgress` didn't properly close its `EventSource` on unmount, StrictMode's mount/unmount/remount cycle would make the bug visible immediately (you'd see duplicate SSE connections in the network tab).

---

## Why Use `<QueryClientProvider>`

### What Is a Provider?

A **Provider** is a React component that makes a value available to every component nested inside it, without passing it through props at every level. It is the "giving" half of React's **Context** system.

The problem Providers solve is called **prop drilling**. Without them, if a deeply nested component needs access to some shared object, you'd have to pass it as a prop through every intermediate component in the tree:

```
App → Layout → Sidebar → QueryPage → ResultsTable → SomeChild
         ↑ passes queryClient as a prop through every level
```

Every component in the chain must accept and forward the prop, even if it doesn't use it. This is fragile, verbose, and couples components to data they don't care about.

A Provider eliminates this by broadcasting the value through React's context system. Any descendant component can access the value directly by calling a hook (like `useQuery` or `useQueryClient`), regardless of how deep it's nested:

```
QueryClientProvider (holds queryClient)
  └── App
       └── Layout
            └── Sidebar
            └── QueryPage  ← calls useQuery(), gets queryClient automatically
                 └── ResultsTable
```

### How Providers Work Under the Hood

React's Context system has two parts:

1. **`React.createContext()`** — Creates a context object with a Provider component and a default value.
2. **`<Context.Provider value={...}>`** — Wraps a subtree and makes `value` available to any descendant that asks for it.

Descendant components access the value via `useContext(SomeContext)` — or, more commonly, through a library's custom hook that calls `useContext` internally. When you call `useQuery()`, it internally calls `useContext(QueryClientContext)` to find the nearest `QueryClientProvider` and retrieve the `queryClient` instance.

If no Provider is found up the tree, the hook throws an error. That's why `QueryClientProvider` must wrap your entire app (or at least the portion that uses TanStack Query).

### What `<QueryClientProvider>` Specifically Does

In `main.tsx`:

```tsx
const queryClient = new QueryClient({ ... })

<QueryClientProvider client={queryClient}>
  <App />
</QueryClientProvider>
```

This makes the single `queryClient` instance available to every component in the app. That one instance holds:

- **The cache** — All fetched data, keyed by query keys like `['stats']` and `['health']`
- **Default options** — The `staleTime: 30000` and `retry: 1` configured at creation
- **Active query tracking** — Which queries are currently mounted, fetching, or stale
- **Deduplication logic** — If `Header.tsx` and another component both use `queryKey: ['health']`, only one network request fires

Every `useQuery` and `useMutation` call in `Dashboard.tsx`, `Header.tsx`, `QueryPage.tsx`, `ScanPage.tsx`, and `TransformPage.tsx` reaches back up to this same Provider to access the same `queryClient`. This is how two components with the same query key automatically share cached data — they're both talking to the same cache.

### Other Providers You'll See in React Apps

The Provider pattern is used by many libraries:

| Provider | What it shares |
|---|---|
| `QueryClientProvider` | TanStack Query cache and configuration |
| `BrowserRouter` | Routing state (URL, navigation) |
| `ThemeProvider` | UI theme (colors, spacing, fonts) |
| `AuthProvider` | Current user session and login state |
| `Redux Provider` | Global application state store |

They all work the same way: wrap the tree, share a value, and descendants access it via hooks.

### How `useQuery` and `useMutation` Find the `queryClient`

Neither `useQuery` nor `useMutation` receives the `queryClient` as an argument. Instead, they find it automatically through React's context system. Inside TanStack Query's source code, the chain looks roughly like this:

```tsx
// TanStack Query creates a React Context internally
const QueryClientContext = React.createContext<QueryClient | undefined>(undefined)

// QueryClientProvider stores the queryClient in that context
function QueryClientProvider({ client, children }) {
  return (
    <QueryClientContext.Provider value={client}>
      {children}
    </QueryClientContext.Provider>
  )
}

// A private hook retrieves it
function useQueryClient() {
  const client = React.useContext(QueryClientContext)
  if (!client) {
    throw new Error('No QueryClient set, use QueryClientProvider to set one')
  }
  return client
}

// useQuery calls useQueryClient internally
function useQuery(options) {
  const queryClient = useQueryClient()  // ← finds it via context
  // uses queryClient.getQueryCache(), queryClient.defaultOptions, etc.
}

// useMutation does the same thing
function useMutation(options) {
  const queryClient = useQueryClient()  // ← same mechanism
  // uses queryClient.getMutationCache(), etc.
}
```

**The lookup path:** When `Header.tsx` calls `useQuery({ queryKey: ['health'], ... })`:

1. `useQuery` internally calls `useQueryClient()`
2. `useQueryClient` calls `React.useContext(QueryClientContext)`
3. React walks **up** the component tree from `Header` looking for the nearest `QueryClientContext.Provider`
4. It finds `<QueryClientProvider client={queryClient}>` in `main.tsx`
5. Returns the `queryClient` instance you created with `new QueryClient({ ... })`
6. `useQuery` now has access to the cache, default options, and everything else on that instance

The same walk happens for every `useMutation` call in `ScanPage`, `QueryPage`, and `TransformPage`. They all reach the same Provider and get the same `queryClient` — which is why they all share one cache.

**What happens if the Provider is missing:** If you accidentally rendered a component with `useQuery` outside the `<QueryClientProvider>` tree, `React.useContext()` would return `undefined`, and TanStack Query throws:

```
No QueryClient set, use QueryClientProvider to set one
```

This is a common error when setting up TanStack Query for the first time, or in test files that forget to wrap the component under test.

---

## React

Explanations of React elements, components, and patterns used in this project.

### Why Use `<aside>`

A semantic HTML element meaning "secondary content related to the main content." It's functionally identical to a `<div>` — same rendering, same styling. The difference is **meaning**: it tells browsers, screen readers, and search engines that this is a sidebar/navigation panel, not primary content. You could replace it with `<div>` and nothing would visually change, but accessibility tools would lose the context.

Used in `Sidebar.tsx:22` to wrap the navigation panel.

### Why Use `<NavLink>` Instead of `<a>` or `<Link>`

`NavLink` is a component from `react-router-dom` that renders an `<a>` tag with two superpowers:

1. **Client-side navigation** — Clicking it updates the URL and renders the matching route component without a full page reload. A plain `<a href="/scan">` would cause the browser to make a new HTTP request and reload the entire app, losing all React state.

2. **Active state awareness** — It knows whether its `to` path matches the current URL. In `Sidebar.tsx:29`, the `className` callback receives `{ isActive }` — NavLink provides this automatically. This is what makes the current page highlight with `bg-neon-cyan/10` while the others stay dimmed:

```tsx
<NavLink
  to={item.to}
  className={({ isActive }) =>
    clsx(
      'flex items-center gap-3 px-4 py-3 mx-2 rounded transition-all',
      'border border-transparent',
      isActive
        ? 'bg-neon-cyan/10 border-neon-cyan/30 text-neon-cyan'
        : 'text-terminal-dim hover:bg-space-light hover:text-terminal-text'
    )
  }
>
```

A regular React Router `<Link>` gives you client-side navigation but not the active state. `<NavLink>` exists specifically for navigation menus where you need to style the current page differently.

### The `to` Attribute on `<NavLink>`

The destination path. This is NavLink's equivalent of `href` on an `<a>` tag. When clicked, React Router pushes this path to the browser history and renders the matching route component. For example, `to="/scan"` navigates to the `<ScanPage>` component defined in the route configuration in `App.tsx`.

In `Sidebar.tsx`, paths are defined in the `navItems` array and passed to each NavLink:

```tsx
const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard', description: 'System Overview' },
  { to: '/scan', icon: Scan, label: 'Scan', description: 'Analyze Projects' },
  { to: '/query', icon: Terminal, label: 'Query', description: 'Execute Cypher' },
  { to: '/transform', icon: Wand2, label: 'Transform', description: 'Replace Constants' },
]
```

### The `key` Attribute in Lists

A React requirement, not specific to NavLink. When you render a list with `.map()`, React needs a unique `key` on each element to efficiently track which items changed, were added, or were removed during re-renders.

```tsx
{navItems.map((item) => (
  <NavLink key={item.to} to={item.to} ...>
```

Here `item.to` is used because the paths (`'/'`, `'/scan'`, `'/query'`, `'/transform'`) are guaranteed unique.

**Why React needs this:** Without `key`, React can only match list items by array index. If items are reordered, inserted, or removed, index-based matching causes React to update the wrong elements — components lose state, animations break, and input fields show the wrong values. A stable unique key lets React track each item by identity regardless of position.

Without `key`, React also warns in the console:

```
Warning: Each child in a list should have a unique "key" prop.
```

---

## Config Considerations

Configuration decisions that affect development workflow, build output, or debugging.

### Disabling Minification for React DevTools

**The problem:** When the frontend runs as a production build (e.g., via `docker compose up frontend`), Vite minifies all JavaScript. This shortens React component names to opaque identifiers like `C0`, `p0`, `b1`, `h0`. React DevTools shows these minified names in the component tree, making it impossible to identify which component you're looking at.

**The fix:** In `vite.config.ts`, disable minification in the build output:

```tsx
export default defineConfig({
  plugins: [react()],
  build: {
    minify: false,
  },
  server: { ... },
})
```

After this change, rebuild the container:

```
docker compose up --build frontend
```

Component names now appear as `Header`, `Dashboard`, `ScanPage`, etc. in React DevTools.

**Trade-offs:**
- The JavaScript bundle will be larger (no variable shortening, no whitespace removal, no dead code elimination)
- This is acceptable for a local developer tool but should be reverted before any production deployment
- An alternative is to run `npm run dev` from `const-catalog-frontend/` which starts the Vite dev server on port 3000 with full source maps and readable names — no config change needed. The dev server proxies `/api` calls to `localhost:8080` (the backend container), so the full stack works.

**When to use which approach:**

| Approach | When to use |
|---|---|
| `npm run dev` (port 3000) | Day-to-day frontend development and debugging |
| `minify: false` in vite.config.ts | Debugging issues that only reproduce in the Docker/nginx build |
| Default (`minify: true`) | Final production deployment |

### Nginx Configuration for SSE (Server-Sent Events)

**The problem:** When the frontend runs inside Docker, nginx serves the static files and proxies `/api/` requests to the Spring Boot backend. The scan progress feature uses Server-Sent Events (SSE) — the backend streams progress events over a long-lived HTTP connection as files are parsed. Without specific nginx configuration, the SSE stream fails with "Failed to load response data" in the browser's Network tab.

**Why it fails:** Nginx buffers proxy responses by default. It collects the backend's output into an internal buffer (typically 4-8KB) and only forwards it to the browser when the buffer is full or the connection closes. SSE events are small (a few hundred bytes each), so they sit in the buffer unseen. The browser's `EventSource` receives nothing, times out, and reports an error.

**The fix:** Add a dedicated `location` block for the SSE endpoint in `nginx.conf` with buffering disabled:

```nginx
server {
    listen 80;
    server_name localhost;
    root /usr/share/nginx/html;
    index index.html;

    # Enable gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml;

    # Proxy API requests to backend
    location /api/ {
        proxy_pass http://backend:8080/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

        # Extended timeouts for long-running scans
        proxy_connect_timeout 6000s;
        proxy_send_timeout 6000s;
        proxy_read_timeout 6000s;
    }

    # SSE endpoint needs buffering disabled so events stream in real time
    location /api/scan/stream {
        proxy_pass http://backend:8080/api/scan/stream;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header Connection '';

        # Disable buffering — nginx must forward each SSE event immediately
        proxy_buffering off;
        proxy_cache off;

        # Disable gzip — compressed chunks break SSE framing
        gzip off;

        # Extended timeout for long-running scans
        proxy_read_timeout 600s;
    }

    # Handle SPA routing - serve index.html for all non-file routes
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

#### Directive-by-Directive Explanation

**General server directives:**

| Directive | Purpose |
|---|---|
| `listen 80` | Accept HTTP connections on port 80. Inside the Docker container, this is mapped to port 3001 on the host via `docker-compose.yml` (`3001:80`). |
| `server_name localhost` | The hostname this server block responds to. For local development, `localhost` matches all requests. |
| `root /usr/share/nginx/html` | The directory containing the built frontend files (`index.html`, JS bundles, CSS). The Dockerfile copies Vite's `dist/` output here. |
| `index index.html` | When a request hits a directory, serve `index.html` by default. |

**Gzip compression:**

| Directive | Purpose |
|---|---|
| `gzip on` | Enable gzip compression for responses. Reduces transfer size for text-based assets. |
| `gzip_types ...` | Which MIME types to compress. Binary files (images, fonts) are already compressed and shouldn't be gzipped again. |

**General API proxy (`location /api/`):**

This block handles all REST API requests (scan, query, transform, stats, health).

| Directive | Purpose |
|---|---|
| `proxy_pass http://backend:8080/api/` | Forward requests to the backend container. `backend` is the Docker Compose service name, resolved via Docker's internal DNS. Port 8080 is the container's internal port (mapped to 9090 on the host). |
| `proxy_http_version 1.1` | Use HTTP/1.1 for the upstream connection. Required for keepalive connections and chunked transfer encoding. HTTP/1.0 (the default for proxy connections) doesn't support these. |
| `proxy_set_header Host $host` | Pass the original `Host` header to the backend. Without this, the backend sees `backend:8080` as the host, which can break URL generation or virtual host routing. |
| `proxy_set_header X-Real-IP $remote_addr` | Pass the client's real IP address. Without this, the backend sees nginx's IP (the Docker bridge network IP) for every request. |
| `proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for` | Appends the client IP to the `X-Forwarded-For` chain. Standard practice for proxied requests — lets the backend know the request passed through a proxy and what the original client IP was. |
| `proxy_connect_timeout 6000s` | How long nginx waits to establish a TCP connection to the backend. 6000 seconds is very generous — if the backend doesn't accept the connection in this time, nginx returns a 502 Bad Gateway. |
| `proxy_send_timeout 6000s` | How long nginx waits between successive writes to the backend. If nginx is sending a large request body and the backend stops reading for this long, the connection is closed. |
| `proxy_read_timeout 6000s` | How long nginx waits between successive reads from the backend. If the backend stops sending response data for this long, nginx closes the connection. Set high because scans can take minutes for large projects. |

**SSE endpoint (`location /api/scan/stream`):**

Nginx uses **longest prefix match** for `location` blocks. A request to `/api/scan/stream?projectPath=...` matches both `/api/` and `/api/scan/stream`. Nginx picks `/api/scan/stream` because it's more specific. This lets us apply SSE-specific settings without affecting regular API requests.

| Directive | Purpose |
|---|---|
| `proxy_buffering off` | **The critical fix.** Disables nginx's response buffering. Without this, nginx collects the backend's SSE events in memory and only forwards them when the buffer fills up or the connection ends. With buffering off, each event is forwarded to the browser immediately as it arrives from the backend. |
| `proxy_cache off` | Prevents nginx from caching the SSE response. Caching a stream makes no sense — each connection is unique and real-time. Without this, nginx might serve a cached (empty or partial) response to subsequent SSE connections. |
| `gzip off` | Disables gzip compression for this endpoint. Gzip works by collecting data into blocks and compressing each block. This re-introduces buffering at the compression layer — events wait until enough data accumulates to form a compression block. The events are small text payloads; compression saves negligible bytes while breaking real-time delivery. |
| `proxy_set_header Connection ''` | Sets the `Connection` header to an empty string. This tells the backend to keep the connection open (the default for HTTP/1.1). The original config had `Connection 'upgrade'`, which tells the backend to switch to the WebSocket protocol — SSE is not WebSocket, so the backend rejects the upgrade request and the connection fails. |
| `proxy_read_timeout 600s` | 10-minute timeout matching the `SseEmitter` timeout in `ScanController.java` (`new SseEmitter(600_000L)`). If no event arrives within 10 minutes, nginx closes the connection. |

**SPA routing (`location /`):**

| Directive | Purpose |
|---|---|
| `try_files $uri $uri/ /index.html` | Handles client-side routing. When the user navigates to `/scan` or `/query`, there's no actual file at that path — it's a React Router route. This directive tells nginx: try the exact path, then try it as a directory, and if neither exists, serve `index.html` and let React Router handle the URL. Without this, refreshing the page on `/scan` would return a 404. |

**Static asset caching:**

| Directive | Purpose |
|---|---|
| `location ~*` | The `~*` means case-insensitive regex match. This block matches any request ending in the listed file extensions. |
| `expires 1y` | Sets the `Expires` header to 1 year from now. The browser caches these files and doesn't re-request them for a year. This is safe because Vite adds content hashes to filenames (e.g., `index-a3b2c1d.js`) — when the code changes, the filename changes, and the browser fetches the new file. |
| `add_header Cache-Control "public, immutable"` | `public` allows shared caches (CDNs, corporate proxies) to cache the file. `immutable` tells the browser not to revalidate the cached file even on a hard refresh — the content hash guarantees the file never changes at the same URL. |

#### Why This Doesn't Affect `npm run dev`

When running via `npm run dev`, Vite's built-in dev server handles all proxying (configured in `vite.config.ts`). Vite doesn't buffer SSE responses — it passes events through natively. The nginx config only applies inside the Docker container. The two environments are completely independent:

| Environment | Proxy | SSE behavior |
|---|---|---|
| `npm run dev` (port 3000) | Vite dev server | Works out of the box, no config needed |
| Docker (port 3001) | Nginx | Requires `proxy_buffering off` for SSE |
