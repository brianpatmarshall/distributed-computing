# Maven Testing Guide

A quick reference for running tests in this multi-module project.

---

## The `-pl` Flag (Project List)

Maven's `-pl` stands for **project list** (long form: `--projects`). It targets a specific module instead of building the entire project:

```bash
mvn test -pl const-catalog-core       # Run only core module tests
mvn test -pl const-catalog-backend    # Run only backend module tests
```

Without `-pl`, Maven runs tests across all modules.

**Important:** The backend module depends on the core JAR in `~/.m2`. If core has changed, install it first:

```bash
mvn install -pl const-catalog-core -DskipTests
```

Otherwise backend tests may fail with `ClassNotFoundException` due to a stale JAR.

---

## Running All Tests

```bash
# Full project — install all modules, then test
mvn install -DskipTests && mvn test

# Single module
mvn test -pl const-catalog-backend
```

---

## Running a Specific Test Class

Use the `-Dtest` flag (capital D, case-sensitive):

```bash
mvn test -pl const-catalog-backend -Dtest=MongoConfigStoreTest
```

Multiple classes:

```bash
mvn test -pl const-catalog-backend -Dtest=MongoConfigStoreTest,ValKeyConfigStoreTest
```

A single method:

```bash
mvn test -pl const-catalog-backend -Dtest=MongoConfigStoreTest#setShouldStoreValue
```

Wildcard pattern:

```bash
mvn test -pl const-catalog-backend -Dtest="*ConfigStore*"
```

---

## Skipping Tests

```bash
mvn install -DskipTests          # Compile tests but don't run them
mvn install -Dmaven.test.skip    # Don't compile or run tests
```

---

## Surefire Report Plugin

Maven Surefire produces XML results in `target/surefire-reports/` every time tests run. The Surefire Report Plugin converts those XML files into a readable HTML page.

### Generating the Report

```bash
# After running tests
mvn surefire-report:report -pl const-catalog-backend

# Or combine test + report in one command
mvn test surefire-report:report -pl const-catalog-backend
```

### Viewing the Report

```bash
xdg-open const-catalog-backend/target/site/surefire-report.html
```

### How the Files Work

| Path | Format | Created by | When |
|---|---|---|---|
| `target/surefire-reports/TEST-*.xml` | XML | `mvn test` | One per test class, overwritten each run |
| `target/site/surefire-report.html` | HTML | `surefire-report:report` | Regenerated from all XML files in directory |

### Staleness Warning

When you run a single test class with `-Dtest=Foo`, only `TEST-Foo.xml` is overwritten. XML files from previous runs of other classes remain. The HTML report aggregates **all** XML files present, so it may include stale results.

For a clean report reflecting only the current run:

```bash
mvn clean test surefire-report:report -pl const-catalog-backend
```

---

## Quick Reference

| Goal | Command |
|---|---|
| All tests, all modules | `mvn test` |
| All tests, one module | `mvn test -pl const-catalog-backend` |
| One test class | `mvn test -pl const-catalog-backend -Dtest=MongoConfigStoreTest` |
| One test method | `mvn test -pl const-catalog-backend -Dtest=MongoConfigStoreTest#methodName` |
| Wildcard | `mvn test -pl const-catalog-backend -Dtest="*ConfigStore*"` |
| Skip tests (compile only) | `mvn install -DskipTests` |
| HTML report after tests | `mvn surefire-report:report -pl const-catalog-backend` |
| Clean test + report | `mvn clean test surefire-report:report -pl const-catalog-backend` |
| Install core before backend | `mvn install -pl const-catalog-core -DskipTests` |

---

## Appendix: Tests Pass in IDE but Fail in Maven (or Vice Versa)

When tests behave differently between IntelliJ/VS Code and `mvn test`, the root cause is almost always a difference in classpath, build state, or environment. Here's a systematic checklist.

### Tests Pass in IDE, Fail in Maven

1. **Stale core JAR.** The IDE compiles against source; Maven resolves `const-catalog-core` from `~/.m2`. If the local JAR is outdated, Maven tests see old classes.
   ```bash
   mvn install -pl const-catalog-core -DskipTests
   ```

2. **Test execution order.** The IDE typically runs one class at a time. Maven Surefire runs all tests in a module together, so shared state (static fields, database data, ValKey keys) can leak between classes. Look for tests that pass in isolation but fail in a full run — that's a test isolation bug.

3. **Resource filtering / missing resources.** The IDE copies `src/test/resources` directly. Maven may apply resource filtering or fail to include files if `pom.xml` resource configuration is wrong. Check that test resource files are present in `target/test-classes/`.

4. **Annotation processing / Lombok.** If Lombok-generated methods are missing at compile time in Maven but work in the IDE, ensure the `lombok` dependency is in the `pom.xml` and the IDE's annotation processor is not doing something Maven's compiler plugin isn't configured for.

5. **Java version mismatch.** The IDE may use a different JDK than Maven. Verify both use Java 21:
   ```bash
   mvn -version          # Shows Maven's JDK
   java -version         # Shows system default
   ```
   In IntelliJ: File > Project Structure > SDKs. In VS Code: check `java.configuration.runtimes` in settings.

6. **Spring profile differences.** The IDE may activate a Spring profile (e.g., via a run configuration's `SPRING_PROFILES_ACTIVE`) that Maven doesn't, or vice versa.

### Tests Pass in Maven, Fail in IDE

1. **Working directory.** Maven runs from the module root (e.g., `const-catalog-backend/`). The IDE may run from the project root. Tests that use relative paths (e.g., `new File("src/test/resources/...")`) will break. Fix: use classpath resources (`getClass().getResource(...)`) instead of relative file paths.

2. **Missing `mvn compile` / `mvn test-compile`.** If you edit source but the IDE hasn't recompiled, you'll run stale bytecode. In IntelliJ: Build > Rebuild Project. In VS Code: clean the Java language server workspace (Ctrl+Shift+P > "Java: Clean Java Language Server Workspace").

3. **IDE test runner vs. Surefire.** IntelliJ and VS Code use their own test runners, not Surefire. Differences include:
   - **Classpath ordering** — the IDE may put dependencies in a different order, causing a different class to win when duplicates exist.
   - **Fork behavior** — Surefire forks a new JVM by default; the IDE runs tests in-process. Tests that depend on system properties or JVM flags set in `pom.xml`'s Surefire configuration won't see those in the IDE.

4. **Environment variables.** Maven tests may rely on env vars set in `.env.mint` or the shell profile that the IDE doesn't inherit. In IntelliJ: Edit Run Configuration > Environment Variables. In VS Code: add to `.vscode/launch.json` or `settings.json`.

5. **Docker services not running.** Some tests need external services (MongoDB, ValKey, Neo4j). Maven may have been run after `docker compose up`, but a later IDE session might not have those services running.
   ```bash
   docker compose --env-file=.env.mint --profile=mongodb ps
   ```

### General Debugging Steps

1. **Run the failing test in isolation from Maven** to confirm it's not a test-interaction problem:
   ```bash
   mvn test -pl const-catalog-backend -Dtest=FailingTestClass
   ```

2. **Compare classpaths.** In IntelliJ: Run > Edit Configurations > select test > Show command line. Compare with Maven's effective classpath:
   ```bash
   mvn dependency:build-classpath -pl const-catalog-backend
   ```

3. **Check `target/` is fresh.** When in doubt, nuke it:
   ```bash
   mvn clean test -pl const-catalog-backend
   ```

4. **Check for `@Disabled` or `@EnabledIf` annotations** that may behave differently based on environment (e.g., `@EnabledIfEnvironmentVariable`).
