# Constants Catalog - Tutorial

## The Philosophy: Why Not Just Now?

This isn't just a tool. It's a mindset.

Every time you see something that should be fixed—a hardcoded value, a magic number, a configuration that should be externalized—you have two choices:

1. **"I'll do it later"** — Join the millions who said the same thing yesterday, last week, last year
2. **"Why not just now?"** — Take the action while the thought is fresh

```mermaid
graph TB
    subgraph "Two Paths"
        OBSERVE[See a problem] --> CHOICE{What now?}

        CHOICE -->|"Later"| FORGET[Forget about it]
        FORGET --> REDISCOVER[Rediscover months later]
        REDISCOVER --> BIGGER[Problem is bigger now]
        BIGGER --> OVERWHELM[Too overwhelming]
        OVERWHELM --> IGNORE[Ignore it]
        IGNORE --> CRISIS[Crisis]

        CHOICE -->|"Why not just now?"| ACT[Act immediately]
        ACT --> SMALL[Small fix]
        SMALL --> DONE[Done]
        DONE --> HABIT[Build the habit]
        HABIT --> CLEAN[Clean codebase]
    end

    style CRISIS fill:#e74c3c,stroke:#333,color:#fff
    style CLEAN fill:#27ae60,stroke:#333,color:#fff
    style CHOICE fill:#f39c12,stroke:#333,color:#000
```

This tutorial will teach you to use the Constants Catalog. But more importantly, it will show you a workflow that turns "I should do something about that" into "I just did something about that."

---

## Part 1: Your First Scan

### The Moment of Truth

You've installed the tool. You've started Docker. The question is: **which project do you scan first?**

Don't overthink it. Pick the project you're working on right now. The one open in your IDE. **Why not just now?**

```mermaid
flowchart LR
    subgraph "Decision Paralysis"
        Q1[Which project?] --> Q2[What if it's too big?]
        Q2 --> Q3[What if there's too many results?]
        Q3 --> Q4[Maybe I should plan first...]
        Q4 --> NOTHING[Do nothing]
    end

    subgraph "Action Bias"
        NOW[Current project] --> SCAN[Scan it]
        SCAN --> LEARN[Learn from results]
        LEARN --> IMPROVE[Improve approach]
    end

    style NOTHING fill:#e74c3c,stroke:#333,color:#fff
    style IMPROVE fill:#27ae60,stroke:#333,color:#fff
```

### Running the Scan

**Via Web UI:**
1. Open [http://localhost:3000](http://localhost:3000)
2. Navigate to **Scan**
3. Enter your project path
4. Click **Scan Project**

**Via API:**
```bash
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{"projectPath": "/path/to/your/project"}'
```

**Via CLI (no backend needed):**
```bash
java -jar const-catalog-cli/target/const-catalog-cli-1.0-SNAPSHOT-shaded.jar /path/to/your/project
```

### What Happens During a Scan

```mermaid
sequenceDiagram
    participant You
    participant Scanner
    participant JavaParser
    participant PropertyParser
    participant Neo4J

    You->>Scanner: Scan /my/project

    loop Every Directory
        Scanner->>Scanner: Check if excluded (target/, .git/, etc.)
        alt Not Excluded
            Scanner->>Scanner: List files
        end
    end

    loop Every .java File
        Scanner->>JavaParser: Parse file
        JavaParser->>JavaParser: Build AST
        JavaParser->>JavaParser: Find static final fields
        JavaParser-->>Scanner: List of Constants
        JavaParser->>JavaParser: Find getProperty() calls
        JavaParser-->>Scanner: List of Parameter Usages
    end

    loop Every .properties/.yml/.env File
        Scanner->>PropertyParser: Parse file
        PropertyParser-->>Scanner: List of Parameters
    end

    Scanner->>Neo4J: Create Project node
    Scanner->>Neo4J: Create File nodes
    Scanner->>Neo4J: Create Constant nodes + relationships
    Scanner->>Neo4J: Create Parameter nodes + relationships
    Scanner->>Neo4J: Create Usage relationships

    Scanner-->>You: Scan complete!
```

### Understanding the Output

After scanning, you'll see statistics:

| Metric | What It Means |
|--------|---------------|
| Files Scanned | Total .java and config files processed |
| Constants Found | `static final` fields discovered |
| Parameters Found | Key-value pairs from config files |
| Usages Detected | Places where parameters are referenced in code |

Don't worry if the numbers seem large. Large numbers aren't bad—they're **information**. Now you know.

---

## Part 2: Exploring Results

### The Graph Model

Your codebase is now a graph. This changes how you can ask questions about it.

```mermaid
graph TB
    subgraph "Your Codebase as a Graph"
        PROJECT[Project<br/>my-app] -->|CONTAINS| F1[File<br/>Config.java]
        PROJECT -->|CONTAINS| F2[File<br/>application.properties]
        PROJECT -->|CONTAINS| F3[File<br/>UserService.java]

        F1 -->|DEFINES| C1[Constant<br/>MAX_RETRIES = 3]
        F1 -->|DEFINES| C2[Constant<br/>API_URL = 'http://...']

        F2 -->|DEFINES| P1[Parameter<br/>db.host = localhost]
        F2 -->|DEFINES| P2[Parameter<br/>db.port = 5432]

        P1 -->|USED_IN| F3
        P2 -->|USED_IN| F3
    end

    style PROJECT fill:#6c5ce7,stroke:#333,color:#fff
    style C1 fill:#fd79a8,stroke:#333,color:#000
    style C2 fill:#fd79a8,stroke:#333,color:#000
    style P1 fill:#fdcb6e,stroke:#333,color:#000
    style P2 fill:#fdcb6e,stroke:#333,color:#000
```

### Pre-Built Queries: Start Here

Don't write Cypher yet. Start with the pre-built queries that encode common questions.

```mermaid
flowchart TB
    subgraph "Query Categories"
        subgraph "EXPLORATION"
            E1[All Constants<br/>See everything]
            E2[All Parameters<br/>Every config value]
            E3[File Summary<br/>What's where]
        end

        subgraph "ANALYSIS - Start Here"
            A1[Config Candidates<br/>Should these be params?]
            A2[Unused Parameters<br/>Dead config]
            A3[Duplicate Values<br/>Consolidation candidates]
        end

        subgraph "SECURITY - Important"
            S1[Sensitive Params<br/>Passwords, keys, secrets]
            S2[Connection Strings<br/>URLs, hosts, ports]
        end
    end

    style A1 fill:#f39c12,stroke:#333,color:#000
    style A2 fill:#f39c12,stroke:#333,color:#000
    style S1 fill:#e74c3c,stroke:#333,color:#fff
```

### The "Why Not Just Now" Query Workflow

When you run a query and see results, you have a choice:

```mermaid
flowchart TD
    QUERY[Run Query] --> RESULTS[See Results]
    RESULTS --> ITEMS{For each item}

    ITEMS --> CHOICE{Can I fix this now?}

    CHOICE -->|"Yes, < 5 min"| FIX[Fix it now]
    FIX --> COMMIT[Commit]
    COMMIT --> NEXT[Next item]

    CHOICE -->|"No, it's complex"| TICKET[Create ticket]
    TICKET --> TAG[Tag with 'config-debt']
    TAG --> NEXT

    CHOICE -->|"It's actually fine"| SKIP[Skip]
    SKIP --> NEXT

    NEXT --> ITEMS

    style FIX fill:#27ae60,stroke:#333,color:#fff
    style TICKET fill:#3498db,stroke:#333,color:#fff
```

**The key insight:** Most configuration issues are small. A hardcoded URL. A magic number. Moving it to a config file takes 2 minutes. **Why not just now?**

---

## Part 3: Writing Custom Queries

### Cypher Basics

Neo4J uses Cypher for queries. Here's the pattern:

```mermaid
flowchart LR
    subgraph "Cypher Structure"
        MATCH[MATCH<br/>Find pattern] --> WHERE[WHERE<br/>Filter]
        WHERE --> RETURN[RETURN<br/>Output]
    end
```

### Essential Queries

**Find all constants in a specific file:**
```cypher
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
WHERE f.fileName = 'Config.java'
RETURN c.name, c.type, c.value
```

**Find where a parameter is used:**
```cypher
MATCH (p:Parameter {name: 'db.host'})-[r:USED_IN]->(f:File)
RETURN f.fileName, r.className, r.lineNumber, r.context
```

**Find constants that look like URLs (should probably be parameters):**
```cypher
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
WHERE c.value CONTAINS 'http://' OR c.value CONTAINS 'https://'
RETURN c.name, c.value, f.fileName
ORDER BY f.fileName
```

**Find files with the most constants (might need refactoring):**
```cypher
MATCH (c:Constant)-[:DEFINED_IN]->(f:File)
RETURN f.fileName, count(c) as constantCount
ORDER BY constantCount DESC
LIMIT 10
```

**Find unused parameters (defined but never referenced):**
```cypher
MATCH (p:Parameter)-[:DEFINED_IN]->(f:File)
WHERE NOT (p)-[:USED_IN]->()
RETURN p.name, p.value, f.fileName
```

### Query Building Workflow

```mermaid
flowchart TD
    QUESTION[I want to know...] --> TRANSLATE[Translate to graph pattern]
    TRANSLATE --> NODES[What nodes am I looking for?]
    NODES --> RELS[What relationships matter?]
    RELS --> FILTER[What filters apply?]
    FILTER --> WRITE[Write MATCH...WHERE...RETURN]
    WRITE --> RUN[Run query]
    RUN --> REFINE{Results useful?}
    REFINE -->|No| ADJUST[Adjust pattern/filter]
    ADJUST --> WRITE
    REFINE -->|Yes| ACTION[Take action]

    style ACTION fill:#27ae60,stroke:#333,color:#fff
```

---

## Part 4: Taking Action

### The Action Loop

Finding issues is only half the value. The other half is **doing something about them**.

```mermaid
flowchart TB
    subgraph "The Complete Loop"
        SCAN[Scan] --> QUERY[Query]
        QUERY --> IDENTIFY[Identify issue]
        IDENTIFY --> DECIDE{Action?}

        DECIDE -->|Quick fix| FIX[Fix now]
        DECIDE -->|Complex| TRACK[Track in backlog]
        DECIDE -->|False positive| IGNORE[Document as OK]

        FIX --> RESCAN[Re-scan to verify]
        TRACK --> SCHEDULE[Schedule for sprint]
        IGNORE --> NEXT[Move on]

        RESCAN --> NEXT
        SCHEDULE --> NEXT
        NEXT --> QUERY
    end

    style FIX fill:#27ae60,stroke:#333,color:#fff
    style TRACK fill:#3498db,stroke:#333,color:#fff
```

### Common Actions

#### 1. Externalize a Hardcoded Value

**Before:**
```java
public class ApiClient {
    private static final String API_URL = "https://api.example.com/v2";
}
```

**After:**
```java
// application.properties
api.url=https://api.example.com/v2

// ApiClient.java
@Value("${api.url}")
private String apiUrl;
```

**Why not just now?** This change takes 3 minutes. You already have the file open from the query results.

#### 2. Remove Dead Configuration

Query found `legacy.feature.enabled=true` that nothing references.

**Why not just now?** Delete it. One line. Commit with message "Remove unused config: legacy.feature.enabled". Done.

#### 3. Consolidate Duplicate Constants

Query found `TIMEOUT_MS = 30000` defined in 5 different files.

**Why not just now?** Create a single `Timeouts.java` class, define it once, import everywhere. 15 minutes, 5 fewer maintenance points.

### The Compound Effect

```mermaid
graph LR
    subgraph "Day 1"
        D1[Scan] --> F1[Fix 3 issues]
    end

    subgraph "Day 2"
        D2[Scan] --> F2[Fix 2 issues]
    end

    subgraph "Day 3"
        D3[Scan] --> F3[Fix 4 issues]
    end

    subgraph "Week 1 Total"
        F1 --> T1[9 issues fixed]
        F2 --> T1
        F3 --> T1
    end

    subgraph "Month 1 Total"
        T1 --> T2[~40 issues fixed]
    end

    subgraph "Quarter 1 Total"
        T2 --> T3[~120 issues fixed<br/>Codebase transformed]
    end

    style T3 fill:#27ae60,stroke:#333,color:#fff
```

Small actions compound. A few fixes per day, every day, transforms a codebase.

---

## Part 5: Building the Habit

### The Daily Scan

Make scanning part of your routine:

```mermaid
flowchart LR
    subgraph "Morning Routine"
        COFFEE[Get coffee] --> SCAN[Run scan]
        SCAN --> REVIEW[Review top 5 issues]
        REVIEW --> FIX[Fix 1-2 quick ones]
        FIX --> CODE[Start regular work]
    end

    style FIX fill:#27ae60,stroke:#333,color:#fff
```

### The PR Check

Add to your code review checklist:

```mermaid
flowchart TB
    subgraph "PR Review Checklist"
        PR[New PR] --> NORMAL[Normal review items]
        NORMAL --> CONFIG{New constants?}

        CONFIG -->|Yes| CHECK[Are they config candidates?]
        CHECK -->|Yes| COMMENT[Request externalization]
        CHECK -->|No| APPROVE[Approve]

        CONFIG -->|No| APPROVE
    end

    style COMMENT fill:#f39c12,stroke:#333,color:#000
    style APPROVE fill:#27ae60,stroke:#333,color:#fff
```

### The Sprint Ritual

Each sprint:

1. **Scan** all active projects
2. **Query** for new configuration debt
3. **Budget** 2-4 hours for config cleanup
4. **Track** trends over time

```mermaid
graph TB
    subgraph "Sprint Metrics"
        S1[Sprint 1<br/>847 constants<br/>23 issues] --> S2[Sprint 2<br/>812 constants<br/>18 issues]
        S2 --> S3[Sprint 3<br/>789 constants<br/>14 issues]
        S3 --> S4[Sprint 4<br/>756 constants<br/>11 issues]
        S4 --> TREND[Consistent improvement]
    end

    style TREND fill:#27ae60,stroke:#333,color:#fff
```

---

## Part 6: Advanced Patterns

### Multi-Project Analysis

Scanning multiple projects reveals cross-cutting patterns:

```cypher
// Find parameters used across multiple projects
MATCH (p:Parameter)-[:USED_IN]->()-[:BELONGS_TO]->(proj:Project)
WITH p, count(DISTINCT proj) as projectCount
WHERE projectCount > 1
RETURN p.name, p.value, projectCount
ORDER BY projectCount DESC
```

### Change Detection

Compare scans over time:

```mermaid
flowchart LR
    subgraph "Temporal Analysis"
        SCAN1[Scan: Jan 1<br/>500 constants] --> DIFF1{Compare}
        SCAN2[Scan: Feb 1<br/>523 constants] --> DIFF1
        DIFF1 --> NEW[23 new constants]
        NEW --> REVIEW[Review additions]
        REVIEW --> PREVENT[Prevent config drift]
    end

    style PREVENT fill:#27ae60,stroke:#333,color:#fff
```

### Integration with CI/CD

```mermaid
flowchart TB
    subgraph "CI Pipeline"
        PUSH[Git Push] --> BUILD[Build]
        BUILD --> TEST[Test]
        TEST --> SCAN[Const Catalog Scan]
        SCAN --> CHECK{New config debt?}

        CHECK -->|Critical| FAIL[Fail build]
        CHECK -->|Warning| WARN[Post comment]
        CHECK -->|None| PASS[Pass]

        FAIL --> FIX[Developer fixes]
        FIX --> PUSH

        WARN --> ARTIFACT[Generate report]
    end

    style FAIL fill:#e74c3c,stroke:#333,color:#fff
    style PASS fill:#27ae60,stroke:#333,color:#fff
```

---

## Conclusion: The Philosophy in Practice

You've learned:
- How to **scan** your codebase
- How to **query** the results
- How to **take action** on findings
- How to **build habits** for continuous improvement

But the most important lesson isn't technical. It's philosophical:

### Every small action matters

```mermaid
graph TB
    subgraph "The Choice"
        CONSTANT[You see a hardcoded URL]

        CONSTANT --> LATER["I'll fix it later"<br/>Probability: 10%]
        CONSTANT --> NOW["Why not just now?"<br/>Probability: 100%]

        LATER --> STAYS[URL stays hardcoded]
        NOW --> FIXED[URL externalized]
    end

    style STAYS fill:#e74c3c,stroke:#333,color:#fff
    style FIXED fill:#27ae60,stroke:#333,color:#fff
    style NOW fill:#f39c12,stroke:#333,color:#000
```

### The question that changes everything

Before you close this tutorial, ask yourself:

> Is there something in my current project—right now—that I've been meaning to fix?

A constant that should be a parameter. A config file that needs cleanup. A magic number that needs a name.

You have the tool. You have the knowledge. You have this moment.

**Why not just now?**

```bash
# Your next command
curl -X POST http://localhost:8080/api/scan \
  -H "Content-Type: application/json" \
  -d '{"projectPath": "YOUR_PROJECT_PATH_HERE"}'
```

---

## Quick Reference

### Scan Commands

| Method | Command |
|--------|---------|
| Web UI | http://localhost:3000 → Scan |
| API | `curl -X POST http://localhost:8080/api/scan -H "Content-Type: application/json" -d '{"projectPath": "/path"}'` |
| CLI | `java -jar const-catalog-cli*.jar /path` |

### Essential Queries

| Purpose | Query |
|---------|-------|
| All constants | `MATCH (c:Constant) RETURN c` |
| Config candidates | `MATCH (c:Constant) WHERE c.name =~ '(?i).*(HOST\|PORT\|URL).*' RETURN c` |
| Unused params | `MATCH (p:Parameter) WHERE NOT (p)-[:USED_IN]->() RETURN p` |
| Duplicates | `MATCH (c:Constant) WITH c.value as val, count(*) as cnt WHERE cnt > 1 RETURN val, cnt` |

### Action Checklist

- [ ] Quick fix (< 5 min)? **Do it now**
- [ ] Complex fix? **Create ticket, tag 'config-debt'**
- [ ] False positive? **Document why it's OK**
- [ ] Unsure? **Ask a teammate**

---

*"The best time to plant a tree was 20 years ago. The second best time is now."*

*The best time to clean up your configuration was when it was first written. The second best time is **right now**.*
