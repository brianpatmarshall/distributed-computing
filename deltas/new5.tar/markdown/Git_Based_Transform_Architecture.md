# Git-Based Transform Architecture

How the Constants Catalog uses git branches to safely transform Java source files, preserving originals and enabling compilation verification.

---

## Table of Contents

1. [Rationale](#1-rationale)
2. [Before and After: Backup vs. Git](#2-before-and-after-backup-vs-git)
3. [Architecture Overview](#3-architecture-overview)
4. [The Transform Flow](#4-the-transform-flow)
5. [Git Repository Initialization](#5-git-repository-initialization)
6. [Branch Naming and Lifecycle](#6-branch-naming-and-lifecycle)
7. [In-Place Transformation](#7-in-place-transformation)
8. [Rollback and Error Handling](#8-rollback-and-error-handling)
9. [File Comparison via Git](#9-file-comparison-via-git)
10. [Compilation Verification](#10-compilation-verification)
11. [Component Responsibilities](#11-component-responsibilities)
12. [Test Coverage](#12-test-coverage)

---

## 1. Rationale

### The Problem with Backup-Based Transforms

The original design wrote transformed files to a `backups/` directory:

```
backups/
  src/
    java/
      com/
        example/
          AppConfig.java          ← transformed
          AppConfig.java.orig     ← original
```

This had several drawbacks:

- **No compilation check** — The transformed files sit in an isolated directory outside any Java project structure. You can't run `mvn compile` on them to verify they're valid Java.
- **Duplicate filesystem** — Every transformed file exists in two places (source and backups), consuming disk and creating confusion about which is authoritative.
- **Manual cleanup** — The `backups/` directory grows with every transform run. Old `.orig` files accumulate.
- **No diff tool integration** — Comparing before/after requires reading two files from different paths. Standard tools like `git diff` don't work.
- **Permission issues in Docker** — The `backups/` volume mount required special ownership handling (`chown` in entrypoint).

### The Git-Based Solution

By transforming files on a git branch, we get all of this for free:

```mermaid
graph LR
    subgraph "main branch"
        O1[AppConfig.java<br/>original code]
    end
    subgraph "main-transform branch"
        T1[AppConfig.java<br/>transformed code]
    end
    O1 -.->|"git diff main..main-transform"| T1
    T1 -.->|"git checkout main"| O1
```

- **Compilation works** — The transform branch is a complete Java project. `mvn compile` verifies everything.
- **No duplication** — Git stores only the diffs, not full copies.
- **Built-in diff** — `git diff main..main-transform` shows exactly what changed.
- **Built-in rollback** — `git checkout main` restores originals instantly.
- **Built-in cleanup** — `git branch -D main-transform` removes all transformed files at once.
- **No Docker permissions** — No `backups/` directory needed.

---

## 2. Before and After: Backup vs. Git

### Before (Backup-Based)

```mermaid
sequenceDiagram
    participant SVC as Service
    participant FS as File System
    participant B as backups/

    SVC->>FS: Read source file
    SVC->>B: Copy original → .orig
    SVC->>SVC: Modify AST
    SVC->>B: Write transformed file
    Note over B: Files sit outside<br/>project structure.<br/>Cannot compile.

    opt Create Branch (optional)
        SVC->>FS: Copy from backups/ back to source
        SVC->>FS: git commit
        SVC->>FS: git checkout original
    end
```

**Problems:** Two copies of every file. Branch creation was optional — extra step after transform. Transformed files couldn't be compiled until copied back.

### After (Git-Based)

```mermaid
sequenceDiagram
    participant SVC as Service
    participant Git as Git
    participant FS as File System

    SVC->>Git: Create branch: main-transform
    SVC->>FS: Read source file
    SVC->>SVC: Modify AST
    SVC->>FS: Write directly to source file
    Note over FS: Transformed file is in the<br/>real project. Can compile.
    SVC->>Git: Commit transformed files
    SVC->>Git: Checkout original branch
    Note over FS: Original files restored<br/>automatically by git.
```

**Benefits:** One copy. Branch is the mechanism, not an afterthought. Transformed files are in a compilable project.

---

## 3. Architecture Overview

```mermaid
graph TB
    subgraph "Frontend"
        UI[TransformPage.tsx]
    end

    subgraph "Backend"
        CTRL[TransformController]
        SVC[CodeTransformationService]
        GIT[GitService]
    end

    subgraph "Core (no Spring)"
        CLT[ConfigLookupTransformer]
        UCR[UnusedConstantRemover]
    end

    subgraph "Storage"
        NEO[(Neo4j)]
        FS[Source Files]
        REPO[".git repository"]
    end

    UI -->|POST /api/transform| CTRL
    CTRL --> SVC
    SVC -->|Query candidates| NEO
    SVC -->|Branch operations| GIT
    GIT -->|git CLI| REPO
    SVC -->|Transform in-place| CLT
    SVC -->|Remove in-place| UCR
    CLT -->|Read/Write| FS
    UCR -->|Read/Write| FS

    style GIT fill:#4488ff,color:#fff
    style REPO fill:#4488ff,color:#fff
```

### Key Design Principle

The core transformers (`ConfigLookupTransformer`, `UnusedConstantRemover`) are **git-unaware**. They read a file, modify the AST, and write the result. They don't know or care about branches.

The `CodeTransformationService` is the **orchestrator** — it manages the git lifecycle (branch, commit, checkout) and delegates the actual file transformation to the core classes.

`GitService` is the **git abstraction** — it wraps git CLI commands with error handling, timeouts, and rollback support.

---

## 4. The Transform Flow

### Live Run (Non-Dry-Run)

```mermaid
flowchart TD
    A[Transform Request<br/>dryRun: false] --> B{Git repo exists?}

    B -->|No| C[git init<br/>Create .gitignore<br/>Commit: 'Pre-transform code']
    B -->|Yes| D[Get current branch name]
    C --> D

    D --> E{Branch<br/>already exists?}
    E -->|Yes| F[Delete old transform branch]
    E -->|No| G[Create: rootBranch-transform]
    F --> G

    G --> H{Scope?}
    H -->|REMOVE_UNUSED| I[removeFromProjectInPlace]
    H -->|ALL/CONSTANTS/PARAMS| J[transformProjectInPlace]

    I --> K[Commit transformed files]
    J --> K

    K --> L[Checkout original branch]
    L --> M[Return BranchResult<br/>with branch name]

    style C fill:#ffaa00,color:#000
    style G fill:#4488ff,color:#fff
    style I fill:#44aa44,color:#fff
    style J fill:#44aa44,color:#fff
    style L fill:#4488ff,color:#fff
```

### Dry Run

```mermaid
flowchart TD
    A[Transform Request<br/>dryRun: true] --> B[Query Neo4j for candidates]
    B --> C[Parse AST, report what would change]
    C --> D[Return results]
    D --> E[No git operations<br/>No file modifications]

    style E fill:#999,color:#fff
```

### Fallback

If git operations fail (e.g., git not installed, permission denied), the service falls back to the legacy backup-based approach:

```mermaid
flowchart TD
    A[transformOnBranch] --> B{Success?}
    B -->|Yes| C[Return BranchResult<br/>with branch name + result]
    B -->|No| D[Log warning]
    D --> E[transformer.transformProject<br/>backup-based fallback]
    E --> F[Return result<br/>without branch name]

    style D fill:#ff8800,color:#fff
    style E fill:#ffaa00,color:#000
```

---

## 5. Git Repository Initialization

When the target project is not a git repository, the system initializes one automatically:

```mermaid
sequenceDiagram
    participant SVC as CodeTransformationService
    participant GIT as GitService
    participant FS as File System

    SVC->>GIT: isGitRepo(projectDir)?
    GIT-->>SVC: false

    SVC->>GIT: initRepoWithInitialCommit(projectDir)

    GIT->>GIT: git init
    GIT->>GIT: git config user.email/name
    GIT->>FS: Create .gitignore (Java standard)
    GIT->>GIT: git add -A
    GIT->>GIT: git commit -m "Pre-transform code"
    GIT->>GIT: Normalize branch to "main"

    GIT-->>SVC: "main"
```

### The .gitignore

Created automatically for non-git projects:

```gitignore
# Build output
target/
build/
out/
bin/

# IDE files
.idea/
*.iml
.project
.classpath
.settings/
.vscode/

# OS files
.DS_Store
Thumbs.db

# Logs and packages
*.log
*.jar
*.war
*.ear
*.class
```

This prevents build artifacts and IDE files from being committed. The initial commit captures only the source code — providing a clean baseline for `git diff`.

---

## 6. Branch Naming and Lifecycle

### Naming Convention

```
<rootBranch>-transform
```

Examples:
- `main` → `main-transform`
- `develop` → `develop-transform`
- `feature/auth` → `feature/auth-transform`

### Lifecycle

```mermaid
stateDiagram-v2
    [*] --> OriginalBranch: Start
    OriginalBranch --> CheckExists: transformOnBranch()

    CheckExists --> DeleteOld: Branch exists
    CheckExists --> CreateNew: Branch doesn't exist
    DeleteOld --> CreateNew: git branch -D

    CreateNew --> OnTransformBranch: git checkout -b

    OnTransformBranch --> TransformFiles: In-place transform
    TransformFiles --> CommitChanges: git add + commit
    CommitChanges --> SwitchBack: git checkout original

    SwitchBack --> OriginalBranch: Files restored

    note right of OnTransformBranch
        Source files are modified
        directly on this branch
    end note

    note right of SwitchBack
        git checkout restores the
        original source files
    end note
```

### Rerunning Transforms

If a transform branch already exists from a previous run, it is **deleted and recreated**:

```java
if (gitService.branchExists(projectDir, newBranch)) {
    gitService.deleteBranch(projectDir, newBranch, true);
}
gitService.createAndCheckoutBranch(projectDir, newBranch);
```

This ensures each transform run starts fresh. The user doesn't accumulate stale transform branches.

---

## 7. In-Place Transformation

### ConfigLookupTransformer

Replaces constant usages and parameter getter calls with `config.lookupType()` calls:

```mermaid
flowchart LR
    subgraph "Before (on original branch)"
        A["String host = DB_HOST;"]
        B["int port = config.getInt('server.port');"]
    end
    subgraph "After (on transform branch)"
        C["String host = config.lookup('db.host');"]
        D["int port = config.lookupInt('server.port');"]
    end
    A -->|transformFileInPlace| C
    B -->|transformFileInPlace| D
```

The `transformFileInPlace()` method:
1. Parses the source file with JavaParser
2. Visits the AST with a `ModifierVisitor`
3. Replaces `NameExpr`/`FieldAccessExpr` (constants) and `MethodCallExpr` (parameter getters)
4. Injects `@Autowired SiteConfigurationService config` field + imports
5. Writes the modified AST **back to the source file**

No backup. No copy. The source file is overwritten directly — the original is preserved on the git branch.

### UnusedConstantRemover

Deletes `public static final` field declarations:

```mermaid
flowchart LR
    subgraph "Before"
        A["public static final String OLD_HOST = 'legacy';"]
        B["public static final String CURRENT = 'prod';"]
    end
    subgraph "After"
        C["(removed)"]
        D["public static final String CURRENT = 'prod';"]
    end
    A -->|removeFromFileInPlace| C
    B -.->|"unchanged"| D

    style C fill:#ff4444,color:#fff,stroke-dasharray: 5 5
```

The `removeFromFileInPlace()` method:
1. Parses, finds `public static final` fields matching targets
2. Checks protected names, logger types, line tolerance
3. Removes candidates from AST (bottom-up)
4. **Validates no dangling references** — checks if removed names still appear in the AST
5. Writes the modified AST back to the source file

### Safety: Dangling Reference Detection

Even with in-place transforms, the dangling reference check prevents broken files:

```mermaid
flowchart TD
    A[Remove constants<br/>from AST] --> B[Scan AST for<br/>NameExpr/FieldAccessExpr<br/>referencing removed names]
    B --> C{Dangling refs?}
    C -->|None| D[Write file ✓]
    C -->|Found| E[Re-parse original]
    E --> F[Remove only safe constants]
    F --> D

    style D fill:#44aa44,color:#fff
```

---

## 8. Rollback and Error Handling

### Normal Flow

```
main → main-transform → [transform files] → [commit] → main
```

Git checkout back to `main` automatically restores all original files.

### Error During Transform

```mermaid
flowchart TD
    A[Create transform branch] --> B[Transform files in-place]
    B --> C{Error?}
    C -->|No| D[Commit + checkout main]
    C -->|Yes| E[Checkout main<br/>restores originals]
    E --> F[Delete transform branch]
    F --> G[Fall back to backup-based transform]

    style E fill:#ff8800,color:#fff
    style F fill:#ff4444,color:#fff
    style G fill:#ffaa00,color:#000
```

```java
try {
    // ... create branch, transform, commit ...
    gitService.checkoutBranch(projectDir, originalBranch);
    return BranchResult.success(newBranch, result);
} catch (GitService.GitException e) {
    // Rollback: restore originals and clean up
    gitService.checkoutBranch(projectDir, originalBranch);
    if (gitService.branchExists(projectDir, newBranch)) {
        gitService.deleteBranch(projectDir, newBranch, true);
    }
    return BranchResult.failure(e.getMessage());
}
```

**Key invariant:** After any error, the original branch is checked out and the transform branch is deleted. The source files are never left in a partially-transformed state.

---

## 9. File Comparison via Git

The compare endpoint reads file content from git branches without checking them out:

```mermaid
sequenceDiagram
    participant FE as Frontend
    participant API as TransformController
    participant GIT as GitService

    FE->>API: GET /api/transform/compare?path=...&branch=main-transform

    API->>API: Read original from source file (current branch)
    API->>GIT: getFileFromBranch("main-transform", relativePath)
    GIT->>GIT: git show main-transform:src/Config.java
    GIT-->>API: transformed content

    API->>API: Generate line-level diff
    API-->>FE: FileComparisonResponse
```

```java
// Read from a branch without checkout
public String getFileFromBranch(Path projectDir, String branchName, String filePath)
        throws GitException {
    return runGitOutput(projectDir, "show", branchName + ":" + filePath);
}
```

The `git show branch:path` command reads a file from any branch without modifying the working directory. This allows the DiffViewer to show before/after comparisons while the user stays on the original branch.

---

## 10. Compilation Verification

The primary advantage of git-based transforms: **the transform branch is a real Java project**.

```mermaid
flowchart LR
    A[Transform complete<br/>on main-transform] --> B["git checkout main-transform"]
    B --> C["mvn compile"]
    C --> D{Compiles?}
    D -->|Yes| E["Transform is valid ✓"]
    D -->|No| F["Fix issues or discard branch"]
    E --> G["git checkout main"]
    F --> G

    style E fill:#44aa44,color:#fff
    style F fill:#ff4444,color:#fff
```

After a transform run, the user (or CI) can:

```bash
# Switch to the transform branch
git checkout main-transform

# Verify compilation
mvn compile

# Run tests
mvn test

# If everything passes, merge
git checkout main
git merge main-transform

# Or discard
git branch -D main-transform
```

This is impossible with the backup-based approach — files in `backups/` are outside the project structure and can't be compiled.

---

## 11. Component Responsibilities

```mermaid
graph TD
    subgraph "Orchestration (Spring)"
        SVC["CodeTransformationService<br/>━━━━━━━━━━━━━━━━━━━━━<br/>• transformOnBranch()<br/>• Queries Neo4j<br/>• Manages git lifecycle<br/>• Handles fallback"]
        GIT["GitService<br/>━━━━━━━━━━━━━━━━━━━━━<br/>• Git CLI wrapper<br/>• init, branch, checkout<br/>• commit, show, delete<br/>• .gitignore creation"]
    end

    subgraph "Core (Pure Java)"
        CLT["ConfigLookupTransformer<br/>━━━━━━━━━━━━━━━━━━━━━<br/>• transformFileInPlace()<br/>• transformProjectInPlace()<br/>• dryRun()<br/>• AST: replace usages"]
        UCR["UnusedConstantRemover<br/>━━━━━━━━━━━━━━━━━━━━━<br/>• removeFromFileInPlace()<br/>• removeFromProjectInPlace()<br/>• dryRun()<br/>• AST: delete declarations"]
    end

    SVC --> GIT
    SVC --> CLT
    SVC --> UCR

    style SVC fill:#336,color:#fff
    style GIT fill:#448,color:#fff
    style CLT fill:#363,color:#fff
    style UCR fill:#363,color:#fff
```

### Separation of Concerns

| Layer | Knows about | Doesn't know about |
|---|---|---|
| `TransformController` | HTTP, request/response, compare endpoint | Git, AST, Neo4j |
| `CodeTransformationService` | Neo4j queries, git lifecycle, scope routing | AST manipulation, file parsing |
| `GitService` | Git CLI commands, branch operations | Transformation logic, Neo4j |
| `ConfigLookupTransformer` | JavaParser AST, lookup method selection | Git, Neo4j, Spring |
| `UnusedConstantRemover` | JavaParser AST, safety checks | Git, Neo4j, Spring |

The core transformers live in `const-catalog-core` (no Spring dependency). They can be tested independently with plain Java files and no git, Spring context, or database.

---

## 12. Test Coverage

### GitTransformWorkflowTest — 17 tests

End-to-end tests using real git operations in temporary directories:

```mermaid
pie title Test Distribution
    "Transform in-place" : 7
    "Remove in-place" : 5
    "Full git workflow" : 5
```

#### Transform In-Place (7 tests)

| Test | Verifies |
|---|---|
| `transformInPlacePreservesOriginalOnMainBranch` | Checkout main → original files restored |
| `transformInPlaceShowsInGitDiff` | `git diff` shows constant → lookup changes |
| `transformInPlaceMultipleFiles` | Two files in different directories |
| `transformInPlaceInjectsConfigField` | `@Autowired` + imports added |
| `transformInPlaceReplacesParameterGetters` | `getProperty()` → `config.lookup()` |
| `transformInPlaceSkipsNoUsages` | No usages → SKIPPED, file unchanged |
| `transformInPlaceUsesCorrectLookupMethods` | 5 types → correct lookup method each |

#### Remove In-Place (5 tests)

| Test | Verifies |
|---|---|
| `removeInPlacePreservesOriginalOnMainBranch` | Removed on branch, restored on main |
| `removeInPlaceMultipleFiles` | Constants removed from 2 files |
| `removeInPlaceDanglingReferencePreventsRemoval` | Referenced constant → FAILED |
| `removeInPlaceMixedSafeAndUnsafe` | Safe removed, unsafe preserved |
| `removeInPlaceProtectsLoggerAndVersion` | LOG/VERSION skipped |

#### Full Git Workflow (5 tests)

| Test | Verifies |
|---|---|
| `fullWorkflowGitShowReadsFromBranch` | `git show branch:file` returns transformed content |
| `fullWorkflowInitialisesNonGitProject` | `git init` + .gitignore + baseline commit |
| `fullWorkflowReusesTransformBranch` | Delete old branch, create new, verify round 2 |
| `fullWorkflowRealisticService` | Multi-constant class, both branches correct |
| `fullWorkflowRemoveUnusedRealistic` | Mixed used/unused, dangling ref blocks one |

### Existing Tests (Unchanged)

The 56 tests in `UnusedConstantRemoverTest` and 41 tests in `ConfigLookupTransformerTest` continue to test the backup-based methods (`transformFile`, `removeFromFile`). These serve as a safety net for the fallback path.
