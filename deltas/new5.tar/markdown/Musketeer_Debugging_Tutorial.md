# The Musketeer's Guide to Debugging

*"All for one, and one for all"* — when multiple layers work together, a bug in one layer can silence another. This tutorial shows how to trace a problem from the user's screen down to the root cause, using a real example from this project.

---

## Table of Contents

### Chapter 1: Case Study — "Where Did My Progress Go?"
1. [The Symptom](#1-the-symptom)
2. [Layer Map: Know Your Terrain](#2-layer-map-know-your-terrain)
3. [Start at the Surface](#3-start-at-the-surface)
4. [Follow the Data Upstream](#4-follow-the-data-upstream)
5. [Check the Backend Logs](#5-check-the-backend-logs)
6. [Read the Source — Find the Timing Bug](#6-read-the-source--find-the-timing-bug)
7. [The Fix](#7-the-fix)
8. [Verify End-to-End](#8-verify-end-to-end)

### Chapter 2: The Musketeer Approach to Debugging
9. [The Philosophy](#9-the-philosophy)
10. [The Five Musketeers](#10-the-five-musketeers)
11. [Athos: Map the Territory](#11-athos-map-the-territory)
12. [Porthos: Observe from the Outside](#12-porthos-observe-from-the-outside)
13. [Aramis: Follow the Data](#13-aramis-follow-the-data)
14. [D'Artagnan: Read the Source](#14-dartagnan-read-the-source)
15. [The Cardinal's Rule: Verify the Fix](#15-the-cardinals-rule-verify-the-fix)
16. [Debugging Checklist](#16-debugging-checklist)

---

# Chapter 1: Case Study — "Where Did My Progress Go?"

## 1. The Symptom

The user reported: *"Scanning in progress... is still circling. How can I tell how much work has been done?"*

After scanning a large project (Apache Flink — thousands of Java files), the scan progress spinner kept spinning but there was no indication of what was happening. The progress bar appeared frozen. The user couldn't tell if the scan was stuck, still working, or had silently failed.

A secondary symptom was discovered during investigation: *"The number of constants updates, the number of parameters does not."*

What seemed like one problem turned out to be two, tangled together.

---

## 2. Layer Map: Know Your Terrain

Before debugging, I identified every layer the data passes through:

```mermaid
flowchart TD
    A["Browser: ScanPage.tsx"] -->|EventSource| B["nginx"]
    B -->|proxy_pass| C["ScanController"]
    C -->|"@Async"| D["ScanService"]
    D -->|callback| E["ProjectScanner"]
    E -->|parse files| F["File System"]
    D -->|after parsing| G["GraphPopulatorService"]
    G -->|write| H["Neo4j"]

    style A fill:#61dafb,color:#000
    style B fill:#009639,color:#fff
    style C fill:#ff8800,color:#fff
    style D fill:#ff8800,color:#fff
    style E fill:#ff8800,color:#fff
    style G fill:#ff8800,color:#fff
    style H fill:#4488ff,color:#fff
```

The data flows: **Scanner** → **ScanService callback** → **SseEmitter** → **nginx** → **Browser EventSource** → **React state** → **UI**

Any layer could be the culprit. The Musketeer approach says: start at the surface, work inward.

---

## 3. Start at the Surface

**Question:** Is the frontend receiving events at all?

**Tool:** Browser DevTools → Network tab → filter for `stream`

**Finding:** The SSE connection was open and events were flowing during the file parsing phase. But after all files were parsed, the events stopped — and the spinner kept going for several more minutes before the results appeared.

**Conclusion:** The frontend was fine. Events stopped because the backend stopped sending them. The scan has two phases: parsing (events flow) and graph population (silence).

---

## 4. Follow the Data Upstream

**Question:** What happens between the last progress event and the completion event?

I read the `ScanService.scanProjectWithProgress()` method:

```java
// Phase 1: Parse files — events stream here
ProjectScanner.ScanResult scanResult = projectScanner.scan(projectPath, listener);

// Phase 2: Populate graph — NO events sent here
graphPopulator.populateGraph(projectPath, ...);

// Phase 3: Send completion event
emitter.send(SseEmitter.event().name("complete").data(...));
```

**Finding:** There's a silent gap between Phase 1 and Phase 3. For a project with thousands of constants, the `populateGraph()` call can take minutes — writing thousands of nodes to Neo4j one at a time. During this entire period, the frontend receives **zero events**.

The user sees: progress bar at 100%, spinner still going, no new file names appearing. It looks frozen.

---

## 5. Check the Backend Logs

**Question:** Is the graph population actually running, or is it stuck?

```bash
docker logs const-catalog-backend 2>&1 | tail -20
```

**Finding:** Logs showed Neo4j deprecation warnings for every relationship being created — hundreds of them. The graph population was running, just slowly and silently. The `@Transactional` method was doing individual `repository.save()` calls for each node — thousands of round-trips to Neo4j.

---

## 6. Read the Source — Find the Timing Bug

While investigating the silent graph phase, I also traced the "parameters don't update" issue.

The progress listener in `ProjectScanner.scan()`:

```java
// BEFORE the fix — listener fires BEFORE parsing
for (Path propertyFile : propertyFiles) {
    fileIndex++;
    listener.onProgress(fileName, ..., constants.size(), parameters.size()); // ← count is STALE
    List<Parameter> fileParams = propertyParser.parseParameters(propertyFile);
    parameters.addAll(fileParams);
}
```

**Finding:** The listener callback fires **before** the file is parsed. So `parameters.size()` is the count from the *previous* file, not the current one. Property files are parsed first, so during that phase the parameter count lags by one file. Once Java files start (parsed second), `parameters.size()` is frozen at its final value while `constants.size()` keeps growing.

The user sees: constants counting up, parameters stuck.

```mermaid
sequenceDiagram
    participant Scanner
    participant Listener
    participant Frontend

    Note over Scanner: Parse property file 1
    Scanner->>Listener: onProgress(constants=0, parameters=0)
    Listener->>Frontend: Event: 0 constants, 0 parameters
    Scanner->>Scanner: Parse → found 5 parameters

    Note over Scanner: Parse property file 2
    Scanner->>Listener: onProgress(constants=0, parameters=5)
    Listener->>Frontend: Event: 0 constants, 5 parameters
    Scanner->>Scanner: Parse → found 3 more parameters

    Note over Scanner: Parse Java file 1
    Scanner->>Listener: onProgress(constants=0, parameters=8)
    Listener->>Frontend: Event: 0 constants, 8 parameters
    Scanner->>Scanner: Parse → found 4 constants

    Note over Scanner: Parse Java file 2
    Scanner->>Listener: onProgress(constants=4, parameters=8)
    Listener->>Frontend: Event: 4 constants, 8 parameters
    Scanner->>Scanner: Parse → found 6 more constants

    Note over Frontend: User sees: constants climbing,<br/>parameters frozen at 8
```

---

## 7. The Fix

Two separate fixes for two separate problems:

### Fix 1: Move the callback to after parsing

```java
// AFTER the fix — listener fires AFTER parsing
for (Path propertyFile : propertyFiles) {
    fileIndex++;
    List<Parameter> fileParams = propertyParser.parseParameters(propertyFile);
    parameters.addAll(fileParams);
    listener.onProgress(fileName, ..., constants.size(), parameters.size()); // ← count is CURRENT
}
```

Same change for the Java file loop. Now both counters reflect the file that was just parsed.

### Fix 2: Send a "Populating graph database" event

Added an event between Phase 1 (parsing) and Phase 2 (graph population):

```java
ScanProgressEvent graphEvent = ScanProgressEvent.builder()
    .eventType(ScanProgressEvent.EventType.FILE_PARSED)
    .fileName("Populating graph database...")
    .constantsFound(scanResult.constants().size())
    .parametersFound(scanResult.parameters().size())
    .build();
emitter.send(SseEmitter.event().name("progress").data(...));
```

And updated the frontend to detect this special event and change the UI:

```typescript
<div className="text-neon-cyan font-medium">
  {currentEvent?.fileName?.startsWith('Populating')
    ? 'Populating graph database...'
    : 'Scanning in progress...'}
</div>
```

### Fix 3: Batch Neo4j writes (bonus)

Replaced individual `repository.save()` calls with `repository.saveAll()` in batches of 500. This reduced thousands of round-trips to a handful, making the graph population phase much shorter.

---

## 8. Verify End-to-End

After the fixes:

```mermaid
sequenceDiagram
    participant FE as Frontend
    participant BE as Backend
    participant Neo as Neo4j

    Note over FE,BE: Phase 1: File Parsing
    loop For each file
        BE->>BE: Parse file
        BE->>FE: progress: file 42/2000, 15 constants, 8 parameters
    end

    Note over FE: User sees: progress bar advancing,<br/>both counters climbing

    Note over FE,Neo: Phase 2: Graph Population
    BE->>FE: progress: "Populating graph database..."
    Note over FE: Header changes to<br/>"Populating graph database..."
    BE->>Neo: saveAll(batch of 500 constants)
    BE->>Neo: saveAll(batch of 500 parameters)

    Note over FE,BE: Phase 3: Complete
    BE->>FE: complete: scan finished
    Note over FE: Results panel appears
```

Verified:
- Both constants and parameters count up during scanning
- "Populating graph database..." appears after all files are parsed
- Graph population is faster due to batch writes
- Results panel appears after graph is fully populated

---

# Chapter 2: The Musketeer Approach to Debugging

## 9. The Philosophy

*"One for all, and all for one"* — in a multi-layer system, every layer depends on the others. A bug doesn't live in one layer; it manifests where the layers meet. The Musketeer approach treats debugging as a coordinated campaign: each Musketeer has a role, and you deploy them in order.

```mermaid
flowchart LR
    A["Athos<br/>Map the Territory"] --> B["Porthos<br/>Observe from Outside"]
    B --> C["Aramis<br/>Follow the Data"]
    C --> D["D'Artagnan<br/>Read the Source"]
    D --> E["The Cardinal's Rule<br/>Verify the Fix"]

    style A fill:#4488ff,color:#fff
    style B fill:#44aa44,color:#fff
    style C fill:#ff8844,color:#fff
    style D fill:#aa44ff,color:#fff
    style E fill:#ff4444,color:#fff
```

The order matters. Skipping straight to reading source code (D'Artagnan) without first observing the system (Porthos) wastes time — you'll read the wrong code. Starting with the fix (the Cardinal) without understanding the problem means you'll fix the wrong thing.

---

## 10. The Five Musketeers

| Musketeer | Role | Tool | When |
|---|---|---|---|
| **Athos** | Map the territory | Architecture diagrams, layer identification | First. Before touching anything. |
| **Porthos** | Observe from outside | Browser DevTools, curl, docker logs | Second. Gather evidence. |
| **Aramis** | Follow the data | Trace the request/response path layer by layer | Third. Narrow the search. |
| **D'Artagnan** | Read the source | IDE, grep, code reading | Fourth. Find the exact cause. |
| **The Cardinal** | Verify the fix | Tests, end-to-end verification | Last. Prove it's fixed. |

---

## 11. Athos: Map the Territory

*"I do not look for quarrels, but I do not run from them."*

Before you debug, draw the map. Identify every layer, every boundary, every handoff. If you don't know the terrain, you'll get ambushed.

```mermaid
flowchart TD
    subgraph "Layer 1: User Interface"
        UI[Browser / React]
    end
    subgraph "Layer 2: Network"
        NET[HTTP / SSE / WebSocket]
    end
    subgraph "Layer 3: Reverse Proxy"
        PROXY[nginx / Vite dev server]
    end
    subgraph "Layer 4: Application"
        APP[Spring Boot / Node.js]
    end
    subgraph "Layer 5: Data"
        DB[(Database / File System)]
    end

    UI --> NET --> PROXY --> APP --> DB
```

**Ask yourself:**
- How many layers does the data pass through?
- Where are the boundaries? (process boundaries, network boundaries, serialization boundaries)
- Where could data be lost, delayed, or transformed?
- What are the timeouts at each layer?

**In our case study:** The data passed through 7 layers (scanner → callback → emitter → Spring MVC → nginx → EventSource → React state → UI). The bug was at the callback layer (timing) and the emitter layer (missing event).

---

## 12. Porthos: Observe from the Outside

*"I fight because I fight."*

Don't guess. Observe. Use the tools that show you what the system is actually doing, not what you think it's doing.

### Browser Tools

```mermaid
flowchart LR
    subgraph "Chrome DevTools"
        N["Network tab<br/>━━━━━━━━━━<br/>• Request/response<br/>• SSE events<br/>• Status codes<br/>• Timing"]
        C["Console tab<br/>━━━━━━━━━━<br/>• JS errors<br/>• console.log<br/>• React warnings"]
        E["Elements tab<br/>━━━━━━━━━━<br/>• DOM state<br/>• Computed styles<br/>• Event listeners"]
    end
```

**Key questions:**
- Network tab: Is the request being made? What status code? What's in the response?
- Console: Any JavaScript errors? Any warnings?
- For SSE: Is the EventSource connection open? Are events arriving?

### Command Line Tools

```bash
# Hit the API directly, bypass the frontend entirely
curl -v http://localhost:9090/api/stats/health

# Watch SSE events in real time
curl -N http://localhost:9090/api/scan/stream?projectPath=/src/myproject

# Check container logs
docker logs const-catalog-backend --tail 50

# Check container state
docker inspect const-catalog-backend --format '{{.State.Status}} {{.State.Health.Status}}'
```

**The principle:** Every observation either **confirms** a layer is working or **narrows** the search to a specific layer. Don't stop until you know which layer is the problem.

### Example from the case study:

```mermaid
flowchart TD
    A["Browser Network tab:<br/>SSE events arriving?"] -->|Yes, during parsing| B["Frontend OK ✓<br/>Problem is upstream"]
    B --> C["curl direct to backend:<br/>Events sent during graph phase?"] -->|No events| D["Backend doesn't send events<br/>during graph population"]
    D --> E["docker logs:<br/>Is graph population running?"] -->|Yes, but slowly| F["Found the gap: parsing → graph → complete"]

    style B fill:#44aa44,color:#fff
    style F fill:#ff8844,color:#fff
```

---

## 13. Aramis: Follow the Data

*"I am a poet; verses displease me."*

Now that you know which layer has the problem, trace the exact path the data takes through that layer. Read the code path from entry to exit.

### The Technique

1. **Find the entry point** — where does the data enter this layer?
2. **Walk the code path** — follow the data through method calls, conditionals, loops
3. **Identify every transformation** — where is the data created, modified, passed, or dropped?
4. **Look at timing** — does the order of operations matter? Is there a race condition?

### What to look for

```mermaid
flowchart TD
    A["Data enters layer"] --> B{Is it received<br/>correctly?}
    B -->|No| C["Problem: serialization,<br/>encoding, parsing"]
    B -->|Yes| D{Is it processed<br/>in the right order?}
    D -->|No| E["Problem: timing,<br/>race condition,<br/>wrong sequence"]
    D -->|Yes| F{Is it sent to<br/>the next layer?}
    F -->|No| G["Problem: missing emit,<br/>swallowed exception,<br/>conditional skip"]
    F -->|Yes| H["This layer is OK<br/>→ check the next one"]

    style C fill:#ff4444,color:#fff
    style E fill:#ff4444,color:#fff
    style G fill:#ff4444,color:#fff
    style H fill:#44aa44,color:#fff
```

### Example from the case study:

I traced the data through `ProjectScanner.scan()`:

```
For each property file:
  1. fileIndex++
  2. listener.onProgress(constants=0, parameters=0)  ← parameters is STALE
  3. Parse file → parameters now has 5 entries
```

The problem was step 2 vs step 3 — the listener fires before the file is parsed. This is a **timing bug**: the order of operations is wrong.

---

## 14. D'Artagnan: Read the Source

*"I am a Gascon, and I know how to use my sword."*

This is where you find the exact line that's wrong. By now, you know which layer, which method, and roughly what kind of bug. Reading the source is surgical, not exploratory.

### What to focus on

- **The exact line** where the data is wrong — not the line that fails, but the line that makes it wrong
- **Assumptions** — what does the code assume about its inputs? Are those assumptions violated?
- **Boundary conditions** — what happens with zero items? One item? Maximum items?
- **Error handling** — are exceptions caught and swallowed?

### Common patterns that cause bugs

| Pattern | Example | Why it's wrong |
|---|---|---|
| Wrong order | Callback before processing | State is stale |
| Missing event | No notification between phases | Client sees silence |
| Individual saves in a loop | `save()` per node | N transactions instead of 1 |
| Name mismatch | `@RequestParam` without explicit name | Works in IDE, fails in Docker |
| Swallowed exception | `catch (Exception e) { }` | Failure is invisible |
| Stale cache | TanStack staleTime | Old data shown after mutation |

### Example from the case study:

```java
// The exact line — listener fires too early
listener.onProgress(fileName, ..., constants.size(), parameters.size());
// This should be AFTER the next two lines:
List<Parameter> fileParams = propertyParser.parseParameters(propertyFile);
parameters.addAll(fileParams);
```

The fix: swap the order. Two lines moved. That's it.

---

## 15. The Cardinal's Rule: Verify the Fix

*"Give me six lines written by the most honest man in the world, and I will find something in them to hang him."*

The Cardinal is the adversary. He tries to break your fix. Never declare victory until you've verified end-to-end.

### Verification checklist

```mermaid
flowchart TD
    A["Apply the fix"] --> B["Run unit tests"]
    B --> C{All pass?}
    C -->|No| D["Fix broke something else<br/>→ rethink"]
    C -->|Yes| E["Rebuild and deploy"]
    E --> F["Reproduce the original bug"]
    F --> G{Bug still present?}
    G -->|Yes| H["Fix didn't work<br/>→ back to Aramis"]
    G -->|No| I["Test edge cases"]
    I --> J{New bugs?}
    J -->|Yes| D
    J -->|No| K["✓ Verified fixed"]

    style D fill:#ff4444,color:#fff
    style H fill:#ff4444,color:#fff
    style K fill:#44aa44,color:#fff
```

### What to verify:

1. **The original symptom is gone** — Don't just test the code path. Reproduce the exact scenario the user reported.
2. **No regressions** — Run the full test suite. A fix in one layer can break another.
3. **Edge cases** — What about empty projects? Projects with only property files? Projects with only Java files?
4. **Different environments** — If it worked in dev, does it work in Docker? On the remote laptop?

---

## 16. Debugging Checklist

A quick reference card for the Musketeer approach:

```
┌─────────────────────────────────────────────────────────┐
│           THE MUSKETEER DEBUGGING CHECKLIST              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  □ ATHOS: Map the territory                             │
│    □ How many layers?                                   │
│    □ Where are the boundaries?                          │
│    □ What are the timeouts?                             │
│                                                         │
│  □ PORTHOS: Observe from outside                        │
│    □ Browser Network tab — requests/responses           │
│    □ Browser Console — errors/warnings                  │
│    □ curl — bypass frontend, hit API directly           │
│    □ docker logs — backend output                       │
│    □ docker inspect — container state                   │
│                                                         │
│  □ ARAMIS: Follow the data                              │
│    □ Find the entry point                               │
│    □ Walk the code path                                 │
│    □ Identify every transformation                      │
│    □ Check timing and order                             │
│                                                         │
│  □ D'ARTAGNAN: Read the source                          │
│    □ Find the exact wrong line                          │
│    □ Check assumptions                                  │
│    □ Check boundary conditions                          │
│    □ Check error handling                               │
│                                                         │
│  □ THE CARDINAL: Verify the fix                         │
│    □ Unit tests pass                                    │
│    □ Original symptom is gone                           │
│    □ No regressions                                     │
│    □ Works in all environments                          │
│                                                         │
│  "All for one, and one for all!"                        │
└─────────────────────────────────────────────────────────┘
```
