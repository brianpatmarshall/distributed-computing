# Microservice Detection — Two Implementation Approaches

When the scanner parses a Java project, we want to identify which classes are microservices and classify them by type. This document describes two implementation approaches that live on separate branches for comparison.

Both branches add the same detection capability. They differ in **how** the scanner invokes the parser — specifically, whether each Java file is parsed once or multiple times.

---

## Table of Contents

1. [What Both Options Share](#1-what-both-options-share)
2. [Minimal Footprint: Add a Third Parse Pass](#2-minimal-footprint-add-a-third-parse-pass)
3. [Parse Once, Extract Everything](#3-parse-once-extract-everything)
4. [Side-by-Side Comparison](#4-side-by-side-comparison)
5. [File Inventory](#5-file-inventory)

---

## 1. What Both Options Share

Regardless of approach, the following components are identical:

### MicroServiceInfo Record

A simple value object in `const-catalog-core/model/`:

```java
public record MicroServiceInfo(
    boolean isMicroService,
    String microServiceType   // e.g., "REST_CONTROLLER", "FEIGN_CLIENT"
) {
    public static MicroServiceInfo none() { ... }
    public static MicroServiceInfo of(String type) { ... }
}
```

### MicroServiceDetector

A dedicated class in `const-catalog-core/parser/` that accepts a JavaParser `CompilationUnit` and returns a `MicroServiceInfo`. Detection is based on annotations and superclass patterns:

| Type | Detected By | Level |
|---|---|---|
| `SPRING_BOOT` | `@SpringBootApplication` | Class |
| `REST_CONTROLLER` | `@RestController`, `@Path` | Class |
| `FEIGN_CLIENT` | `@FeignClient` | Class |
| `GRPC_SERVICE` | `@GrpcService`, extends `*ImplBase` | Class / Superclass |
| `KAFKA_LISTENER` | `@KafkaListener` | Method |
| `SCHEDULED_SERVICE` | `@Scheduled` | Method |
| `EUREKA_CLIENT` | `@EnableEurekaClient`, `@EnableDiscoveryClient` | Class |

Annotations are checked in priority order. If a class has `@SpringBootApplication` and `@EnableEurekaClient`, it is classified as `SPRING_BOOT` (highest priority wins).

### FileNode Changes

Two new fields on the Neo4j `FileNode` entity:

```java
private boolean isMicroService;
private String microServiceType;
```

No Neo4j migration needed — Spring Data Neo4j adds new properties on save. Existing nodes get `false` / `null`.

### GraphPopulatorService Step 9

A new `setMicroServiceInfo()` method that iterates `ScanResult.microServiceInfos()` and updates matching `FileNode` entries. Follows the exact same pattern as the existing `setJavaFileFqns()` step.

### ScanResult Record

Both options add the same field:

```java
Map<String, MicroServiceInfo> microServiceInfos
```

### Unit Tests

15 tests in `MicroServiceDetectorTest` covering every annotation type, priority ordering, non-microservice classes, and edge cases.

---

## 2. Minimal Footprint: Add a Third Parse Pass

**Branch:** `mono_1-option1`
**Files changed:** 7 (+368 lines)

### Approach

Add a `detectMicroService(Path)` method to `JavaFileParser` that parses the file, builds a `CompilationUnit`, and delegates to `MicroServiceDetector`. This is the same pattern used by the existing `extractFqn(Path)` method.

The scanner calls it as an additional step in the Java file loop, after the existing `parseConstants()`, `parseParameterUsages()`, and `extractFqn()` calls:

```java
// Existing calls (each parses the file independently)
List<Constant> fileConstants = javaParser.parseConstants(javaFile);
List<ParameterUsage> fileUsages = javaParser.parseParameterUsages(javaFile, parameterNames);
String fqn = javaParser.extractFqn(javaFile);

// New call (parses the file a fourth time)
MicroServiceInfo msInfo = javaParser.detectMicroService(javaFile);
```

### What Changes

- **`JavaFileParser`**: Add `MicroServiceDetector` field and `detectMicroService(Path)` method
- **`ProjectScanner`**: Add `microServiceInfos` map, call `detectMicroService()` in the loop

### Why Choose This

- **Smallest diff** — only touches two existing files (parser and scanner), plus new files
- **No refactoring risk** — existing `parseConstants()`, `parseParameterUsages()`, and `extractFqn()` methods are untouched
- **Easy to understand** — follows the established pattern exactly
- **Easy to revert** — remove the call and the method, done

### Tradeoff

Each Java file is now parsed **four** times (constants, parameter usages, FQN, microservice detection). On a project like Apache Flink with thousands of Java files, this adds measurable scan time. The AST parse itself is the expensive part — running visitors on an already-parsed AST is cheap.

---

## 3. Parse Once, Extract Everything

**Branch:** `mono_1-option2`
**Files changed:** 8 (+543 lines)

### Approach

Add a `parseAll(Path, Set<String>)` method to `JavaFileParser` that parses the file **once** and extracts all data from the single `CompilationUnit`: constants, parameter usages, FQN, and microservice info. Results are returned in a new `JavaFileParseResult` composite record:

```java
public record JavaFileParseResult(
    List<Constant> constants,
    List<ParameterUsage> parameterUsages,
    String fqn,
    MicroServiceInfo microServiceInfo
) {}
```

The scanner's Java file loop is simplified to a single call:

```java
// One parse, all data extracted
JavaFileParseResult parseResult = javaParser.parseAll(javaFile, parameterNames);

constants.addAll(parseResult.constants());
parameterUsages.addAll(parseResult.parameterUsages());
if (parseResult.fqn() != null) { javaFileFqns.put(...); }
if (parseResult.microServiceInfo().isMicroService()) { microServiceInfos.put(...); }
```

### What Changes

- **`JavaFileParser`**: Add `parseAll()` method with private helper methods (`extractConstants()`, `extractParameterUsages()`, `extractFqnFromCu()`) that operate on a shared `CompilationUnit`. Existing public methods (`parseConstants()`, `parseParameterUsages()`, `extractFqn()`) are preserved for backward compatibility.
- **`JavaFileParseResult`**: New composite record
- **`ProjectScanner`**: Java file loop rewritten to call `parseAll()` instead of three separate methods

### Why Choose This

- **Faster on large projects** — each file is parsed once instead of four times
- **Cleaner scanner code** — the loop body is shorter and more cohesive
- **Sets the pattern** — future extractors (e.g., dependency detection, import analysis) plug into `parseAll()` without adding another re-parse
- **No breaking changes** — existing individual methods are still available for callers outside the scanner (e.g., CLI, tests)

### Tradeoff

- **Larger diff** — the visitor logic is refactored into private helper methods, which means more lines changed even though the behavior is identical
- **More review surface** — the refactored `extractConstants()` and `extractParameterUsages()` private methods must produce exactly the same results as the original public methods. The existing tests validate this, but it requires careful review.
- **`parseConstantUsages()`** is not yet included in `parseAll()` because it requires a second pass over the files (it needs the full constant list from all files first). This could be addressed in a future iteration.

---

## 4. Side-by-Side Comparison

| Aspect | Option 1 (Third Parse Pass) | Option 2 (Parse Once) |
|---|---|---|
| **Branch** | `mono_1-option1` | `mono_1-option2` |
| **Files changed** | 7 | 8 |
| **Lines added** | +368 | +543 |
| **Parses per Java file** | 4 (was 3) | 1 (was 3) |
| **Existing methods touched** | None | `parseConstants` and `parseParameterUsages` logic extracted to private helpers |
| **New types introduced** | None | `JavaFileParseResult` record |
| **Risk** | Low — additive only | Medium — refactors existing logic into helpers |
| **Scan speed on Flink** | ~33% slower than option 2 | Fastest possible (single parse) |
| **Future extensibility** | Each new extractor adds another re-parse | New extractors plug into `parseAll()` |

---

## 5. File Inventory

### Files identical in both options

| File | Status |
|---|---|
| `core/model/MicroServiceInfo.java` | New |
| `core/parser/MicroServiceDetector.java` | New |
| `core/test/parser/MicroServiceDetectorTest.java` | New |
| `backend/entity/FileNode.java` | Modified (+2 fields) |
| `backend/service/GraphPopulatorService.java` | Modified (+Step 9) |

### Files that differ between options

| File | Option 1 | Option 2 |
|---|---|---|
| `core/parser/JavaFileParser.java` | +15 lines (new method) | +175 lines (parseAll + helpers) |
| `core/parser/JavaFileParseResult.java` | Does not exist | New record |
| `core/scanner/ProjectScanner.java` | +8 lines (new call + map) | +15 lines (rewritten loop) |
