# Accessing Neo4j from Java

This tutorial explains how our Spring Boot backend queries the Neo4j graph database
using **Spring Data Neo4j's `Neo4jClient`**. All examples are drawn from
`CodeTransformationService.java`, which queries the project graph to find constants,
parameters, and source files for the AST transformation pipeline.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Neo4jClient Overview](#neo4jclient-overview)
3. [The Query Pipeline (Step by Step)](#the-query-pipeline-step-by-step)
4. [Deep Dive: findConstantFiles()](#deep-dive-findconstantfiles)
5. [Other Queries in CodeTransformationService](#other-queries-in-codetransformationservice)
   - [findConfigurationCandidates()](#findconfigurationcandidates)
   - [findParameterCandidates()](#findparametercandidates)
   - [findProjectJavaFiles()](#findprojectjavafiles)
6. [Java-side Post-processing Patterns](#java-side-post-processing-patterns)
7. [Key Takeaways](#key-takeaways)

---

## Prerequisites

- **Spring Data Neo4j** on the classpath (pulled in via `spring-boot-starter-data-neo4j`)
- A running Neo4j instance (our `docker-compose.yml` provides one)
- The graph has already been populated by the project scanner, which creates
  `Project`, `File`, `Constant`, and `Parameter` nodes connected by
  `CONTAINS`, `DEFINED_IN`, and `USED_IN` relationships

### Graph Model Quick Reference

```
(:Project {rootPath})
    -[:CONTAINS]-> (:File {path, fileName})

(:Constant {name, type, value, className, lineNumber})
    -[:DEFINED_IN]-> (:File)

(:Parameter {name, value})
    -[:DEFINED_IN]-> (:File)           // where the parameter is declared
    -[:USED_IN {className, lineNumber}]-> (:File)   // where it is referenced
```

---

## Neo4jClient Overview

Spring Data Neo4j offers two main APIs for queries:

| API | Use Case |
|-----|----------|
| `Neo4jRepository<T, ID>` | CRUD operations on `@Node`-annotated entities |
| `Neo4jClient` | Free-form Cypher queries with manual result mapping |

Our service uses **`Neo4jClient`** because our queries are read-only projections that
join multiple node types. We don't need full entity management -- we just need to
extract specific fields and map them into lightweight Java records.

`Neo4jClient` is injected via constructor injection:

```java
@Service
public class CodeTransformationService {

    private final Neo4jClient neo4jClient;

    public CodeTransformationService(Neo4jClient neo4jClient) {
        this.neo4jClient = neo4jClient;
    }
}
```

---

## The Query Pipeline (Step by Step)

Every Neo4j query in our codebase follows the same five-step pipeline:

```
neo4jClient.query(cypherString)     // 1. Provide the Cypher query
    .bind(value).to("param")        // 2. Bind Java variables to Cypher $parameters
    .fetchAs(TargetType.class)      // 3. Declare the Java type for each result row
    .mappedBy((typeSystem, record)   // 4. Map each Neo4j Record to a Java object
        -> new TargetType(...))
    .all()                           // 5. Execute and collect all rows
```

| Step | Method | What It Does |
|------|--------|-------------|
| 1 | `.query(cypher)` | Accepts a Cypher string. We use Java text blocks (`"""..."""`) for readability. |
| 2 | `.bind(val).to("name")` | Binds a Java value to a `$name` parameter in the Cypher query. This is **parameterized** -- never use string concatenation for query values. |
| 3 | `.fetchAs(Class)` | Tells the client what Java type each row will be mapped into. Can be a record, a class, or even `String.class` for single-column results. |
| 4 | `.mappedBy(BiFunction)` | A lambda that receives `(TypeSystem, Record)` and returns an instance of the target type. You pull fields from the `Record` using `record.get("alias")`. |
| 5 | `.all()` | Executes the query and returns a `Collection<T>`. (Use `.one()` for single-row results, `.first()` for optional single-row.) |

After `.all()`, we typically chain `.stream().toList()` to convert from the Spring
`Collection` to an immutable `List`.

---

## Deep Dive: findConstantFiles()

This method answers the question: *"For a given constant, which files is it defined in?"*
It returns a `Map<String, List<String>>` where each key is a constant name and the value
is the list of file names containing its definition.

### The Complete Method

```java
private Map<String, List<String>> findConstantFiles(String projectPath) {
    record ConstantFile(String constantName, String fileName) {}               // A
    List<ConstantFile> rows = neo4jClient.query("""                            // B
        MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)
              <-[:DEFINED_IN]-(c:Constant)
        RETURN c.name AS constantName, f.fileName AS fileName
        ORDER BY c.name
        """)
        .bind(projectPath).to("path")                                         // C
        .fetchAs(ConstantFile.class)                                           // D
        .mappedBy((typeSystem, record) -> new ConstantFile(                    // E
            record.get("constantName").asString(),
            record.get("fileName").asString()
        ))
        .all()                                                                 // F
        .stream()
        .toList();

    return rows.stream().collect(Collectors.groupingBy(                        // G
        ConstantFile::constantName,
        Collectors.mapping(ConstantFile::fileName, Collectors.toList())
    ));
}
```

### Line-by-Line Explanation

#### A -- Local Record Declaration

```java
record ConstantFile(String constantName, String fileName) {}
```

We declare a **local record** inside the method body. This is a Java 16+ feature that
gives us a lightweight, immutable data carrier with automatic `equals()`, `hashCode()`,
and accessor methods. Because `ConstantFile` is only needed inside this method, defining
it locally keeps the class's namespace clean. It has exactly two fields matching the two
columns we `RETURN` from Cypher.

#### B -- Cypher Query (Text Block)

```java
neo4jClient.query("""
    MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)
          <-[:DEFINED_IN]-(c:Constant)
    RETURN c.name AS constantName, f.fileName AS fileName
    ORDER BY c.name
    """)
```

The Cypher query traverses the graph in three hops:

1. **`(p:Project {rootPath: $path})`** -- Anchor on the `Project` node whose
   `rootPath` matches the bound parameter. This scopes the query to a single scanned
   project.
2. **`-[:CONTAINS]->(f:File)`** -- Follow the `CONTAINS` relationship to reach the
   project's `File` nodes.
3. **`<-[:DEFINED_IN]-(c:Constant)`** -- From each file, follow the *incoming*
   `DEFINED_IN` relationship to find `Constant` nodes defined in that file. The arrow
   direction `<-` means the relationship points *from* the Constant *to* the File.

The `RETURN` clause projects two values:
- `c.name AS constantName` -- the constant's identifier (e.g., `DATABASE_HOST`)
- `f.fileName AS fileName` -- the file's short name (e.g., `AppConfig.java`)

`ORDER BY c.name` sorts the results alphabetically by constant name, which keeps the
output deterministic and easy to read.

> **Note:** We use `f.fileName` (short name) here rather than `f.path` (absolute path)
> because this query is intended for display/reporting. Other queries in the service use
> `f.path` when the result feeds into file I/O operations.

#### C -- Parameter Binding

```java
.bind(projectPath).to("path")
```

Binds the Java `String projectPath` to the Cypher parameter `$path`. This is
**parameterized** -- the Neo4j driver sends the value separately from the query text,
which prevents Cypher injection and allows the database to cache the query plan.

#### D -- Target Type Declaration

```java
.fetchAs(ConstantFile.class)
```

Tells the Neo4j client that each result row will be mapped into a `ConstantFile` instance.
This is only a type hint for the mapping step; it doesn't perform any automatic mapping.

#### E -- Row Mapping

```java
.mappedBy((typeSystem, record) -> new ConstantFile(
    record.get("constantName").asString(),
    record.get("fileName").asString()
))
```

The `mappedBy` lambda is called once for each row in the result set. It receives:

- `typeSystem` -- Neo4j's type system (rarely needed; useful for handling complex types
  like `Point` or `Duration`)
- `record` -- a `Record` object representing one result row

We extract values using `record.get("alias")`, where the alias matches the `AS` name in
the `RETURN` clause. The `.asString()` call converts the Neo4j `Value` to a Java `String`.

Common conversion methods on `Value`:

| Method | Java Type |
|--------|-----------|
| `.asString()` | `String` |
| `.asString(defaultValue)` | `String` (with fallback if `NULL`) |
| `.asInt()` | `int` |
| `.asLong()` | `long` |
| `.asBoolean()` | `boolean` |
| `.asList(Value::asString)` | `List<String>` |

#### F -- Execute and Collect

```java
.all()
.stream()
.toList();
```

- `.all()` sends the query to Neo4j and returns a `Collection<ConstantFile>`
- `.stream().toList()` converts to an immutable `List<ConstantFile>`

At this point, `rows` contains one entry per (constant, file) pair. If `DATABASE_HOST`
is defined in both `AppConfig.java` and `LegacyConfig.java`, there will be two rows.

#### G -- Java-side Grouping

```java
return rows.stream().collect(Collectors.groupingBy(
    ConstantFile::constantName,
    Collectors.mapping(ConstantFile::fileName, Collectors.toList())
));
```

This is where we transform the flat list into a grouped `Map`. The `Collectors.groupingBy`
collector partitions the stream by constant name, and the downstream
`Collectors.mapping` extracts just the file name from each entry.

**Example input (flat rows):**

| constantName | fileName |
|---|---|
| `DATABASE_HOST` | `AppConfig.java` |
| `DATABASE_HOST` | `LegacyConfig.java` |
| `SERVER_PORT`   | `AppConfig.java` |

**Example output (grouped map):**

```json
{
  "DATABASE_HOST": ["AppConfig.java", "LegacyConfig.java"],
  "SERVER_PORT":   ["AppConfig.java"]
}
```

> **Why group in Java instead of Cypher?** Neo4j's `COLLECT()` aggregation function
> could produce the same grouping, but doing it in Java gives us typed records with
> individual field access rather than a list-of-maps. It also keeps the Cypher query
> simpler and easier to test in the Neo4j Browser.

---

## Other Queries in CodeTransformationService

The remaining queries follow the same pipeline pattern. Here we highlight what is
**different** about each one.

### findConfigurationCandidates()

**Purpose:** Find constants that look like configuration values (hostnames, ports,
passwords, etc.) along with their type, value, and definition location.

**Cypher:**
```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE (c.type IN ['String', 'java.lang.String', 'int', 'long', ...]
       OR c.isEnum = true)
  AND c.name =~ '(?i).*(HOST|PORT|URL|URI|PATH|KEY|SECRET|PASSWORD|...).*'
RETURN c.name AS constantName,
       c.type AS constantType,
       c.value AS constantValue,
       c.className AS className,
       c.lineNumber AS lineNumber,
       f.path AS filePath
ORDER BY f.path, c.lineNumber
```

**Key differences from `findConstantFiles()`:**

1. **WHERE clause with filtering** -- This query doesn't return *all* constants. It
   filters by type (only primitive and string types, plus enums) and by name pattern
   (a regex matching configuration-related keywords like `HOST`, `PORT`, `URL`, etc.).
   The `=~` operator is Neo4j's regex match.

2. **More RETURN columns** -- Returns six fields instead of two, including `constantType`,
   `constantValue`, `className`, and `lineNumber`. These are needed to build a
   `ConstantTarget` that the AST transformer uses to locate and replace the constant.

3. **Uses `f.path`** (absolute path) instead of `f.fileName` because this path is used
   for file I/O.

4. **Maps to a class-level record** (`ConstantWithFile`) rather than a local record,
   because the record includes a `toTarget()` conversion method used elsewhere in the
   class.

5. **Default value handling** -- `record.get("constantValue").asString("")` passes an
   empty string as a default, so `null` values in Neo4j become `""` in Java rather than
   throwing an exception.

### findParameterCandidates()

**Purpose:** Find parameter usages (e.g., `getProperty("db.host")`) and the files where
those usages occur.

**Cypher:**
```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(param:Parameter)
      -[usage:USED_IN]->(usageFile:File)
RETURN param.name AS paramName,
       param.value AS paramValue,
       usage.className AS className,
       usage.lineNumber AS lineNumber,
       usageFile.path AS filePath
ORDER BY usageFile.path, usage.lineNumber
```

**Key differences:**

1. **Relationship variable** -- `[usage:USED_IN]` binds the relationship itself to a
   variable named `usage`. This lets us read *properties on the relationship*
   (`usage.className`, `usage.lineNumber`) rather than on a node. Relationship properties
   are useful when the same data (like line number) varies per connection rather than being
   inherent to either endpoint.

2. **Two File nodes in the pattern** -- The `MATCH` traverses from `Parameter` back to its
   definition file (`f`), then forward through `USED_IN` to a *different* file
   (`usageFile`). The `RETURN` uses `usageFile.path` because we care about where the
   parameter is *used*, not where it is *defined*.

3. **Node type** -- Matches `Parameter` nodes instead of `Constant` nodes.

### findProjectJavaFiles()

**Purpose:** Get all Java source file paths in a project.

**Cypher:**
```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)
WHERE f.path ENDS WITH '.java'
RETURN f.path AS filePath
```

**Key differences:**

1. **Single-column result** -- Only returns one value (`filePath`), so we use
   `.fetchAs(String.class)` directly instead of a record type. This is the simplest
   form of the query pipeline.

2. **`ENDS WITH` filter** -- Instead of pattern-matching node labels or properties with
   regex, this uses Cypher's `ENDS WITH` string predicate to filter for `.java` files.

3. **No relationship to Constant or Parameter** -- This is a pure file-listing query.
   It starts at the Project, follows `CONTAINS`, and stops at File nodes.

---

## Java-side Post-processing Patterns

After executing a query, the service often transforms the flat result list in Java.
Here are the patterns used:

### Deduplication via `Collectors.toMap` with Merge Function

```java
List<ConstantTarget> constantTargets = constantCandidates.stream()
    .map(ConstantWithFile::toTarget)
    .collect(Collectors.toMap(
        ConstantTarget::constantName,   // key: constant name
        t -> t,                         // value: the target itself
        (a, b) -> a                     // merge: keep the first if duplicates
    ))
    .values().stream().toList();
```

This deduplicates by constant name. If `DATABASE_HOST` appears in two files, only the
first one is kept. The third argument `(a, b) -> a` is the merge function that resolves
collisions.

### Grouping via `Collectors.groupingBy`

```java
rows.stream().collect(Collectors.groupingBy(
    ConstantFile::constantName,
    Collectors.mapping(ConstantFile::fileName, Collectors.toList())
));
```

Groups a flat list into a `Map<K, List<V>>`. The downstream `Collectors.mapping`
transforms each element before collecting, extracting just the file name from the full
record.

### Building a Multi-map with `computeIfAbsent`

```java
for (String javaFile : javaFiles) {
    targetsByFile.computeIfAbsent(Paths.get(javaFile), k -> new ArrayList<>())
        .addAll(constantTargets);
}
```

Builds a `Map<Path, List<ConstantTarget>>` imperatively. `computeIfAbsent` creates a
new `ArrayList` only if the key doesn't exist yet, then returns the list so we can
immediately add to it. This is the standard Java idiom for multi-maps.

---

## Key Takeaways

1. **Always use parameterized queries** (`.bind().to()`) -- never concatenate user input
   into Cypher strings.

2. **Use local records for simple projections** -- if the mapping type is only needed
   inside one method, declare it locally to keep the class clean.

3. **Use class-level records when behavior is needed** -- if the record has methods like
   `toTarget()`, declare it at class level so other methods can reference the type.

4. **Match the `RETURN` aliases to `record.get()` keys** -- these must be identical
   strings, and typos will cause runtime errors rather than compile-time errors.

5. **Choose `f.path` vs `f.fileName`** based on intent -- use `path` for file I/O, use
   `fileName` for display.

6. **Relationship properties** (`[r:REL_TYPE]` then `r.prop`) are the right tool when
   metadata varies per connection rather than per node.

7. **Keep Cypher simple; post-process in Java** -- it's easier to test, debug, and
   refactor Java stream operations than complex Cypher aggregations.
