# JavaParser Tutorial

JavaParser is a powerful open-source library for parsing, analyzing, and transforming Java source code. It builds an Abstract Syntax Tree (AST) that you can traverse, query, and modify programmatically.

**Repository:** https://github.com/javaparser/javaparser

## Table of Contents

1. [Getting Started](#getting-started)
2. [Core Concepts](#core-concepts)
3. [Parsing Java Code](#parsing-java-code)
4. [Navigating the AST](#navigating-the-ast)
5. [Using Visitors](#using-visitors)
6. [Common Use Cases](#common-use-cases)
7. [Modifying Code](#modifying-code)
8. [Symbol Resolution](#symbol-resolution)
9. [Best Practices](#best-practices)

---

## Getting Started

### Maven Dependency

```xml
<dependency>
    <groupId>com.github.javaparser</groupId>
    <artifactId>javaparser-core</artifactId>
    <version>3.27.1</version>
</dependency>

<!-- Optional: For symbol resolution (type inference, method resolution) -->
<dependency>
    <groupId>com.github.javaparser</groupId>
    <artifactId>javaparser-symbol-solver-core</artifactId>
    <version>3.27.1</version>
</dependency>
```

### Gradle Dependency

```groovy
implementation 'com.github.javaparser:javaparser-core:3.27.1'
implementation 'com.github.javaparser:javaparser-symbol-solver-core:3.27.1'
```

---

## Core Concepts

### Abstract Syntax Tree (AST)

JavaParser converts Java source code into a tree structure where each node represents a syntactic element:

```
CompilationUnit (root)
├── PackageDeclaration
├── ImportDeclaration(s)
└── TypeDeclaration(s)
    └── ClassOrInterfaceDeclaration
        ├── FieldDeclaration(s)
        ├── ConstructorDeclaration(s)
        └── MethodDeclaration(s)
            └── BlockStmt (method body)
                └── Statement(s)
                    └── Expression(s)
```

### Key Node Types

| Node Type | Description |
|-----------|-------------|
| `CompilationUnit` | Root node representing a Java file |
| `ClassOrInterfaceDeclaration` | A class or interface definition |
| `MethodDeclaration` | A method definition |
| `FieldDeclaration` | A field/variable declaration |
| `VariableDeclarator` | Individual variable within a declaration |
| `MethodCallExpr` | A method invocation |
| `AnnotationExpr` | An annotation (`@Override`, `@Value`, etc.) |

---

## Parsing Java Code

### Basic Parsing

```java
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;

import java.nio.file.Path;

public class BasicParsing {

    public static void main(String[] args) {
        JavaParser parser = new JavaParser();

        // Parse from a file
        ParseResult<CompilationUnit> result = parser.parse(Path.of("MyClass.java"));

        if (result.isSuccessful() && result.getResult().isPresent()) {
            CompilationUnit cu = result.getResult().get();
            System.out.println("Parsed successfully!");
        } else {
            result.getProblems().forEach(problem ->
                System.err.println("Problem: " + problem.getMessage()));
        }
    }
}
```

### Parsing from a String

```java
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;

String code = """
    public class Hello {
        public static void main(String[] args) {
            System.out.println("Hello, World!");
        }
    }
    """;

CompilationUnit cu = StaticJavaParser.parse(code);
```

### Parsing Code Fragments

```java
import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.stmt.Statement;

// Parse a single expression
Expression expr = StaticJavaParser.parseExpression("x + y * 2");

// Parse a single statement
Statement stmt = StaticJavaParser.parseStatement("int x = 5;");
```

---

## Navigating the AST

### Direct Node Access

```java
CompilationUnit cu = StaticJavaParser.parse(code);

// Get package declaration
cu.getPackageDeclaration().ifPresent(pkg ->
    System.out.println("Package: " + pkg.getNameAsString()));

// Get all imports
cu.getImports().forEach(imp ->
    System.out.println("Import: " + imp.getNameAsString()));

// Get all classes
cu.findAll(ClassOrInterfaceDeclaration.class).forEach(cls ->
    System.out.println("Class: " + cls.getNameAsString()));
```

### Using findAll()

The `findAll()` method searches the entire subtree for nodes of a specific type:

```java
// Find all method declarations
List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);

// Find all string literals
List<StringLiteralExpr> strings = cu.findAll(StringLiteralExpr.class);

// Find all method calls
List<MethodCallExpr> calls = cu.findAll(MethodCallExpr.class);

// Find with a filter
List<MethodDeclaration> publicMethods = cu.findAll(
    MethodDeclaration.class,
    method -> method.isPublic()
);
```

### Navigating Parent/Child Relationships

```java
// Get parent node
methodDecl.getParentNode().ifPresent(parent -> {
    if (parent instanceof ClassOrInterfaceDeclaration cls) {
        System.out.println("Method belongs to: " + cls.getNameAsString());
    }
});

// Get all child nodes
methodDecl.getChildNodes().forEach(child ->
    System.out.println("Child: " + child.getClass().getSimpleName()));

// Find first ancestor of a type
methodCall.findAncestor(MethodDeclaration.class).ifPresent(method ->
    System.out.println("Call is inside method: " + method.getNameAsString()));
```

### Getting Source Position

```java
MethodDeclaration method = ...;

method.getBegin().ifPresent(pos ->
    System.out.println("Starts at line " + pos.line + ", column " + pos.column));

method.getEnd().ifPresent(pos ->
    System.out.println("Ends at line " + pos.line + ", column " + pos.column));

method.getRange().ifPresent(range ->
    System.out.println("Lines " + range.begin.line + " to " + range.end.line));
```

---

## Using Visitors

Visitors provide a structured way to traverse the AST. JavaParser offers two visitor types:

### VoidVisitorAdapter

Use when you don't need to return values:

```java
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

public class MethodPrinter extends VoidVisitorAdapter<Void> {

    @Override
    public void visit(MethodDeclaration method, Void arg) {
        System.out.println("Found method: " + method.getNameAsString());
        System.out.println("  Return type: " + method.getTypeAsString());
        System.out.println("  Parameters: " + method.getParameters().size());

        // Important: call super to continue visiting child nodes
        super.visit(method, arg);
    }
}

// Usage
cu.accept(new MethodPrinter(), null);
```

### GenericVisitorAdapter

Use when you need to return and accumulate values:

```java
import com.github.javaparser.ast.visitor.GenericVisitorAdapter;

public class MethodCounter extends GenericVisitorAdapter<Integer, Void> {

    @Override
    public Integer visit(CompilationUnit cu, Void arg) {
        int count = 0;
        for (var type : cu.getTypes()) {
            Integer result = type.accept(this, arg);
            if (result != null) count += result;
        }
        return count;
    }

    @Override
    public Integer visit(MethodDeclaration method, Void arg) {
        return 1;
    }
}

// Usage
Integer methodCount = cu.accept(new MethodCounter(), null);
```

### Visitor with Context

Pass context data through the visitor:

```java
public class ConstantCollector extends VoidVisitorAdapter<List<String>> {

    @Override
    public void visit(FieldDeclaration field, List<String> collector) {
        boolean isStatic = field.isStatic();
        boolean isFinal = field.isFinal();

        if (isStatic && isFinal) {
            field.getVariables().forEach(var ->
                collector.add(var.getNameAsString()));
        }

        super.visit(field, collector);
    }
}

// Usage
List<String> constants = new ArrayList<>();
cu.accept(new ConstantCollector(), constants);
System.out.println("Constants: " + constants);
```

### Nested Class Tracking

When dealing with nested classes, track the current class context:

```java
public class ClassAwareVisitor extends VoidVisitorAdapter<Void> {
    private String currentClass = "";

    @Override
    public void visit(ClassOrInterfaceDeclaration cls, Void arg) {
        String previousClass = currentClass;
        currentClass = cls.getNameAsString();

        System.out.println("Entering class: " + currentClass);
        super.visit(cls, arg);  // Visit members

        currentClass = previousClass;  // Restore for nested classes
    }

    @Override
    public void visit(MethodDeclaration method, Void arg) {
        System.out.println("  " + currentClass + "." + method.getNameAsString());
        super.visit(method, arg);
    }
}
```

---

## Common Use Cases

### Finding Static Final Fields (Constants)

```java
public List<Constant> findConstants(CompilationUnit cu) {
    List<Constant> constants = new ArrayList<>();

    cu.accept(new VoidVisitorAdapter<Void>() {
        private String currentClass = "";

        @Override
        public void visit(ClassOrInterfaceDeclaration cls, Void arg) {
            String prev = currentClass;
            currentClass = cls.getNameAsString();
            super.visit(cls, arg);
            currentClass = prev;
        }

        @Override
        public void visit(FieldDeclaration field, Void arg) {
            // Check modifiers
            boolean isStatic = field.getModifiers().stream()
                .anyMatch(m -> m.getKeyword() == Modifier.Keyword.STATIC);
            boolean isFinal = field.getModifiers().stream()
                .anyMatch(m -> m.getKeyword() == Modifier.Keyword.FINAL);

            if (isStatic && isFinal) {
                for (VariableDeclarator var : field.getVariables()) {
                    String name = var.getNameAsString();
                    String type = var.getTypeAsString();
                    String value = var.getInitializer()
                        .map(Object::toString)
                        .orElse("");
                    int line = field.getBegin()
                        .map(pos -> pos.line)
                        .orElse(0);

                    constants.add(new Constant(name, type, value, currentClass, line));
                }
            }
            super.visit(field, arg);
        }
    }, null);

    return constants;
}
```

### Finding Method Calls

```java
public List<MethodCallInfo> findMethodCalls(CompilationUnit cu, Set<String> targetMethods) {
    List<MethodCallInfo> calls = new ArrayList<>();

    cu.accept(new VoidVisitorAdapter<Void>() {
        @Override
        public void visit(MethodCallExpr call, Void arg) {
            String methodName = call.getNameAsString();

            if (targetMethods.contains(methodName)) {
                int line = call.getBegin().map(p -> p.line).orElse(0);
                String scope = call.getScope()
                    .map(Object::toString)
                    .orElse("");

                calls.add(new MethodCallInfo(methodName, scope, line));
            }

            super.visit(call, arg);
        }
    }, null);

    return calls;
}
```

### Finding Annotations

```java
public List<AnnotationInfo> findAnnotations(CompilationUnit cu, String annotationName) {
    List<AnnotationInfo> annotations = new ArrayList<>();

    // On classes
    cu.findAll(ClassOrInterfaceDeclaration.class).forEach(cls -> {
        cls.getAnnotations().stream()
            .filter(a -> a.getNameAsString().equals(annotationName))
            .forEach(a -> annotations.add(new AnnotationInfo(
                "class", cls.getNameAsString(), a.toString())));
    });

    // On methods
    cu.findAll(MethodDeclaration.class).forEach(method -> {
        method.getAnnotations().stream()
            .filter(a -> a.getNameAsString().equals(annotationName))
            .forEach(a -> annotations.add(new AnnotationInfo(
                "method", method.getNameAsString(), a.toString())));
    });

    // On fields
    cu.findAll(FieldDeclaration.class).forEach(field -> {
        field.getAnnotations().stream()
            .filter(a -> a.getNameAsString().equals(annotationName))
            .forEach(a -> {
                String fieldName = field.getVariables().get(0).getNameAsString();
                annotations.add(new AnnotationInfo("field", fieldName, a.toString()));
            });
    });

    return annotations;
}
```

### Extracting @Value Annotation Parameters

```java
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Pattern for @Value("${property.name}") or @Value("${property.name:default}")
private static final Pattern VALUE_PATTERN = Pattern.compile("\\$\\{([^:}]+)");

public List<String> findValueAnnotationProperties(CompilationUnit cu) {
    List<String> properties = new ArrayList<>();

    cu.findAll(AnnotationExpr.class).stream()
        .filter(a -> a.getNameAsString().equals("Value"))
        .forEach(annotation -> {
            Matcher matcher = VALUE_PATTERN.matcher(annotation.toString());
            while (matcher.find()) {
                properties.add(matcher.group(1));
            }
        });

    return properties;
}
```

### Analyzing Method Complexity

```java
public int countStatements(MethodDeclaration method) {
    return method.findAll(Statement.class).size();
}

public int countBranches(MethodDeclaration method) {
    int branches = 0;
    branches += method.findAll(IfStmt.class).size();
    branches += method.findAll(SwitchStmt.class).size();
    branches += method.findAll(ForStmt.class).size();
    branches += method.findAll(ForEachStmt.class).size();
    branches += method.findAll(WhileStmt.class).size();
    branches += method.findAll(DoStmt.class).size();
    branches += method.findAll(TryStmt.class).size();
    return branches;
}
```

---

## Modifying Code

### Adding Imports

```java
cu.addImport("java.util.List");
cu.addImport("java.util.ArrayList");

// Add static import
cu.addImport("org.junit.Assert.assertEquals", true, false);
```

### Adding a Method

```java
ClassOrInterfaceDeclaration cls = cu.getClassByName("MyClass").orElseThrow();

MethodDeclaration method = cls.addMethod("newMethod", Modifier.Keyword.PUBLIC);
method.setType("String");
method.addParameter("int", "id");
method.setBody(StaticJavaParser.parseBlock("""
    {
        return "ID: " + id;
    }
    """));
```

### Adding a Field

```java
ClassOrInterfaceDeclaration cls = cu.getClassByName("MyClass").orElseThrow();

FieldDeclaration field = cls.addField("String", "name", Modifier.Keyword.PRIVATE);

// Add with initializer
cls.addFieldWithInitializer(
    "int",
    "count",
    StaticJavaParser.parseExpression("0"),
    Modifier.Keyword.PRIVATE
);
```

### Adding Annotations

```java
MethodDeclaration method = ...;

// Simple annotation
method.addAnnotation("Override");

// Annotation with value
method.addAnnotation(StaticJavaParser.parseAnnotation("@Test(timeout = 1000)"));

// Single member annotation
method.addSingleMemberAnnotation("SuppressWarnings", "\"unchecked\"");
```

### Renaming

```java
// Rename a class
ClassOrInterfaceDeclaration cls = cu.getClassByName("OldName").orElseThrow();
cls.setName("NewName");

// Rename a method
MethodDeclaration method = cls.getMethodsByName("oldMethod").get(0);
method.setName("newMethod");

// Rename all references to a variable (simple approach)
cu.findAll(NameExpr.class).stream()
    .filter(n -> n.getNameAsString().equals("oldVar"))
    .forEach(n -> n.setName("newVar"));
```

### Removing Nodes

```java
// Remove a method
MethodDeclaration method = cls.getMethodsByName("deprecated").get(0);
method.remove();

// Remove all private fields
cls.getFields().stream()
    .filter(FieldDeclaration::isPrivate)
    .forEach(Node::remove);

// Remove specific annotation
method.getAnnotations().removeIf(a -> a.getNameAsString().equals("Deprecated"));
```

### Outputting Modified Code

```java
// Get the modified source code as a string
String modifiedCode = cu.toString();

// Write to file
Files.writeString(Path.of("Modified.java"), cu.toString());

// Pretty print with custom configuration
PrettyPrinterConfiguration config = new PrettyPrinterConfiguration();
config.setIndentSize(4);
config.setEndOfLineCharacter("\n");

PrettyPrinter printer = new PrettyPrinter(config);
String formatted = printer.print(cu);
```

---

## Symbol Resolution

Symbol resolution allows you to resolve types, find method declarations, and understand the full context of your code.

### Setup

```java
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

// Configure type solvers
CombinedTypeSolver typeSolver = new CombinedTypeSolver();
typeSolver.add(new ReflectionTypeSolver());  // JDK classes
typeSolver.add(new JavaParserTypeSolver(Path.of("src/main/java")));  // Your source

// Create symbol solver
JavaSymbolSolver symbolSolver = new JavaSymbolSolver(typeSolver);

// Configure parser to use symbol solver
ParserConfiguration config = new ParserConfiguration();
config.setSymbolResolver(symbolSolver);

JavaParser parser = new JavaParser(config);
```

### Resolving Types

```java
MethodCallExpr call = ...;

// Resolve the method being called
try {
    ResolvedMethodDeclaration resolved = call.resolve();
    System.out.println("Calls: " + resolved.getQualifiedSignature());
    System.out.println("Declared in: " + resolved.declaringType().getQualifiedName());
} catch (UnsolvedSymbolException e) {
    System.err.println("Could not resolve: " + call);
}
```

### Resolving Variable Types

```java
NameExpr nameExpr = ...;

try {
    ResolvedType type = nameExpr.calculateResolvedType();
    System.out.println("Type: " + type.describe());
} catch (UnsolvedSymbolException e) {
    System.err.println("Could not resolve type");
}
```

---

## Best Practices

### 1. Always Check Parse Results

```java
ParseResult<CompilationUnit> result = parser.parse(path);

if (!result.isSuccessful()) {
    result.getProblems().forEach(p ->
        logger.warn("Parse problem: {}", p.getMessage()));
    return;
}

CompilationUnit cu = result.getResult().orElseThrow();
```

### 2. Use Optional Properly

```java
// Good: Handle optionals explicitly
method.getBegin()
    .map(pos -> pos.line)
    .orElse(0);

// Good: Use ifPresent for side effects
cu.getPackageDeclaration().ifPresent(pkg ->
    System.out.println(pkg.getNameAsString()));
```

### 3. Call super in Visitors

```java
@Override
public void visit(MethodDeclaration method, Void arg) {
    // Your logic here

    // Important! Continue visiting child nodes
    super.visit(method, arg);
}
```

### 4. Track Context in Nested Structures

```java
private String currentClass = "";

@Override
public void visit(ClassOrInterfaceDeclaration cls, Void arg) {
    String previous = currentClass;
    currentClass = cls.getNameAsString();
    super.visit(cls, arg);
    currentClass = previous;  // Restore for sibling classes
}
```

### 5. Handle Exceptions Gracefully

```java
try {
    ParseResult<CompilationUnit> result = parser.parse(filePath);
    // Process result
} catch (IOException e) {
    logger.error("Failed to read file: {}", filePath, e);
} catch (Exception e) {
    logger.error("Unexpected error parsing: {}", filePath, e);
}
```

### 6. Use findAll() for Simple Queries

```java
// Instead of writing a visitor for simple cases:
List<MethodDeclaration> publicMethods = cu.findAll(
    MethodDeclaration.class,
    m -> m.isPublic() && !m.isStatic()
);
```

### 7. Prefer Specific Node Types

```java
// More specific is better
cu.findAll(MethodCallExpr.class)  // Good

// Rather than filtering generic nodes
cu.findAll(Expression.class)
    .stream()
    .filter(e -> e instanceof MethodCallExpr)  // Less efficient
```

---

## Additional Resources

- **Official Documentation:** https://javaparser.org/
- **GitHub Repository:** https://github.com/javaparser/javaparser
- **JavaDoc:** https://www.javadoc.io/doc/com.github.javaparser/javaparser-core
- **Example Projects:** https://github.com/javaparser/javaparser/tree/master/javaparser-core-testing

---

## Quick Reference

| Task | Method |
|------|--------|
| Parse file | `parser.parse(Path.of("File.java"))` |
| Parse string | `StaticJavaParser.parse(code)` |
| Find all of type | `cu.findAll(MethodDeclaration.class)` |
| Find with filter | `cu.findAll(Class.class, predicate)` |
| Get line number | `node.getBegin().map(p -> p.line).orElse(0)` |
| Add import | `cu.addImport("java.util.List")` |
| Add method | `cls.addMethod("name", Modifier.Keyword.PUBLIC)` |
| Remove node | `node.remove()` |
| Output code | `cu.toString()` |
