# Constants Catalog Frontend - CSS & Styling Deep Dive

A detailed walkthrough of every CSS class and styling decision in the Constants Catalog frontend. This tutorial uses TailwindCSS utility classes mapped to a custom "Space Command" design system.

> **Note:** All component files use the `.tsx` extension (TypeScript + JSX). The CSS is applied entirely through Tailwind utility classes in `className` attributes, plus a small set of custom classes defined in `index.css`.

---

## Table of Contents

1. [Part 1: The Design System Foundation](#part-1-the-design-system-foundation)
   - [1.1 Tailwind Configuration (tailwind.config.js)](#11-tailwind-configuration)
   - [1.2 Global Stylesheet (index.css)](#12-global-stylesheet)
2. [Part 2: The Header (Header.tsx)](#part-2-the-header)
3. [Part 3: The Application Shell](#part-3-the-application-shell)
   - [3.1 Layout.tsx](#31-layout)
   - [3.2 Sidebar.tsx](#32-sidebar)
4. [Part 4: The Command Line Footer](#part-4-the-command-line-footer)
   - [4.1 CommandLine.tsx](#41-commandline)
   - [4.2 CommandLineResults.tsx](#42-commandlineresults)
5. [Part 5: Shared Data Components](#part-5-shared-data-components)
   - [5.1 ResultsTable.tsx](#51-resultstable)
6. [Part 6: Page Components](#part-6-page-components)
   - [6.1 Dashboard.tsx](#61-dashboard)
   - [6.2 ScanPage.tsx](#62-scanpage)
   - [6.3 QueryPage.tsx](#63-querypage)
   - [6.4 TransformPage.tsx](#64-transformpage)
7. [Part 7: Modal Components](#part-7-modal-components)
   - [7.1 FileViewerModal.tsx](#71-fileviewermodal)
   - [7.2 DiffViewer.tsx](#72-diffviewer)
8. [Appendix: Quick Reference Tables](#appendix-quick-reference-tables)

---

## Part 1: The Design System Foundation

Before examining any component, you must understand the two files that define every color, font, animation, and reusable class in the application.

### 1.1 Tailwind Configuration

**File:** `const-catalog-frontend/tailwind.config.js`

Tailwind generates utility classes from this configuration. Every custom class like `bg-space-darker` or `text-neon-cyan` originates here.

#### Content Scanning

```js
content: [
  "./index.html",
  "./src/**/*.{js,ts,jsx,tsx}",
],
```

Tailwind reads these files to determine which utility classes are actually used, then generates only those classes in the final CSS bundle. Unused classes are purged automatically in production builds. If you add a class in a `.tsx` file but it is not inside one of these glob patterns, Tailwind will never generate it.

#### Custom Color Palette

```js
colors: {
  space: {
    black:  '#0a0a0f',   // Deepest background, near-black with a blue tint
    darker: '#0d0d14',   // Panel backgrounds (header, sidebar, cards)
    dark:   '#12121a',   // Slightly lighter, used for secondary panels
    medium: '#1a1a24',   // Mid-tone, used for hover states and sub-panels
    light:  '#252530',   // Lightest dark shade, used for borders and dividers
  },
  neon: {
    cyan:   '#00ffff',   // Primary accent - headings, active states, links
    green:  '#00ff9f',   // Success states, positive indicators
    blue:   '#00aaff',   // Secondary accent
    purple: '#aa00ff',   // Tertiary accent
    pink:   '#ff00aa',   // Unused in current components (available for future use)
    orange: '#ff6600',   // Pending/warning states
    red:    '#ff3333',   // Error states, danger actions
  },
  terminal: {
    text:   '#e0e0e0',   // Primary readable text (light gray)
    dim:    '#888899',   // Secondary/muted text (medium gray with blue tint)
    bright: '#ffffff',   // Maximum emphasis text (pure white)
  }
}
```

**How these become Tailwind classes:**

Each nested key creates utility classes following the pattern `{property}-{group}-{shade}`:

| Config Key | Example Tailwind Classes |
|---|---|
| `space.black` | `bg-space-black`, `text-space-black`, `border-space-black` |
| `space.darker` | `bg-space-darker`, `text-space-darker`, `border-space-darker` |
| `neon.cyan` | `bg-neon-cyan`, `text-neon-cyan`, `border-neon-cyan` |
| `terminal.text` | `text-terminal-text`, `bg-terminal-text` |
| `terminal.dim` | `text-terminal-dim`, `placeholder-terminal-dim` |

**Opacity modifiers:** Tailwind allows any color to be used with an opacity suffix. For example:
- `border-neon-cyan/30` = `#00ffff` at 30% opacity (produces `rgba(0, 255, 255, 0.3)`)
- `bg-neon-red/10` = `#ff3333` at 10% opacity
- `bg-neon-cyan/20` = `#00ffff` at 20% opacity

The `/` opacity syntax is used extensively throughout the codebase to create subtle, translucent variations of the neon colors against the dark backgrounds.

#### Font Family

```js
fontFamily: {
  mono: ['JetBrains Mono', 'Fira Code', 'Monaco', 'Consolas', 'monospace'],
},
```

This overrides the default Tailwind `font-mono` stack. When any element uses `font-mono`, the browser will try each font in order, falling back through the chain. JetBrains Mono is loaded via Google Fonts in `index.html`:

```html
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
```

The `display=swap` parameter tells the browser to show text in a fallback font immediately, then swap to JetBrains Mono once it downloads. This avoids a flash of invisible text (FOIT).

#### Custom Box Shadows (Neon Glow Effects)

```js
boxShadow: {
  'neon-cyan':  '0 0 10px rgba(0, 255, 255, 0.3), 0 0 20px rgba(0, 255, 255, 0.2)',
  'neon-green': '0 0 10px rgba(0, 255, 159, 0.3), 0 0 20px rgba(0, 255, 159, 0.2)',
  'neon-blue':  '0 0 10px rgba(0, 170, 255, 0.3), 0 0 20px rgba(0, 170, 255, 0.2)',
},
```

These are multi-layered `box-shadow` values. Each uses `0 0` for X/Y offsets (centered glow, no directional shadow), with two blur layers of different sizes and opacities to create a "neon light" halo effect. Used as:
- `shadow-neon-cyan` - applied on hover for primary buttons
- `shadow-neon-green` - applied to the online status indicator

The `box-shadow` CSS property syntax is: `offset-x offset-y blur-radius color`. Using `0 0 10px` means no offset, 10px blur radius, creating an even glow around the element.

#### Custom Animations

```js
animation: {
  'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
  'glow':       'glow 2s ease-in-out infinite alternate',
  'slide-up':   'slide-up 0.2s ease-out forwards',
},
```

| Animation Class | Behavior |
|---|---|
| `animate-pulse-slow` | Reuses Tailwind's built-in `pulse` keyframes but slows the cycle to 3 seconds. Used on the "online" status dot for a gentle heartbeat. |
| `animate-glow` | Alternates box-shadow intensity over 2 seconds. The `alternate` direction means it grows then shrinks, creating a breathing neon effect. |
| `animate-slide-up` | One-shot animation (note `forwards` fill mode). Grows `maxHeight` from 0 to `50vh` and fades in opacity from 0 to 1 over 0.2 seconds. Used by `CommandLineResults` to slide into view. |

The `forwards` fill mode means the element retains the final keyframe state after the animation completes (i.e., it stays visible at `maxHeight: 50vh` rather than snapping back to 0).

#### Custom Keyframes

```js
keyframes: {
  glow: {
    '0%':   { boxShadow: '0 0 5px rgba(0, 255, 255, 0.2)' },
    '100%': { boxShadow: '0 0 20px rgba(0, 255, 255, 0.4), 0 0 30px rgba(0, 255, 255, 0.2)' },
  },
  'slide-up': {
    '0%':   { maxHeight: '0', opacity: '0' },
    '100%': { maxHeight: '50vh', opacity: '1' },
  },
}
```

`glow` goes from a subtle 5px shadow to a bright 20px+30px double shadow. Because the animation uses `alternate`, this plays forward then backward, creating a pulsing glow.

`slide-up` animates using `maxHeight` rather than `height` because `maxHeight` works with `auto`-height content. You cannot transition `height: auto` in CSS, but you can transition `maxHeight` from `0` to a large value.

---

### 1.2 Global Stylesheet

**File:** `const-catalog-frontend/src/index.css`

This file uses three layers:

```css
@tailwind base;       /* Tailwind's CSS reset (normalize) and base styles */
@tailwind components; /* Component classes generated from @apply in this file */
@tailwind utilities;  /* All utility classes (bg-*, text-*, flex, etc.) */
```

The `@apply` directive inside this file tells Tailwind to inline utility classes into custom CSS rules. This is the bridge between Tailwind's utility-first approach and traditional CSS class names.

#### Body Defaults

```css
body {
  @apply bg-space-black text-terminal-text font-mono;
  min-height: 100vh;
}
```

This sets the global defaults that every element inherits:

| Class / Property | CSS Generated | Purpose |
|---|---|---|
| `bg-space-black` | `background-color: #0a0a0f` | The deepest, near-black background |
| `text-terminal-text` | `color: #e0e0e0` | Light gray as the default text color |
| `font-mono` | `font-family: 'JetBrains Mono', ...` | Monospace font everywhere |
| `min-height: 100vh` | `min-height: 100vh` | Body always fills at least the full viewport height |

#### Scrollbar Styling

```css
::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}
::-webkit-scrollbar-track {
  @apply bg-space-darker;          /* #0d0d14 track background */
}
::-webkit-scrollbar-thumb {
  @apply bg-space-light rounded;   /* #252530 rounded thumb */
  border: 2px solid transparent;   /* Adds visual padding around the thumb */
}
::-webkit-scrollbar-thumb:hover {
  @apply bg-neon-cyan/30;          /* Cyan glow on hover */
}
```

These are WebKit-specific pseudo-elements (Chrome, Safari, Edge). Firefox uses a different system (`scrollbar-color`, `scrollbar-width`). The `border: 2px solid transparent` on the thumb creates visual space between the thumb and track edges, making the scrollbar appear thinner and more refined than its 8px width.

#### Neon Border Utility

```css
.neon-border {
  @apply border border-neon-cyan/30;
  box-shadow: inset 0 0 10px rgba(0, 255, 255, 0.1);
}
.neon-border:hover {
  @apply border-neon-cyan/50;
  box-shadow: inset 0 0 15px rgba(0, 255, 255, 0.15);
}
```

A reusable class for any element that should glow on its inner edge. The `inset` keyword on `box-shadow` places the glow inside the element rather than outside. On hover, both the border opacity and shadow intensity increase, creating a "coming alive" effect.

#### Text Selection

```css
::selection {
  @apply bg-neon-cyan/30 text-terminal-bright;
}
```

When users select text with their mouse, the highlight appears as a translucent cyan overlay with pure white text, maintaining the neon theme even during text selection.

#### Global Input Styling

```css
input, textarea {
  @apply bg-space-darker border border-space-light rounded px-3 py-2;
  @apply text-terminal-text placeholder-terminal-dim;
  @apply focus:outline-none focus:border-neon-cyan/50 focus:ring-1 focus:ring-neon-cyan/30;
}
```

This applies to *every* `<input>` and `<textarea>` in the application:

| Classes | CSS Effect |
|---|---|
| `bg-space-darker` | Dark background (#0d0d14) |
| `border border-space-light` | 1px solid #252530 border |
| `rounded` | `border-radius: 0.25rem` (4px) |
| `px-3 py-2` | Horizontal padding 0.75rem, vertical padding 0.5rem |
| `text-terminal-text` | Input text color #e0e0e0 |
| `placeholder-terminal-dim` | Placeholder text color #888899 |
| `focus:outline-none` | Removes the browser's default blue outline ring |
| `focus:border-neon-cyan/50` | On focus, border becomes cyan at 50% opacity |
| `focus:ring-1 focus:ring-neon-cyan/30` | On focus, a 1px box-shadow ring appears in cyan at 30% opacity |

The `focus:` prefix in Tailwind is a variant that only applies when the element has focus. This creates a two-layer focus indicator: the border color change plus a ring shadow, both in theme-consistent cyan.

#### Button Classes

```css
.btn {
  @apply px-4 py-2 rounded font-medium transition-all duration-200;
  @apply disabled:opacity-50 disabled:cursor-not-allowed;
}
```

Base button class shared by all button variants:

| Class | Effect |
|---|---|
| `px-4 py-2` | Padding: 1rem horizontal, 0.5rem vertical |
| `rounded` | 4px border radius |
| `font-medium` | `font-weight: 500` |
| `transition-all duration-200` | All CSS properties animate over 200ms on change |
| `disabled:opacity-50` | When `disabled` attribute is present, element becomes 50% transparent |
| `disabled:cursor-not-allowed` | Cursor shows the "not allowed" symbol when disabled |

```css
.btn-primary {
  @apply bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/50;
  @apply hover:bg-neon-cyan/30 hover:shadow-neon-cyan;
}
```

The primary action button. Background is cyan at 20% opacity (nearly transparent, just a tint), text is full cyan, and border is cyan at 50%. On hover, background increases to 30% and the neon-cyan box-shadow glow appears. Combined with `transition-all duration-200` from `.btn`, the glow fades in smoothly.

```css
.btn-secondary {
  @apply bg-space-light text-terminal-text border border-space-light;
  @apply hover:bg-space-medium hover:border-terminal-dim;
}
```

A neutral button. Background and border match (`space-light`), making the border invisible at rest. On hover, the background darkens and a visible border appears.

```css
.btn-danger {
  @apply bg-neon-red/20 text-neon-red border border-neon-red/50;
  @apply hover:bg-neon-red/30;
}
```

Same pattern as `.btn-primary` but in red. Note: no `hover:shadow-neon-red` is defined, so danger buttons don't glow on hover (a deliberate restraint).

#### Data Table Classes

```css
.data-table { @apply w-full text-sm; }
.data-table th {
  @apply bg-space-medium text-neon-cyan font-medium text-left px-3 py-2;
  @apply border-b border-neon-cyan/30;
}
.data-table td { @apply px-3 py-2 border-b border-space-light; }
.data-table tr:hover td { @apply bg-space-light/50; }
```

A reusable table style used by `ResultsTable.tsx`:
- Headers have a medium-dark background with cyan text and a cyan-tinted bottom border
- Cells have consistent padding and subtle bottom borders
- Row hover highlights cells with a semi-transparent version of `space-light`

#### Status Dot Indicators

```css
.status-dot { @apply w-2 h-2 rounded-full; }
.status-dot.online  { @apply bg-neon-green shadow-neon-green animate-pulse-slow; }
.status-dot.offline { @apply bg-neon-red; }
.status-dot.pending { @apply bg-neon-orange animate-pulse; }
```

Small 8px circles used in the Header to show connection status:
- **online**: Green with a green neon glow shadow, pulsing slowly (3-second cycle)
- **offline**: Static red, no animation (dead state)
- **pending**: Orange with the default Tailwind pulse (faster, 2-second cycle)

---

## Part 2: The Header

**File:** `const-catalog-frontend/src/components/Header.tsx`

The Header is the HUD-style top bar showing the application title and live system status. We examine it first because it introduces the core patterns reused everywhere else.

### The `<header>` Element

```tsx
<header className="bg-space-darker border-b border-neon-cyan/30 px-6 py-3">
```

| Class | CSS | Purpose |
|---|---|---|
| `bg-space-darker` | `background-color: #0d0d14` | Panel background, one shade lighter than the body's `space-black` |
| `border-b` | `border-bottom-width: 1px; border-style: solid` | Bottom border only |
| `border-neon-cyan/30` | `border-color: rgba(0, 255, 255, 0.3)` | A subtle cyan line separating the header from the content below |
| `px-6` | `padding-left: 1.5rem; padding-right: 1.5rem` | Horizontal padding |
| `py-3` | `padding-top: 0.75rem; padding-bottom: 0.75rem` | Vertical padding |

This pattern - `bg-space-darker` with a single directional border in `border-neon-cyan/30` - is the signature panel style throughout the application. The 30% opacity cyan border creates a faint glow line that defines panel edges without being harsh.

### Main Flex Container

```tsx
<div className="flex items-center justify-between">
```

| Class | CSS | Purpose |
|---|---|---|
| `flex` | `display: flex` | Enables flexbox layout |
| `items-center` | `align-items: center` | Vertically centers all children |
| `justify-between` | `justify-content: space-between` | Pushes left group (logo) and right group (status) to opposite edges |

This is the most common layout pattern in the app. Flexbox with `justify-between` creates a two-sided layout: content on the left, controls on the right, with auto-distributed space between them.

### Logo Group

```tsx
<div className="flex items-center gap-4">
  <div className="text-neon-cyan text-2xl font-bold tracking-wider">
    <span className="text-terminal-bright">&lt;</span>
    CONST_CATALOG
    <span className="text-terminal-bright">/&gt;</span>
  </div>
  <div className="text-terminal-dim text-sm">
    Configuration Intelligence System
  </div>
</div>
```

The outer `<div>`:

| Class | CSS | Purpose |
|---|---|---|
| `flex` | `display: flex` | Horizontal layout |
| `items-center` | `align-items: center` | Vertical centering between title and subtitle |
| `gap-4` | `gap: 1rem` | 16px space between title and subtitle. `gap` is cleaner than using margins because it only applies between children, not before the first or after the last. |

The title `<div>`:

| Class | CSS | Purpose |
|---|---|---|
| `text-neon-cyan` | `color: #00ffff` | Full cyan text for the main title |
| `text-2xl` | `font-size: 1.5rem; line-height: 2rem` | Large heading size |
| `font-bold` | `font-weight: 700` | Heavy weight |
| `tracking-wider` | `letter-spacing: 0.05em` | Slightly expanded letter spacing, giving the title a "display" feel. In a monospace font, this extra tracking creates a spacious, high-tech appearance. |

The `<span>` wrappers around `<` and `/>`:

| Class | CSS | Purpose |
|---|---|---|
| `text-terminal-bright` | `color: #ffffff` | Pure white for the angle brackets, creating visual contrast against the cyan title text. The brackets (`<CONST_CATALOG/>`) evoke an XML/HTML tag, reinforcing the code-tool identity. |

The subtitle `<div>`:

| Class | CSS | Purpose |
|---|---|---|
| `text-terminal-dim` | `color: #888899` | Muted gray |
| `text-sm` | `font-size: 0.875rem; line-height: 1.25rem` | Smaller than the default 1rem base |

### Status Indicators Group

```tsx
<div className="flex items-center gap-6">
```

The status indicators use a wider `gap-6` (1.5rem) than the logo group's `gap-4`, giving each status block breathing room. This creates a visual rhythm: tight coupling within each indicator, looser spacing between them.

#### Database Status Block

```tsx
<div className="flex items-center gap-2">
  <Database className="w-4 h-4 text-terminal-dim" />
  <span className="text-sm text-terminal-dim">Neo4J</span>
  <div className={`status-dot ${isConnected ? 'online' : 'offline'}`} />
</div>
```

| Class | CSS | Purpose |
|---|---|---|
| `gap-2` | `gap: 0.5rem` | Tight 8px spacing between icon, label, and dot |
| `w-4 h-4` | `width: 1rem; height: 1rem` | 16px icon size. Lucide icons are SVGs that accept width/height via className |
| `text-terminal-dim` | `color: #888899` | Both the icon and label are dim, keeping attention on the status dot |
| `text-sm` | `font-size: 0.875rem` | Slightly smaller than body text |

The `status-dot` class plus `online`/`offline` is a **dynamic class** computed from the `isConnected` state. This is how Tailwind handles conditional styling: the full class name is constructed via a template literal, and Tailwind's content scanner finds both `'online'` and `'offline'` in the source, so both class sets are generated.

#### System Status Block

```tsx
<div className="flex items-center gap-2">
  <Activity className="w-4 h-4 text-terminal-dim" />
  <span className="text-sm text-terminal-dim">
    {isLoading ? 'CHECKING...' : isError ? 'ERROR' : 'ONLINE'}
  </span>
</div>
```

Same structural pattern as the database block. The text content changes but the styling remains the same, maintaining visual consistency across all status blocks.

#### Project Count Block

```tsx
{health && (
  <div className="flex items-center gap-2">
    <Cpu className="w-4 h-4 text-neon-cyan" />
    <span className="text-sm text-neon-cyan">
      {health.projectCount} PROJECT{health.projectCount !== 1 ? 'S' : ''}
    </span>
  </div>
)}
```

This block differs from the others: it uses `text-neon-cyan` instead of `text-terminal-dim`. The cyan color elevates this from a passive status indicator to an active data point. It's the only status block that communicates a quantity rather than a state.

The `{health && (...)}` pattern means this block only renders when the health check has returned data, preventing a flash of `undefined` during the initial load.

---

## Part 3: The Application Shell

### 3.1 Layout

**File:** `const-catalog-frontend/src/components/Layout.tsx`

```tsx
<div className="min-h-screen flex flex-col bg-space-black">
  <Header />
  <div className="flex flex-1">
    <Sidebar />
    <main className="flex-1 p-6 overflow-auto">
      <Outlet />
    </main>
  </div>
  <CommandLine />
</div>
```

This is the entire application shell. Every page renders inside `<Outlet />`.

#### Root Container

| Class | CSS | Purpose |
|---|---|---|
| `min-h-screen` | `min-height: 100vh` | Ensures the layout fills at least the full viewport |
| `flex` | `display: flex` | Flexbox on the root |
| `flex-col` | `flex-direction: column` | Children stack vertically: Header, middle row, CommandLine |
| `bg-space-black` | `background-color: #0a0a0f` | The deepest background color, visible in any gap between components |

#### Middle Row

```tsx
<div className="flex flex-1">
```

| Class | CSS | Purpose |
|---|---|---|
| `flex` | `display: flex` | Horizontal flexbox for sidebar + main content |
| `flex-1` | `flex: 1 1 0%` | Expands to fill all vertical space between Header and CommandLine. This is the key: `flex-1` on a flex-column child means "take all remaining space." |

#### Main Content Area

```tsx
<main className="flex-1 p-6 overflow-auto">
```

| Class | CSS | Purpose |
|---|---|---|
| `flex-1` | `flex: 1 1 0%` | Takes all horizontal space not used by the Sidebar's fixed `w-64` |
| `p-6` | `padding: 1.5rem` | 24px padding on all four sides, giving page content breathing room |
| `overflow-auto` | `overflow: auto` | Enables scrolling when page content exceeds the viewport. Only this area scrolls; the Header, Sidebar, and CommandLine stay fixed in place. |

**Architectural pattern:** The combination of `flex-col` on the root with `flex-1` on the middle row and `overflow-auto` on `<main>` creates a "holy grail" layout where the header and footer are fixed, the sidebar is fixed-width, and only the content area scrolls.

---

### 3.2 Sidebar

**File:** `const-catalog-frontend/src/components/Sidebar.tsx`

#### Sidebar Container

```tsx
<aside className="w-64 bg-space-darker border-r border-neon-cyan/20 flex flex-col">
```

| Class | CSS | Purpose |
|---|---|---|
| `w-64` | `width: 16rem` (256px) | Fixed sidebar width. In a flex row, this prevents the sidebar from growing or shrinking. |
| `bg-space-darker` | `background-color: #0d0d14` | Same background as the Header, creating a unified "chrome" around the content area |
| `border-r` | `border-right-width: 1px` | Right border separating sidebar from content |
| `border-neon-cyan/20` | `border-color: rgba(0, 255, 255, 0.2)` | Even subtler than the Header's `/30` border. The sidebar's edge is less prominent because the sidebar is a secondary navigation element. |
| `flex flex-col` | Column flexbox | Allows the nav to grow and the footer to stick to the bottom via `flex-1` on `<nav>` |

#### Navigation Container

```tsx
<nav className="flex-1 py-4">
```

`flex-1` makes the nav expand to fill all vertical space, pushing the footer to the bottom. `py-4` adds 1rem padding top and bottom.

#### NavLink Items

```tsx
<NavLink
  className={({ isActive }) =>
    clsx(
      'flex items-center gap-3 px-4 py-3 mx-2 rounded transition-all',
      'border border-transparent',
      isActive
        ? 'bg-neon-cyan/10 border-neon-cyan/30 text-neon-cyan'
        : 'text-terminal-dim hover:bg-space-light hover:text-terminal-text'
    )
  }
>
```

`NavLink` is a React Router component that receives an `isActive` boolean. The `clsx()` utility concatenates class strings conditionally.

**Always-applied classes (line 1 and 2):**

| Class | CSS | Purpose |
|---|---|---|
| `flex items-center` | Horizontal flex, vertically centered | Icon and text side by side |
| `gap-3` | `gap: 0.75rem` | 12px between icon and label |
| `px-4 py-3` | Padding 1rem horizontal, 0.75rem vertical | Comfortable click target |
| `mx-2` | `margin-left: 0.5rem; margin-right: 0.5rem` | Indents the items from sidebar edges, creating a visual "rail" |
| `rounded` | `border-radius: 0.25rem` | Rounded corners |
| `transition-all` | Smooth transitions on all properties | Background color, border color, and text color all animate |
| `border border-transparent` | 1px transparent border | **Critical trick:** By always having a border, the element doesn't shift size when the border becomes visible in the active state. If you only added `border` on active, the 1px border would push content by 1px, causing a layout jump. |

**Active state classes:**

| Class | CSS | Purpose |
|---|---|---|
| `bg-neon-cyan/10` | `background-color: rgba(0, 255, 255, 0.1)` | Very faint cyan tint background |
| `border-neon-cyan/30` | `border-color: rgba(0, 255, 255, 0.3)` | Visible cyan border |
| `text-neon-cyan` | `color: #00ffff` | Cyan text for both icon and label |

**Inactive state classes:**

| Class | CSS | Purpose |
|---|---|---|
| `text-terminal-dim` | `color: #888899` | Dimmed text |
| `hover:bg-space-light` | On hover: `background-color: #252530` | Subtle background highlight |
| `hover:text-terminal-text` | On hover: `color: #e0e0e0` | Text brightens on hover |

#### Icon and Label

```tsx
<item.icon className="w-5 h-5" />
<div>
  <div className="font-medium">{item.label}</div>
  <div className="text-xs opacity-60">{item.description}</div>
</div>
```

| Class | Purpose |
|---|---|
| `w-5 h-5` | 20px icon, slightly larger than the Header's `w-4 h-4` because the sidebar items are bigger click targets |
| `font-medium` | Font weight 500 for the label |
| `text-xs` | 0.75rem font size for the description |
| `opacity-60` | 60% opacity on the description, an alternative to using `text-terminal-dim`. This preserves whatever color the text inherits (cyan when active, dim when inactive) but makes it fainter. |

#### Sidebar Footer

```tsx
<div className="p-4 border-t border-space-light">
  <div className="flex items-center gap-2 text-terminal-dim text-xs">
    <FileCode className="w-4 h-4" />
    <span>v1.0.0 | Space Command</span>
  </div>
</div>
```

| Class | Purpose |
|---|---|
| `p-4` | 1rem padding all around |
| `border-t border-space-light` | Top border in `#252530`, separating from nav. Note this uses `space-light` (opaque gray) rather than `neon-cyan/30` (translucent cyan). This is intentional: the footer is informational, not interactive, so it gets the understated border style. |
| `text-terminal-dim text-xs` | Small, muted version info |

---

## Part 4: The Command Line Footer

### 4.1 CommandLine

**File:** `const-catalog-frontend/src/components/CommandLine.tsx`

The CommandLine is a terminal-style input bar fixed at the bottom of the screen.

#### Footer Container

```tsx
<footer className="bg-space-darker border-t border-neon-cyan/30 px-4 py-2">
```

Mirrors the Header's styling but with `border-t` (top) instead of `border-b` (bottom). Together, the Header and CommandLine bookend the application with matching cyan-tinted borders.

| Class | Purpose |
|---|---|
| `bg-space-darker` | Same background as Header |
| `border-t border-neon-cyan/30` | Top border matching the Header's bottom border |
| `px-4 py-2` | Tighter padding than the Header (py-2 vs py-3) because the command line should feel compact |

#### Form Layout

```tsx
<form onSubmit={handleSubmit} className="flex items-center gap-2">
```

Horizontal flex with tight 8px gap between the prompt symbols, input field, and status indicator.

#### Prompt Symbols

```tsx
<ChevronRight className="w-4 h-4 text-neon-cyan" />
<span className="text-neon-green">cypher</span>
<span className="text-terminal-dim">$</span>
```

This creates a visual prompt: `> cypher $` using three distinct colors:
- **Cyan chevron**: The cursor/prompt indicator
- **Green "cypher"**: Identifies the command context (like a shell prompt showing the current tool)
- **Dim dollar sign**: The traditional shell prompt separator

#### Input Field

```tsx
<input
  className="flex-1 bg-transparent border-none outline-none text-terminal-text placeholder-terminal-dim"
/>
```

| Class | CSS | Purpose |
|---|---|---|
| `flex-1` | `flex: 1 1 0%` | Takes all remaining horizontal space |
| `bg-transparent` | `background-color: transparent` | **Overrides the global input style.** The global `index.css` sets `bg-space-darker` on all inputs, but here we want the input to blend seamlessly into the footer background. |
| `border-none` | `border: none` | Removes the global 1px border |
| `outline-none` | `outline: none` | Removes the focus outline (the footer border provides enough context) |
| `text-terminal-text` | `color: #e0e0e0` | Standard text color |
| `placeholder-terminal-dim` | `color: #888899` on `::placeholder` | Muted placeholder text |

This is an example of **specificity override**: the inline Tailwind classes override the global `input` styles from `index.css` because Tailwind's utility classes are generated after the `@tailwind components` layer.

#### Loading Spinner

```tsx
<Loader2 className="w-4 h-4 text-neon-cyan animate-spin" />
```

| Class | Purpose |
|---|---|
| `animate-spin` | Tailwind's built-in spin animation: `animation: spin 1s linear infinite`. Rotates the element 360 degrees every second. |

#### Results Reminder Button

```tsx
<button className="text-neon-cyan text-xs hover:underline bg-transparent border-none cursor-pointer">
```

A minimal "link-style" button that appears when results exist but the panel is minimized:

| Class | Purpose |
|---|---|
| `text-neon-cyan` | Cyan link color |
| `text-xs` | Small text (12px) to keep it unobtrusive |
| `hover:underline` | Only shows underline on hover, like a hyperlink |
| `bg-transparent border-none` | Removes default button chrome |
| `cursor-pointer` | Ensures the pointer cursor appears (browsers don't always do this for non-link buttons) |

---

### 4.2 CommandLineResults

**File:** `const-catalog-frontend/src/components/CommandLineResults.tsx`

A slide-up panel that appears between the main content and the CommandLine footer.

#### Panel Container

```tsx
<div className="animate-slide-up overflow-hidden border-t border-neon-cyan/30 bg-space-dark">
```

| Class | Purpose |
|---|---|
| `animate-slide-up` | The custom animation from `tailwind.config.js`. Grows from `maxHeight: 0` to `maxHeight: 50vh` over 0.2 seconds. |
| `overflow-hidden` | Hides content that extends beyond the current `maxHeight` during the animation. Without this, content would be visible before the panel finishes opening. |
| `border-t border-neon-cyan/30` | Top border matching the CommandLine footer |
| `bg-space-dark` | `#12121a` - note this uses `space-dark`, not `space-darker`. It's slightly lighter than the footer, creating a visual layering: the results panel appears to "sit on top of" the footer. |

#### Title Bar

```tsx
<div className="flex items-center justify-between px-4 py-2 bg-space-darker border-b border-space-light">
```

A `justify-between` flex row with the title on the left and minimize/close buttons on the right. The `bg-space-darker` background makes the title bar distinct from the results content area (`bg-space-dark`).

#### Window Control Buttons

```tsx
<button className="p-1 text-terminal-dim hover:text-terminal-text transition-colors">
  <Minus className="w-4 h-4" />
</button>
<button className="p-1 text-terminal-dim hover:text-neon-red transition-colors">
  <X className="w-4 h-4" />
</button>
```

| Class | Purpose |
|---|---|
| `p-1` | Minimal padding (4px), keeping buttons compact |
| `text-terminal-dim` | Default gray state |
| `hover:text-terminal-text` | Minimize button brightens to white on hover |
| `hover:text-neon-red` | Close button turns red on hover, a universal "destructive action" signal |
| `transition-colors` | Only animates color changes (more efficient than `transition-all`) |

#### Scrollable Content Area

```tsx
<div className="max-h-[50vh] overflow-auto p-4">
```

| Class | Purpose |
|---|---|
| `max-h-[50vh]` | **Arbitrary value syntax.** The brackets `[]` let you use any CSS value inline. This caps the panel at 50% of the viewport height, preventing it from pushing the CommandLine off-screen. |
| `overflow-auto` | Adds scrollbars only when content exceeds the max height |
| `p-4` | 1rem padding around the ResultsTable |

---

## Part 5: Shared Data Components

### 5.1 ResultsTable

**File:** `const-catalog-frontend/src/components/ResultsTable.tsx`

Used by both `QueryPage` and `CommandLineResults` to display Cypher query results.

#### Error State

```tsx
<div className="bg-neon-red/10 border border-neon-red/30 rounded p-4">
  <span className="text-neon-red">Error: </span>
  <span className="text-terminal-text">{data.error}</span>
</div>
```

The error box uses the same opacity-layering pattern as buttons: a very faint background (`/10`), a slightly more visible border (`/30`), and full-intensity text (`text-neon-red`). This three-tier opacity creates depth without overwhelming the UI.

#### Empty State

```tsx
<div className="bg-space-medium border border-space-light rounded p-4 text-center text-terminal-dim">
  No results found
</div>
```

Uses neutral colors (no neon) because "no results" is informational, not an error or success.

#### Table Structure

```tsx
<table className="data-table">
```

This applies the `.data-table` class from `index.css` (described in Part 1). The table headers (`<th>`) and cells (`<td>`) receive their styling from the global stylesheet rather than inline classes, keeping the component markup clean.

#### Clickable File Link Button

```tsx
<button className="text-neon-cyan cursor-pointer hover:underline bg-transparent border-none p-0 font-inherit text-inherit">
```

This is a `<button>` element styled to look like a hyperlink:

| Class | Purpose |
|---|---|
| `text-neon-cyan` | Cyan color signals "this is clickable" |
| `cursor-pointer` | Pointer cursor on hover |
| `hover:underline` | Underline appears only on hover |
| `bg-transparent border-none p-0` | Removes all default button styling |
| `font-inherit text-inherit` | Inherits the table cell's font family and size rather than using browser defaults for buttons |

Using a `<button>` instead of an `<a>` is correct here because clicking triggers a JavaScript action (opening the file viewer modal), not a URL navigation.

#### Row Count Footer

```tsx
<div className="mt-4 text-terminal-dim text-sm">
```

| Class | Purpose |
|---|---|
| `mt-4` | 1rem top margin, separating from the table |
| `text-terminal-dim text-sm` | Small, muted text for the count |

---

## Part 6: Page Components

### 6.1 Dashboard

**File:** `const-catalog-frontend/src/pages/Dashboard.tsx`

#### Page Layout Pattern

```tsx
<div className="space-y-6">
```

Every page in the application uses `space-y-6` as its root container. This applies `margin-top: 1.5rem` to every child except the first, creating consistent vertical rhythm between sections. It is equivalent to putting `mt-6` on each child, but cleaner.

#### Page Header Pattern

```tsx
<h1 className="text-2xl font-bold text-neon-cyan">System Dashboard</h1>
<p className="text-terminal-dim mt-1">Configuration intelligence overview</p>
```

This two-line header pattern (cyan heading + dim subtitle) is repeated identically on every page:

| Class | Purpose |
|---|---|
| `text-2xl` | 1.5rem / 24px font size |
| `font-bold` | Font weight 700 |
| `text-neon-cyan` | Cyan heading color |
| `mt-1` | 4px space between heading and subtitle |

#### Stats Cards Grid

```tsx
<div className="grid grid-cols-4 gap-4">
```

| Class | CSS | Purpose |
|---|---|---|
| `grid` | `display: grid` | CSS Grid layout |
| `grid-cols-4` | `grid-template-columns: repeat(4, minmax(0, 1fr))` | Four equal-width columns |
| `gap-4` | `gap: 1rem` | 16px between cards |

#### StatCard Component

```tsx
<div className={`bg-space-darker border rounded-lg p-4 ${colorClasses[color]}`}>
  <div className="flex items-center gap-3">
    <Icon className="w-8 h-8 opacity-60" />
    <div>
      <div className="text-3xl font-bold">{value.toLocaleString()}</div>
      <div className="text-terminal-dim text-sm">{label}</div>
    </div>
  </div>
</div>
```

The `colorClasses` map determines both text and border color per card:

```tsx
const colorClasses = {
  cyan:   'text-neon-cyan border-neon-cyan/30',
  blue:   'text-neon-blue border-neon-blue/30',
  green:  'text-neon-green border-neon-green/30',
  purple: 'text-neon-purple border-neon-purple/30',
}
```

Each card gets a unique accent color. The `text-neon-*` class cascades down to the icon and the number, while the `border-neon-*/30` class tints the card's border. The label explicitly uses `text-terminal-dim` to opt out of the inherited color.

| Class | Purpose |
|---|---|
| `rounded-lg` | `border-radius: 0.5rem` (8px). Larger radius than `rounded` (4px), giving cards a softer appearance. |
| `w-8 h-8` | 32px icon, the largest icon size in the app |
| `opacity-60` | Makes the icon 60% transparent, keeping focus on the number |
| `text-3xl` | 1.875rem / 30px, the largest text size in the app |

#### Horizontal Bar Chart

```tsx
<div
  className="h-2 bg-neon-cyan/50 rounded"
  style={{ width: `${Math.min(100, (item.count / stats.constantCount) * 200)}px` }}
/>
```

| Class | Purpose |
|---|---|
| `h-2` | 8px tall bar |
| `bg-neon-cyan/50` | Cyan at 50% opacity |
| `rounded` | Rounded ends |

The width is calculated dynamically via inline `style` because it depends on runtime data. Tailwind classes only work for fixed values; dynamic values must use `style`.

#### InsightCard Component

```tsx
<a href={href} className="block bg-space-medium border border-space-light rounded p-3 hover:border-neon-cyan/50 transition-colors">
```

| Class | Purpose |
|---|---|
| `block` | Makes the `<a>` behave as a block element (fills width) rather than inline |
| `bg-space-medium` | `#1a1a24` - slightly lighter than the surrounding `bg-space-darker` card panel, creating a raised-card effect |
| `hover:border-neon-cyan/50` | Border glows cyan on hover |
| `transition-colors` | Smooth border color transition |

#### Loading and Error States

```tsx
/* Loading */
<div className="flex items-center justify-center h-64">
  <div className="text-neon-cyan animate-pulse">Loading dashboard...</div>
</div>

/* Error */
<div className="flex items-center justify-center h-64">
  <div className="text-center">
    <div className="text-neon-red text-lg">Failed to load dashboard</div>
    <div className="text-terminal-dim mt-2">Check backend connection</div>
  </div>
</div>
```

| Class | Purpose |
|---|---|
| `h-64` | `height: 16rem` (256px). Gives the loading/error state a fixed height, preventing the page from collapsing to nothing. |
| `flex items-center justify-center` | Centers the message both horizontally and vertically within the 256px box |
| `animate-pulse` | Tailwind's built-in pulse: fades opacity between 1 and 0 over 2 seconds |

---

### 6.2 ScanPage

**File:** `const-catalog-frontend/src/pages/ScanPage.tsx`

#### Form Card

```tsx
<div className="bg-space-darker border border-space-light rounded-lg p-6">
```

This is the standard "card" pattern: dark background, subtle border, rounded corners, generous padding. The `p-6` (1.5rem) is larger than the `p-4` used in smaller cards, giving the form more breathing room.

#### Input with Icon

```tsx
<div className="flex-1 relative">
  <FolderSearch className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-terminal-dim" />
  <input className="w-full pl-10" />
</div>
```

This creates an input with an icon inside it:

| Class | CSS | Purpose |
|---|---|---|
| `relative` | `position: relative` | Establishes a positioning context for the absolutely-positioned icon |
| `absolute` | `position: absolute` | Removes icon from flow, positions it relative to the parent |
| `left-3` | `left: 0.75rem` | 12px from left edge |
| `top-1/2` | `top: 50%` | Starts at vertical midpoint |
| `-translate-y-1/2` | `transform: translateY(-50%)` | Shifts up by half its own height, achieving true vertical centering. The combination of `top-1/2` + `-translate-y-1/2` is the standard absolute-centering technique. |
| `pl-10` | `padding-left: 2.5rem` | On the input: 40px left padding prevents text from overlapping the 20px icon plus its 12px offset |

#### Checkbox Row

```tsx
<div className="flex items-center gap-2">
  <input type="checkbox" className="rounded border-space-light" />
  <label className="text-terminal-dim text-sm flex items-center gap-1">
```

| Class | Purpose |
|---|---|
| `rounded` on checkbox | Rounds the checkbox corners |
| `border-space-light` on checkbox | Custom border color for the checkbox |
| `gap-1` on label | 4px gap between the Radio icon and text inside the label |

#### Progress Bar

```tsx
<div className="h-2 bg-space-light rounded-full overflow-hidden">
  <div
    className="h-full bg-neon-cyan transition-all duration-300"
    style={{ width: `${progressPercent}%` }}
  />
</div>
```

| Class on track | Purpose |
|---|---|
| `h-2` | 8px track height |
| `bg-space-light` | Gray background for the unfilled portion |
| `rounded-full` | Fully rounded ends (pill shape). `border-radius: 9999px` |
| `overflow-hidden` | Clips the fill bar's edges to the track's rounded shape |

| Class on fill | Purpose |
|---|---|
| `h-full` | Fills the full height of the track |
| `bg-neon-cyan` | Full cyan color for the filled portion |
| `transition-all duration-300` | Animates width changes over 300ms, creating a smooth progress effect as the SSE events arrive |

#### Live Indicator Dot

```tsx
<div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
```

An 8px green circle that pulses, paired with the text "LIVE". This is a smaller, inline version of the Header's `status-dot.online` pattern.

#### Scrolling File List

```tsx
<div className="bg-space-medium rounded p-3 max-h-48 overflow-y-auto font-mono text-xs">
  {latestFiles.map((file, i) => (
    <div className={`py-0.5 ${
      i === latestFiles.length - 1
        ? 'text-neon-cyan'
        : 'text-terminal-dim'
    }`}>
```

| Class | Purpose |
|---|---|
| `max-h-48` | `max-height: 12rem` (192px). Limits the file list height |
| `overflow-y-auto` | Vertical scrollbar when content exceeds 192px |
| `font-mono text-xs` | Small monospace font for file names |
| `py-0.5` | 2px vertical padding per line, keeping the list compact |

The last file in the list gets `text-neon-cyan` (highlighted as the current file being processed), while all previous files use `text-terminal-dim`. This creates a visual "tail" effect where the most recent item stands out.

#### Success/Failure Result Card

```tsx
<div className={`bg-space-darker border rounded-lg p-6 ${
  scanResult.success ? 'border-neon-green/30' : 'border-neon-red/30'
}`}>
```

Dynamic border color: green on success, red on failure. This single-class change transforms the card's character.

#### Result Stats Row

```tsx
<div className="mt-4 grid grid-cols-5 gap-4">
```

Five equal columns for: Project, Java Files, Property Files, Constants, Parameters.

#### ResultStat Component

```tsx
<div className="text-center">
  <div className={`text-2xl font-bold ${highlight ? 'text-neon-cyan' : 'text-terminal-text'}`}>
    {value}
  </div>
  <div className="text-terminal-dim text-sm">{label}</div>
</div>
```

When `highlight` is true, the number is cyan; otherwise, it's default text color. This draws the eye to the most important stats (Constants and Parameters).

#### File Type Breakdown Section

```tsx
<div className="mt-4 border-t border-space-light pt-4">
  <div className="text-terminal-dim text-xs mb-2 uppercase tracking-wide">File Type Breakdown</div>
  <div className="grid grid-cols-6 gap-4">
```

| Class | Purpose |
|---|---|
| `border-t border-space-light pt-4` | A horizontal rule effect: top border with padding after it |
| `uppercase` | `text-transform: uppercase` |
| `tracking-wide` | `letter-spacing: 0.025em`, slightly expanded. Combined with `uppercase text-xs`, this creates a typical "section label" style. |

---

### 6.3 QueryPage

**File:** `const-catalog-frontend/src/pages/QueryPage.tsx`

#### Three-Column Grid Layout

```tsx
<div className="grid grid-cols-3 gap-6">
  {/* Left panel: 1 column */}
  <div className="bg-space-darker border border-space-light rounded-lg p-4">
    ...Pre-built Queries...
  </div>

  {/* Right panel: 2 columns */}
  <div className="col-span-2 space-y-4">
    ...Editor and Results...
  </div>
</div>
```

| Class | CSS | Purpose |
|---|---|---|
| `grid grid-cols-3` | Three equal columns | Creates a 1:2 ratio layout |
| `gap-6` | 1.5rem gaps | Space between panels |
| `col-span-2` | `grid-column: span 2 / span 2` | The right panel spans columns 2 and 3, taking 2/3 of the width |

#### Query Category Labels

```tsx
<div className="text-terminal-dim text-xs uppercase tracking-wider mb-2">
  {category}
</div>
```

| Class | Purpose |
|---|---|
| `tracking-wider` | `letter-spacing: 0.05em`. Wider than `tracking-wide` (0.025em), giving these category labels a "heading" feel despite being tiny. |

#### Query Buttons (Selected vs Unselected)

```tsx
<button className={`w-full text-left px-3 py-2 rounded transition-colors ${
  selectedQuery === query.id
    ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30'
    : 'bg-space-medium hover:bg-space-light text-terminal-text'
}`}>
```

| State | Classes | Effect |
|---|---|---|
| Selected | `bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/30` | Cyan tinted background, cyan text, cyan border |
| Unselected | `bg-space-medium hover:bg-space-light text-terminal-text` | Neutral background that lightens on hover |

Note `w-full text-left`: buttons are full-width and left-aligned, making them behave like list items rather than centered buttons.

#### Scrollable Query List

```tsx
<div className="space-y-4 max-h-[600px] overflow-y-auto">
```

`max-h-[600px]` uses Tailwind's arbitrary value syntax to set a 600px scroll container for the query list. This prevents the query panel from growing taller than the viewport.

#### Textarea (Cypher Editor)

```tsx
<textarea className="w-full h-32 font-mono text-sm resize-y" />
```

| Class | CSS | Purpose |
|---|---|---|
| `w-full` | `width: 100%` | Full panel width |
| `h-32` | `height: 8rem` (128px) | Default height |
| `font-mono` | Monospace font | Code editing |
| `text-sm` | 14px font | Compact code display |
| `resize-y` | `resize: vertical` | User can drag to resize vertically but not horizontally |

The global `input, textarea` styles from `index.css` also apply here: dark background, border, focus ring.

#### Help Section Inline Code

```tsx
<code className="bg-space-dark px-1 rounded">
  MATCH (c:Constant) RETURN c.name, c.value LIMIT 10
</code>
```

| Class | Purpose |
|---|---|
| `bg-space-dark` | `#12121a` background behind the code snippet |
| `px-1` | 4px horizontal padding |
| `rounded` | 4px corner rounding |

---

### 6.4 TransformPage

**File:** `const-catalog-frontend/src/pages/TransformPage.tsx`

#### Radio Button Group

```tsx
<div className="flex gap-4">
  <label className="flex items-center gap-2 cursor-pointer">
    <input type="radio" className="text-neon-cyan" />
    <span className="text-terminal-dim text-sm">{label}</span>
  </label>
</div>
```

| Class | Purpose |
|---|---|
| `flex gap-4` | Horizontal row with 1rem spacing between radio options |
| `cursor-pointer` on label | Entire label is clickable |
| `text-neon-cyan` on radio | Attempts to color the radio button accent (browser support varies) |

#### Summary Stats Row

```tsx
<div className="grid grid-cols-3 gap-4 mb-6">
  <div className="text-center bg-space-medium rounded p-3">
    <div className="text-2xl font-bold text-neon-green">{result.totalTransformed}</div>
    <div className="text-terminal-dim text-sm">Transformed</div>
  </div>
```

Three equal cards showing Transformed (green), Skipped (yellow), and Failed (red) counts. Each uses the same structure but different accent colors.

Note `text-yellow-400`: this is a **standard Tailwind color**, not a custom theme color. It's used because the neon palette doesn't include a yellow; `yellow-400` is close enough to an amber/warning tone.

#### Status Filter Buttons

```tsx
<button className={`px-3 py-1.5 rounded border text-sm font-medium transition-colors ${
  statusFilter === value
    ? `${color} bg-space-medium`
    : 'text-terminal-dim border-space-light hover:border-terminal-dim'
}`}>
```

| `py-1.5` | `padding-top: 0.375rem; padding-bottom: 0.375rem` | Slightly less than `py-2` (0.5rem), making these "pill" buttons more compact |

The `color` variable is a pre-built string like `'text-neon-green border-neon-green'`. When active, both the text and border take on the status color. When inactive, the button fades to dim gray.

#### Source Kind Badges

```tsx
/* Parameter badge */
<span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-blue-500/20 text-blue-400 border border-blue-500/30">
  Param
</span>

/* Constant badge */
<span className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-purple-500/20 text-purple-400 border border-purple-500/30">
  Const
</span>
```

These badges use standard Tailwind `blue-500` and `purple-500` colors (not the custom neon palette) with the same three-tier opacity pattern (background `/20`, text full, border `/30`). The `inline-flex` with `items-center` ensures the badge text is vertically centered even when mixed with other inline content.

#### Transform Results Table

```tsx
<tr className="border-b border-space-light/50 hover:bg-space-medium/50">
```

| Class | Purpose |
|---|---|
| `border-b border-space-light/50` | Bottom border at 50% opacity, even subtler than the standard `border-space-light` |
| `hover:bg-space-medium/50` | Semi-transparent hover highlight |

```tsx
<td className="py-2 px-3 text-terminal-dim text-xs truncate max-w-[200px]">
```

| Class | Purpose |
|---|---|
| `truncate` | `overflow: hidden; text-overflow: ellipsis; white-space: nowrap`. Truncates long file paths or messages with an ellipsis. |
| `max-w-[200px]` | Limits the column width to 200px. Without this, long paths would push the table wider than its container. |

#### View Comparison Button

```tsx
<button className="text-neon-cyan hover:text-neon-cyan/80 flex items-center gap-1 text-xs">
  <Eye className="w-3 h-3" />
  View
</button>
```

| Class | Purpose |
|---|---|
| `hover:text-neon-cyan/80` | Slightly dims on hover (from 100% to 80% opacity). This is an inverted hover pattern: most elements brighten on hover, but this one subtly fades. It works because the cyan is already very bright. |
| `w-3 h-3` | 12px icon, the smallest icon size in the app. Matches the `text-xs` text size. |

---

## Part 7: Modal Components

### 7.1 FileViewerModal

**File:** `const-catalog-frontend/src/components/FileViewerModal.tsx`

#### Backdrop Overlay

```tsx
<div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
```

| Class | CSS | Purpose |
|---|---|---|
| `fixed` | `position: fixed` | Positions relative to the viewport, covering the entire screen |
| `inset-0` | `top: 0; right: 0; bottom: 0; left: 0` | Stretches to fill the viewport |
| `z-50` | `z-index: 50` | Ensures the modal sits above all other content. Tailwind's z-index scale goes 0, 10, 20, 30, 40, 50. |
| `flex items-center justify-center` | Centers the modal box both horizontally and vertically |
| `bg-black/80` | `background-color: rgba(0, 0, 0, 0.8)` | Dark overlay that dims the background content |
| `backdrop-blur-sm` | `backdrop-filter: blur(4px)` | Slightly blurs the content behind the overlay. This modern CSS property adds a frosted-glass effect. |

#### Modal Container

```tsx
<div className="relative w-[90vw] h-[85vh] bg-space-darker border border-neon-cyan/30 rounded-lg shadow-neon-cyan flex flex-col overflow-hidden">
```

| Class | CSS | Purpose |
|---|---|---|
| `w-[90vw]` | `width: 90vw` | 90% of viewport width |
| `h-[85vh]` | `height: 85vh` | 85% of viewport height |
| `shadow-neon-cyan` | The custom neon glow shadow | Gives the modal a floating, glowing appearance against the dark backdrop |
| `flex flex-col` | Column layout for header + body |
| `overflow-hidden` | Prevents the modal content from leaking outside its rounded corners |

#### Modal Header

```tsx
<div className="flex items-center justify-between px-4 py-3 border-b border-space-light bg-space-dark">
  <div className="min-w-0">
    <h2 className="text-neon-cyan font-semibold truncate">
    <p className="text-terminal-dim text-xs truncate">
  </div>
```

| Class | Purpose |
|---|---|
| `min-w-0` | **Critical for truncation.** In a flex container, children have an implicit `min-width: auto`, which prevents them from shrinking below their content width. Setting `min-w-0` overrides this, allowing `truncate` to work on the children. Without it, long file paths would stretch the header instead of being truncated. |
| `truncate` | Ellipsis for long file names and paths |

#### Close Button

```tsx
<button className="ml-4 p-1 rounded hover:bg-space-light text-terminal-dim hover:text-terminal-text transition-colors">
```

| Class | Purpose |
|---|---|
| `ml-4` | Left margin pushes button away from the title text |
| `hover:bg-space-light` | Background appears only on hover, keeping the button invisible at rest |

#### Source Code Display

```tsx
<pre className="text-sm font-mono leading-relaxed">
  <table className="w-full">
    <tbody>
      <tr className="hover:bg-space-medium/50">
        <td className="select-none text-right pr-4 pl-4 py-0 text-terminal-dim/50 border-r border-space-light w-1 whitespace-nowrap">
          {idx + 1}
        </td>
        <td className="pl-4 pr-4 py-0 text-terminal-text whitespace-pre">
          {line}
        </td>
      </tr>
```

Line number column:

| Class | Purpose |
|---|---|
| `select-none` | `user-select: none`. Prevents line numbers from being selected when the user copies code. |
| `text-right` | Right-aligns line numbers |
| `text-terminal-dim/50` | `color: rgba(136, 136, 153, 0.5)`. Line numbers are extra dim, at 50% opacity of the already-dim gray. |
| `border-r border-space-light` | Vertical separator between line numbers and code |
| `w-1` | `width: 0.25rem`. A very small base width; the actual width is determined by `whitespace-nowrap` keeping the number on one line. |
| `whitespace-nowrap` | Prevents line numbers from wrapping |
| `py-0` | Zero vertical padding, keeping lines tightly packed |

Code column:

| Class | Purpose |
|---|---|
| `whitespace-pre` | `white-space: pre`. Preserves all whitespace and indentation exactly as it appears in the source file. |
| `text-terminal-text` | Standard light gray text |

The `leading-relaxed` on the `<pre>` sets `line-height: 1.625`, giving each line of code comfortable vertical spacing.

#### Error State in Modal

```tsx
<div className="bg-neon-red/10 border border-neon-red/30 rounded p-6 text-center max-w-md">
  <AlertTriangle className="w-8 h-8 text-neon-red mx-auto mb-2" />
```

| Class | Purpose |
|---|---|
| `max-w-md` | `max-width: 28rem` (448px). Constrains the error message to a readable width rather than stretching across the full modal. |
| `mx-auto` | `margin-left: auto; margin-right: auto`. Centers the icon horizontally. |
| `mb-2` | 8px bottom margin below the icon |

---

### 7.2 DiffViewer

**File:** `const-catalog-frontend/src/components/DiffViewer.tsx`

#### Modal Backdrop

```tsx
<div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
```

Same backdrop pattern as FileViewerModal, but adds `p-4` (1rem padding) so the modal never touches the viewport edges.

#### Modal Container

```tsx
<div className="bg-space-darker border border-space-light rounded-lg w-full max-w-7xl max-h-[90vh] flex flex-col">
```

| Class | CSS | Purpose |
|---|---|---|
| `w-full` | `width: 100%` | Fills the available space (minus the `p-4` padding from the backdrop) |
| `max-w-7xl` | `max-width: 80rem` (1280px) | Caps at a comfortable maximum width for side-by-side code viewing |
| `max-h-[90vh]` | 90% of viewport height | Prevents the modal from exceeding the screen |

#### Column Headers

```tsx
<div className="grid grid-cols-2 border-b border-space-light">
  <div className="px-4 py-2 text-terminal-dim text-sm font-medium border-r border-space-light">
    Original
  </div>
  <div className="px-4 py-2 text-terminal-dim text-sm font-medium">
    Transformed
  </div>
</div>
```

Two equal columns. The left column has `border-r` (right border) to visually separate the two panels.

#### Diff Content Area

```tsx
<div className="grid grid-cols-2 flex-1 overflow-hidden">
```

| Class | Purpose |
|---|---|
| `grid grid-cols-2` | Two equal columns for side-by-side comparison |
| `flex-1` | Takes remaining vertical space (below the header and column labels) |
| `overflow-hidden` | Each panel handles its own scrolling independently |

#### Individual Diff Panel

```tsx
<div ref={leftRef} className="overflow-auto border-r border-space-light font-mono text-xs">
```

| Class | Purpose |
|---|---|
| `overflow-auto` | Each panel scrolls independently. The synchronized scrolling is handled via JavaScript (the `useEffect` scroll event listeners), not CSS. |
| `border-r border-space-light` | Only the left panel has a right border |
| `font-mono text-xs` | 12px monospace text for compact code display |

#### Diff Line Styling

```tsx
const getLineClass = (origLine: string, transLine: string, side: 'left' | 'right') => {
  if (origLine === transLine) return ''
  return side === 'left'
    ? 'bg-red-900/30 border-l-2 border-red-500'
    : 'bg-green-900/30 border-l-2 border-green-500'
}
```

Changed lines get:

| Side | Classes | Visual Effect |
|---|---|---|
| Left (original) | `bg-red-900/30 border-l-2 border-red-500` | Faint red background tint with a solid red left border |
| Right (transformed) | `bg-green-900/30 border-l-2 border-green-500` | Faint green background tint with a solid green left border |
| Unchanged | (empty string) | No highlight |

The `red-900` and `green-900` are very dark variants of the standard Tailwind red/green palette, at 30% opacity. This keeps the diff highlights visible without obscuring the code text. The `border-l-2` (2px left border) provides a strong visual indicator in the gutter area.

#### Line Number in Diff

```tsx
<span className="w-12 text-right pr-3 py-0.5 text-terminal-dim select-none flex-shrink-0">
  {i + 1}
</span>
```

| Class | Purpose |
|---|---|
| `w-12` | `width: 3rem` (48px). Fixed width for line numbers |
| `flex-shrink-0` | Prevents the line number column from shrinking when the code content is wide |
| `select-none` | Prevents selecting line numbers when copying code |

#### Code Content in Diff

```tsx
<pre className="py-0.5 text-terminal-text whitespace-pre overflow-x-auto flex-1">
```

| Class | Purpose |
|---|---|
| `whitespace-pre` | Preserves all whitespace and indentation |
| `overflow-x-auto` | Allows horizontal scrolling for long lines |
| `flex-1` | Takes remaining width after the line number column |

---

## Appendix: Quick Reference Tables

### Color Usage Map

| Color Token | Hex | Where Used |
|---|---|---|
| `space-black` | `#0a0a0f` | Body background, outermost container |
| `space-darker` | `#0d0d14` | Panel backgrounds (header, sidebar, cards, footer) |
| `space-dark` | `#12121a` | Secondary panels (CommandLineResults, modal headers) |
| `space-medium` | `#1a1a24` | Hover backgrounds, sub-panels, table headers |
| `space-light` | `#252530` | Borders, dividers, scrollbar thumb |
| `neon-cyan` | `#00ffff` | Primary accent, headings, active states, links |
| `neon-green` | `#00ff9f` | Success states, online indicator, "LIVE" badge |
| `neon-blue` | `#00aaff` | Stats card accent (Files count) |
| `neon-purple` | `#aa00ff` | Stats card accent (Parameters count) |
| `neon-red` | `#ff3333` | Error states, offline indicator, close buttons |
| `neon-orange` | `#ff6600` | Pending indicator |
| `terminal-text` | `#e0e0e0` | Primary body text |
| `terminal-dim` | `#888899` | Secondary text, labels, placeholders |
| `terminal-bright` | `#ffffff` | Maximum emphasis (angle brackets, selected text) |

### Opacity Scale Used

| Opacity | Purpose |
|---|---|
| `/10` | Very faint backgrounds (error boxes, success boxes) |
| `/20` | Button backgrounds, active nav item backgrounds, sidebar border |
| `/30` | Borders (header, footer, cards), status dot glow |
| `/50` | Focused input borders, hover borders, bar charts, hover backgrounds |
| `/60` | Icon opacity on stat cards |
| `/80` | Modal backdrops, hover dimming on bright elements |

### Common Layout Patterns

| Pattern | Classes | Used In |
|---|---|---|
| Two-sided header | `flex items-center justify-between` | Header, modal headers, title bars |
| Vertical stack with spacing | `space-y-6` | All page roots, form contents |
| Equal grid columns | `grid grid-cols-N gap-N` | Dashboard stats, scan results, query layout |
| Card panel | `bg-space-darker border border-space-light rounded-lg p-4` | Every section panel |
| Centered loading/error | `flex items-center justify-center h-64` | Dashboard states |
| Full-screen modal | `fixed inset-0 z-50 flex items-center justify-center bg-black/80` | FileViewerModal, DiffViewer |
| Input with icon | `relative` parent + `absolute` icon + `pl-10` input | ScanPage, TransformPage |
| Truncated text | `truncate max-w-[Npx]` | File paths in tables, modal headers |

### Animation Usage

| Animation | Class | Where Used |
|---|---|---|
| Slow pulse | `animate-pulse-slow` | Online status dot |
| Default pulse | `animate-pulse` | Pending status dot, loading text, live indicator |
| Spin | `animate-spin` | Loader2 icons during API calls |
| Slide up | `animate-slide-up` | CommandLineResults panel |
| Glow | `animate-glow` | Available but not currently used in components |

### Typography Scale

| Class | Size | Used For |
|---|---|---|
| `text-xs` | 0.75rem / 12px | Descriptions, labels, badges, file lists, diff code |
| `text-sm` | 0.875rem / 14px | Secondary text, table content, subtitles |
| (default) | 1rem / 16px | Body text, nav labels |
| `text-lg` | 1.125rem / 18px | Section headings inside cards |
| `text-2xl` | 1.5rem / 24px | Page titles, stat values |
| `text-3xl` | 1.875rem / 30px | Dashboard stat card numbers |

### Icon Size Scale

| Class | Pixels | Where Used |
|---|---|---|
| `w-3 h-3` | 12px | Tiny inline icons (Radio, Eye in tables) |
| `w-4 h-4` | 16px | Standard icons (Header status, buttons, close buttons) |
| `w-5 h-5` | 20px | Navigation icons, section heading icons, input icons |
| `w-6 h-6` | 24px | Result status icons (CheckCircle, XCircle, Loader2) |
| `w-8 h-8` | 32px | Dashboard stat card icons, modal loading/error icons |
