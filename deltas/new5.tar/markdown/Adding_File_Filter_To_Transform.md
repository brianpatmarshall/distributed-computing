# Adding File Filter to Transform

Documents the changes made to add an optional `fileFilter` parameter to the Code Transformer. When set, only files whose path contains the filter string are transformed. All other files are excluded from the operation.

---

## Table of Contents

1. [What It Does](#1-what-it-does)
2. [Files Changed](#2-files-changed)
3. [Backend: TransformRequest DTO](#3-backend-transformrequest-dto)
4. [Backend: CodeTransformationService](#4-backend-codetransformationservice)
5. [Frontend: TypeScript Types](#5-frontend-typescript-types)
6. [Frontend: TransformPage UI](#6-frontend-transformpage-ui)
7. [Data Flow](#7-data-flow)

---

## 1. What It Does

The file filter is an optional text field on the Transform page. When the user enters a value:

- **`"AppConfig.java"`** — only files named AppConfig.java are transformed
- **`"src/main/java"`** — only files under src/main/java are transformed
- **`"com/boeing"`** — only files in the com/boeing package tree are transformed
- **Empty (default)** — all files in the project are transformed

The filter is a simple substring match on the full file path. It applies to all transform operations: ALL, CONSTANTS_ONLY, PARAMETERS_ONLY, and REMOVE_UNUSED.

---

## 2. Files Changed

| File | Change |
|---|---|
| `const-catalog-backend/.../dto/TransformRequest.java` | Added `fileFilter` field |
| `const-catalog-backend/.../service/CodeTransformationService.java` | Added `applyFileFilter()` method; called in both `transform()` and `handleRemoveUnused()` |
| `const-catalog-frontend/src/types/index.ts` | Added `fileFilter?: string` to `TransformRequest` |
| `const-catalog-frontend/src/pages/TransformPage.tsx` | Added `fileFilter` state, text input, and passed to `mutate()` |

No changes needed in:
- `services/api.ts` — already passes the full `TransformRequest` object
- `TransformController.java` — already passes the full `TransformRequest` to the service
- `TransformResponse` — the filter doesn't affect the response shape

---

## 3. Backend: TransformRequest DTO

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/dto/TransformRequest.java`

**Added:**
```java
@Schema(
    description = "Optional file path filter. Only files whose path contains this string will be transformed.",
    example = "src/main/java"
)
private String fileFilter;
```

Lombok's `@Data` generates `getFileFilter()` and `setFileFilter()` automatically. Jackson deserializes the field from the JSON request body. If the client doesn't send `fileFilter`, it's `null`.

---

## 4. Backend: CodeTransformationService

**File:** `const-catalog-backend/src/main/java/com/boeing/constcatalog/backend/service/CodeTransformationService.java`

### New helper method:

```java
private void applyFileFilter(Map<Path, List<ConstantTarget>> targetsByFile, String fileFilter) {
    if (fileFilter != null && !fileFilter.isBlank()) {
        String trimmed = fileFilter.trim();
        int before = targetsByFile.size();
        targetsByFile.keySet().removeIf(path -> !path.toString().contains(trimmed));
        log.info("File filter '{}': {} → {} files", trimmed, before, targetsByFile.size());
    }
}
```

**How it works:**

`targetsByFile` is a `Map<Path, List<ConstantTarget>>` where each key is a file path. `keySet().removeIf(...)` iterates the keys and removes any entry where the file path doesn't contain the filter string. This modifies the map in place.

The method is a no-op if `fileFilter` is null or blank — preserving the existing behavior when no filter is specified.

### Called in `transform()`:

After building `targetsByFile` from both constant and parameter queries, but before the empty check:

```java
// Phase 1: Query Neo4j for candidates
Map<Path, List<ConstantTarget>> targetsByFile = new HashMap<>();
// ... populate from constants and parameters ...

// Apply optional file filter
applyFileFilter(targetsByFile, request.getFileFilter());

if (targetsByFile.isEmpty()) {
    // "No configuration candidates found"
}
```

If the filter removes all files, the user sees "No configuration candidates found" rather than an empty result with zero counts.

### Called in `handleRemoveUnused()`:

Same pattern — after grouping unused constants by file, before the removal phase:

```java
Map<Path, List<ConstantTarget>> targetsByFile = new HashMap<>();
for (ConstantWithFile c : unusedConstants) {
    targetsByFile.computeIfAbsent(Paths.get(c.filePath()), k -> new ArrayList<>())
        .add(c.toTarget());
}

// Apply optional file filter
applyFileFilter(targetsByFile, request.getFileFilter());
```

---

## 5. Frontend: TypeScript Types

**File:** `const-catalog-frontend/src/types/index.ts`

**Added:**
```typescript
export interface TransformRequest {
  projectPath: string
  dryRun: boolean
  candidateScope?: 'CONSTANTS_ONLY' | 'PARAMETERS_ONLY' | 'ALL' | 'REMOVE_UNUSED'
  createBranch?: boolean
  fileFilter?: string    // ← new
}
```

The `?` makes it optional. When the user leaves the filter empty, `undefined` is passed, and Jackson ignores it on the backend (the field stays `null`).

---

## 6. Frontend: TransformPage UI

**File:** `const-catalog-frontend/src/pages/TransformPage.tsx`

### State:
```typescript
const [fileFilter, setFileFilter] = useState('')
```

### Passed to mutation:
```typescript
transformMutation.mutate({
  projectPath: projectPath.trim(),
  dryRun,
  candidateScope,
  createBranch: !dryRun && createBranch,
  fileFilter: fileFilter.trim() || undefined,   // omit if empty
})
```

`fileFilter.trim() || undefined` means: if the user typed only whitespace or nothing, send `undefined` (omitted from JSON). If they typed a value, send the trimmed string.

### Text input:
Added between the Project Path input and the Candidate Scope selector:

```tsx
<div>
  <label className="block text-terminal-text mb-2 text-sm">File Filter (optional)</label>
  <input
    type="text"
    value={fileFilter}
    onChange={(e) => setFileFilter(e.target.value)}
    placeholder="e.g., src/main/java or AppConfig.java"
    className="w-full"
  />
  <div className="text-terminal-dim text-xs mt-1">
    Only files whose path contains this text will be transformed. Leave empty to transform all files.
  </div>
</div>
```

---

## 7. Data Flow

```
User types "AppConfig" in the File Filter input
  │
  ▼
fileFilter state = "AppConfig"
  │
  ▼
handleTransform() calls mutate({ ..., fileFilter: "AppConfig" })
  │
  ▼
transformProject(request) sends POST /api/transform
  Body: { "projectPath": "/src/...", "fileFilter": "AppConfig", ... }
  │
  ▼
TransformController receives TransformRequest with fileFilter = "AppConfig"
  │
  ▼
CodeTransformationService.transform(request)
  │
  ├── Queries Neo4j → targetsByFile has 50 files
  │
  ├── applyFileFilter(targetsByFile, "AppConfig")
  │     → removeIf(path → !path.contains("AppConfig"))
  │     → targetsByFile now has 1 file: .../AppConfig.java
  │
  └── Transforms only AppConfig.java
```
