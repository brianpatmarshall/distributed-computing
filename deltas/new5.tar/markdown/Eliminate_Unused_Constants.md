# Eliminate Unused Constants — Design & Implementation

## Overview

This feature adds a new transformation mode, **Remove Unused**, to the existing Code Transformer pipeline. When selected, it queries the Neo4j graph for constants that have no `USED_IN` relationships (i.e., they are declared but never referenced in any scanned file), then removes their `static final` field declarations from the source files using JavaParser AST manipulation.

## Rationale: Extend Rather Than Duplicate

The original design sketch (in the Developer Guide) proposed a completely separate pipeline: new controller, new endpoint, new DTOs, a dedicated frontend page, and separate response types. That approach would have duplicated roughly 500 lines of existing infrastructure (dry-run logic, git branching, response building, comparison viewer, logging, error handling).

Instead, we **extend the existing transform pipeline** by adding a new value to the `CandidateScope` enum and dispatching to a new handler inside `CodeTransformationService`. This approach:

- **Reuses** the existing `/api/transform` endpoint, `TransformRequest`/`TransformResponse` DTOs, the `TransformController`, the diff viewer, git branching, dry-run mode, and status filtering — all without any changes to those components.
- **Minimises blast radius**: only 6 files were touched (1 new class, 1 new test, 4 edits).
- **Preserves UX consistency**: the user interacts with the same Transform page, same radio-button pattern, same results table, same comparison viewer.

## Architecture

```
TransformPage (frontend)
    |
    | POST /api/transform  { candidateScope: "REMOVE_UNUSED", ... }
    |
    v
TransformController (unchanged)
    |
    v
CodeTransformationService.transform()
    |-- scope == REMOVE_UNUSED?  --> handleRemoveUnused()
    |       |
    |       |-- Phase 1: findUnusedConstants() — Cypher query
    |       |-- Phase 2: UnusedConstantRemover.removeFromProject() or .dryRun()
    |       |-- Phase 2.5: createBranchWithTransformedFiles() (reused)
    |       |-- Phase 3: Build TransformResponse (reused pattern)
    |
    |-- else --> existing config-lookup transform flow
```

## Files Changed

### New Files

| File | Description |
|------|-------------|
| `const-catalog-core/.../transformer/UnusedConstantRemover.java` | Core AST remover. Parses Java files, identifies `static final` field declarations matching target names, and removes them. |
| `const-catalog-core/.../transformer/UnusedConstantRemoverTest.java` | 11 unit tests covering removal, protection, dry-run, multi-variable declarations, edge cases. |

### Modified Files

| File | Change |
|------|--------|
| `const-catalog-backend/.../dto/TransformRequest.java` | Added `REMOVE_UNUSED` to the `CandidateScope` enum. |
| `const-catalog-backend/.../service/CodeTransformationService.java` | Added `unusedRemover` field, `handleRemoveUnused()` method, and `findUnusedConstants()` Cypher query. Dispatch at top of `transform()`. |
| `const-catalog-frontend/src/types/index.ts` | Added `'REMOVE_UNUSED'` to the `candidateScope` union type. |
| `const-catalog-frontend/src/pages/TransformPage.tsx` | Added "Remove Unused" radio button to scope selector; added conditional description text explaining what the remover does vs. the existing transformer. |

### Files NOT Changed

`TransformController`, `TransformResponse`, `TransformationEntry`, `TransformationResult`, `ConstantTarget`, `api.ts`, `App.tsx`, `Sidebar.tsx`, `DiffViewer` — all reused as-is.

## UnusedConstantRemover — Design Details

### Core Algorithm

1. Parse the source file with JavaParser (Java 21 language level).
2. Find all `FieldDeclaration` nodes that have both `static` and `final` modifiers.
3. For each `VariableDeclarator` within those fields, check if it matches a target constant name.
4. Apply safety checks:
   - **Protected names**: `serialVersionUID`, `VERSION`, `LOG`, `LOGGER`, `logger` are never removed.
   - **Line tolerance**: If the Neo4j line number and the AST line number differ by more than 3 lines, skip (same tolerance as `ConfigLookupTransformer`).
5. Sort candidates **bottom-up** (highest line number first) to avoid line-number drift during removal.
6. For each candidate:
   - If the `FieldDeclaration` has a single variable → remove the entire field.
   - If the `FieldDeclaration` has multiple variables (e.g., `static final int A = 1, B = 2;`) → remove only the specific `VariableDeclarator`, leaving the rest intact.
7. Write the modified AST to the backups directory; preserve the original as `.orig`.

### Public API

```java
// Remove constants, write modified files to backupsDir
List<TransformationEntry> removeFromFile(Path sourceFile, List<ConstantTarget> targets, Path backupsDir)

// Preview without modifying
List<TransformationEntry> dryRun(Path sourceFile, List<ConstantTarget> targets)

// Batch removal across a project
TransformationResult removeFromProject(String projectPath, Map<Path, List<ConstantTarget>> targetsByFile)
```

All three methods follow the same patterns as `ConfigLookupTransformer` — same return types, same status enum, same backup conventions — so the rest of the pipeline works without changes.

## Neo4j Query

The `findUnusedConstants` query identifies constants with no outgoing `USED_IN` edges:

```cypher
MATCH (p:Project {rootPath: $path})-[:CONTAINS]->(f:File)<-[:DEFINED_IN]-(c:Constant)
WHERE NOT exists { MATCH (c)-[:USED_IN]->() }
  AND NOT coalesce(c.isEnum, false) = true
RETURN c.name AS constantName,
       c.type AS constantType,
       c.value AS constantValue,
       c.className AS className,
       c.lineNumber AS lineNumber,
       f.path AS filePath
ORDER BY f.path, c.lineNumber
```

Key filters:
- `NOT exists { MATCH (c)-[:USED_IN]->() }` — the constant has zero usage relationships in the graph.
- `NOT coalesce(c.isEnum, false) = true` — enum constants are excluded (they may be used via pattern matching or serialisation in ways the scanner doesn't track).

Unlike the config-lookup transform (which assigns all constants to every Java file), the remove-unused flow targets each constant in its **definition file only**, since we're removing declarations, not usages.

## Frontend Changes

The `TransformPage` scope selector gains a fourth radio button:

```
( ) All    ( ) Constants Only    ( ) Parameters Only    (•) Remove Unused
```

When "Remove Unused" is selected, the description text switches to explain the removal behaviour (query graph for unused, remove declarations, protect special names). All other UI — dry-run checkbox, git branch checkbox, results table, diff viewer, status filters — works unchanged.

## Test Coverage

The `UnusedConstantRemoverTest` includes 11 tests:

| Test | What it verifies |
|------|-----------------|
| `testRemovesSingleUnusedConstant` | Basic single-constant removal; other constants remain |
| `testRemovesMultipleConstants` | Batch removal of 3 constants from one file |
| `testProtectsSerialVersionUID` | `serialVersionUID` is skipped even when targeted |
| `testProtectsLoggerField` | `LOG` field is skipped |
| `testDryRunDoesNotModifyFile` | Dry run reports what would happen without writing |
| `testSkipsNonStaticFinalFields` | Non-`static final` fields are not touched |
| `testMultiVariableDeclarationRemovesSingleVar` | `int A = 1, B = 2, C = 3;` → removes only A |
| `testPreservesBackupFile` | `.orig` backup contains the original content |
| `testSkipsWhenDeclarationNotFound` | Missing constant → SKIPPED status |
| `testRemoveFromProject` | Multi-file batch removal via `removeFromProject()` |
| `testEmptyTargetListReturnsEmpty` | Empty input → empty output |

## Verification

```bash
# Core tests (11 pass)
mvn test -pl const-catalog-core -Dtest=UnusedConstantRemoverTest

# Full backend + core regression (all pass, 0 failures)
mvn test -pl const-catalog-backend -am

# Manual: scan a project, Transform page → "Remove Unused" → Dry Run → Execute
```
