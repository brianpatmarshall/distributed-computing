package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import com.boeing.constcatalog.backend.service.SiteConfigurationService;

public class SampleClass {

    private static final String API_URL = "https://api.example.com";

    private static final int MAX_RETRIES = 3;

    private static final long TIMEOUT_MS = 5000L;

    public static final String PUBLIC_CONSTANT = "public";

    protected static final double PI = 3.14159;

    // Not a constant - missing final
    private static String notAConstant = "mutable";

    // Not a constant - missing static
    private final String instanceFinal = "instance";

    // Regular field
    private String regularField;

    public void doSomething() {
        String host = config.lookup("database.host");
        int port = config.lookupInt("server.port");
    }

    @Autowired
    private SiteConfigurationService config;
}
