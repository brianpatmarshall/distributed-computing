package com.boeing.constcatalog.transformer;

import com.boeing.constcatalog.model.ConstantTarget;
import com.boeing.constcatalog.model.TransformationEntry;
import com.boeing.constcatalog.model.TransformationResult;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ConfigLookupTransformerTest {

    private ConfigLookupTransformer transformer;

    @TempDir
    Path tempDir;

    private Path backupsDir;

    @BeforeEach
    void setUp() {
        transformer = new ConfigLookupTransformer();
        backupsDir = tempDir.resolve("backups");
    }

    /**
     * Computes the path where the transformer writes the transformed file.
     */
    private Path outputPath(Path sourceFile) {
        Path abs = sourceFile.toAbsolutePath();
        return backupsDir.resolve(abs.getRoot().relativize(abs));
    }

    @Test
    void testReplacesStringConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class MyService {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("MyService.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "MyService", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookup(\"db.host\")"),
            "Expected config.lookup call, got:\n" + transformed);
    }

    @Test
    void testReplacesIntConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class ServerConfig {
                public static final int SSH_PORT = 22;

                public void connect() {
                    int port = SSH_PORT;
                }
            }
            """;

        Path javaFile = writeSource("ServerConfig.java", source);

        ConstantTarget target = new ConstantTarget(
            "SSH_PORT", "ssh.port", "22", "int", "ServerConfig", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupInt(\"ssh.port\""),
            "Expected config.lookupInt call, got:\n" + transformed);
    }

    @Test
    void testReplacesLongConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class TimeoutConfig {
                public static final long TIMEOUT_MS = 30000L;

                public void configure() {
                    long timeout = TIMEOUT_MS;
                }
            }
            """;

        Path javaFile = writeSource("TimeoutConfig.java", source);

        ConstantTarget target = new ConstantTarget(
            "TIMEOUT_MS", "timeout.ms", "30000", "long", "TimeoutConfig", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupLong(\"timeout.ms\""),
            "Expected config.lookupLong call, got:\n" + transformed);
    }

    @Test
    void testReplacesBooleanConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class FeatureFlags {
                public static final boolean DEBUG_ENABLED = true;

                public void check() {
                    boolean debug = DEBUG_ENABLED;
                }
            }
            """;

        Path javaFile = writeSource("FeatureFlags.java", source);

        ConstantTarget target = new ConstantTarget(
            "DEBUG_ENABLED", "debug.enabled", "true", "boolean", "FeatureFlags", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupBoolean(\"debug.enabled\""),
            "Expected config.lookupBoolean call, got:\n" + transformed);
    }

    @Test
    void testReplacesDoubleConstantUsage() throws IOException {
        String source = """
            package com.example;

            public class MathConstants {
                public static final double RATE = 0.15;

                public void calculate() {
                    double r = RATE;
                }
            }
            """;

        Path javaFile = writeSource("MathConstants.java", source);

        ConstantTarget target = new ConstantTarget(
            "RATE", "rate", "0.15", "double", "MathConstants", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("config.lookupDouble(\"rate\""),
            "Expected config.lookupDouble call, got:\n" + transformed);
    }

    @Test
    void testReplacesMultipleUsagesInSameFile() throws IOException {
        String source = """
            package com.example;

            public class MultiUsage {
                public static final String API_HOST = "api.example.com";
                public static final int API_PORT = 443;

                public void connect() {
                    String host = API_HOST;
                    int port = API_PORT;
                }
            }
            """;

        Path javaFile = writeSource("MultiUsage.java", source);

        List<ConstantTarget> targets = List.of(
            new ConstantTarget("API_HOST", "api.host", "\"api.example.com\"", "String", "MultiUsage", 4),
            new ConstantTarget("API_PORT", "api.port", "443", "int", "MultiUsage", 5)
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, targets, backupsDir);

        long transformed = results.stream()
            .filter(e -> e.status() == TransformationEntry.Status.TRANSFORMED)
            .count();
        assertEquals(2, transformed);

        String output = Files.readString(outputPath(javaFile));
        assertTrue(output.contains("config.lookup(\"api.host\")"));
        assertTrue(output.contains("config.lookupInt(\"api.port\""));
    }

    @Test
    void testDryRunDoesNotModifyFile() throws IOException {
        String source = """
            package com.example;

            public class DryRunTest {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("DryRunTest.java", source);
        String originalContent = Files.readString(javaFile);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "DryRunTest", 4
        );

        List<TransformationEntry> results = transformer.dryRun(javaFile, List.of(target));

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());

        // File should be unchanged
        String afterContent = Files.readString(javaFile);
        assertEquals(originalContent, afterContent, "Dry run should not modify the file");
    }

    @Test
    void testAddsConfigFieldIfMissing() throws IOException {
        String source = """
            package com.example;

            public class NoConfigField {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("NoConfigField.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "NoConfigField", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        String transformed = Files.readString(outputPath(javaFile));
        assertTrue(transformed.contains("@Autowired"),
            "Expected @Autowired annotation, got:\n" + transformed);
        assertTrue(transformed.contains("SiteConfigurationService config"),
            "Expected config field, got:\n" + transformed);
    }

    @Test
    void testSkipsAlreadyTransformedUsages() throws IOException {
        String source = """
            package com.example;

            public class AlreadyDone {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    // No usages of DB_HOST here
                    String host = "hardcoded";
                }
            }
            """;

        Path javaFile = writeSource("AlreadyDone.java", source);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "AlreadyDone", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.SKIPPED, results.getFirst().status());
    }

    @Test
    void testPreservesOriginalFileAsBackup() throws IOException {
        String source = """
            package com.example;

            public class BackupTest {
                public static final String DB_HOST = "localhost";

                public void connect() {
                    String host = DB_HOST;
                }
            }
            """;

        Path javaFile = writeSource("BackupTest.java", source);
        String originalContent = Files.readString(javaFile);

        ConstantTarget target = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "BackupTest", 4
        );

        transformer.transformFile(javaFile, List.of(target), backupsDir);

        Path backupFile = Path.of(outputPath(javaFile) + ".orig");
        assertTrue(Files.exists(backupFile), "Backup file should exist in backups directory");

        String backupContent = Files.readString(backupFile);
        assertEquals(originalContent, backupContent, "Backup should contain original content");
    }

    @Test
    void testHandlesEnumConstantUsages() throws IOException {
        String source = """
            package com.example;

            public class EnumUser {
                public static final String ENV_MODE = "production";

                public void configure() {
                    String mode = ENV_MODE;
                }
            }
            """;

        Path javaFile = writeSource("EnumUser.java", source);

        ConstantTarget target = new ConstantTarget(
            "ENV_MODE", "env.mode", "\"production\"", "String", "EnumUser", 4
        );

        List<TransformationEntry> results = transformer.transformFile(javaFile, List.of(target), backupsDir);

        assertEquals(1, results.size());
        assertEquals(TransformationEntry.Status.TRANSFORMED, results.getFirst().status());
    }

    @Test
    void testChooseLookupMethod() {
        assertEquals("lookup", ConfigLookupTransformer.chooseLookupMethod("String"));
        assertEquals("lookup", ConfigLookupTransformer.chooseLookupMethod("java.lang.String"));
        assertEquals("lookupInt", ConfigLookupTransformer.chooseLookupMethod("int"));
        assertEquals("lookupInt", ConfigLookupTransformer.chooseLookupMethod("Integer"));
        assertEquals("lookupLong", ConfigLookupTransformer.chooseLookupMethod("long"));
        assertEquals("lookupLong", ConfigLookupTransformer.chooseLookupMethod("Long"));
        assertEquals("lookupBoolean", ConfigLookupTransformer.chooseLookupMethod("boolean"));
        assertEquals("lookupBoolean", ConfigLookupTransformer.chooseLookupMethod("Boolean"));
        assertEquals("lookupDouble", ConfigLookupTransformer.chooseLookupMethod("double"));
        assertEquals("lookupDouble", ConfigLookupTransformer.chooseLookupMethod("Double"));
        assertEquals("lookup", ConfigLookupTransformer.chooseLookupMethod("SomeOtherType"));
    }

    @Test
    void testDeriveConfigLookupCall() {
        ConstantTarget stringTarget = new ConstantTarget(
            "DB_HOST", "db.host", "\"localhost\"", "String", "Config", 1
        );
        assertEquals("config.lookup(\"db.host\")", transformer.deriveConfigLookupCall(stringTarget));

        ConstantTarget intTarget = new ConstantTarget(
            "SSH_PORT", "ssh.port", "22", "int", "Config", 2
        );
        assertEquals("config.lookupInt(\"ssh.port\", 22)", transformer.deriveConfigLookupCall(intTarget));
    }

    // ========================================================================
    // Helpers
    // ========================================================================

    private Path writeSource(String fileName, String content) throws IOException {
        Path file = tempDir.resolve(fileName);
        Files.writeString(file, content);
        return file;
    }
}
