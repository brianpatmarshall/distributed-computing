package com.boeing.constcatalog.parser;

import com.boeing.constcatalog.model.Constant;
import com.boeing.constcatalog.model.ParameterUsage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class JavaFileParserTest {

    private JavaFileParser parser;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        parser = new JavaFileParser();
    }

    @Test
    void testCatalogsPrivateStaticFinalFields() throws IOException {
        String javaCode = """
            package com.example;

            public class TestClass {
                private static final String NAME = "test";
                private static final int COUNT = 42;
                private static final long BIG_NUMBER = 1000000L;
            }
            """;

        Path javaFile = tempDir.resolve("TestClass.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        // All static final fields are cataloged regardless of access modifier
        assertEquals(3, constants.size());
        assertNotNull(findConstantByName(constants, "NAME"));
        assertNotNull(findConstantByName(constants, "COUNT"));
        assertNotNull(findConstantByName(constants, "BIG_NUMBER"));
    }

    @Test
    void testCatalogsPublicStaticFinalFields() throws IOException {
        String javaCode = """
            package com.example;

            public class TestClass {
                public static final String PUBLIC_NAME = "test";
                public static final int PUBLIC_COUNT = 42;
                public static final long PUBLIC_BIG = 1000000L;
            }
            """;

        Path javaFile = tempDir.resolve("TestClass.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        assertEquals(3, constants.size());

        Constant nameConst = findConstantByName(constants, "PUBLIC_NAME");
        assertNotNull(nameConst);
        assertEquals("String", nameConst.type());
        assertEquals("\"test\"", nameConst.value());
        assertEquals("TestClass", nameConst.className());
        assertEquals("public", nameConst.accessModifier());
        assertFalse(nameConst.isEnum());
        assertNull(nameConst.enumClassName());

        Constant countConst = findConstantByName(constants, "PUBLIC_COUNT");
        assertNotNull(countConst);
        assertEquals("int", countConst.type());
        assertEquals("42", countConst.value());

        Constant bigConst = findConstantByName(constants, "PUBLIC_BIG");
        assertNotNull(bigConst);
        assertEquals("long", bigConst.type());
    }

    @Test
    void testCatalogsProtectedAndPackagePrivateStaticFinalFields() throws IOException {
        String javaCode = """
            package com.example;

            public class TestClass {
                protected static final String PROTECTED_CONST = "protected";
                static final String PACKAGE_CONST = "package";
            }
            """;

        Path javaFile = tempDir.resolve("TestClass.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        // All static final fields are cataloged regardless of access modifier
        assertEquals(2, constants.size());
        assertNotNull(findConstantByName(constants, "PROTECTED_CONST"));
        assertNotNull(findConstantByName(constants, "PACKAGE_CONST"));
    }

    @Test
    void testAllAccessModifiersCataloged() throws IOException {
        String javaCode = """
            package com.example;

            public class TestClass {
                public static final String PUBLIC_CONST = "public";
                protected static final String PROTECTED_CONST = "protected";
                static final String PACKAGE_CONST = "package";
                private static final String PRIVATE_CONST = "private";
            }
            """;

        Path javaFile = tempDir.resolve("TestClass.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        // All static final fields are cataloged regardless of access modifier
        assertEquals(4, constants.size());
        assertNotNull(findConstantByName(constants, "PUBLIC_CONST"));
        assertNotNull(findConstantByName(constants, "PROTECTED_CONST"));
        assertNotNull(findConstantByName(constants, "PACKAGE_CONST"));
        assertNotNull(findConstantByName(constants, "PRIVATE_CONST"));
    }

    @Test
    void testDoesNotCatalogEnumValues() throws IOException {
        String javaCode = """
            package com.example;

            public enum Color {
                RED,
                GREEN,
                BLUE
            }
            """;

        Path javaFile = tempDir.resolve("Color.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        // Enum values are not static final fields; they are not cataloged
        assertEquals(0, constants.size());
    }

    @Test
    void testDoesNotCatalogEnumValuesWithArguments() throws IOException {
        String javaCode = """
            package com.example;

            public enum Planet {
                MERCURY(3.303e+23, 2.4397e6),
                VENUS(4.869e+24, 6.0518e6),
                EARTH(5.976e+24, 6.37814e6);

                private final double mass;
                private final double radius;

                Planet(double mass, double radius) {
                    this.mass = mass;
                    this.radius = radius;
                }
            }
            """;

        Path javaFile = tempDir.resolve("Planet.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        // Enum values are not cataloged; private final instance fields are also not static
        assertEquals(0, constants.size());
    }

    @Test
    void testIgnoreNonConstants() throws IOException {
        String javaCode = """
            package com.example;

            public class TestClass {
                public static final String CONSTANT = "const";

                // Not constants:
                private static String notFinal = "mutable";
                private final String notStatic = "instance";
                private String regularField;
            }
            """;

        Path javaFile = tempDir.resolve("TestClass.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        assertEquals(1, constants.size());
        assertEquals("CONSTANT", constants.get(0).name());
    }

    @Test
    void testParseInnerClassConstants() throws IOException {
        String javaCode = """
            package com.example;

            public class OuterClass {
                public static final String OUTER = "outer";

                public static class InnerClass {
                    public static final String INNER = "inner";
                }
            }
            """;

        Path javaFile = tempDir.resolve("OuterClass.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        assertEquals(2, constants.size());

        Constant outerConst = findConstantByName(constants, "OUTER");
        assertNotNull(outerConst);
        assertEquals("OuterClass", outerConst.className());

        Constant innerConst = findConstantByName(constants, "INNER");
        assertNotNull(innerConst);
        assertEquals("InnerClass", innerConst.className());
    }

    @Test
    void testParseParameterUsages() throws IOException {
        String javaCode = """
            package com.example;

            public class ConfigUser {
                public void loadConfig(Properties props) {
                    String host = props.getProperty("database.host");
                    String port = props.getProperty("database.port");
                    String unknown = props.getProperty("unknown.param");
                }
            }
            """;

        Path javaFile = tempDir.resolve("ConfigUser.java");
        Files.writeString(javaFile, javaCode);

        Set<String> knownParams = Set.of("database.host", "database.port");
        List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

        assertEquals(2, usages.size());

        ParameterUsage hostUsage = usages.stream()
            .filter(u -> u.parameterName().equals("database.host"))
            .findFirst()
            .orElse(null);
        assertNotNull(hostUsage);
        assertEquals("ConfigUser", hostUsage.usedInClass());
    }

    @Test
    void testParseEmptyFile() throws IOException {
        Path javaFile = tempDir.resolve("Empty.java");
        Files.writeString(javaFile, "");

        List<Constant> constants = parser.parseConstants(javaFile);
        assertTrue(constants.isEmpty());
    }

    @Test
    void testParseInvalidJavaFile() throws IOException {
        Path javaFile = tempDir.resolve("Invalid.java");
        Files.writeString(javaFile, "this is not valid java code { } }");

        List<Constant> constants = parser.parseConstants(javaFile);
        // Should return empty list instead of throwing
        assertTrue(constants.isEmpty());
    }

    @Test
    void testParseConstantWithComplexInitializer() throws IOException {
        String javaCode = """
            package com.example;

            public class TestClass {
                public static final String COMPLEX = "part1" + "part2";
                public static final List<String> LIST = Arrays.asList("a", "b", "c");
                public static final Map<String, Integer> MAP = new HashMap<>();
            }
            """;

        Path javaFile = tempDir.resolve("TestClass.java");
        Files.writeString(javaFile, javaCode);

        List<Constant> constants = parser.parseConstants(javaFile);

        assertEquals(3, constants.size());
        assertNotNull(findConstantByName(constants, "COMPLEX"));
        assertNotNull(findConstantByName(constants, "LIST"));
        assertNotNull(findConstantByName(constants, "MAP"));
    }

    private Constant findConstantByName(List<Constant> constants, String name) {
        return constants.stream()
            .filter(c -> c.name().equals(name))
            .findFirst()
            .orElse(null);
    }
}
