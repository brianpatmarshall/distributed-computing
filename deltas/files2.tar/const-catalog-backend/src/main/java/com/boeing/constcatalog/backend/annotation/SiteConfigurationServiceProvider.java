package com.boeing.constcatalog.backend.annotation;

import com.boeing.constcatalog.backend.service.SiteConfigurationService;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Static provider for SiteConfigurationService, enabling Lombok-style injection.
 *
 * This class bridges Spring's dependency injection with static access,
 * allowing the @SiteConfig annotation to provide a static 'config' field
 * similar to how @Slf4j provides a static 'log' field.
 *
 * <p>The provider is automatically initialized when the Spring context starts.
 * Once initialized, SiteConfigurationService can be accessed statically:</p>
 *
 * <pre>{@code
 * String host = SiteConfigurationServiceProvider.get().lookup("smtp.host");
 * }</pre>
 *
 * <p>However, the preferred usage is via the @SiteConfig annotation:</p>
 *
 * <pre>{@code
 * @SiteConfig
 * public class EmailService {
 *     public void sendEmail() {
 *         String host = config.lookup("smtp.host");  // 'config' is auto-generated
 *     }
 * }
 * }</pre>
 *
 * <p><strong>Thread Safety:</strong> The provider uses volatile with double-checked
 * locking to ensure safe publication across threads.</p>
 *
 * <p><strong>Lifecycle:</strong> The service reference is set during Spring
 * context initialization via @PostConstruct and cleared during shutdown.</p>
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class SiteConfigurationServiceProvider {

    private static volatile SiteConfigurationService instance;

    private final SiteConfigurationService siteConfigurationService;

    /**
     * Initializes the static provider with the Spring-managed service instance.
     * Called automatically when the Spring context initializes this bean.
     *
     * <p>May also be called explicitly in tests where multiple Spring contexts exist
     * in the same JVM, to re-anchor the static reference to the current context's bean
     * before asserting instance identity.</p>
     */
    @PostConstruct
    public void initialize() {
        instance = siteConfigurationService;
        log.info("SiteConfigurationServiceProvider initialized - @SiteConfig annotation is now available");
    }

    /**
     * Returns the SiteConfigurationService instance.
     *
     * @return the service instance
     * @throws IllegalStateException if called before Spring context initialization
     */
    public static SiteConfigurationService get() {
        SiteConfigurationService service = instance;
        if (service == null) {
            throw new IllegalStateException(
                "SiteConfigurationService not yet initialized. " +
                "Ensure Spring context is fully loaded before accessing configuration. " +
                "This typically happens when accessing config during static initialization."
            );
        }
        return service;
    }

    /**
     * Checks if the provider has been initialized.
     *
     * @return true if the service is available
     */
    public static boolean isInitialized() {
        return instance != null;
    }

    /**
     * Returns the service or null if not yet initialized.
     * Useful for optional configuration access during startup.
     *
     * @return the service instance or null
     */
    public static SiteConfigurationService getOrNull() {
        return instance;
    }
}
