package com.boeing.constcatalog.backend;

import com.boeing.constcatalog.backend.annotation.SiteConfigurationServiceProvider;
import com.boeing.constcatalog.backend.service.SiteConfigurationService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;
import java.util.Map;

import static com.boeing.constcatalog.backend.Config.*;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for the static Config class providing @Slf4j-like access pattern.
 */
@SpringBootTest
@Import({Neo4jTestConfiguration.class, ValKeyTestConfiguration.class})
@ActiveProfiles("test")
class ConfigStaticAccessTest {

    @Autowired
    private SiteConfigurationService configService;

    @Autowired
    private SiteConfigurationServiceProvider provider;

    @BeforeEach
    void setUp() {
        // Re-anchor the static reference to this context's bean.
        // When multiple Spring contexts co-exist in the same JVM test run,
        // another context may have overwritten the static field; this corrects it.
        provider.initialize();
        configService.store("test.key", "test-value");
        configService.store("test.port", "8080");
        configService.store("test.enabled", "true");
        configService.store("test.rate", "3.14");
    }

    @AfterEach
    void tearDown() {
        configService.delete("test.key");
        configService.delete("test.port");
        configService.delete("test.enabled");
        configService.delete("test.rate");
        configService.delete("test.batch1");
        configService.delete("test.batch2");
    }

    @Nested
    @DisplayName("config() Method Pattern")
    class ConfigMethodPattern {

        @Test
        @DisplayName("config() should return the service instance")
        void configShouldReturnServiceInstance() {
            SiteConfigurationService service = config();

            assertThat(service).isNotNull();
            assertThat(service).isSameAs(configService);
        }

        @Test
        @DisplayName("config().lookup() should work like log.info()")
        void configLookupShouldWorkLikeLogInfo() {
            String value = config().lookup("test.key");

            assertThat(value).isEqualTo("test-value");
        }

        @Test
        @DisplayName("config() should support all lookup methods")
        void configShouldSupportAllLookupMethods() {
            assertThat(config().lookup("test.key")).isEqualTo("test-value");
            assertThat(config().lookupInt("test.port", 0)).isEqualTo(8080);
            assertThat(config().lookupBoolean("test.enabled", false)).isTrue();
            assertThat(config().lookupDouble("test.rate", 0.0)).isEqualTo(3.14);
        }
    }

    @Nested
    @DisplayName("Direct Static Method Pattern")
    class DirectStaticMethodPattern {

        @Test
        @DisplayName("lookup() static method should work directly")
        void lookupStaticMethodShouldWorkDirectly() {
            String value = lookup("test.key");

            assertThat(value).isEqualTo("test-value");
        }

        @Test
        @DisplayName("lookup() with default should work")
        void lookupWithDefaultShouldWork() {
            String value = lookup("nonexistent", "default");

            assertThat(value).isEqualTo("default");
        }

        @Test
        @DisplayName("lookupInt() static method should work")
        void lookupIntStaticMethodShouldWork() {
            int port = lookupInt("test.port", 0);

            assertThat(port).isEqualTo(8080);
        }

        @Test
        @DisplayName("lookupBoolean() static method should work")
        void lookupBooleanStaticMethodShouldWork() {
            boolean enabled = lookupBoolean("test.enabled", false);

            assertThat(enabled).isTrue();
        }

        @Test
        @DisplayName("lookupDouble() static method should work")
        void lookupDoubleStaticMethodShouldWork() {
            double rate = lookupDouble("test.rate", 0.0);

            assertThat(rate).isEqualTo(3.14);
        }

        @Test
        @DisplayName("lookupLong() static method should work")
        void lookupLongStaticMethodShouldWork() {
            configService.store("test.longval", "9999999999");

            long value = lookupLong("test.longval", 0L);

            assertThat(value).isEqualTo(9999999999L);

            configService.delete("test.longval");
        }

        @Test
        @DisplayName("lookup() with transformer should work")
        void lookupWithTransformerShouldWork() {
            configService.store("test.list", "a,b,c");

            List<String> list = lookup("test.list",
                value -> List.of(value.split(",")),
                List.of());

            assertThat(list).containsExactly("a", "b", "c");

            configService.delete("test.list");
        }
    }

    @Nested
    @DisplayName("Batch Operations")
    class BatchOperations {

        @Test
        @DisplayName("lookupBatch() should return multiple values")
        void lookupBatchShouldReturnMultipleValues() {
            Map<String, String> values = lookupBatch(List.of(
                "test.key",
                "test.port",
                "nonexistent"
            ));

            assertThat(values)
                .containsEntry("test.key", "test-value")
                .containsEntry("test.port", "8080")
                .containsEntry("nonexistent", null);
        }

        @Test
        @DisplayName("lookupByPrefix() should return matching keys")
        void lookupByPrefixShouldReturnMatchingKeys() {
            Map<String, String> values = lookupByPrefix("test.");

            assertThat(values).hasSize(4);
            assertThat(values).containsEntry("test.key", "test-value");
        }
    }

    @Nested
    @DisplayName("Write Operations")
    class WriteOperations {

        @Test
        @DisplayName("store() static method should work")
        void storeStaticMethodShouldWork() {
            store("test.batch1", "value1");

            assertThat(lookup("test.batch1")).isEqualTo("value1");
        }

        @Test
        @DisplayName("storeBatch() static method should work")
        void storeBatchStaticMethodShouldWork() {
            storeBatch(Map.of(
                "test.batch1", "val1",
                "test.batch2", "val2"
            ));

            assertThat(lookup("test.batch1")).isEqualTo("val1");
            assertThat(lookup("test.batch2")).isEqualTo("val2");
        }

        @Test
        @DisplayName("delete() static method should work")
        void deleteStaticMethodShouldWork() {
            store("test.todelete", "value");
            assertThat(lookup("test.todelete")).isNotNull();

            boolean deleted = delete("test.todelete");

            assertThat(deleted).isTrue();
            assertThat(lookup("test.todelete")).isNull();
        }
    }

    @Nested
    @DisplayName("Thread Safety")
    class ThreadSafety {

        @Test
        @DisplayName("should be thread-safe for concurrent lookups")
        void shouldBeThreadSafeForConcurrentLookups() throws InterruptedException {
            int threadCount = 10;
            Thread[] threads = new Thread[threadCount];
            boolean[] results = new boolean[threadCount];

            for (int i = 0; i < threadCount; i++) {
                final int index = i;
                threads[i] = new Thread(() -> {
                    try {
                        results[index] = "test-value".equals(lookup("test.key"));
                    } catch (Exception e) {
                        results[index] = false;
                    }
                });
            }

            for (Thread thread : threads) {
                thread.start();
            }

            for (Thread thread : threads) {
                thread.join();
            }

            for (boolean result : results) {
                assertThat(result).isTrue();
            }
        }
    }
}
