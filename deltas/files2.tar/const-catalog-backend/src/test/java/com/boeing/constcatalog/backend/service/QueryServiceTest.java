package com.boeing.constcatalog.backend.service;

import com.boeing.constcatalog.backend.Neo4jTestConfiguration;
import com.boeing.constcatalog.backend.dto.PreCannedQuery;
import com.boeing.constcatalog.backend.dto.QueryRequest;
import com.boeing.constcatalog.backend.dto.QueryResponse;
import com.boeing.constcatalog.backend.entity.ConstantNode;
import com.boeing.constcatalog.backend.entity.FileNode;
import com.boeing.constcatalog.backend.entity.ParameterNode;
import com.boeing.constcatalog.backend.repository.ConstantRepository;
import com.boeing.constcatalog.backend.repository.FileRepository;
import com.boeing.constcatalog.backend.repository.ParameterRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import static org.assertj.core.api.Assertions.assertThat;

/*
 * Integration tests for QueryService.
 *
 * The QueryService is the interface between user queries and the graph.
 * It provides two modes: pre-canned queries for common analysis patterns,
 * and ad-hoc Cypher execution for power users.
 *
 * These tests verify:
 * - Pre-canned queries return correct results
 * - Ad-hoc queries execute correctly
 * - Write operations are blocked
 * - Result formatting is correct
 */
@SpringBootTest
@Import(Neo4jTestConfiguration.class)
@ActiveProfiles("test")
class QueryServiceTest {

    @Autowired
    private QueryService queryService;

    @Autowired
    private ConstantRepository constantRepository;

    @Autowired
    private ParameterRepository parameterRepository;

    @Autowired
    private FileRepository fileRepository;

    private FileNode configFile;

    private FileNode serviceFile;

    @BeforeEach
    void setUp() {
        parameterRepository.deleteAll();
        constantRepository.deleteAll();
        fileRepository.deleteAll();
        configFile = fileRepository.save(FileNode.builder().path("/src/main/java/Config.java").fileName("Config.java").fileType("JAVA").build());
        serviceFile = fileRepository.save(FileNode.builder().path("/src/main/java/Service.java").fileName("Service.java").fileType("JAVA").build());
    }

    @Nested
    @DisplayName("Pre-Canned Query Management")
    class PreCannedQueryManagement {

        @Test
        @DisplayName("should return all pre-canned queries")
        void shouldReturnAllPreCannedQueries() {
            List<PreCannedQuery> queries = queryService.getPreCannedQueries();
            assertThat(queries).isNotEmpty();
            assertThat(queries).extracting(PreCannedQuery::getId).contains("all-constants", "all-parameters", "config-candidates", "unused-parameters", "cross-file-params", "duplicate-values");
        }

        @Test
        @DisplayName("should find pre-canned query by ID")
        void shouldFindPreCannedQueryById() {
            Optional<PreCannedQuery> query = queryService.getPreCannedQueryById("all-constants");
            assertThat(query).isPresent();
            assertThat(query.get().getName()).isEqualTo("All Constants");
            assertThat(query.get().getCategory()).isEqualTo("EXPLORATION");
        }

        @Test
        @DisplayName("should return empty for unknown query ID")
        void shouldReturnEmptyForUnknownId() {
            Optional<PreCannedQuery> query = queryService.getPreCannedQueryById("nonexistent");
            assertThat(query).isEmpty();
        }

        @Test
        @DisplayName("should have queries in all categories")
        void shouldHaveQueriesInAllCategories() {
            List<PreCannedQuery> queries = queryService.getPreCannedQueries();
            assertThat(queries).extracting(PreCannedQuery::getCategory).contains("EXPLORATION", "ANALYSIS", "SECURITY", "ORGANIZATION");
        }
    }

    @Nested
    @DisplayName("Pre-Canned Query Execution")
    class PreCannedQueryExecution {

        @BeforeEach
        void setUpData() {
            constantRepository.save(ConstantNode.builder().name("DATABASE_HOST").type("String").value("localhost").className("Config").lineNumber(10).definedIn(configFile).build());
            constantRepository.save(ConstantNode.builder().name("MAX_SIZE").type("int").value("100").className("Utils").lineNumber(5).definedIn(serviceFile).build());
        }

        @Test
        @DisplayName("should execute all-constants query")
        void shouldExecuteAllConstantsQuery() {
            QueryResponse response = queryService.executePreCannedQuery("all-constants");
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isEqualTo(2);
            assertThat(response.getColumns()).contains("name", "type", "value");
        }

        @Test
        @DisplayName("should execute config-candidates query")
        void shouldExecuteConfigCandidatesQuery() {
            QueryResponse response = queryService.executePreCannedQuery("config-candidates");
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isEqualTo(1);
            assertThat(response.getRows().get(0).get("name")).isEqualTo("DATABASE_HOST");
        }

        @Test
        @DisplayName("should return error for unknown query ID")
        void shouldReturnErrorForUnknownQueryId() {
            QueryResponse response = queryService.executePreCannedQuery("unknown-query");
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).contains("Unknown query ID");
        }
    }

    @Nested
    @DisplayName("Ad-Hoc Query Execution")
    class AdHocQueryExecution {

        @BeforeEach
        void setUpData() {
            constantRepository.save(ConstantNode.builder().name("TEST_CONSTANT").type("String").value("test-value").className("TestClass").lineNumber(1).definedIn(configFile).build());
        }

        @Test
        @DisplayName("should execute simple MATCH query")
        void shouldExecuteSimpleMatchQuery() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) RETURN c.name as name").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isGreaterThanOrEqualTo(1);
            assertThat(response.getColumns()).contains("name");
        }

        @Test
        @DisplayName("should execute query with WHERE clause")
        void shouldExecuteQueryWithWhereClause() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) WHERE c.name = 'TEST_CONSTANT' RETURN c.value as value").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isEqualTo(1);
            assertThat(response.getRows().get(0).get("value")).isEqualTo("test-value");
        }

        @Test
        @DisplayName("should execute query with aggregation")
        void shouldExecuteQueryWithAggregation() {
            constantRepository.save(ConstantNode.builder().name("ANOTHER_CONSTANT").type("String").value("another").className("TestClass").lineNumber(2).definedIn(configFile).build());
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) RETURN count(c) as total").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isEqualTo(1);
            assertThat(((Number) response.getRows().get(0).get("total")).intValue()).isGreaterThanOrEqualTo(2);
        }

        @Test
        @DisplayName("should return empty result for no matches")
        void shouldReturnEmptyResultForNoMatches() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) WHERE c.name = 'NONEXISTENT' RETURN c").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isZero();
        }

        @Test
        @DisplayName("should handle query with relationship traversal")
        void shouldHandleRelationshipTraversal() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant)-[:DEFINED_IN]->(f:File) RETURN c.name as constant, f.fileName as file").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getColumns()).containsExactlyInAnyOrder("constant", "file");
        }
    }

    @Nested
    @DisplayName("Write Query Prevention")
    class WriteQueryPrevention {

        @Test
        @DisplayName("should block CREATE queries")
        void shouldBlockCreateQueries() {
            QueryRequest request = QueryRequest.builder().cypher("CREATE (n:Malicious {name: 'bad'})").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).contains("read queries");
        }

        @Test
        @DisplayName("should block DELETE queries")
        void shouldBlockDeleteQueries() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) DELETE c").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).contains("read queries");
        }

        @Test
        @DisplayName("should block SET queries")
        void shouldBlockSetQueries() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) SET c.name = 'modified'").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).contains("read queries");
        }

        @Test
        @DisplayName("should block MERGE queries")
        void shouldBlockMergeQueries() {
            QueryRequest request = QueryRequest.builder().cypher("MERGE (n:NewNode {name: 'created'})").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).contains("read queries");
        }

        @Test
        @DisplayName("should block DROP queries")
        void shouldBlockDropQueries() {
            QueryRequest request = QueryRequest.builder().cypher("DROP INDEX ON :Constant(name)").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).contains("read queries");
        }

        @Test
        @DisplayName("should block REMOVE queries")
        void shouldBlockRemoveQueries() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) REMOVE c.name").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).contains("read queries");
        }
    }

    @Nested
    @DisplayName("Error Handling")
    class ErrorHandling {

        @Test
        @DisplayName("should handle syntax errors gracefully")
        void shouldHandleSyntaxErrors() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant RETURN c").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isFalse();
            assertThat(response.getError()).isNotNull();
        }

        @Test
        @DisplayName("should handle unknown labels")
        void shouldHandleUnknownLabels() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (x:NonExistentLabel) RETURN x").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isZero();
        }
    }

    @Nested
    @DisplayName("Result Formatting")
    class ResultFormatting {

        @BeforeEach
        void setUpData() {
            constantRepository.save(ConstantNode.builder().name("FORMAT_TEST").type("String").value("test-value").className("TestClass").lineNumber(1).definedIn(configFile).build());
        }

        @Test
        @DisplayName("should format string values correctly")
        void shouldFormatStringValues() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) WHERE c.name = 'FORMAT_TEST' RETURN c.value as value").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRows().get(0).get("value")).isInstanceOf(String.class);
        }

        @Test
        @DisplayName("should format numeric values correctly")
        void shouldFormatNumericValues() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) WHERE c.name = 'FORMAT_TEST' RETURN c.lineNumber as line").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            Object lineValue = response.getRows().get(0).get("line");
            assertThat(lineValue).isInstanceOfAny(Integer.class, Long.class);
        }

        @Test
        @DisplayName("should format list values correctly")
        void shouldFormatListValues() {
            constantRepository.save(ConstantNode.builder().name("LIST_TEST_1").type("String").value("value1").className("TestClass").lineNumber(2).definedIn(configFile).build());
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) WHERE c.name STARTS WITH 'FORMAT_TEST' OR c.name STARTS WITH 'LIST_TEST' RETURN collect(c.name) as names").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRows().get(0).get("names")).isInstanceOf(List.class);
        }

        @Test
        @DisplayName("should handle null values")
        void shouldHandleNullValues() {
            QueryRequest request = QueryRequest.builder().cypher("MATCH (c:Constant) WHERE c.name = 'FORMAT_TEST' RETURN c.nonexistent as missing").build();
            QueryResponse response = queryService.executeQuery(request);
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRows().get(0).get("missing")).isNull();
        }
    }

    @Nested
    @DisplayName("Pre-Canned Query Results")
    class PreCannedQueryResults {

        @BeforeEach
        void setUpComplexData() {
            FileNode propertiesFile = fileRepository.save(FileNode.builder().path("/src/main/resources/app.properties").fileName("app.properties").fileType("PROPERTIES").build());
            constantRepository.save(ConstantNode.builder().name("API_URL").type("String").value("http://api.example.com").className("Config").lineNumber(10).definedIn(configFile).build());
            constantRepository.save(ConstantNode.builder().name("DB_DUPLICATE").type("String").value("duplicate-value").className("DatabaseConfig").lineNumber(5).definedIn(configFile).build());
            constantRepository.save(ConstantNode.builder().name("CACHE_DUPLICATE").type("String").value("duplicate-value").className("CacheConfig").lineNumber(10).definedIn(serviceFile).build());
            parameterRepository.save(ParameterNode.builder().name("db.password").value("secret123").lineNumber(1).definedIn(propertiesFile).usages(new HashSet<>()).build());
            parameterRepository.save(ParameterNode.builder().name("unused.param").value("unused-value").lineNumber(2).definedIn(propertiesFile).usages(new HashSet<>()).build());
        }

        @Test
        @DisplayName("should find duplicate values")
        void shouldFindDuplicateValues() {
            QueryResponse response = queryService.executePreCannedQuery("duplicate-values");
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRowCount()).isGreaterThanOrEqualTo(1);
        }

        @Test
        @DisplayName("should find connection strings")
        void shouldFindConnectionStrings() {
            QueryResponse response = queryService.executePreCannedQuery("connection-strings");
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRows()).anyMatch(row -> "API_URL".equals(row.get("name")));
        }

        @Test
        @DisplayName("should find sensitive parameters")
        void shouldFindSensitiveParameters() {
            QueryResponse response = queryService.executePreCannedQuery("sensitive-params");
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRows()).anyMatch(row -> "db.password".equals(row.get("name")));
        }

        @Test
        @DisplayName("should find unused parameters")
        void shouldFindUnusedParameters() {
            QueryResponse response = queryService.executePreCannedQuery("unused-parameters");
            assertThat(response.isSuccess()).isTrue();
            assertThat(response.getRows()).anyMatch(row -> "unused.param".equals(row.get("name")));
        }
    }
}
