package com.boeing.constcatalog.backend.annotation;

import com.boeing.constcatalog.backend.Neo4jTestConfiguration;
import com.boeing.constcatalog.backend.ValKeyTestConfiguration;
import com.boeing.constcatalog.backend.service.SiteConfigurationService;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Integration tests for SiteConfigurationServiceProvider.
 *
 * Tests the static provider that makes SiteConfigurationService available
 * for static access patterns.
 */
@SpringBootTest
@Import({Neo4jTestConfiguration.class, ValKeyTestConfiguration.class})
@ActiveProfiles("test")
class SiteConfigurationServiceProviderTest {

    @Autowired
    private SiteConfigurationService configService;

    @Autowired
    private SiteConfigurationServiceProvider provider;

    @BeforeEach
    void setUp() {
        // Re-anchor the static reference to this context's bean.
        // When multiple Spring contexts co-exist in the same JVM test run,
        // another context may have overwritten the static field; this corrects it.
        provider.initialize();
        configService.store("provider.test", "test-value");
    }

    @AfterEach
    void tearDown() {
        configService.delete("provider.test");
    }

    @Nested
    @DisplayName("Initialization")
    class Initialization {

        @Test
        @DisplayName("should be initialized after Spring context loads")
        void shouldBeInitializedAfterSpringContextLoads() {
            assertThat(SiteConfigurationServiceProvider.isInitialized()).isTrue();
        }

        @Test
        @DisplayName("get() should return the service instance")
        void getShouldReturnServiceInstance() {
            SiteConfigurationService service = SiteConfigurationServiceProvider.get();

            assertThat(service).isNotNull();
            assertThat(service).isSameAs(configService);
        }

        @Test
        @DisplayName("getOrNull() should return the service instance when initialized")
        void getOrNullShouldReturnServiceInstanceWhenInitialized() {
            SiteConfigurationService service = SiteConfigurationServiceProvider.getOrNull();

            assertThat(service).isNotNull();
            assertThat(service).isSameAs(configService);
        }
    }

    @Nested
    @DisplayName("Service Operations via Provider")
    class ServiceOperationsViaProvider {

        @Test
        @DisplayName("should lookup values via provider")
        void shouldLookupValuesViaProvider() {
            SiteConfigurationService service = SiteConfigurationServiceProvider.get();

            String value = service.lookup("provider.test");

            assertThat(value).isEqualTo("test-value");
        }

        @Test
        @DisplayName("should store values via provider")
        void shouldStoreValuesViaProvider() {
            SiteConfigurationService service = SiteConfigurationServiceProvider.get();

            service.store("provider.new", "new-value");

            assertThat(service.lookup("provider.new")).isEqualTo("new-value");

            service.delete("provider.new");
        }

        @Test
        @DisplayName("should support all lookup operations via provider")
        void shouldSupportAllLookupOperationsViaProvider() {
            SiteConfigurationService service = SiteConfigurationServiceProvider.get();

            service.store("provider.int", "42");
            service.store("provider.bool", "true");
            service.store("provider.double", "3.14");

            assertThat(service.lookupInt("provider.int", 0)).isEqualTo(42);
            assertThat(service.lookupBoolean("provider.bool", false)).isTrue();
            assertThat(service.lookupDouble("provider.double", 0.0)).isEqualTo(3.14);

            service.delete("provider.int");
            service.delete("provider.bool");
            service.delete("provider.double");
        }
    }

    @Nested
    @DisplayName("Thread Safety")
    class ThreadSafety {

        @Test
        @DisplayName("should be thread-safe for concurrent access")
        void shouldBeThreadSafeForConcurrentAccess() throws InterruptedException {
            int threadCount = 10;
            Thread[] threads = new Thread[threadCount];
            boolean[] results = new boolean[threadCount];

            for (int i = 0; i < threadCount; i++) {
                final int index = i;
                threads[i] = new Thread(() -> {
                    try {
                        SiteConfigurationService service = SiteConfigurationServiceProvider.get();
                        results[index] = service != null && "test-value".equals(service.lookup("provider.test"));
                    } catch (Exception e) {
                        results[index] = false;
                    }
                });
            }

            for (Thread thread : threads) {
                thread.start();
            }

            for (Thread thread : threads) {
                thread.join();
            }

            for (boolean result : results) {
                assertThat(result).isTrue();
            }
        }
    }
}
