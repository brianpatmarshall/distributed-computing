package com.boeing.constcatalog.backend.service;

import com.boeing.constcatalog.backend.store.ConfigStore;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * SiteConfigurationService provides centralized configuration management with
 * a two-tier caching strategy:
 *
 * Tier 1: Caffeine (Local, In-Memory)
 *   - Sub-millisecond lookups
 *   - No network overhead
 *   - Invalidated via ValKey pub/sub
 *
 * Tier 2: ValKey (Distributed, Persistent)
 *   - Shared across all application instances
 *   - Pub/sub for change propagation
 *   - Survives application restarts
 *
 * Usage Example (replacing hardcoded values):
 *
 *   BEFORE:
 *     String host = "mail.yahoo.com";
 *   AFTER:
 *     String host = siteConfigurationService.lookup("mail.host");
 * The service supports:
 * - Type-safe lookups with default values
 * - Batch operations for efficiency
 * - Cache statistics for monitoring
 * - Automatic cache invalidation on changes
 *
 * Architecture follows the Cache-Aside pattern with pub/sub notifications:
 *
 *   lookup("key")
 *        │
 *        ▼
 *   ┌─────────────┐    miss     ┌─────────────┐
 *   │  Caffeine   │────────────▶│   ValKey    │
 *   │   Cache     │◀────────────│   (Redis)   │
 *   └─────────────┘    value    └─────────────┘
 *        │
 *        ▼
 *      return
 *
 *   update("key", "value")
 *        │
 *        ├─────────────────────▶ ValKey.SET
 *        │
 *        └─────────────────────▶ ValKey.PUBLISH("config:changes", "key")
 *                                       │
 *              ┌────────────────────────┼────────────────────────┐
 *              │                        │                        │
 *              ▼                        ▼                        ▼
 *        ┌─────────────┐          ┌─────────────┐          ┌─────────────┐
 *        │ Instance 1  │          │ Instance 2  │          │ Instance N  │
 *        │  Caffeine   │          │  Caffeine   │          │  Caffeine   │
 *        │ INVALIDATE  │          │ INVALIDATE  │          │ INVALIDATE  │
 *        └─────────────┘          └─────────────┘          └─────────────┘
 */
@Service
@Slf4j
public class SiteConfigurationService {

    private final ConfigStore configStore;
    private final Caffeine<Object, Object> caffeineBuilder;

    public SiteConfigurationService(
            ConfigStore configStore,
            Caffeine<Object, Object> caffeineBuilder) {
        this.configStore = configStore;
        this.caffeineBuilder = caffeineBuilder;
    }

    private Cache<String, String> localCache;

    /**
     * Sentinel value for caching null/missing values to prevent repeated lookups.
     */
    private static final String NULL_SENTINEL = "\0__NULL__\0";

    @PostConstruct
    void initialize() {
        this.localCache = caffeineBuilder.build();
        log.info("SiteConfigurationService initialized with Caffeine cache and {} backend", configStore.storeName());
    }

    /* ========================================================================
     * Primary Lookup Methods
     * ========================================================================
     */
    /**
     * Looks up a configuration value by key.
     * This method implements the cache-aside pattern:
     * 1. Check Caffeine (local cache)
     * 2. On miss, fetch from ValKey
     * 3. Populate local cache on hit
     *
     * @param key the configuration key
     * @return the value, or null if not found
     */
    public String lookup(String key) {
        Objects.requireNonNull(key, "Configuration key cannot be null");

        return Optional.ofNullable(localCache.get(key, this::fetchFromStore))
            .filter(v -> !NULL_SENTINEL.equals(v))
            .orElse(null);
    }

    /**
     * Looks up a configuration value with a default fallback.
     *
     * @param key the configuration key
     * @param defaultValue the value to return if key is not found
     * @return the configured value or the default
     */
    public String lookup(String key, String defaultValue) {
        return Optional.ofNullable(lookup(key)).orElse(defaultValue);
    }

    /**
     * Looks up a configuration value with lazy default computation.
     *
     * @param key the configuration key
     * @param defaultSupplier supplier for the default value (called only if needed)
     * @return the configured value or the computed default
     */
    public String lookup(String key, Supplier<String> defaultSupplier) {
        return Optional.ofNullable(lookup(key)).orElseGet(defaultSupplier);
    }

    // ========================================================================
    // Type-Safe Lookup Methods (using Java 21 pattern matching)
    // ========================================================================

    /**
     * Looks up an integer configuration value.
     *
     * @param key the configuration key
     * @param defaultValue fallback if not found or not parseable
     * @return the integer value
     */
    public int lookupInt(String key, int defaultValue) {
        return Optional.ofNullable(lookup(key))
            .map(this::parseIntSafely)
            .orElse(defaultValue);
    }

    /**
     * Looks up a long configuration value.
     */
    public long lookupLong(String key, long defaultValue) {
        return Optional.ofNullable(lookup(key))
            .map(this::parseLongSafely)
            .orElse(defaultValue);
    }

    /**
     * Looks up a boolean configuration value.
     * Recognizes: true/false, yes/no, 1/0, on/off
     */
    public boolean lookupBoolean(String key, boolean defaultValue) {
        return Optional.ofNullable(lookup(key))
            .map(this::parseBooleanSafely)
            .orElse(defaultValue);
    }

    /**
     * Looks up a double configuration value.
     */
    public double lookupDouble(String key, double defaultValue) {
        return Optional.ofNullable(lookup(key))
            .map(this::parseDoubleSafely)
            .orElse(defaultValue);
    }

    /**
     * Looks up a configuration value and transforms it.
     *
     * @param key the configuration key
     * @param transformer function to transform the string value
     * @param defaultValue fallback if not found or transformation fails
     * @return the transformed value
     */
    public <T> T lookup(String key, Function<String, T> transformer, T defaultValue) {
        try {
            return Optional.ofNullable(lookup(key))
                .map(transformer)
                .orElse(defaultValue);
        } catch (Exception e) {
            log.warn("Failed to transform config value for key '{}': {}", key, e.getMessage());
            return defaultValue;
        }
    }

    // ========================================================================
    // Batch Operations
    // ========================================================================

    /**
     * Looks up multiple configuration values at once.
     * More efficient than individual lookups for bulk operations.
     *
     * @param keys the configuration keys
     * @return map of key to value (missing keys have null values)
     */
    public Map<String, String> lookupBatch(List<String> keys) {
        Map<String, String> result = new java.util.HashMap<>();
        for (String key : keys) {
            result.put(key, lookup(key));
        }
        return result;
    }

    /**
     * Looks up all configuration values matching a prefix.
     *
     * @param prefix the key prefix to match
     * @return map of matching keys to their values
     */
    public Map<String, String> lookupByPrefix(String prefix) {
        return configStore.getByPrefix(prefix);
    }

    // ========================================================================
    // Write Operations
    // ========================================================================

    /**
     * Stores a configuration value and notifies all instances.
     *
     * @param key the configuration key
     * @param value the value to store
     */
    public void store(String key, String value) {
        Objects.requireNonNull(key, "Configuration key cannot be null");

        configStore.set(key, value);
        configStore.publishChange(key);

        // Immediately update local cache
        localCache.put(key, value != null ? value : NULL_SENTINEL);

        log.debug("Stored configuration: {} = {}", key, maskSensitiveValue(key, value));
    }

    /**
     * Stores multiple configuration values in a batch.
     *
     * @param entries map of key-value pairs to store
     */
    public void storeBatch(Map<String, String> entries) {
        configStore.setBatch(entries);

        // Publish changes and update local cache
        entries.forEach((key, value) -> {
            configStore.publishChange(key);
            localCache.put(key, value != null ? value : NULL_SENTINEL);
        });

        log.info("Batch stored {} configuration entries", entries.size());
    }

    /**
     * Deletes a configuration value.
     *
     * @param key the configuration key to delete
     * @return true if the key existed and was deleted
     */
    public boolean delete(String key) {
        boolean deleted = configStore.delete(key);

        if (deleted) {
            configStore.publishChange(key);
            localCache.invalidate(key);
            log.debug("Deleted configuration: {}", key);
        }

        return deleted;
    }

    // ========================================================================
    // Cache Management
    // ========================================================================

    /**
     * Invalidates a specific key in the local cache.
     * Called by the ConfigurationChangeListener on pub/sub messages.
     *
     * @param key the key to invalidate
     */
    public void invalidateLocal(String key) {
        localCache.invalidate(key);
        log.trace("Invalidated local cache for key: {}", key);
    }

    /**
     * Invalidates all entries in the local cache.
     * Use sparingly as this forces re-fetching all values.
     */
    public void invalidateAll() {
        localCache.invalidateAll();
        log.info("Invalidated entire local cache");
    }

    /**
     * Returns the name of the active config store backend (e.g., "ValKey", "MongoDB").
     */
    public String getStoreName() {
        return configStore.storeName();
    }

    /**
     * Returns cache statistics for monitoring.
     */
    public CacheStats getCacheStats() {
        var stats = localCache.stats();
        return new CacheStats(
            stats.hitCount(),
            stats.missCount(),
            stats.hitRate(),
            stats.evictionCount(),
            localCache.estimatedSize()
        );
    }

    /**
     * Record class for cache statistics (Java 21 feature).
     */
    public record CacheStats(
        long hitCount,
        long missCount,
        double hitRate,
        long evictionCount,
        long estimatedSize
    ) {}

    // ========================================================================
    // Internal Methods
    // ========================================================================

    private String fetchFromStore(String key) {
        String value = configStore.get(key);

        if (value == null) {
            log.trace("Cache miss for key '{}', not found in {}", key, configStore.storeName());
            return NULL_SENTINEL;
        }

        log.trace("Cache miss for key '{}', fetched from {}", key, configStore.storeName());
        return value;
    }

    private Integer parseIntSafely(String value) {
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Long parseLongSafely(String value) {
        try {
            return Long.parseLong(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Double parseDoubleSafely(String value) {
        try {
            return Double.parseDouble(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Boolean parseBooleanSafely(String value) {
        return switch (value.trim().toLowerCase()) {
            case "true", "yes", "1", "on" -> true;
            case "false", "no", "0", "off" -> false;
            default -> null;
        };
    }

    private String maskSensitiveValue(String key, String value) {
        if (value == null) return "null";

        String upperKey = key.toUpperCase();
        if (upperKey.contains("PASSWORD") ||
            upperKey.contains("SECRET") ||
            upperKey.contains("TOKEN") ||
            upperKey.contains("KEY") ||
            upperKey.contains("CREDENTIAL")) {
            return "***MASKED***";
        }
        return value;
    }
}
