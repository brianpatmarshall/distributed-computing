package com.example;

public class InnerClassSample {

    public static final String OUTER_CONST = "outer";

    public static class InnerClass {
        public static final String INNER_CONST = "inner";
        public static final int INNER_NUMBER = 42;
    }

    private class PrivateInner {
        public static final String PRIVATE_INNER_CONST = "private-inner";
    }
}
