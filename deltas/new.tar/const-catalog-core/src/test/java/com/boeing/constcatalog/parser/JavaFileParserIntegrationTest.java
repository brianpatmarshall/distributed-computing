package com.boeing.constcatalog.parser;

import com.boeing.constcatalog.model.Constant;
import com.boeing.constcatalog.model.ParameterUsage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for JavaFileParser focusing on real-world scenarios,
 * performance, thread safety, and typical Java project patterns.
 */
class JavaFileParserIntegrationTest {

    private JavaFileParser parser;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        parser = new JavaFileParser();
    }

    // ========================================================================
    // SECTION 1: REAL-WORLD CLASS PATTERNS
    // ========================================================================
    @Nested
    @DisplayName("Real-World Class Patterns")
    class RealWorldPatternsTest {

        @Test
        @DisplayName("Should parse Spring Boot application class")
        void testSpringBootApplication() throws IOException {
            String javaCode = """
                package com.example.myapp;

                import org.springframework.boot.SpringApplication;
                import org.springframework.boot.autoconfigure.SpringBootApplication;
                import org.springframework.context.annotation.Bean;

                @SpringBootApplication
                public class MyApplication {

                    public static final String APPLICATION_NAME = "MyApp";
                    public static final String VERSION = "1.0.0";
                    public static final int DEFAULT_PORT = 8080;

                    public static void main(String[] args) {
                        SpringApplication.run(MyApplication.class, args);
                    }

                    @Bean
                    public String applicationName() {
                        return APPLICATION_NAME;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("MyApplication.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertNotNull(findConstantByName(constants, "APPLICATION_NAME"));
            assertNotNull(findConstantByName(constants, "VERSION"));
            assertNotNull(findConstantByName(constants, "DEFAULT_PORT"));
        }

        @Test
        @DisplayName("Should parse Spring configuration class with @Value")
        void testSpringConfiguration() throws IOException {
            String javaCode = """
                package com.example.config;

                import org.springframework.beans.factory.annotation.Value;
                import org.springframework.context.annotation.Configuration;
                import org.springframework.context.annotation.Bean;

                @Configuration
                public class DatabaseConfig {

                    public static final String DEFAULT_DRIVER = "com.mysql.cj.jdbc.Driver";
                    public static final int DEFAULT_POOL_SIZE = 10;

                    @Value("${database.url}")
                    private String databaseUrl;

                    @Value("${database.username}")
                    private String username;

                    @Value("${database.password}")
                    private String password;

                    @Value("${database.pool-size:10}")
                    private int poolSize;

                    @Bean
                    public DataSource dataSource() {
                        // Create datasource
                        return null;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("DatabaseConfig.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);
            assertEquals(2, constants.size());

            Set<String> knownParams = Set.of("database.url", "database.username",
                "database.password", "database.pool-size");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);
            assertEquals(4, usages.size());
        }

        @Test
        @DisplayName("Should parse REST controller")
        void testRestController() throws IOException {
            String javaCode = """
                package com.example.controller;

                import org.springframework.web.bind.annotation.*;
                import org.springframework.beans.factory.annotation.Value;

                @RestController
                @RequestMapping("/api/v1")
                public class UserController {

                    public static final String API_VERSION = "v1";
                    public static final String USERS_PATH = "/users";
                    public static final int DEFAULT_PAGE_SIZE = 20;

                    @Value("${api.rate-limit}")
                    private int rateLimit;

                    private final UserService userService;

                    public UserController(UserService userService) {
                        this.userService = userService;
                    }

                    @GetMapping(USERS_PATH)
                    public List<User> getUsers(@RequestParam(defaultValue = "0") int page) {
                        return userService.getUsers(page, DEFAULT_PAGE_SIZE);
                    }

                    @GetMapping(USERS_PATH + "/{id}")
                    public User getUser(@PathVariable Long id) {
                        return userService.getUser(id);
                    }
                }
                """;

            Path javaFile = tempDir.resolve("UserController.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);
            assertEquals(3, constants.size());

            Set<String> knownParams = Set.of("api.rate-limit");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);
            assertEquals(1, usages.size());
        }

        @Test
        @DisplayName("Should parse JPA entity")
        void testJpaEntity() throws IOException {
            String javaCode = """
                package com.example.entity;

                import javax.persistence.*;
                import java.time.LocalDateTime;

                @Entity
                @Table(name = "users")
                public class User {

                    public static final String TABLE_NAME = "users";
                    public static final String ID_COLUMN = "user_id";
                    public static final String EMAIL_COLUMN = "email";
                    public static final int MAX_NAME_LENGTH = 100;
                    public static final int MAX_EMAIL_LENGTH = 255;

                    @Id
                    @GeneratedValue(strategy = GenerationType.IDENTITY)
                    @Column(name = ID_COLUMN)
                    private Long id;

                    @Column(name = "name", length = MAX_NAME_LENGTH, nullable = false)
                    private String name;

                    @Column(name = EMAIL_COLUMN, length = MAX_EMAIL_LENGTH, unique = true)
                    private String email;

                    @Column(name = "created_at")
                    private LocalDateTime createdAt;

                    // Getters and setters...
                }
                """;

            Path javaFile = tempDir.resolve("User.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());
            assertNotNull(findConstantByName(constants, "TABLE_NAME"));
            assertNotNull(findConstantByName(constants, "ID_COLUMN"));
            assertNotNull(findConstantByName(constants, "MAX_NAME_LENGTH"));
        }

        @Test
        @DisplayName("Should parse utility class")
        void testUtilityClass() throws IOException {
            String javaCode = """
                package com.example.util;

                public final class StringUtils {

                    public static final String EMPTY = "";
                    public static final String SPACE = " ";
                    public static final String COMMA = ",";
                    public static final String NEWLINE = "\\n";
                    public static final char[] HEX_CHARS = "0123456789ABCDEF".toCharArray();

                    private StringUtils() {
                        throw new UnsupportedOperationException("Utility class");
                    }

                    public static boolean isEmpty(String str) {
                        return str == null || str.isEmpty();
                    }

                    public static boolean isNotEmpty(String str) {
                        return !isEmpty(str);
                    }

                    public static String join(String... parts) {
                        return String.join(COMMA, parts);
                    }
                }
                """;

            Path javaFile = tempDir.resolve("StringUtils.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());
        }

        @Test
        @DisplayName("Should parse constants class")
        void testConstantsClass() throws IOException {
            String javaCode = """
                package com.example.constants;

                public final class AppConstants {

                    // HTTP Status codes
                    public static final int HTTP_OK = 200;
                    public static final int HTTP_CREATED = 201;
                    public static final int HTTP_BAD_REQUEST = 400;
                    public static final int HTTP_UNAUTHORIZED = 401;
                    public static final int HTTP_FORBIDDEN = 403;
                    public static final int HTTP_NOT_FOUND = 404;
                    public static final int HTTP_INTERNAL_ERROR = 500;

                    // Error messages
                    public static final String ERR_INVALID_INPUT = "Invalid input provided";
                    public static final String ERR_NOT_FOUND = "Resource not found";
                    public static final String ERR_UNAUTHORIZED = "Unauthorized access";

                    // Configuration keys
                    public static final String CONFIG_DB_URL = "database.url";
                    public static final String CONFIG_DB_USER = "database.username";
                    public static final String CONFIG_DB_PASS = "database.password";

                    private AppConstants() {}
                }
                """;

            Path javaFile = tempDir.resolve("AppConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(13, constants.size());
        }
    }

    // ========================================================================
    // SECTION 2: BUILDER PATTERN
    // ========================================================================
    @Nested
    @DisplayName("Builder Pattern")
    class BuilderPatternTest {

        @Test
        @DisplayName("Should parse class with builder pattern")
        void testBuilderPattern() throws IOException {
            String javaCode = """
                package com.example.model;

                public class Request {

                    public static final String DEFAULT_METHOD = "GET";
                    public static final int DEFAULT_TIMEOUT = 30000;
                    public static final String CONTENT_TYPE_JSON = "application/json";

                    private final String url;
                    private final String method;
                    private final int timeout;

                    private Request(Builder builder) {
                        this.url = builder.url;
                        this.method = builder.method;
                        this.timeout = builder.timeout;
                    }

                    public static Builder builder() {
                        return new Builder();
                    }

                    public static class Builder {
                        public static final String BUILDER_NAME = "RequestBuilder";

                        private String url;
                        private String method = DEFAULT_METHOD;
                        private int timeout = DEFAULT_TIMEOUT;

                        public Builder url(String url) {
                            this.url = url;
                            return this;
                        }

                        public Builder method(String method) {
                            this.method = method;
                            return this;
                        }

                        public Builder timeout(int timeout) {
                            this.timeout = timeout;
                            return this;
                        }

                        public Request build() {
                            return new Request(this);
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Request.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());

            // Verify outer class constants
            Constant defaultMethod = findConstantByName(constants, "DEFAULT_METHOD");
            assertNotNull(defaultMethod);
            assertEquals("Request", defaultMethod.className());

            // Verify inner builder class constant
            Constant builderName = findConstantByName(constants, "BUILDER_NAME");
            assertNotNull(builderName);
            assertEquals("Builder", builderName.className());
        }
    }

    // ========================================================================
    // SECTION 3: SERVICE LAYER PATTERNS
    // ========================================================================
    @Nested
    @DisplayName("Service Layer Patterns")
    class ServiceLayerTest {

        @Test
        @DisplayName("Should parse service with property injection")
        void testServiceWithPropertyInjection() throws IOException {
            String javaCode = """
                package com.example.service;

                import org.springframework.beans.factory.annotation.Value;
                import org.springframework.stereotype.Service;

                @Service
                public class EmailService {

                    public static final String DEFAULT_FROM = "noreply@example.com";
                    public static final int MAX_RETRIES = 3;
                    public static final long RETRY_DELAY_MS = 1000L;

                    @Value("${email.smtp.host}")
                    private String smtpHost;

                    @Value("${email.smtp.port:587}")
                    private int smtpPort;

                    @Value("${email.from:noreply@example.com}")
                    private String fromAddress;

                    @Value("${email.enabled:true}")
                    private boolean emailEnabled;

                    private final Properties mailProperties;

                    public EmailService() {
                        this.mailProperties = new Properties();
                    }

                    public void sendEmail(String to, String subject, String body) {
                        if (!emailEnabled) {
                            return;
                        }
                        String host = mailProperties.getProperty("mail.smtp.host");
                        String port = mailProperties.getProperty("mail.smtp.port");
                        // Send email logic
                    }
                }
                """;

            Path javaFile = tempDir.resolve("EmailService.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);
            assertEquals(3, constants.size());

            Set<String> knownParams = Set.of(
                "email.smtp.host", "email.smtp.port", "email.from", "email.enabled",
                "mail.smtp.host", "mail.smtp.port"
            );
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            // 4 @Value annotations + 2 getProperty calls
            assertEquals(6, usages.size());
        }
    }

    // ========================================================================
    // SECTION 4: EXCEPTION CLASSES
    // ========================================================================
    @Nested
    @DisplayName("Exception Classes")
    class ExceptionClassTest {

        @Test
        @DisplayName("Should parse custom exception class")
        void testCustomException() throws IOException {
            String javaCode = """
                package com.example.exception;

                public class BusinessException extends RuntimeException {

                    public static final String DEFAULT_MESSAGE = "A business error occurred";
                    public static final String ERROR_CODE_PREFIX = "BUS_";
                    public static final long serialVersionUID = 1L;

                    private final String errorCode;
                    private final Object[] args;

                    public BusinessException(String errorCode) {
                        this(errorCode, DEFAULT_MESSAGE);
                    }

                    public BusinessException(String errorCode, String message) {
                        this(errorCode, message, (Object[]) null);
                    }

                    public BusinessException(String errorCode, String message, Object... args) {
                        super(message);
                        this.errorCode = ERROR_CODE_PREFIX + errorCode;
                        this.args = args;
                    }

                    public String getErrorCode() {
                        return errorCode;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("BusinessException.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertNotNull(findConstantByName(constants, "DEFAULT_MESSAGE"));
            assertNotNull(findConstantByName(constants, "ERROR_CODE_PREFIX"));
            assertNotNull(findConstantByName(constants, "serialVersionUID"));
        }
    }

    // ========================================================================
    // SECTION 5: DTO/RECORD PATTERNS
    // ========================================================================
    @Nested
    @DisplayName("DTO and Record Patterns")
    class DtoRecordTest {

        @Test
        @DisplayName("Should parse DTO with validation constants")
        void testDtoWithValidation() throws IOException {
            String javaCode = """
                package com.example.dto;

                import javax.validation.constraints.*;

                public class UserDto {

                    public static final int MIN_NAME_LENGTH = 2;
                    public static final int MAX_NAME_LENGTH = 100;
                    public static final int MIN_AGE = 0;
                    public static final int MAX_AGE = 150;
                    public static final String EMAIL_PATTERN = "^[A-Za-z0-9+_.-]+@(.+)$";

                    @NotBlank
                    @Size(min = MIN_NAME_LENGTH, max = MAX_NAME_LENGTH)
                    private String name;

                    @Email(regexp = EMAIL_PATTERN)
                    private String email;

                    @Min(MIN_AGE)
                    @Max(MAX_AGE)
                    private int age;

                    // Getters and setters
                }
                """;

            Path javaFile = tempDir.resolve("UserDto.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());
        }

        @Test
        @DisplayName("Should parse Lombok-annotated class")
        void testLombokClass() throws IOException {
            String javaCode = """
                package com.example.model;

                import lombok.Data;
                import lombok.Builder;
                import lombok.AllArgsConstructor;
                import lombok.NoArgsConstructor;

                @Data
                @Builder
                @AllArgsConstructor
                @NoArgsConstructor
                public class Product {

                    public static final String DEFAULT_CURRENCY = "USD";
                    public static final double MIN_PRICE = 0.0;
                    public static final String PRODUCT_TYPE = "physical";

                    private Long id;
                    private String name;
                    private double price;
                    private String currency;
                }
                """;

            Path javaFile = tempDir.resolve("Product.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
        }
    }

    // ========================================================================
    // SECTION 6: CONCURRENT PARSING
    // ========================================================================
    @Nested
    @DisplayName("Concurrent Parsing")
    class ConcurrentParsingTest {

        @Test
        @DisplayName("Should handle concurrent parsing with multiple parser instances")
        void testConcurrentParsingMultipleInstances() throws Exception {
            // Create multiple test files
            int fileCount = 20;
            for (int i = 0; i < fileCount; i++) {
                String javaCode = String.format("""
                    package com.example;

                    public class Class%d {
                        public static final String CONST_%d = "value%d";
                        public static final int NUMBER_%d = %d;
                    }
                    """, i, i, i, i, i);

                Path javaFile = tempDir.resolve("Class" + i + ".java");
                Files.writeString(javaFile, javaCode);
            }

            // Parse concurrently with separate parser instances
            ExecutorService executor = Executors.newFixedThreadPool(4);
            AtomicInteger successCount = new AtomicInteger(0);
            CountDownLatch latch = new CountDownLatch(fileCount);

            for (int i = 0; i < fileCount; i++) {
                final int index = i;
                executor.submit(() -> {
                    try {
                        JavaFileParser localParser = new JavaFileParser();
                        Path javaFile = tempDir.resolve("Class" + index + ".java");
                        List<Constant> constants = localParser.parseConstants(javaFile);
                        if (constants.size() == 2) {
                            successCount.incrementAndGet();
                        }
                    } finally {
                        latch.countDown();
                    }
                });
            }

            latch.await(30, TimeUnit.SECONDS);
            executor.shutdown();

            assertEquals(fileCount, successCount.get());
        }

        @Test
        @DisplayName("Should handle concurrent parsing with single parser instance")
        void testConcurrentParsingSingleInstance() throws Exception {
            // Create test files
            int fileCount = 10;
            for (int i = 0; i < fileCount; i++) {
                String javaCode = String.format("""
                    package com.example;

                    public class Shared%d {
                        public static final String VALUE = "shared%d";
                    }
                    """, i, i);

                Path javaFile = tempDir.resolve("Shared" + i + ".java");
                Files.writeString(javaFile, javaCode);
            }

            // Note: JavaParser instance is NOT thread-safe by default
            // This test verifies that parsing succeeds (may not be perfectly concurrent)
            AtomicInteger successCount = new AtomicInteger(0);

            for (int i = 0; i < fileCount; i++) {
                Path javaFile = tempDir.resolve("Shared" + i + ".java");
                List<Constant> constants = parser.parseConstants(javaFile);
                if (constants.size() == 1) {
                    successCount.incrementAndGet();
                }
            }

            assertEquals(fileCount, successCount.get());
        }
    }

    // ========================================================================
    // SECTION 7: COMBINED CONSTANT AND PARAMETER USAGE
    // ========================================================================
    @Nested
    @DisplayName("Combined Constant and Parameter Usage")
    class CombinedTest {

        @Test
        @DisplayName("Should find constants and parameter usages in same file")
        void testConstantsAndParametersTogether() throws IOException {
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;
                import java.util.Properties;

                public class ConfigurableService {

                    // Constants
                    public static final String SERVICE_NAME = "ConfigurableService";
                    public static final int DEFAULT_TIMEOUT = 5000;
                    public static final String DEFAULT_URL = "http://localhost";

                    // Injected properties
                    @Value("${service.url}")
                    private String serviceUrl;

                    @Value("${service.timeout:5000}")
                    private int timeout;

                    private final Properties props;

                    public ConfigurableService(Properties props) {
                        this.props = props;
                    }

                    public void connect() {
                        String url = props.getProperty("connection.url");
                        String user = props.getProperty("connection.username");
                        // Connect logic
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ConfigurableService.java");
            Files.writeString(javaFile, javaCode);

            // Parse constants
            List<Constant> constants = parser.parseConstants(javaFile);
            assertEquals(3, constants.size());

            // Parse parameter usages
            Set<String> knownParams = Set.of(
                "service.url", "service.timeout",
                "connection.url", "connection.username"
            );
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);
            assertEquals(4, usages.size());
        }
    }

    // ========================================================================
    // SECTION 8: COMPLEX HIERARCHY
    // ========================================================================
    @Nested
    @DisplayName("Complex Class Hierarchy")
    class ComplexHierarchyTest {

        @Test
        @DisplayName("Should parse constants in complex nested structure")
        void testComplexNestedStructure() throws IOException {
            String javaCode = """
                package com.example;

                public class OuterClass {
                    public static final String OUTER = "outer";

                    public static class StaticNested {
                        public static final String STATIC_NESTED = "static_nested";

                        public static class DeeplyNested {
                            public static final String DEEP = "deep";
                        }
                    }

                    public class InnerClass {
                        // In Java 16+, inner classes can have static fields
                        public static final String INNER = "inner";
                    }

                    public interface NestedInterface {
                        public static final String INTERFACE_CONST = "interface";
                    }

                    public enum NestedEnum {
                        VALUE1, VALUE2;

                        public static final String ENUM_CONST = "enum";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("OuterClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertTrue(constants.size() >= 5);
            assertNotNull(findConstantByName(constants, "OUTER"));
            assertNotNull(findConstantByName(constants, "STATIC_NESTED"));
            assertNotNull(findConstantByName(constants, "DEEP"));
        }
    }

    // ========================================================================
    // SECTION 9: PERFORMANCE TEST
    // ========================================================================
    @Nested
    @DisplayName("Performance Tests")
    class PerformanceTest {

        @Test
        @DisplayName("Should parse large file efficiently")
        void testLargeFilePerformance() throws IOException {
            // Generate a large file with many constants and methods
            StringBuilder code = new StringBuilder();
            code.append("package com.example;\n\n");
            code.append("import java.util.*;\n\n");
            code.append("public class LargeClass {\n");

            // Add 500 constants
            for (int i = 0; i < 500; i++) {
                code.append(String.format("    public static final String CONST_%d = \"value%d\";\n", i, i));
            }

            // Add 100 methods with property access
            for (int i = 0; i < 100; i++) {
                code.append(String.format("""
                        public void method%d(Properties props) {
                            String val = props.getProperty("param.%d");
                            System.out.println(val);
                        }
                    """, i, i));
            }

            code.append("}\n");

            Path javaFile = tempDir.resolve("LargeClass.java");
            Files.writeString(javaFile, code.toString());

            long startTime = System.currentTimeMillis();
            List<Constant> constants = parser.parseConstants(javaFile);
            long parseTime = System.currentTimeMillis() - startTime;

            assertEquals(500, constants.size());
            assertTrue(parseTime < 5000, "Parsing should complete within 5 seconds, took: " + parseTime + "ms");

            // Parse parameter usages
            Set<String> knownParams = new HashSet<>();
            for (int i = 0; i < 100; i++) {
                knownParams.add("param." + i);
            }

            startTime = System.currentTimeMillis();
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);
            parseTime = System.currentTimeMillis() - startTime;

            assertEquals(100, usages.size());
            assertTrue(parseTime < 5000, "Parameter parsing should complete within 5 seconds, took: " + parseTime + "ms");
        }
    }

    // ========================================================================
    // SECTION 10: ENCODING AND SPECIAL CHARACTERS
    // ========================================================================
    @Nested
    @DisplayName("Encoding and Special Characters")
    class EncodingTest {

        @Test
        @DisplayName("Should handle various encodings in string constants")
        void testVariousEncodings() throws IOException {
            String javaCode = """
                package com.example;

                public class Encodings {
                    // Various Unicode strings
                    public static final String GERMAN = "Guten Tag, wie geht's?";
                    public static final String FRENCH = "Bonjour, comment allez-vous?";
                    public static final String SPANISH = "Hola, \\u00bfc\\u00f3mo est\\u00e1s?";
                    public static final String CHINESE = "\\u4f60\\u597d";
                    public static final String EMOJI = "Hello \\uD83D\\uDC4B";
                    public static final String MATH = "x\\u00b2 + y\\u00b2 = z\\u00b2";
                    public static final String COPYRIGHT = "\\u00a9 2024";
                }
                """;

            Path javaFile = tempDir.resolve("Encodings.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(7, constants.size());
        }

        @Test
        @DisplayName("Should handle special regex characters in parameter names")
        void testRegexCharactersInParams() throws IOException {
            String javaCode = """
                package com.example;

                public class RegexParams {
                    public void method(Properties props) {
                        String val1 = props.getProperty("param.with.dots");
                        String val2 = props.getProperty("param-with-dashes");
                        String val3 = props.getProperty("param_with_underscores");
                        String val4 = props.getProperty("param[0]");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("RegexParams.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of(
                "param.with.dots",
                "param-with-dashes",
                "param_with_underscores",
                "param[0]"
            );
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(4, usages.size());
        }
    }

    // ========================================================================
    // SECTION 11: MALFORMED/EDGE CASE FILES
    // ========================================================================
    @Nested
    @DisplayName("Malformed and Edge Case Files")
    class MalformedFilesTest {

        @Test
        @DisplayName("Should handle file with BOM (Byte Order Mark)")
        void testFileWithBom() throws IOException {
            // UTF-8 BOM: EF BB BF
            byte[] bom = new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF };
            String javaCode = """
                package com.example;

                public class BomFile {
                    public static final String CONST = "bom";
                }
                """;

            Path javaFile = tempDir.resolve("BomFile.java");
            byte[] codeBytes = javaCode.getBytes();
            byte[] fullContent = new byte[bom.length + codeBytes.length];
            System.arraycopy(bom, 0, fullContent, 0, bom.length);
            System.arraycopy(codeBytes, 0, fullContent, bom.length, codeBytes.length);
            Files.write(javaFile, fullContent);

            // Parser should handle BOM gracefully
            List<Constant> constants = parser.parseConstants(javaFile);

            // May or may not parse depending on JavaParser's BOM handling
            // The important thing is it doesn't throw
            assertNotNull(constants);
        }

        @Test
        @DisplayName("Should handle file with Windows line endings (CRLF)")
        void testWindowsLineEndings() throws IOException {
            String javaCode = "package com.example;\r\n\r\npublic class WindowsFile {\r\n    public static final String CONST = \"crlf\";\r\n}\r\n";

            Path javaFile = tempDir.resolve("WindowsFile.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
            assertEquals("CONST", constants.get(0).name());
        }

        @Test
        @DisplayName("Should handle file with mixed line endings")
        void testMixedLineEndings() throws IOException {
            String javaCode = "package com.example;\n\r\npublic class MixedFile {\r\n    public static final String CONST = \"mixed\";\n}\r\n";

            Path javaFile = tempDir.resolve("MixedFile.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
        }

        @Test
        @DisplayName("Should handle file with trailing whitespace")
        void testTrailingWhitespace() throws IOException {
            String javaCode = """
                package com.example;   \s

                public class Whitespace {   \s
                    public static final String CONST = "whitespace";   \s
                }   \s
                """;

            Path javaFile = tempDir.resolve("Whitespace.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
        }

        @Test
        @DisplayName("Should handle file with no newline at end")
        void testNoFinalNewline() throws IOException {
            String javaCode = "package com.example;\npublic class NoNewline {\n    public static final String CONST = \"no newline\";\n}";

            Path javaFile = tempDir.resolve("NoNewline.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
        }
    }

    // ========================================================================
    // SECTION 12: PARSER REUSE
    // ========================================================================
    @Nested
    @DisplayName("Parser Reuse")
    class ParserReuseTest {

        @Test
        @DisplayName("Should correctly parse multiple files with same parser")
        void testMultipleFilesSequential() throws IOException {
            // Create and parse multiple files
            List<Path> files = new java.util.ArrayList<>();
            int totalConstants = 0;

            for (int i = 0; i < 5; i++) {
                int numConstants = i + 1;
                StringBuilder code = new StringBuilder();
                code.append("package com.example;\npublic class File").append(i).append(" {\n");
                for (int j = 0; j < numConstants; j++) {
                    code.append("    public static final int C").append(j).append(" = ").append(j).append(";\n");
                }
                code.append("}\n");

                Path file = tempDir.resolve("File" + i + ".java");
                Files.writeString(file, code.toString());
                files.add(file);
                totalConstants += numConstants;
            }

            // Parse all files with same parser instance
            int foundConstants = 0;
            for (Path file : files) {
                List<Constant> constants = parser.parseConstants(file);
                foundConstants += constants.size();
            }

            assertEquals(totalConstants, foundConstants);
        }

        @Test
        @DisplayName("Parser state should not leak between files")
        void testNoStateLeakage() throws IOException {
            // First file with many constants
            String code1 = """
                package com.example;
                public class First {
                    public static final String A = "a";
                    public static final String B = "b";
                    public static final String C = "c";
                }
                """;
            Path file1 = tempDir.resolve("First.java");
            Files.writeString(file1, code1);

            // Second file with one constant
            String code2 = """
                package com.example;
                public class Second {
                    public static final String X = "x";
                }
                """;
            Path file2 = tempDir.resolve("Second.java");
            Files.writeString(file2, code2);

            // Parse first file
            List<Constant> constants1 = parser.parseConstants(file1);
            assertEquals(3, constants1.size());

            // Parse second file - should only find its constants
            List<Constant> constants2 = parser.parseConstants(file2);
            assertEquals(1, constants2.size());
            assertEquals("X", constants2.get(0).name());
            assertEquals("Second", constants2.get(0).className());
        }
    }

    // ========================================================================
    // HELPER METHODS
    // ========================================================================

    private Constant findConstantByName(List<Constant> constants, String name) {
        return constants.stream()
            .filter(c -> c.name().equals(name))
            .findFirst()
            .orElse(null);
    }
}
