package com.boeing.constcatalog.parser;

import com.boeing.constcatalog.model.Constant;
import com.boeing.constcatalog.model.ParameterUsage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests specifically focused on JavaParser AST features and node type handling.
 * Complements JavaFileParserComprehensiveTest with more AST-specific scenarios.
 */
class JavaParserAstFeaturesTest {

    private JavaFileParser parser;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        parser = new JavaFileParser();
    }

    // ========================================================================
    // SECTION 1: COMPILATION UNIT STRUCTURE
    // ========================================================================
    @Nested
    @DisplayName("Compilation Unit Structure")
    class CompilationUnitTest {

        @Test
        @DisplayName("Should parse file without package declaration")
        void testNoPackageDeclaration() throws IOException {
            String javaCode = """
                public class NoPackage {
                    public static final String CONST = "no package";
                }
                """;

            Path javaFile = tempDir.resolve("NoPackage.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
            assertEquals("CONST", constants.get(0).name());
            assertEquals("NoPackage", constants.get(0).className());
        }

        @Test
        @DisplayName("Should parse file with multiple top-level classes")
        void testMultipleTopLevelClasses() throws IOException {
            String javaCode = """
                package com.example;

                public class PublicClass {
                    public static final String PUBLIC_CONST = "public";
                }

                class PackageClass1 {
                    public static final String PACKAGE1_CONST = "package1";
                }

                class PackageClass2 {
                    public static final String PACKAGE2_CONST = "package2";
                }
                """;

            Path javaFile = tempDir.resolve("PublicClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertEquals("PublicClass", findConstantByName(constants, "PUBLIC_CONST").className());
            assertEquals("PackageClass1", findConstantByName(constants, "PACKAGE1_CONST").className());
            assertEquals("PackageClass2", findConstantByName(constants, "PACKAGE2_CONST").className());
        }

        @Test
        @DisplayName("Should parse file with static imports")
        void testStaticImports() throws IOException {
            String javaCode = """
                package com.example;

                import static java.lang.Math.PI;
                import static java.lang.Math.E;
                import static java.util.Collections.*;

                public class StaticImports {
                    public static final double MY_PI = PI;
                    public static final double MY_E = E;
                }
                """;

            Path javaFile = tempDir.resolve("StaticImports.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }

        @Test
        @DisplayName("Should parse file with module declaration comment (pre-Java 9 style)")
        void testModuleCommentStyle() throws IOException {
            String javaCode = """
                // module com.example
                package com.example;

                public class ModuleComment {
                    public static final String CONST = "module comment";
                }
                """;

            Path javaFile = tempDir.resolve("ModuleComment.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
        }
    }

    // ========================================================================
    // SECTION 2: CLASS/INTERFACE DECLARATION VARIATIONS
    // ========================================================================
    @Nested
    @DisplayName("Class and Interface Declaration Variations")
    class ClassDeclarationTest {

        @Test
        @DisplayName("Should parse class with extends and implements")
        void testExtendsAndImplements() throws IOException {
            String javaCode = """
                package com.example;

                import java.io.Serializable;

                public class ExtendedClass extends BaseClass implements Serializable, Comparable<ExtendedClass> {
                    public static final String CONST = "extended";
                    public static final long serialVersionUID = 1L;

                    @Override
                    public int compareTo(ExtendedClass other) {
                        return 0;
                    }
                }

                class BaseClass {
                    public static final String BASE_CONST = "base";
                }
                """;

            Path javaFile = tempDir.resolve("ExtendedClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertNotNull(findConstantByName(constants, "CONST"));
            assertNotNull(findConstantByName(constants, "serialVersionUID"));
            assertNotNull(findConstantByName(constants, "BASE_CONST"));
        }

        @Test
        @DisplayName("Should parse interface with extends")
        void testInterfaceExtends() throws IOException {
            String javaCode = """
                package com.example;

                public interface ExtendedInterface extends BaseInterface, OtherInterface {
                    public static final String CONST = "extended interface";
                }

                interface BaseInterface {
                    public static final String BASE = "base";
                }

                interface OtherInterface {
                    public static final String OTHER = "other";
                }
                """;

            Path javaFile = tempDir.resolve("ExtendedInterface.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
        }

        @Test
        @DisplayName("Should parse class with type parameters and bounds")
        void testTypeBounds() throws IOException {
            String javaCode = """
                package com.example;

                public class BoundedClass<T extends Number & Comparable<T>, U extends List<T>> {
                    public static final String CONST = "bounded";
                    public static final int MAX = 100;
                }
                """;

            Path javaFile = tempDir.resolve("BoundedClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }
    }

    // ========================================================================
    // SECTION 3: FIELD DECLARATION AST NODES
    // ========================================================================
    @Nested
    @DisplayName("Field Declaration AST Nodes")
    class FieldDeclarationTest {

        @Test
        @DisplayName("Should correctly identify modifier combinations")
        void testModifierCombinations() throws IOException {
            String javaCode = """
                package com.example;

                public class Modifiers {
                    // Public static final — cataloged
                    public static final String PSF = "psf";
                    public final static String PFS = "pfs";  // Different order

                    // Non-public static final — NOT cataloged
                    protected static final String PRSF = "prsf";
                    private static final String PRVSF = "prvsf";
                    static final String SF = "sf";
                    final static String FS = "fs";

                    // NOT constants (missing static or final)
                    public final String NOT1 = "not1";
                    public static String NOT2 = "not2";
                    private String NOT3 = "not3";
                    final String NOT4 = "not4";
                    static String NOT5 = "not5";
                }
                """;

            Path javaFile = tempDir.resolve("Modifiers.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Only public static final (in any order) are cataloged
            assertEquals(2, constants.size());
            assertNotNull(findConstantByName(constants, "PSF"));
            assertNotNull(findConstantByName(constants, "PFS"));
        }

        @Test
        @DisplayName("Should handle volatile and transient modifiers correctly")
        void testVolatileTransient() throws IOException {
            String javaCode = """
                package com.example;

                public class VolatileTransient {
                    // Volatile cannot be final (compile error), but parser should handle gracefully
                    public static final transient String TRANSIENT_CONST = "transient";

                    // These are NOT constants
                    private volatile String volatileField = "volatile";
                    private transient String transientField = "transient";
                }
                """;

            Path javaFile = tempDir.resolve("VolatileTransient.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // transient static final is still a constant
            assertEquals(1, constants.size());
            assertEquals("TRANSIENT_CONST", constants.get(0).name());
        }
    }

    // ========================================================================
    // SECTION 4: VARIABLE DECLARATOR AST NODES
    // ========================================================================
    @Nested
    @DisplayName("Variable Declarator AST Nodes")
    class VariableDeclaratorTest {

        @Test
        @DisplayName("Should handle var type (Java 10+)")
        void testVarType() throws IOException {
            // Note: var cannot be used for static final fields, but parser should handle
            String javaCode = """
                package com.example;

                public class VarType {
                    public static final String CONST = "const";

                    public void method() {
                        var local = "local variable";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("VarType.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
            assertEquals("CONST", constants.get(0).name());
        }

        @Test
        @DisplayName("Should handle array types in different syntaxes")
        void testArrayTypeSyntax() throws IOException {
            String javaCode = """
                package com.example;

                public class ArraySyntax {
                    // C-style array declaration
                    public static final int ARRAY1[] = {1, 2, 3};

                    // Java-style array declaration
                    public static final int[] ARRAY2 = {4, 5, 6};

                    // Mixed (C-style with type)
                    public static final String STRINGS[] = {"a", "b"};

                    // Multi-dimensional mixed
                    public static final int MATRIX[][] = {{1, 2}, {3, 4}};
                }
                """;

            Path javaFile = tempDir.resolve("ArraySyntax.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
        }
    }

    // ========================================================================
    // SECTION 5: EXPRESSION AST NODES
    // ========================================================================
    @Nested
    @DisplayName("Expression AST Nodes")
    class ExpressionTest {

        @Test
        @DisplayName("Should handle instanceof expressions")
        void testInstanceofExpression() throws IOException {
            String javaCode = """
                package com.example;

                public class InstanceofTest {
                    public static final boolean IS_STRING = "test" instanceof String;
                    public static final boolean IS_OBJECT = "test" instanceof Object;
                }
                """;

            Path javaFile = tempDir.resolve("InstanceofTest.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            assertTrue(findConstantByName(constants, "IS_STRING").value().contains("instanceof"));
        }

        @Test
        @DisplayName("Should handle pattern matching instanceof (Java 16+) if supported")
        void testPatternMatchingInstanceof() throws IOException {
            // Pattern matching instanceof requires Java 16+ language level
            String javaCode = """
                package com.example;

                public class PatternMatch {
                    public static final Object OBJ = "test";

                    public void method() {
                        if (OBJ instanceof String s) {
                            System.out.println(s);
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("PatternMatch.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may not support pattern matching without language level configuration
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                assertEquals(1, constants.size());
            }
        }

        @Test
        @DisplayName("Should handle traditional instanceof (all Java versions)")
        void testTraditionalInstanceof() throws IOException {
            String javaCode = """
                package com.example;

                public class TraditionalInstanceof {
                    public static final Object OBJ = "test";
                    public static final boolean IS_STRING = OBJ instanceof String;

                    public void method() {
                        if (OBJ instanceof String) {
                            String s = (String) OBJ;
                            System.out.println(s);
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("TraditionalInstanceof.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }

        @Test
        @DisplayName("Should handle switch expressions (Java 14+) if supported")
        void testSwitchExpression() throws IOException {
            // Switch expressions require Java 14+ language level
            String javaCode = """
                package com.example;

                public class SwitchExpr {
                    public static final int DAY = 1;
                    public static final String DAY_NAME = switch (DAY) {
                        case 1 -> "Monday";
                        case 2 -> "Tuesday";
                        default -> "Unknown";
                    };
                }
                """;

            Path javaFile = tempDir.resolve("SwitchExpr.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may not support switch expressions without language level configuration
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                assertEquals(2, constants.size());
                Constant dayName = findConstantByName(constants, "DAY_NAME");
                assertNotNull(dayName);
                assertTrue(dayName.value().contains("switch"));
            }
        }

        @Test
        @DisplayName("Should handle traditional switch statement (all Java versions)")
        void testTraditionalSwitch() throws IOException {
            String javaCode = """
                package com.example;

                public class TraditionalSwitch {
                    public static final int DAY = 1;
                    public static final String[] DAY_NAMES = {"Unknown", "Monday", "Tuesday"};

                    public String getDayName(int day) {
                        String result;
                        switch (day) {
                            case 1:
                                result = "Monday";
                                break;
                            case 2:
                                result = "Tuesday";
                                break;
                            default:
                                result = "Unknown";
                        }
                        return result;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("TraditionalSwitch.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }

        @Test
        @DisplayName("Should handle array access expressions")
        void testArrayAccessExpression() throws IOException {
            String javaCode = """
                package com.example;

                public class ArrayAccess {
                    public static final int[] ARRAY = {1, 2, 3};
                    public static final int FIRST = ARRAY[0];
                    public static final int SECOND = ARRAY[1];
                }
                """;

            Path javaFile = tempDir.resolve("ArrayAccess.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertTrue(findConstantByName(constants, "FIRST").value().contains("[0]"));
        }

        @Test
        @DisplayName("Should handle field access expressions")
        void testFieldAccessExpression() throws IOException {
            String javaCode = """
                package com.example;

                public class FieldAccess {
                    public static final String OUT = System.out.toString();
                    public static final int MAX_INT = Integer.MAX_VALUE;
                    public static final double PI = Math.PI;
                    public static final String SEPARATOR = File.separator;
                }
                """;

            Path javaFile = tempDir.resolve("FieldAccess.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
        }

        @Test
        @DisplayName("Should handle unary expressions")
        void testUnaryExpressions() throws IOException {
            String javaCode = """
                package com.example;

                public class UnaryExpr {
                    public static final int POSITIVE = +42;
                    public static final int NEGATIVE = -42;
                    public static final boolean NOT_TRUE = !true;
                    public static final int BITWISE_NOT = ~0xFF;
                }
                """;

            Path javaFile = tempDir.resolve("UnaryExpr.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
        }

        @Test
        @DisplayName("Should handle enclosed/parenthesized expressions")
        void testParenthesizedExpressions() throws IOException {
            String javaCode = """
                package com.example;

                public class ParenExpr {
                    public static final int SIMPLE = (42);
                    public static final int NESTED = ((42));
                    public static final int COMPLEX = ((10 + 20) * (5 - 3));
                }
                """;

            Path javaFile = tempDir.resolve("ParenExpr.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
        }

        @Test
        @DisplayName("Should handle conditional (ternary) expressions with nesting")
        void testNestedTernary() throws IOException {
            String javaCode = """
                package com.example;

                public class NestedTernary {
                    public static final int A = 1;
                    public static final int B = 2;
                    public static final int C = 3;
                    public static final int RESULT = A > B ? A : (B > C ? B : C);
                    public static final String NESTED = A == 1 ? "one" : A == 2 ? "two" : "other";
                }
                """;

            Path javaFile = tempDir.resolve("NestedTernary.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());
        }

        @Test
        @DisplayName("Should handle this and super references in initializers")
        void testThisSuperReferences() throws IOException {
            String javaCode = """
                package com.example;

                public class ThisSuper {
                    public static final String CONST = "const";

                    public void method() {
                        String local = this.CONST;  // Not a constant
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ThisSuper.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
        }
    }

    // ========================================================================
    // SECTION 6: ANNOTATION AST NODES
    // ========================================================================
    @Nested
    @DisplayName("Annotation AST Nodes")
    class AnnotationTest {

        @Test
        @DisplayName("Should parse fields with marker annotations")
        void testMarkerAnnotations() throws IOException {
            String javaCode = """
                package com.example;

                public class MarkerAnnotations {
                    @Deprecated
                    public static final String DEPRECATED = "deprecated";

                    @Override
                    public String toString() {
                        return DEPRECATED;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("MarkerAnnotations.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
        }

        @Test
        @DisplayName("Should parse fields with single-element annotations")
        void testSingleElementAnnotations() throws IOException {
            String javaCode = """
                package com.example;

                public class SingleElementAnnotations {
                    @SuppressWarnings("unchecked")
                    public static final String SUPPRESSED = "suppressed";

                    @SuppressWarnings("deprecation")
                    public static final String SUPPRESSED2 = "suppressed2";
                }
                """;

            Path javaFile = tempDir.resolve("SingleElementAnnotations.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }

        @Test
        @DisplayName("Should parse fields with normal annotations (multiple elements)")
        void testNormalAnnotations() throws IOException {
            String javaCode = """
                package com.example;

                public class NormalAnnotations {
                    @Deprecated(since = "1.0", forRemoval = true)
                    public static final String OLD = "old";

                    @SuppressWarnings({"unchecked", "deprecation"})
                    public static final String MULTI_SUPPRESS = "multi";
                }
                """;

            Path javaFile = tempDir.resolve("NormalAnnotations.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }

        @Test
        @DisplayName("Should detect @Value annotations in inner classes")
        void testValueAnnotationInInnerClass() throws IOException {
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;

                public class Outer {
                    @Value("${outer.param}")
                    private String outerValue;

                    public static class Inner {
                        @Value("${inner.param}")
                        private String innerValue;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Outer.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("outer.param", "inner.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(2, usages.size());
            assertTrue(usages.stream().anyMatch(u ->
                u.parameterName().equals("outer.param") && u.usedInClass().equals("Outer")));
            assertTrue(usages.stream().anyMatch(u ->
                u.parameterName().equals("inner.param") && u.usedInClass().equals("Inner")));
        }
    }

    // ========================================================================
    // SECTION 7: METHOD CALL EXPRESSION VARIATIONS
    // ========================================================================
    @Nested
    @DisplayName("Method Call Expression Variations")
    class MethodCallTest {

        @Test
        @DisplayName("Should detect chained method calls with property access")
        void testChainedMethodCalls() throws IOException {
            String javaCode = """
                package com.example;

                public class ChainedCalls {
                    public void method(Properties props) {
                        String value = props.getProperty("chain.param").trim().toUpperCase();
                        String value2 = Optional.ofNullable(props.getProperty("optional.param")).orElse("");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ChainedCalls.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("chain.param", "optional.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(2, usages.size());
        }

        @Test
        @DisplayName("Should detect method calls with multiple string arguments")
        void testMultipleStringArgs() throws IOException {
            String javaCode = """
                package com.example;

                public class MultiArgs {
                    public void method(Properties props) {
                        // getProperty with default value
                        String value = props.getProperty("param.name", "default");
                        // getOrDefault
                        Object obj = props.getOrDefault("other.param", "fallback");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("MultiArgs.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("param.name", "other.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(2, usages.size());
        }

        @Test
        @DisplayName("Should detect method calls in lambda expressions")
        void testMethodCallsInLambda() throws IOException {
            String javaCode = """
                package com.example;

                public class LambdaCalls {
                    public void method(Properties props, List<String> keys) {
                        keys.forEach(key -> {
                            String value = props.getProperty("lambda.param");
                            System.out.println(value);
                        });
                    }
                }
                """;

            Path javaFile = tempDir.resolve("LambdaCalls.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("lambda.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
        }

        @Test
        @DisplayName("Should detect method calls in anonymous classes")
        void testMethodCallsInAnonymousClass() throws IOException {
            String javaCode = """
                package com.example;

                public class AnonymousCalls {
                    public void method(Properties props) {
                        Runnable r = new Runnable() {
                            @Override
                            public void run() {
                                String value = props.getProperty("anon.param");
                                System.out.println(value);
                            }
                        };
                    }
                }
                """;

            Path javaFile = tempDir.resolve("AnonymousCalls.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("anon.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
        }

        @Test
        @DisplayName("Should detect static method calls for property access")
        void testStaticMethodCalls() throws IOException {
            String javaCode = """
                package com.example;

                public class StaticCalls {
                    public void method() {
                        String env = System.getenv("ENV_VAR");
                        String prop = System.getProperty("system.prop");
                        String config = Config.get("config.key");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("StaticCalls.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("ENV_VAR", "system.prop", "config.key");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            // Should find all three since getenv, getProperty, and get are in PROPERTY_GETTER_METHODS
            assertEquals(3, usages.size());
        }
    }

    // ========================================================================
    // SECTION 8: STRING LITERAL VARIATIONS
    // ========================================================================
    @Nested
    @DisplayName("String Literal Variations")
    class StringLiteralTest {

        @Test
        @DisplayName("Should handle empty string parameter names")
        void testEmptyStringParameter() throws IOException {
            String javaCode = """
                package com.example;

                public class EmptyString {
                    public void method(Properties props) {
                        String empty = props.getProperty("");
                        String notEmpty = props.getProperty("real.param");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("EmptyString.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("", "real.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(2, usages.size());
        }

        @Test
        @DisplayName("Should handle parameter names with special characters")
        void testSpecialCharParameters() throws IOException {
            String javaCode = """
                package com.example;

                public class SpecialChars {
                    public void method(Properties props) {
                        String dot = props.getProperty("a.b.c.d");
                        String underscore = props.getProperty("my_param_name");
                        String dash = props.getProperty("my-param-name");
                        String mixed = props.getProperty("app.my-param_name.value");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("SpecialChars.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("a.b.c.d", "my_param_name", "my-param-name", "app.my-param_name.value");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(4, usages.size());
        }
    }

    // ========================================================================
    // SECTION 9: RECORD COMPONENTS AND COMPACT CONSTRUCTORS
    // ========================================================================
    @Nested
    @DisplayName("Record Components")
    class RecordComponentTest {

        @Test
        @DisplayName("Should parse constants in records with compact constructor (if supported)")
        void testRecordWithCompactConstructor() throws IOException {
            // Records require Java 16+ language level
            String javaCode = """
                package com.example;

                public record ValidatedPerson(String name, int age) {
                    public static final int MIN_AGE = 0;
                    public static final int MAX_AGE = 150;

                    public ValidatedPerson {
                        if (age < MIN_AGE || age > MAX_AGE) {
                            throw new IllegalArgumentException("Invalid age");
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ValidatedPerson.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may not support records without language level configuration
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                assertEquals(2, constants.size());
            }
        }

        @Test
        @DisplayName("Should parse constants in records with @Value on components (if supported)")
        void testRecordWithValueAnnotation() throws IOException {
            // Records require Java 16+ language level
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;

                public record ConfigRecord(
                    @Value("${config.name}") String name,
                    @Value("${config.count}") int count
                ) {
                    public static final String TYPE = "ConfigRecord";
                }
                """;

            Path javaFile = tempDir.resolve("ConfigRecord.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may not support records without language level configuration
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                assertEquals(1, constants.size());
            }
        }

        @Test
        @DisplayName("Should parse constants in class with validation (all Java versions)")
        void testClassWithValidation() throws IOException {
            // Fallback test using regular class
            String javaCode = """
                package com.example;

                public final class ValidatedPersonClass {
                    public static final int MIN_AGE = 0;
                    public static final int MAX_AGE = 150;

                    private final String name;
                    private final int age;

                    public ValidatedPersonClass(String name, int age) {
                        if (age < MIN_AGE || age > MAX_AGE) {
                            throw new IllegalArgumentException("Invalid age");
                        }
                        this.name = name;
                        this.age = age;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ValidatedPersonClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }
    }

    // ========================================================================
    // SECTION 10: ENUM WITH METHODS AND ABSTRACT METHODS
    // ========================================================================
    @Nested
    @DisplayName("Enum with Methods")
    class EnumMethodTest {

        @Test
        @DisplayName("Should parse constants in enum with abstract method")
        void testEnumWithAbstractMethod() throws IOException {
            String javaCode = """
                package com.example;

                public enum Operation {
                    ADD {
                        @Override
                        public int apply(int a, int b) {
                            return a + b;
                        }
                    },
                    SUBTRACT {
                        @Override
                        public int apply(int a, int b) {
                            return a - b;
                        }
                    };

                    public static final String OPERATION_TYPE = "arithmetic";
                    public static final int MAX_OPERAND = 1000;

                    public abstract int apply(int a, int b);
                }
                """;

            Path javaFile = tempDir.resolve("Operation.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            assertNotNull(findConstantByName(constants, "OPERATION_TYPE"));
            assertNotNull(findConstantByName(constants, "MAX_OPERAND"));
        }
    }

    // ========================================================================
    // SECTION 11: TRY-WITH-RESOURCES AND EXCEPTION HANDLING
    // ========================================================================
    @Nested
    @DisplayName("Exception Handling Constructs")
    class ExceptionHandlingTest {

        @Test
        @DisplayName("Should detect parameter usage in try-with-resources")
        void testTryWithResources() throws IOException {
            String javaCode = """
                package com.example;

                import java.io.*;
                import java.util.Properties;

                public class TryResources {
                    public void method() {
                        try (InputStream is = new FileInputStream(props.getProperty("file.path"))) {
                            // process
                        } catch (IOException e) {
                            // handle
                        }
                    }

                    private Properties props;
                }
                """;

            Path javaFile = tempDir.resolve("TryResources.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("file.path");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
        }

        @Test
        @DisplayName("Should detect parameter usage in catch block")
        void testCatchBlock() throws IOException {
            String javaCode = """
                package com.example;

                public class CatchBlock {
                    public void method(Properties props) {
                        try {
                            // something
                        } catch (Exception e) {
                            String errorHandler = props.getProperty("error.handler");
                            System.err.println(errorHandler);
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("CatchBlock.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("error.handler");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
        }
    }

    // ========================================================================
    // SECTION 12: SYNCHRONIZED AND VOLATILE
    // ========================================================================
    @Nested
    @DisplayName("Synchronized and Volatile")
    class SynchronizedVolatileTest {

        @Test
        @DisplayName("Should detect parameter usage in synchronized block")
        void testSynchronizedBlock() throws IOException {
            String javaCode = """
                package com.example;

                public class SyncBlock {
                    private final Object lock = new Object();

                    public void method(Properties props) {
                        synchronized (lock) {
                            String value = props.getProperty("sync.param");
                            System.out.println(value);
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("SyncBlock.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("sync.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
        }
    }

    // ========================================================================
    // SECTION 13: ASSERTIONS
    // ========================================================================
    @Nested
    @DisplayName("Assertions")
    class AssertionTest {

        @Test
        @DisplayName("Should parse class with assert statements")
        void testAssertStatements() throws IOException {
            String javaCode = """
                package com.example;

                public class Assertions {
                    public static final int MAX = 100;
                    public static final String MESSAGE = "Value must be less than MAX";

                    public void validate(int value) {
                        assert value < MAX : MESSAGE;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Assertions.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }
    }

    // ========================================================================
    // SECTION 14: YIELD STATEMENT (Java 14+)
    // ========================================================================
    @Nested
    @DisplayName("Yield Statement")
    class YieldTest {

        @Test
        @DisplayName("Should parse constants with switch expressions using yield (if supported)")
        void testYieldStatement() throws IOException {
            // Switch expressions with yield require Java 14+
            String javaCode = """
                package com.example;

                public class YieldExpr {
                    public static final int VALUE = 2;
                    public static final String RESULT = switch (VALUE) {
                        case 1 -> "one";
                        case 2 -> {
                            String result = "two";
                            yield result;
                        }
                        default -> "other";
                    };
                }
                """;

            Path javaFile = tempDir.resolve("YieldExpr.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may not support yield/switch expressions without language level configuration
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                assertEquals(2, constants.size());
            }
        }

        @Test
        @DisplayName("Should parse constants with method returning value (all Java versions)")
        void testMethodReturningValue() throws IOException {
            // Fallback test without switch expressions
            String javaCode = """
                package com.example;

                public class ReturnExpr {
                    public static final int VALUE = 2;
                    public static final String DEFAULT_RESULT = "other";

                    public String getResult() {
                        if (VALUE == 1) return "one";
                        if (VALUE == 2) return "two";
                        return DEFAULT_RESULT;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ReturnExpr.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }
    }

    // ========================================================================
    // HELPER METHODS
    // ========================================================================

    private Constant findConstantByName(List<Constant> constants, String name) {
        return constants.stream()
            .filter(c -> c.name().equals(name))
            .findFirst()
            .orElse(null);
    }
}
