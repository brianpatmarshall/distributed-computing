package com.boeing.constcatalog.parser;

import com.boeing.constcatalog.model.Constant;
import com.boeing.constcatalog.model.ParameterUsage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Comprehensive unit tests for JavaFileParser covering all aspects of JavaParser.
 * Tests exercise parsing of various Java constructs, edge cases, and error handling.
 */
class JavaFileParserComprehensiveTest {

    private JavaFileParser parser;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        parser = new JavaFileParser();
    }

    // ========================================================================
    // SECTION 1: PRIMITIVE TYPE CONSTANTS
    // ========================================================================
    @Nested
    @DisplayName("Primitive Type Constants")
    class PrimitiveTypeConstantsTest {

        @Test
        @DisplayName("Should parse all primitive type constants")
        void testAllPrimitiveTypes() throws IOException {
            String javaCode = """
                package com.example;

                public class PrimitiveConstants {
                    public static final byte BYTE_CONST = 127;
                    public static final short SHORT_CONST = 32767;
                    public static final int INT_CONST = 2147483647;
                    public static final long LONG_CONST = 9223372036854775807L;
                    public static final float FLOAT_CONST = 3.14f;
                    public static final double DOUBLE_CONST = 3.141592653589793;
                    public static final char CHAR_CONST = 'A';
                    public static final boolean BOOLEAN_TRUE = true;
                    public static final boolean BOOLEAN_FALSE = false;
                }
                """;

            Path javaFile = tempDir.resolve("PrimitiveConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(9, constants.size());

            assertConstantExists(constants, "BYTE_CONST", "byte", "127");
            assertConstantExists(constants, "SHORT_CONST", "short", "32767");
            assertConstantExists(constants, "INT_CONST", "int", "2147483647");
            assertConstantExists(constants, "LONG_CONST", "long", "9223372036854775807L");
            assertConstantExists(constants, "FLOAT_CONST", "float", "3.14f");
            assertConstantExists(constants, "DOUBLE_CONST", "double", "3.141592653589793");
            assertConstantExists(constants, "CHAR_CONST", "char", "'A'");
            assertConstantExists(constants, "BOOLEAN_TRUE", "boolean", "true");
            assertConstantExists(constants, "BOOLEAN_FALSE", "boolean", "false");
        }

        @Test
        @DisplayName("Should parse numeric literals with different formats")
        void testNumericLiteralFormats() throws IOException {
            String javaCode = """
                package com.example;

                public class NumericFormats {
                    public static final int HEX = 0xFF;
                    public static final int OCTAL = 0777;
                    public static final int BINARY = 0b1010;
                    public static final long HEX_LONG = 0xFFL;
                    public static final int UNDERSCORE = 1_000_000;
                    public static final double SCIENTIFIC = 1.5e10;
                    public static final double NEG_SCIENTIFIC = 1.5e-10;
                    public static final float HEX_FLOAT = 0x1.0p10f;
                }
                """;

            Path javaFile = tempDir.resolve("NumericFormats.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(8, constants.size());
            assertConstantExists(constants, "HEX", "int", "0xFF");
            assertConstantExists(constants, "OCTAL", "int", "0777");
            assertConstantExists(constants, "BINARY", "int", "0b1010");
            assertConstantExists(constants, "UNDERSCORE", "int", "1_000_000");
            assertConstantExists(constants, "SCIENTIFIC", "double", "1.5e10");
        }

        @Test
        @DisplayName("Should parse special char literals")
        void testSpecialCharLiterals() throws IOException {
            String javaCode = """
                package com.example;

                public class CharConstants {
                    public static final char NEWLINE = '\\n';
                    public static final char TAB = '\\t';
                    public static final char CARRIAGE_RETURN = '\\r';
                    public static final char BACKSLASH = '\\\\';
                    public static final char SINGLE_QUOTE = '\\'';
                    public static final char NULL_CHAR = '\\0';
                    public static final char UNICODE = '\\u0041';
                }
                """;

            Path javaFile = tempDir.resolve("CharConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(7, constants.size());
            assertConstantExists(constants, "NEWLINE", "char");
            assertConstantExists(constants, "TAB", "char");
            assertConstantExists(constants, "UNICODE", "char");
        }
    }

    // ========================================================================
    // SECTION 2: WRAPPER TYPE CONSTANTS
    // ========================================================================
    @Nested
    @DisplayName("Wrapper Type Constants")
    class WrapperTypeConstantsTest {

        @Test
        @DisplayName("Should parse all wrapper type constants")
        void testAllWrapperTypes() throws IOException {
            String javaCode = """
                package com.example;

                public class WrapperConstants {
                    public static final Byte BYTE_CONST = 127;
                    public static final Short SHORT_CONST = 32767;
                    public static final Integer INT_CONST = 2147483647;
                    public static final Long LONG_CONST = 9223372036854775807L;
                    public static final Float FLOAT_CONST = 3.14f;
                    public static final Double DOUBLE_CONST = 3.141592653589793;
                    public static final Character CHAR_CONST = 'A';
                    public static final Boolean BOOLEAN_CONST = true;
                }
                """;

            Path javaFile = tempDir.resolve("WrapperConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(8, constants.size());
            assertConstantExists(constants, "BYTE_CONST", "Byte");
            assertConstantExists(constants, "SHORT_CONST", "Short");
            assertConstantExists(constants, "INT_CONST", "Integer");
            assertConstantExists(constants, "LONG_CONST", "Long");
            assertConstantExists(constants, "FLOAT_CONST", "Float");
            assertConstantExists(constants, "DOUBLE_CONST", "Double");
            assertConstantExists(constants, "CHAR_CONST", "Character");
            assertConstantExists(constants, "BOOLEAN_CONST", "Boolean");
        }

        @Test
        @DisplayName("Should parse wrapper types with explicit constructor")
        void testWrapperTypeExplicitConstructors() throws IOException {
            String javaCode = """
                package com.example;

                public class WrapperConstructors {
                    public static final Integer INT_NEW = new Integer(42);
                    public static final Long LONG_VALUEOF = Long.valueOf(100L);
                    public static final Boolean BOOL_PARSE = Boolean.parseBoolean("true");
                    public static final Integer INT_PARSE = Integer.parseInt("42");
                }
                """;

            Path javaFile = tempDir.resolve("WrapperConstructors.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertNotNull(findConstantByName(constants, "INT_NEW"));
            assertNotNull(findConstantByName(constants, "LONG_VALUEOF"));
        }
    }

    // ========================================================================
    // SECTION 3: STRING CONSTANTS
    // ========================================================================
    @Nested
    @DisplayName("String Constants")
    class StringConstantsTest {

        @Test
        @DisplayName("Should parse basic string constants")
        void testBasicStringConstants() throws IOException {
            String javaCode = """
                package com.example;

                public class StringConstants {
                    public static final String SIMPLE = "hello";
                    public static final String EMPTY = "";
                    public static final String WITH_SPACES = "hello world";
                    public static final String WITH_NUMBERS = "abc123";
                }
                """;

            Path javaFile = tempDir.resolve("StringConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertConstantExists(constants, "SIMPLE", "String", "\"hello\"");
            assertConstantExists(constants, "EMPTY", "String", "\"\"");
            assertConstantExists(constants, "WITH_SPACES", "String", "\"hello world\"");
        }

        @Test
        @DisplayName("Should parse string constants with escape sequences")
        void testStringEscapeSequences() throws IOException {
            String javaCode = """
                package com.example;

                public class EscapeStrings {
                    public static final String NEWLINE = "line1\\nline2";
                    public static final String TAB = "col1\\tcol2";
                    public static final String QUOTE = "say \\"hello\\"";
                    public static final String BACKSLASH = "path\\\\to\\\\file";
                    public static final String UNICODE = "\\u0041\\u0042\\u0043";
                }
                """;

            Path javaFile = tempDir.resolve("EscapeStrings.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());
            assertConstantExists(constants, "NEWLINE", "String");
            assertConstantExists(constants, "QUOTE", "String");
        }

        @Test
        @DisplayName("Should parse string concatenation constants")
        void testStringConcatenation() throws IOException {
            String javaCode = """
                package com.example;

                public class ConcatStrings {
                    public static final String CONCAT = "hello" + " " + "world";
                    public static final String MULTI_LINE = "line1"
                        + "line2"
                        + "line3";
                    public static final String WITH_VAR = "prefix" + OTHER + "suffix";
                    public static final String OTHER = "middle";
                }
                """;

            Path javaFile = tempDir.resolve("ConcatStrings.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            Constant concatConst = findConstantByName(constants, "CONCAT");
            assertNotNull(concatConst);
            assertTrue(concatConst.value().contains("+"));
        }

        @Test
        @DisplayName("Should parse text block constants (Java 15+) if supported")
        void testTextBlockConstants() throws IOException {
            // Text blocks require Java 15+ language level in JavaParser
            // JavaParser may or may not support this depending on configuration
            String javaCode = """
                package com.example;

                public class TextBlocks {
                    public static final String JSON = \"\"\"
                        {
                            "name": "test",
                            "value": 42
                        }
                        \"\"\";

                    public static final String HTML = \"\"\"
                        <html>
                            <body>Hello</body>
                        </html>
                        \"\"\";
                }
                """;

            Path javaFile = tempDir.resolve("TextBlocks.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may not support text blocks without language level configuration
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                assertEquals(2, constants.size());
                assertConstantExists(constants, "JSON", "String");
                assertConstantExists(constants, "HTML", "String");
            }
        }

        @Test
        @DisplayName("Should parse multi-line string concatenation (all Java versions)")
        void testMultiLineStringConcatenation() throws IOException {
            // This is a fallback test using standard string concatenation
            String javaCode = """
                package com.example;

                public class MultiLineStrings {
                    public static final String JSON = "{\\n" +
                        "  \\"name\\": \\"test\\",\\n" +
                        "  \\"value\\": 42\\n" +
                        "}";

                    public static final String HTML = "<html>\\n" +
                        "  <body>Hello</body>\\n" +
                        "</html>";
                }
                """;

            Path javaFile = tempDir.resolve("MultiLineStrings.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            assertConstantExists(constants, "JSON", "String");
            assertConstantExists(constants, "HTML", "String");
        }

        @Test
        @DisplayName("Should parse null String constant")
        void testNullStringConstant() throws IOException {
            String javaCode = """
                package com.example;

                public class NullString {
                    public static final String NULL_VALUE = null;
                    public static final Object NULL_OBJECT = null;
                }
                """;

            Path javaFile = tempDir.resolve("NullString.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            Constant nullConst = findConstantByName(constants, "NULL_VALUE");
            assertNotNull(nullConst);
            assertEquals("null", nullConst.value());
        }
    }

    // ========================================================================
    // SECTION 4: ARRAY CONSTANTS
    // ========================================================================
    @Nested
    @DisplayName("Array Constants")
    class ArrayConstantsTest {

        @Test
        @DisplayName("Should parse primitive array constants")
        void testPrimitiveArrayConstants() throws IOException {
            String javaCode = """
                package com.example;

                public class ArrayConstants {
                    public static final int[] INT_ARRAY = {1, 2, 3, 4, 5};
                    public static final double[] DOUBLE_ARRAY = {1.1, 2.2, 3.3};
                    public static final boolean[] BOOL_ARRAY = {true, false, true};
                    public static final char[] CHAR_ARRAY = {'a', 'b', 'c'};
                }
                """;

            Path javaFile = tempDir.resolve("ArrayConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertConstantExists(constants, "INT_ARRAY", "int[]");
            assertConstantExists(constants, "DOUBLE_ARRAY", "double[]");
            assertConstantExists(constants, "BOOL_ARRAY", "boolean[]");
            assertConstantExists(constants, "CHAR_ARRAY", "char[]");
        }

        @Test
        @DisplayName("Should parse object array constants")
        void testObjectArrayConstants() throws IOException {
            String javaCode = """
                package com.example;

                public class ObjectArrays {
                    public static final String[] STRING_ARRAY = {"a", "b", "c"};
                    public static final Integer[] INT_WRAPPER_ARRAY = {1, 2, 3};
                    public static final Object[] OBJECT_ARRAY = {"mixed", 42, true};
                }
                """;

            Path javaFile = tempDir.resolve("ObjectArrays.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertConstantExists(constants, "STRING_ARRAY", "String[]");
            assertConstantExists(constants, "INT_WRAPPER_ARRAY", "Integer[]");
        }

        @Test
        @DisplayName("Should parse multi-dimensional array constants")
        void testMultiDimensionalArrayConstants() throws IOException {
            String javaCode = """
                package com.example;

                public class MultiDimArrays {
                    public static final int[][] MATRIX = {{1, 2}, {3, 4}};
                    public static final String[][] STRING_MATRIX = {{"a", "b"}, {"c", "d"}};
                    public static final int[][][] CUBE = {{{1, 2}, {3, 4}}, {{5, 6}, {7, 8}}};
                }
                """;

            Path javaFile = tempDir.resolve("MultiDimArrays.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertConstantExists(constants, "MATRIX", "int[][]");
            assertConstantExists(constants, "STRING_MATRIX", "String[][]");
            assertConstantExists(constants, "CUBE", "int[][][]");
        }

        @Test
        @DisplayName("Should parse array with new keyword")
        void testArrayWithNewKeyword() throws IOException {
            String javaCode = """
                package com.example;

                public class NewArrays {
                    public static final int[] SIZED_ARRAY = new int[10];
                    public static final String[] INIT_ARRAY = new String[]{"x", "y"};
                    public static final int[][] SIZED_MATRIX = new int[3][3];
                }
                """;

            Path javaFile = tempDir.resolve("NewArrays.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertConstantExists(constants, "SIZED_ARRAY", "int[]");
            assertConstantExists(constants, "INIT_ARRAY", "String[]");
        }
    }

    // ========================================================================
    // SECTION 5: COMPLEX INITIALIZERS
    // ========================================================================
    @Nested
    @DisplayName("Complex Initializer Constants")
    class ComplexInitializerTest {

        @Test
        @DisplayName("Should parse constants with method call initializers")
        void testMethodCallInitializers() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.*;

                public class MethodCallInit {
                    public static final List<String> LIST = Arrays.asList("a", "b", "c");
                    public static final List<Integer> NUMBERS = List.of(1, 2, 3);
                    public static final Set<String> SET = Set.of("x", "y", "z");
                    public static final Map<String, Integer> MAP = Map.of("a", 1, "b", 2);
                    public static final String UPPER = "hello".toUpperCase();
                    public static final int LENGTH = "test".length();
                }
                """;

            Path javaFile = tempDir.resolve("MethodCallInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(6, constants.size());

            Constant listConst = findConstantByName(constants, "LIST");
            assertNotNull(listConst);
            assertTrue(listConst.value().contains("Arrays.asList"));
        }

        @Test
        @DisplayName("Should parse constants with constructor initializers")
        void testConstructorInitializers() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.*;
                import java.math.*;

                public class ConstructorInit {
                    public static final ArrayList<String> ARRAY_LIST = new ArrayList<>();
                    public static final HashMap<String, Object> HASH_MAP = new HashMap<>();
                    public static final StringBuilder BUILDER = new StringBuilder("initial");
                    public static final BigDecimal DECIMAL = new BigDecimal("123.456");
                    public static final BigInteger BIG_INT = new BigInteger("999999999999");
                }
                """;

            Path javaFile = tempDir.resolve("ConstructorInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());

            Constant arrayListConst = findConstantByName(constants, "ARRAY_LIST");
            assertNotNull(arrayListConst);
            assertTrue(arrayListConst.value().contains("new ArrayList"));
        }

        @Test
        @DisplayName("Should parse constants with binary expressions")
        void testBinaryExpressionInitializers() throws IOException {
            String javaCode = """
                package com.example;

                public class BinaryExpInit {
                    public static final int SUM = 10 + 20;
                    public static final int PRODUCT = 5 * 6;
                    public static final int BITWISE_AND = 0xFF & 0x0F;
                    public static final int BITWISE_OR = 0x0F | 0xF0;
                    public static final int LEFT_SHIFT = 1 << 8;
                    public static final int RIGHT_SHIFT = 256 >> 4;
                    public static final boolean LOGICAL = true && false;
                    public static final int COMPLEX = (10 + 20) * (5 - 3) / 2;
                }
                """;

            Path javaFile = tempDir.resolve("BinaryExpInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(8, constants.size());

            Constant sumConst = findConstantByName(constants, "SUM");
            assertNotNull(sumConst);
            assertTrue(sumConst.value().contains("+"));
        }

        @Test
        @DisplayName("Should parse constants with ternary expressions")
        void testTernaryExpressionInitializers() throws IOException {
            String javaCode = """
                package com.example;

                public class TernaryInit {
                    public static final boolean CONDITION = true;
                    public static final int TERNARY = CONDITION ? 1 : 0;
                    public static final String TERNARY_STR = true ? "yes" : "no";
                    public static final int NESTED = true ? (false ? 1 : 2) : 3;
                }
                """;

            Path javaFile = tempDir.resolve("TernaryInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());

            Constant ternaryConst = findConstantByName(constants, "TERNARY");
            assertNotNull(ternaryConst);
            assertTrue(ternaryConst.value().contains("?"));
        }

        @Test
        @DisplayName("Should parse constants with lambda expressions")
        void testLambdaExpressionInitializers() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.function.*;

                public class LambdaInit {
                    public static final Runnable RUNNABLE = () -> System.out.println("run");
                    public static final Consumer<String> CONSUMER = s -> System.out.println(s);
                    public static final Function<Integer, String> FUNCTION = i -> String.valueOf(i);
                    public static final BiFunction<Integer, Integer, Integer> ADD = (a, b) -> a + b;
                    public static final Predicate<String> NOT_EMPTY = s -> !s.isEmpty();
                }
                """;

            Path javaFile = tempDir.resolve("LambdaInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());

            Constant runnableConst = findConstantByName(constants, "RUNNABLE");
            assertNotNull(runnableConst);
            assertTrue(runnableConst.value().contains("->"));
        }

        @Test
        @DisplayName("Should parse constants with method references")
        void testMethodReferenceInitializers() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.function.*;

                public class MethodRefInit {
                    public static final Consumer<String> PRINTLN = System.out::println;
                    public static final Function<String, Integer> PARSE_INT = Integer::parseInt;
                    public static final Supplier<String> TO_STRING = Object::toString;
                    public static final Comparator<String> COMPARE = String::compareTo;
                }
                """;

            Path javaFile = tempDir.resolve("MethodRefInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());

            Constant printlnConst = findConstantByName(constants, "PRINTLN");
            assertNotNull(printlnConst);
            assertTrue(printlnConst.value().contains("::"));
        }

        @Test
        @DisplayName("Should parse constants with class literals")
        void testClassLiteralInitializers() throws IOException {
            String javaCode = """
                package com.example;

                public class ClassLiteralInit {
                    public static final Class<String> STRING_CLASS = String.class;
                    public static final Class<?> INT_CLASS = int.class;
                    public static final Class<int[]> INT_ARRAY_CLASS = int[].class;
                    public static final Class<Void> VOID_CLASS = Void.class;
                }
                """;

            Path javaFile = tempDir.resolve("ClassLiteralInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertConstantExists(constants, "STRING_CLASS", "Class<String>");
            assertConstantExists(constants, "INT_CLASS", "Class<?>");
        }

        @Test
        @DisplayName("Should parse constants with cast expressions")
        void testCastExpressionInitializers() throws IOException {
            String javaCode = """
                package com.example;

                public class CastInit {
                    public static final long CAST_TO_LONG = (long) 42;
                    public static final double CAST_TO_DOUBLE = (double) 3.14f;
                    public static final Object CAST_TO_OBJECT = (Object) "string";
                    public static final int COMPLEX_CAST = (int) ((long) 100 * 2);
                }
                """;

            Path javaFile = tempDir.resolve("CastInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
        }
    }

    // ========================================================================
    // SECTION 6: GENERICS
    // ========================================================================
    @Nested
    @DisplayName("Generic Type Constants")
    class GenericTypeConstantsTest {

        @Test
        @DisplayName("Should parse constants with simple generic types")
        void testSimpleGenericTypes() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.*;

                public class SimpleGenerics {
                    public static final List<String> STRING_LIST = new ArrayList<>();
                    public static final Set<Integer> INT_SET = new HashSet<>();
                    public static final Queue<Double> DOUBLE_QUEUE = new LinkedList<>();
                    public static final Optional<String> OPTIONAL = Optional.empty();
                }
                """;

            Path javaFile = tempDir.resolve("SimpleGenerics.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertConstantExists(constants, "STRING_LIST", "List<String>");
            assertConstantExists(constants, "INT_SET", "Set<Integer>");
            assertConstantExists(constants, "OPTIONAL", "Optional<String>");
        }

        @Test
        @DisplayName("Should parse constants with nested generic types")
        void testNestedGenericTypes() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.*;

                public class NestedGenerics {
                    public static final Map<String, List<Integer>> MAP_OF_LISTS = new HashMap<>();
                    public static final List<Map<String, Object>> LIST_OF_MAPS = new ArrayList<>();
                    public static final Map<String, Map<String, String>> NESTED_MAPS = new HashMap<>();
                }
                """;

            Path javaFile = tempDir.resolve("NestedGenerics.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            // Note: JavaParser may format generic types with or without spaces
            Constant mapOfLists = findConstantByName(constants, "MAP_OF_LISTS");
            assertNotNull(mapOfLists);
            assertTrue(mapOfLists.type().contains("Map") && mapOfLists.type().contains("List"));
        }

        @Test
        @DisplayName("Should parse constants with wildcard generic types")
        void testWildcardGenericTypes() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.*;

                public class WildcardGenerics {
                    public static final List<?> UNBOUNDED = new ArrayList<>();
                    public static final List<? extends Number> UPPER_BOUNDED = new ArrayList<>();
                    public static final List<? super Integer> LOWER_BOUNDED = new ArrayList<>();
                    public static final Map<String, ? extends Comparable<?>> COMPLEX = new HashMap<>();
                }
                """;

            Path javaFile = tempDir.resolve("WildcardGenerics.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertConstantExists(constants, "UNBOUNDED", "List<?>");
            assertConstantExists(constants, "UPPER_BOUNDED", "List<? extends Number>");
            assertConstantExists(constants, "LOWER_BOUNDED", "List<? super Integer>");
        }
    }

    // ========================================================================
    // SECTION 7: ACCESS MODIFIERS
    // ========================================================================
    @Nested
    @DisplayName("Access Modifier Variations")
    class AccessModifierTest {

        @Test
        @DisplayName("Should parse only public static final constants")
        void testAllAccessModifiers() throws IOException {
            String javaCode = """
                package com.example;

                public class AccessModifiers {
                    public static final String PUBLIC_CONST = "public";
                    protected static final String PROTECTED_CONST = "protected";
                    static final String PACKAGE_CONST = "package";
                    private static final String PRIVATE_CONST = "private";
                }
                """;

            Path javaFile = tempDir.resolve("AccessModifiers.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Only public static final fields are cataloged
            assertEquals(1, constants.size());
            assertConstantExists(constants, "PUBLIC_CONST", "String");
        }

        @Test
        @DisplayName("Should NOT parse non-static or non-final fields")
        void testNonConstantFields() throws IOException {
            String javaCode = """
                package com.example;

                public class NonConstants {
                    public static String NOT_FINAL = "not final";
                    public final String NOT_STATIC = "not static";
                    public String NEITHER = "neither";
                    private String INSTANCE = "instance";
                    public static final String ACTUAL_CONST = "constant";
                }
                """;

            Path javaFile = tempDir.resolve("NonConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
            assertEquals("ACTUAL_CONST", constants.get(0).name());
        }
    }

    // ========================================================================
    // SECTION 8: MULTIPLE VARIABLES IN SINGLE DECLARATION
    // ========================================================================
    @Nested
    @DisplayName("Multiple Variable Declarations")
    class MultipleVariableDeclarationTest {

        @Test
        @DisplayName("Should parse multiple constants in single declaration")
        void testMultipleConstantsInDeclaration() throws IOException {
            String javaCode = """
                package com.example;

                public class MultiConstants {
                    public static final int A = 1, B = 2, C = 3;
                    public static final String X = "x", Y = "y";
                    public static final double PI = 3.14, E = 2.71;
                }
                """;

            Path javaFile = tempDir.resolve("MultiConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(7, constants.size());
            assertConstantExists(constants, "A", "int", "1");
            assertConstantExists(constants, "B", "int", "2");
            assertConstantExists(constants, "C", "int", "3");
            assertConstantExists(constants, "X", "String");
            assertConstantExists(constants, "Y", "String");
            assertConstantExists(constants, "PI", "double");
            assertConstantExists(constants, "E", "double");
        }
    }

    // ========================================================================
    // SECTION 9: INNER CLASSES
    // ========================================================================
    @Nested
    @DisplayName("Inner Class Constants")
    class InnerClassTest {

        @Test
        @DisplayName("Should parse constants in nested inner classes")
        void testNestedInnerClasses() throws IOException {
            String javaCode = """
                package com.example;

                public class Outer {
                    public static final String OUTER_CONST = "outer";

                    public static class Inner1 {
                        public static final String INNER1_CONST = "inner1";

                        public static class Inner2 {
                            public static final String INNER2_CONST = "inner2";

                            public static class Inner3 {
                                public static final String INNER3_CONST = "inner3";
                            }
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Outer.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());

            Constant outerConst = findConstantByName(constants, "OUTER_CONST");
            assertEquals("Outer", outerConst.className());

            Constant inner1Const = findConstantByName(constants, "INNER1_CONST");
            assertEquals("Inner1", inner1Const.className());

            Constant inner2Const = findConstantByName(constants, "INNER2_CONST");
            assertEquals("Inner2", inner2Const.className());

            Constant inner3Const = findConstantByName(constants, "INNER3_CONST");
            assertEquals("Inner3", inner3Const.className());
        }

        @Test
        @DisplayName("Should parse constants in multiple sibling inner classes")
        void testSiblingInnerClasses() throws IOException {
            String javaCode = """
                package com.example;

                public class Parent {
                    public static final String PARENT_CONST = "parent";

                    public static class Child1 {
                        public static final String CHILD1_CONST = "child1";
                    }

                    public static class Child2 {
                        public static final String CHILD2_CONST = "child2";
                    }

                    public static class Child3 {
                        public static final String CHILD3_CONST = "child3";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Parent.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertEquals("Parent", findConstantByName(constants, "PARENT_CONST").className());
            assertEquals("Child1", findConstantByName(constants, "CHILD1_CONST").className());
            assertEquals("Child2", findConstantByName(constants, "CHILD2_CONST").className());
            assertEquals("Child3", findConstantByName(constants, "CHILD3_CONST").className());
        }

        @Test
        @DisplayName("Should parse constants in non-static inner classes")
        void testNonStaticInnerClass() throws IOException {
            String javaCode = """
                package com.example;

                public class Outer {
                    public static final String OUTER_CONST = "outer";

                    public class NonStaticInner {
                        // Note: Non-static inner classes CAN have static final fields in Java 16+
                        public static final String INNER_CONST = "inner";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Outer.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }
    }

    // ========================================================================
    // SECTION 10: INTERFACES
    // ========================================================================
    @Nested
    @DisplayName("Interface Constants")
    class InterfaceConstantsTest {

        @Test
        @DisplayName("Should parse constants in interfaces (implicitly public static final)")
        void testInterfaceConstants() throws IOException {
            String javaCode = """
                package com.example;

                public interface Constants {
                    String CONST1 = "const1";
                    int CONST2 = 42;
                    double CONST3 = 3.14;

                    // Explicit modifiers (redundant but valid)
                    public static final String CONST4 = "const4";
                }
                """;

            Path javaFile = tempDir.resolve("Constants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Interface fields are implicitly public static final
            // But our parser only looks for explicit static final
            // This test verifies the current behavior
            assertTrue(constants.size() >= 1);
            assertNotNull(findConstantByName(constants, "CONST4"));
        }

        @Test
        @DisplayName("Should parse constants in nested interfaces")
        void testNestedInterfaceConstants() throws IOException {
            String javaCode = """
                package com.example;

                public class Outer {
                    public static final String OUTER_CONST = "outer";

                    public interface InnerInterface {
                        public static final String INTERFACE_CONST = "interface";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Outer.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            assertConstantExists(constants, "OUTER_CONST", "String");
            assertConstantExists(constants, "INTERFACE_CONST", "String");
        }
    }

    // ========================================================================
    // SECTION 11: ENUMS
    // ========================================================================
    @Nested
    @DisplayName("Enum Constants")
    class EnumConstantsTest {

        @Test
        @DisplayName("Should parse static final constants in enums")
        void testEnumWithConstants() throws IOException {
            String javaCode = """
                package com.example;

                public enum Status {
                    ACTIVE, INACTIVE, PENDING;

                    public static final String STATUS_PREFIX = "STATUS_";
                    public static final int MAX_STATUS = 3;
                }
                """;

            Path javaFile = tempDir.resolve("Status.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Should only find explicit static final fields, not enum values
            assertEquals(2, constants.size());
            assertConstantExists(constants, "STATUS_PREFIX", "String");
            assertConstantExists(constants, "MAX_STATUS", "int");
        }

        @Test
        @DisplayName("Should parse constants in enum with constructor")
        void testEnumWithConstructorAndConstants() throws IOException {
            String javaCode = """
                package com.example;

                public enum Color {
                    RED(255, 0, 0),
                    GREEN(0, 255, 0),
                    BLUE(0, 0, 255);

                    public static final String COLOR_PREFIX = "COLOR_";
                    public static final int MAX_VALUE = 255;

                    private final int r, g, b;

                    Color(int r, int g, int b) {
                        this.r = r;
                        this.g = g;
                        this.b = b;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Color.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            assertConstantExists(constants, "COLOR_PREFIX", "String");
            assertConstantExists(constants, "MAX_VALUE", "int");
        }
    }

    // ========================================================================
    // SECTION 12: RECORDS (Java 16+)
    // ========================================================================
    @Nested
    @DisplayName("Record Constants")
    class RecordConstantsTest {

        @Test
        @DisplayName("Should parse static final constants in records (if JavaParser supports)")
        void testRecordWithConstants() throws IOException {
            // Records require Java 16+ language level in JavaParser
            String javaCode = """
                package com.example;

                public record Person(String name, int age) {
                    public static final String RECORD_TYPE = "Person";
                    public static final int MIN_AGE = 0;
                    public static final int MAX_AGE = 150;
                }
                """;

            Path javaFile = tempDir.resolve("Person.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may not support records without language level configuration
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                assertEquals(3, constants.size());
                assertConstantExists(constants, "RECORD_TYPE", "String");
                assertConstantExists(constants, "MIN_AGE", "int");
                assertConstantExists(constants, "MAX_AGE", "int");
            }
        }

        @Test
        @DisplayName("Should parse constants in regular class as fallback")
        void testClassWithRecordLikeStructure() throws IOException {
            // Fallback test using a regular class with similar structure
            String javaCode = """
                package com.example;

                public final class PersonClass {
                    public static final String RECORD_TYPE = "Person";
                    public static final int MIN_AGE = 0;
                    public static final int MAX_AGE = 150;

                    private final String name;
                    private final int age;

                    public PersonClass(String name, int age) {
                        this.name = name;
                        this.age = age;
                    }
                }
                """;

            Path javaFile = tempDir.resolve("PersonClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertConstantExists(constants, "RECORD_TYPE", "String");
            assertConstantExists(constants, "MIN_AGE", "int");
            assertConstantExists(constants, "MAX_AGE", "int");
        }
    }

    // ========================================================================
    // SECTION 13: ANNOTATIONS
    // ========================================================================
    @Nested
    @DisplayName("Annotated Constants")
    class AnnotatedConstantsTest {

        @Test
        @DisplayName("Should parse constants with annotations")
        void testAnnotatedConstants() throws IOException {
            String javaCode = """
                package com.example;

                public class AnnotatedConstants {
                    @Deprecated
                    public static final String OLD_CONST = "old";

                    @SuppressWarnings("unused")
                    public static final int UNUSED_CONST = 42;

                    @Deprecated
                    @SuppressWarnings("all")
                    public static final String MULTI_ANNOTATED = "multi";
                }
                """;

            Path javaFile = tempDir.resolve("AnnotatedConstants.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());
            assertConstantExists(constants, "OLD_CONST", "String");
            assertConstantExists(constants, "UNUSED_CONST", "int");
            assertConstantExists(constants, "MULTI_ANNOTATED", "String");
        }
    }

    // ========================================================================
    // SECTION 14: PARAMETER USAGE DETECTION - @Value ANNOTATIONS
    // ========================================================================
    @Nested
    @DisplayName("Parameter Usage - @Value Annotations")
    class ValueAnnotationTest {

        @Test
        @DisplayName("Should detect simple @Value annotations")
        void testSimpleValueAnnotations() throws IOException {
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;

                public class ConfigClass {
                    @Value("${database.url}")
                    private String dbUrl;

                    @Value("${database.username}")
                    private String dbUsername;

                    @Value("${database.password}")
                    private String dbPassword;
                }
                """;

            Path javaFile = tempDir.resolve("ConfigClass.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("database.url", "database.username", "database.password");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(3, usages.size());
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("database.url")));
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("database.username")));
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("database.password")));
        }

        @Test
        @DisplayName("Should detect @Value annotations with default values")
        void testValueAnnotationsWithDefaults() throws IOException {
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;

                public class DefaultConfig {
                    @Value("${server.port:8080}")
                    private int serverPort;

                    @Value("${server.host:localhost}")
                    private String serverHost;

                    @Value("${debug.enabled:false}")
                    private boolean debugEnabled;

                    @Value("${timeout.seconds:30}")
                    private long timeoutSeconds;
                }
                """;

            Path javaFile = tempDir.resolve("DefaultConfig.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("server.port", "server.host", "debug.enabled", "timeout.seconds");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(4, usages.size());
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("server.port")));
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("server.host")));
        }

        @Test
        @DisplayName("Should detect @Value with SpEL expressions")
        void testValueAnnotationsWithSpel() throws IOException {
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;

                public class SpelConfig {
                    @Value("#{${my.list}}")
                    private List<String> myList;

                    @Value("${app.name}")
                    private String appName;
                }
                """;

            Path javaFile = tempDir.resolve("SpelConfig.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("my.list", "app.name");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            // Should find at least app.name
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("app.name")));
        }

        @Test
        @DisplayName("Should NOT detect @Value with unknown parameters")
        void testValueAnnotationsWithUnknownParams() throws IOException {
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;

                public class UnknownConfig {
                    @Value("${unknown.param}")
                    private String unknownParam;

                    @Value("${known.param}")
                    private String knownParam;
                }
                """;

            Path javaFile = tempDir.resolve("UnknownConfig.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("known.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
            assertEquals("known.param", usages.get(0).parameterName());
        }
    }

    // ========================================================================
    // SECTION 15: PARAMETER USAGE DETECTION - METHOD CALLS
    // ========================================================================
    @Nested
    @DisplayName("Parameter Usage - Method Calls")
    class MethodCallParameterTest {

        @Test
        @DisplayName("Should detect getProperty method calls")
        void testGetPropertyCalls() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.Properties;

                public class PropReader {
                    public void readProps(Properties props) {
                        String host = props.getProperty("db.host");
                        String port = props.getProperty("db.port");
                        String driver = props.getProperty("db.driver");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("PropReader.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("db.host", "db.port");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(2, usages.size());
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("db.host")));
            assertTrue(usages.stream().anyMatch(u -> u.parameterName().equals("db.port")));
        }

        @ParameterizedTest
        @ValueSource(strings = {"get", "getString", "getInt", "getInteger", "getLong",
                                "getBoolean", "getDouble", "getFloat", "getValue",
                                "getConfig", "getenv", "getOrDefault", "getPropertyValue"})
        @DisplayName("Should detect various property getter methods")
        void testVariousPropertyGetters(String methodName) throws IOException {
            String javaCode = String.format("""
                package com.example;

                public class PropGetter {
                    public void getProp(Object config) {
                        Object value = config.%s("test.param");
                    }
                }
                """, methodName);

            Path javaFile = tempDir.resolve("PropGetter.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("test.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
            assertEquals("test.param", usages.get(0).parameterName());
        }

        @Test
        @DisplayName("Should detect nested method call parameter usages")
        void testNestedMethodCalls() throws IOException {
            String javaCode = """
                package com.example;

                public class NestedCalls {
                    public void process(Properties props) {
                        if (props.getProperty("feature.enabled") != null) {
                            String value = Optional.ofNullable(props.getProperty("feature.value"))
                                .orElse("default");
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("NestedCalls.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("feature.enabled", "feature.value");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(2, usages.size());
        }

        @Test
        @DisplayName("Should track correct class name for parameter usages in inner classes")
        void testParameterUsageInInnerClass() throws IOException {
            String javaCode = """
                package com.example;

                public class Outer {
                    public void outerMethod(Properties props) {
                        String value = props.getProperty("outer.param");
                    }

                    public static class Inner {
                        public void innerMethod(Properties props) {
                            String value = props.getProperty("inner.param");
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("Outer.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("outer.param", "inner.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(2, usages.size());

            ParameterUsage outerUsage = usages.stream()
                .filter(u -> u.parameterName().equals("outer.param"))
                .findFirst().orElse(null);
            assertNotNull(outerUsage);
            assertEquals("Outer", outerUsage.usedInClass());

            ParameterUsage innerUsage = usages.stream()
                .filter(u -> u.parameterName().equals("inner.param"))
                .findFirst().orElse(null);
            assertNotNull(innerUsage);
            assertEquals("Inner", innerUsage.usedInClass());
        }
    }

    // ========================================================================
    // SECTION 16: LINE NUMBER TRACKING
    // ========================================================================
    @Nested
    @DisplayName("Line Number Tracking")
    class LineNumberTest {

        @Test
        @DisplayName("Should track correct line numbers for constants")
        void testConstantLineNumbers() throws IOException {
            String javaCode = """
                package com.example;

                public class LineNumbers {
                    public static final String LINE_4 = "line4";

                    public static final String LINE_6 = "line6";



                    public static final String LINE_10 = "line10";
                }
                """;

            Path javaFile = tempDir.resolve("LineNumbers.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(3, constants.size());

            Constant line4 = findConstantByName(constants, "LINE_4");
            assertEquals(4, line4.lineNumber());

            Constant line6 = findConstantByName(constants, "LINE_6");
            assertEquals(6, line6.lineNumber());

            Constant line10 = findConstantByName(constants, "LINE_10");
            assertEquals(10, line10.lineNumber());
        }

        @Test
        @DisplayName("Should track correct line numbers for parameter usages")
        void testParameterUsageLineNumbers() throws IOException {
            String javaCode = """
                package com.example;

                public class UsageLines {
                    public void method(Properties props) {
                        String a = props.getProperty("param.a");

                        String b = props.getProperty("param.b");


                        String c = props.getProperty("param.c");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("UsageLines.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("param.a", "param.b", "param.c");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(3, usages.size());

            ParameterUsage usageA = usages.stream()
                .filter(u -> u.parameterName().equals("param.a"))
                .findFirst().orElse(null);
            assertNotNull(usageA);
            assertEquals(5, usageA.lineNumber());
        }
    }

    // ========================================================================
    // SECTION 17: EDGE CASES AND ERROR HANDLING
    // ========================================================================
    @Nested
    @DisplayName("Edge Cases and Error Handling")
    class EdgeCasesTest {

        @Test
        @DisplayName("Should handle empty file")
        void testEmptyFile() throws IOException {
            Path javaFile = tempDir.resolve("Empty.java");
            Files.writeString(javaFile, "");

            List<Constant> constants = parser.parseConstants(javaFile);
            assertTrue(constants.isEmpty());

            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, Set.of("any"));
            assertTrue(usages.isEmpty());
        }

        @Test
        @DisplayName("Should handle file with only comments")
        void testOnlyCommentsFile() throws IOException {
            String javaCode = """
                // This is a comment
                /* This is a block comment */
                /**
                 * This is a JavaDoc comment
                 */
                """;

            Path javaFile = tempDir.resolve("OnlyComments.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);
            assertTrue(constants.isEmpty());
        }

        @Test
        @DisplayName("Should handle file with only package declaration")
        void testOnlyPackageFile() throws IOException {
            String javaCode = "package com.example;";

            Path javaFile = tempDir.resolve("OnlyPackage.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);
            assertTrue(constants.isEmpty());
        }

        @Test
        @DisplayName("Should handle file with only imports")
        void testOnlyImportsFile() throws IOException {
            String javaCode = """
                package com.example;

                import java.util.*;
                import java.io.*;
                import static java.lang.Math.*;
                """;

            Path javaFile = tempDir.resolve("OnlyImports.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);
            assertTrue(constants.isEmpty());
        }

        @Test
        @DisplayName("Should handle malformed Java code gracefully")
        void testMalformedJavaCode() throws IOException {
            String javaCode = """
                package com.example

                public class Broken {
                    public static final String CONST = "test"
                    // Missing semicolons and syntax errors
                    public void method( {
                        int x =
                    }
                """;

            Path javaFile = tempDir.resolve("Broken.java");
            Files.writeString(javaFile, javaCode);

            // Should not throw, should return empty list
            List<Constant> constants = parser.parseConstants(javaFile);
            assertTrue(constants.isEmpty());
        }

        @Test
        @DisplayName("Should handle file with Unicode characters")
        void testUnicodeCharacters() throws IOException {
            String javaCode = """
                package com.example;

                public class UnicodeTest {
                    public static final String JAPANESE = "こんにちは";
                    public static final String CHINESE = "你好";
                    public static final String EMOJI = "Hello 👋 World 🌍";
                    public static final String ARABIC = "مرحبا";
                    public static final String RUSSIAN = "Привет";
                }
                """;

            Path javaFile = tempDir.resolve("UnicodeTest.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(5, constants.size());
            assertConstantExists(constants, "JAPANESE", "String");
            assertConstantExists(constants, "CHINESE", "String");
            assertConstantExists(constants, "EMOJI", "String");
        }

        @Test
        @DisplayName("Should handle non-existent file gracefully")
        void testNonExistentFile() {
            Path nonExistent = tempDir.resolve("NonExistent.java");

            // Should not throw, should return empty list
            List<Constant> constants = parser.parseConstants(nonExistent);
            assertTrue(constants.isEmpty());

            List<ParameterUsage> usages = parser.parseParameterUsages(nonExistent, Set.of("any"));
            assertTrue(usages.isEmpty());
        }

        @Test
        @DisplayName("Should handle file with unusual whitespace")
        void testUnusualWhitespace() throws IOException {
            String javaCode = "package com.example;\n\n\n\n" +
                "public   class    Whitespace    {\n" +
                "    public    static    final    String    CONST    =    \"value\"    ;\n" +
                "}\n";

            Path javaFile = tempDir.resolve("Whitespace.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
            assertEquals("CONST", constants.get(0).name());
        }

        @Test
        @DisplayName("Should handle constants without initializers")
        void testConstantsWithoutInitializers() throws IOException {
            // This is technically invalid Java for final fields, but parser should handle it
            String javaCode = """
                package com.example;

                public class NoInit {
                    public static final String CONST;

                    static {
                        CONST = "initialized in static block";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("NoInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
            Constant constant = constants.get(0);
            assertEquals("CONST", constant.name());
            assertEquals("", constant.value()); // No initializer in declaration
        }

        @Test
        @DisplayName("Should handle empty knownParameters set")
        void testEmptyKnownParameters() throws IOException {
            String javaCode = """
                package com.example;

                public class PropUser {
                    public void method(Properties props) {
                        String value = props.getProperty("some.param");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("PropUser.java");
            Files.writeString(javaFile, javaCode);

            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, Set.of());
            assertTrue(usages.isEmpty());
        }
    }

    // ========================================================================
    // SECTION 18: ABSTRACT AND FINAL CLASSES
    // ========================================================================
    @Nested
    @DisplayName("Abstract and Final Classes")
    class AbstractFinalClassTest {

        @Test
        @DisplayName("Should parse constants in abstract classes")
        void testAbstractClassConstants() throws IOException {
            String javaCode = """
                package com.example;

                public abstract class AbstractClass {
                    public static final String CONST1 = "const1";
                    public static final int CONST2 = 42;

                    public abstract void doSomething();
                }
                """;

            Path javaFile = tempDir.resolve("AbstractClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            assertConstantExists(constants, "CONST1", "String");
            assertConstantExists(constants, "CONST2", "int");
        }

        @Test
        @DisplayName("Should parse constants in final classes")
        void testFinalClassConstants() throws IOException {
            String javaCode = """
                package com.example;

                public final class FinalClass {
                    public static final String CONST1 = "const1";
                    public static final int CONST2 = 42;
                }
                """;

            Path javaFile = tempDir.resolve("FinalClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
        }
    }

    // ========================================================================
    // SECTION 19: GENERIC CLASSES
    // ========================================================================
    @Nested
    @DisplayName("Generic Class Constants")
    class GenericClassTest {

        @Test
        @DisplayName("Should parse constants in generic classes")
        void testGenericClassConstants() throws IOException {
            String javaCode = """
                package com.example;

                public class GenericClass<T, U extends Comparable<U>> {
                    public static final String CONST = "generic class constant";
                    public static final int COUNT = 100;

                    private T value;

                    public void process(T item) { }
                }
                """;

            Path javaFile = tempDir.resolve("GenericClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(2, constants.size());
            assertConstantExists(constants, "CONST", "String");
            assertConstantExists(constants, "COUNT", "int");
        }
    }

    // ========================================================================
    // SECTION 20: ANONYMOUS CLASSES
    // ========================================================================
    @Nested
    @DisplayName("Anonymous Class Handling")
    class AnonymousClassTest {

        @Test
        @DisplayName("Should handle anonymous classes (no constants expected)")
        void testAnonymousClass() throws IOException {
            String javaCode = """
                package com.example;

                public class WithAnonymous {
                    public static final String CONST = "outer constant";

                    public static final Runnable RUNNER = new Runnable() {
                        // Anonymous class - fields here would not be static final
                        @Override
                        public void run() {
                            System.out.println("Running");
                        }
                    };
                }
                """;

            Path javaFile = tempDir.resolve("WithAnonymous.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Should find CONST and RUNNER (both are static final)
            assertEquals(2, constants.size());
            assertConstantExists(constants, "CONST", "String");
            assertConstantExists(constants, "RUNNER", "Runnable");
        }
    }

    // ========================================================================
    // SECTION 21: LOCAL CLASSES
    // ========================================================================
    @Nested
    @DisplayName("Local Class Handling")
    class LocalClassTest {

        @Test
        @DisplayName("Should parse constants in classes with local classes")
        void testLocalClass() throws IOException {
            String javaCode = """
                package com.example;

                public class WithLocalClass {
                    public static final String CONST = "outer constant";

                    public void method() {
                        class LocalClass {
                            // Local classes cannot have static members (pre-Java 16)
                            // But in Java 16+ they can have static final fields
                            public static final String LOCAL_CONST = "local";
                        }
                    }
                }
                """;

            Path javaFile = tempDir.resolve("WithLocalClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Should find at least CONST
            assertTrue(constants.size() >= 1);
            assertConstantExists(constants, "CONST", "String");
        }
    }

    // ========================================================================
    // SECTION 22: SEALED CLASSES (Java 17+)
    // ========================================================================
    @Nested
    @DisplayName("Sealed Class Constants")
    class SealedClassTest {

        @Test
        @DisplayName("Should parse constants in sealed classes (if JavaParser supports)")
        void testSealedClassConstants() throws IOException {
            // Note: JavaParser may require specific language level configuration for sealed classes
            // This test verifies graceful handling whether parsing succeeds or fails
            String javaCode = """
                package com.example;

                public sealed class Shape permits Circle, Rectangle {
                    public static final String TYPE = "Shape";
                    public static final double PI = 3.14159;
                }

                final class Circle extends Shape {
                    public static final String CIRCLE_TYPE = "Circle";
                }

                final class Rectangle extends Shape {
                    public static final String RECT_TYPE = "Rectangle";
                }
                """;

            Path javaFile = tempDir.resolve("Shape.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // JavaParser may or may not support sealed classes depending on configuration
            // The important thing is it handles gracefully (returns empty or parses correctly)
            assertNotNull(constants);
            if (!constants.isEmpty()) {
                // If parsing succeeded, verify the constants are correct
                assertTrue(constants.size() >= 2, "Should find at least the Shape class constants");
            }
        }

        @Test
        @DisplayName("Should parse regular final classes as fallback for sealed class syntax")
        void testFinalClassesWithoutSealed() throws IOException {
            // This test uses non-sealed syntax to verify parsing works
            String javaCode = """
                package com.example;

                public abstract class BaseShape {
                    public static final String TYPE = "Shape";
                    public static final double PI = 3.14159;
                }

                final class CircleShape extends BaseShape {
                    public static final String CIRCLE_TYPE = "Circle";
                }

                final class RectangleShape extends BaseShape {
                    public static final String RECT_TYPE = "Rectangle";
                }
                """;

            Path javaFile = tempDir.resolve("BaseShape.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(4, constants.size());
            assertConstantExists(constants, "TYPE", "String");
            assertConstantExists(constants, "PI", "double");
            assertConstantExists(constants, "CIRCLE_TYPE", "String");
            assertConstantExists(constants, "RECT_TYPE", "String");
        }
    }

    // ========================================================================
    // SECTION 23: LARGE FILES
    // ========================================================================
    @Nested
    @DisplayName("Large File Handling")
    class LargeFileTest {

        @Test
        @DisplayName("Should handle file with many constants")
        void testManyConstants() throws IOException {
            StringBuilder code = new StringBuilder();
            code.append("package com.example;\n\n");
            code.append("public class ManyConstants {\n");

            for (int i = 0; i < 1000; i++) {
                code.append(String.format("    public static final int CONST_%d = %d;\n", i, i));
            }

            code.append("}\n");

            Path javaFile = tempDir.resolve("ManyConstants.java");
            Files.writeString(javaFile, code.toString());

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1000, constants.size());
        }

        @Test
        @DisplayName("Should handle file with many classes")
        void testManyClasses() throws IOException {
            StringBuilder code = new StringBuilder();
            code.append("package com.example;\n\n");
            code.append("public class ManyClasses {\n");
            code.append("    public static final String MAIN = \"main\";\n");

            for (int i = 0; i < 100; i++) {
                code.append(String.format("    public static class Inner%d {\n", i));
                code.append(String.format("        public static final String INNER_%d = \"inner%d\";\n", i, i));
                code.append("    }\n");
            }

            code.append("}\n");

            Path javaFile = tempDir.resolve("ManyClasses.java");
            Files.writeString(javaFile, code.toString());

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(101, constants.size()); // 1 main + 100 inner
        }
    }

    // ========================================================================
    // SECTION 24: CONTEXT CAPTURE
    // ========================================================================
    @Nested
    @DisplayName("Context Capture in Parameter Usages")
    class ContextCaptureTest {

        @Test
        @DisplayName("Should capture method call context for parameter usages")
        void testMethodCallContext() throws IOException {
            String javaCode = """
                package com.example;

                public class ContextCapture {
                    public void method(Properties props) {
                        String value = props.getProperty("test.param");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ContextCapture.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("test.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
            ParameterUsage usage = usages.get(0);
            assertTrue(usage.context().contains("getProperty"));
            assertTrue(usage.context().contains("test.param"));
        }

        @Test
        @DisplayName("Should capture @Value annotation context")
        void testValueAnnotationContext() throws IOException {
            String javaCode = """
                package com.example;

                import org.springframework.beans.factory.annotation.Value;

                public class ValueContext {
                    @Value("${app.name:MyApp}")
                    private String appName;
                }
                """;

            Path javaFile = tempDir.resolve("ValueContext.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("app.name");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
            ParameterUsage usage = usages.get(0);
            assertTrue(usage.context().contains("@Value"));
            assertTrue(usage.context().contains("app.name"));
        }
    }

    // ========================================================================
    // SECTION 25: FILE NAME TRACKING
    // ========================================================================
    @Nested
    @DisplayName("File Name Tracking")
    class FileNameTrackingTest {

        @Test
        @DisplayName("Should track correct file name for constants")
        void testConstantFileName() throws IOException {
            String javaCode = """
                package com.example;

                public class MyClass {
                    public static final String CONST = "test";
                }
                """;

            Path javaFile = tempDir.resolve("MyClass.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            assertEquals(1, constants.size());
            assertTrue(constants.get(0).fileName().endsWith("MyClass.java"));
        }

        @Test
        @DisplayName("Should track correct file name for parameter usages")
        void testParameterUsageFileName() throws IOException {
            String javaCode = """
                package com.example;

                public class ConfigReader {
                    public void read(Properties props) {
                        String value = props.getProperty("test.param");
                    }
                }
                """;

            Path javaFile = tempDir.resolve("ConfigReader.java");
            Files.writeString(javaFile, javaCode);

            Set<String> knownParams = Set.of("test.param");
            List<ParameterUsage> usages = parser.parseParameterUsages(javaFile, knownParams);

            assertEquals(1, usages.size());
            assertTrue(usages.get(0).usedInFile().endsWith("ConfigReader.java"));
        }
    }

    // ========================================================================
    // SECTION 26: REUSABILITY OF PARSER INSTANCE
    // ========================================================================
    @Nested
    @DisplayName("Parser Instance Reusability")
    class ParserReusabilityTest {

        @Test
        @DisplayName("Should reuse parser instance for multiple files")
        void testParserReuse() throws IOException {
            String javaCode1 = """
                package com.example;
                public class Class1 {
                    public static final String CONST1 = "const1";
                }
                """;

            String javaCode2 = """
                package com.example;
                public class Class2 {
                    public static final String CONST2 = "const2";
                }
                """;

            String javaCode3 = """
                package com.example;
                public class Class3 {
                    public static final String CONST3 = "const3";
                }
                """;

            Path file1 = tempDir.resolve("Class1.java");
            Path file2 = tempDir.resolve("Class2.java");
            Path file3 = tempDir.resolve("Class3.java");

            Files.writeString(file1, javaCode1);
            Files.writeString(file2, javaCode2);
            Files.writeString(file3, javaCode3);

            // Reuse same parser instance
            List<Constant> constants1 = parser.parseConstants(file1);
            List<Constant> constants2 = parser.parseConstants(file2);
            List<Constant> constants3 = parser.parseConstants(file3);

            assertEquals(1, constants1.size());
            assertEquals("CONST1", constants1.get(0).name());

            assertEquals(1, constants2.size());
            assertEquals("CONST2", constants2.get(0).name());

            assertEquals(1, constants3.size());
            assertEquals("CONST3", constants3.get(0).name());
        }
    }

    // ========================================================================
    // SECTION 27: STATIC INITIALIZER BLOCKS (should not be confused with constants)
    // ========================================================================
    @Nested
    @DisplayName("Static Initializer Blocks")
    class StaticInitializerTest {

        @Test
        @DisplayName("Should not confuse static initializers with constants")
        void testStaticInitializer() throws IOException {
            String javaCode = """
                package com.example;

                public class WithStaticInit {
                    public static final String CONST = "const";
                    public static final List<String> LIST;

                    static {
                        LIST = new ArrayList<>();
                        LIST.add("item1");
                        LIST.add("item2");
                        // This is initialization, not a constant declaration
                        String temp = "temporary";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("WithStaticInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Should only find CONST and LIST declarations, not temp
            assertEquals(2, constants.size());
            assertConstantExists(constants, "CONST", "String");
            assertConstantExists(constants, "LIST", "List<String>");
        }
    }

    // ========================================================================
    // SECTION 28: INSTANCE INITIALIZER BLOCKS
    // ========================================================================
    @Nested
    @DisplayName("Instance Initializer Blocks")
    class InstanceInitializerTest {

        @Test
        @DisplayName("Should handle classes with instance initializers")
        void testInstanceInitializer() throws IOException {
            String javaCode = """
                package com.example;

                public class WithInstanceInit {
                    public static final String STATIC_CONST = "static";
                    private final String instanceField;

                    {
                        // Instance initializer
                        instanceField = "initialized";
                    }
                }
                """;

            Path javaFile = tempDir.resolve("WithInstanceInit.java");
            Files.writeString(javaFile, javaCode);

            List<Constant> constants = parser.parseConstants(javaFile);

            // Should only find STATIC_CONST (instanceField is not static)
            assertEquals(1, constants.size());
            assertEquals("STATIC_CONST", constants.get(0).name());
        }
    }

    // ========================================================================
    // HELPER METHODS
    // ========================================================================

    private Constant findConstantByName(List<Constant> constants, String name) {
        return constants.stream()
            .filter(c -> c.name().equals(name))
            .findFirst()
            .orElse(null);
    }

    private void assertConstantExists(List<Constant> constants, String name, String type) {
        Constant constant = findConstantByName(constants, name);
        assertNotNull(constant, "Constant '" + name + "' should exist");
        assertEquals(type, constant.type(), "Constant '" + name + "' should have type '" + type + "'");
    }

    private void assertConstantExists(List<Constant> constants, String name, String type, String value) {
        Constant constant = findConstantByName(constants, name);
        assertNotNull(constant, "Constant '" + name + "' should exist");
        assertEquals(type, constant.type(), "Constant '" + name + "' should have type '" + type + "'");
        assertEquals(value, constant.value(), "Constant '" + name + "' should have value '" + value + "'");
    }
}
