#!/bin/sh
# Ensure the backups and logs directories exist and are writable.
# The volume mount from docker-compose may create them as root,
# so this script runs as root, fixes permissions, then drops to appuser.
mkdir -p /app/backups /app/logs
chown appuser:appgroup /app/backups /app/logs

exec su -s /bin/sh appuser -c "java -jar /app/app.jar $*"
