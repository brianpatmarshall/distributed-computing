/*
 * TypeScript type definitions for the Constants Catalog API.
 * These mirror the DTOs from the backend to ensure type safety.
 */

export interface ScanRequest {
  projectPath: string
}

export interface FileTypeStats {
  propertiesFiles: number
  ymlFiles: number
  xmlFiles: number
  jsonFiles: number
  envFiles: number
  publicStaticFinals: number
}

export interface ScanResponse {
  success: boolean
  message: string
  projectPath?: string
  projectName?: string
  scannedAt?: string
  javaFilesScanned?: number
  propertyFilesScanned?: number
  constantsFound?: number
  parametersFound?: number
  parameterUsagesFound?: number
  fileTypeStats?: FileTypeStats
}

export interface QueryRequest {
  cypher: string
}

export interface QueryResponse {
  success: boolean
  error?: string
  columns?: string[]
  rows?: Record<string, unknown>[]
  rowCount?: number
}

export interface PreCannedQuery {
  id: string
  name: string
  description: string
  category: string
  cypher?: string
}

export interface StatsResponse {
  projectCount: number
  fileCount: number
  constantCount: number
  parameterCount: number
  constantsByType?: { type: string; count: number }[]
  parametersByPrefix?: { name: string; usageCount: number }[]
  topFiles?: { file: string; count: number }[]
}

export interface HealthResponse {
  status: string
  database: string
  projectCount: number
}

export interface FileContentResponse {
  path: string
  fileName: string
  content: string
  lineCount: number
}

/* Scan Progress SSE Types */
export interface ScanProgressEvent {
  eventType: 'FILE_DISCOVERED' | 'FILE_PARSING' | 'FILE_PARSED' | 'SCAN_COMPLETE' | 'ERROR'
  fileName: string
  filePath: string
  fileIndex: number
  totalFiles: number
  constantsFound: number
  parametersFound: number
  timestamp: string
}

/* Transform Types */
export interface TransformRequest {
  projectPath: string
  dryRun: boolean
  candidateScope?: 'CONSTANTS_ONLY' | 'PARAMETERS_ONLY' | 'ALL' | 'REMOVE_UNUSED'
  createBranch?: boolean
  fileFilter?: string
}

export interface TransformEntry {
  filePath: string
  className: string
  constantName: string
  propertyKey: string
  originalValue: string
  originalType: string
  lineNumber: number
  status: string
  message: string
  sourceKind: 'CONSTANT' | 'PARAMETER'
  originalContent?: string
  transformedContent?: string
  backupFilePath?: string
}

export interface TransformResponse {
  success: boolean
  message: string
  projectPath: string
  transformedAt: string
  dryRun: boolean
  totalTransformed: number
  totalSkipped: number
  totalFailed: number
  branchName?: string
  entries: TransformEntry[]
}

export interface FileComparisonResponse {
  filePath: string
  originalContent: string
  transformedContent: string
  changes: string[]
}
